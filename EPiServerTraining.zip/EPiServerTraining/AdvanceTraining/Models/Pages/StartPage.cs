﻿using AdvanceTraining.Business.Validation;
using EPiServer.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdvanceTraining.Models.Pages
{
    public class StartPage : PageData
    {
        [StrongPassword]
        public virtual string Password { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
    }
}