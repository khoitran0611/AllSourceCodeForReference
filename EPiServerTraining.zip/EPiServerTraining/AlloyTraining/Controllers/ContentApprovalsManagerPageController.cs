﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AlloyTraining.Models.Pages;
using EPiServer;
using EPiServer.Approvals;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.Framework.DataAnnotations;
using EPiServer.Shell.Security;
using EPiServer.Web.Mvc;

namespace AlloyTraining.Controllers
{
    public class ContentApprovalsManagerPageController : PageControllerBase<ContentApprovalsManagerPage>
    {
        #region Properties
        private readonly IApprovalDefinitionRepository repoDefinitions;
        //private readonly IContentRepository repoContent;
        private readonly IApprovalRepository repoApprovals;
        private readonly IApprovalEngine engine;
        //private int totalRecords;

        #endregion
        public ContentApprovalsManagerPageController(
            IContentLoader loader,
            IApprovalDefinitionRepository repoDefinitions,
            IApprovalRepository repoApprovals,
            IApprovalEngine engine,
            IContentRepository repoContent,
            UIRoleProvider roles,
            UIUserProvider users,
            IContentSecurityRepository repoSecurity
            ) : base(loader)
        {
            this.repoDefinitions = repoDefinitions;
            this.repoApprovals = repoApprovals;
            this.engine = engine;

            var userList = users.GetAllUsers(pageIndex: 0, pageSize: 30, totalRecords: out int totalRecords);
        }

        public ActionResult Index(ContentApprovalsManagerPage currentPage)
        {               
            /* Implementation of action. You can create your own view model class that you pass to the view or
             * you can pass the page type for simpler templates */

            return View(currentPage);
        }
    }
}