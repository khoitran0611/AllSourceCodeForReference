﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using AlloyTraining.Models.DDS;
using AlloyTraining.Models.Pages;
using AlloyTraining.Models.ViewModels;
using EPiServer;
using EPiServer.Core;
using EPiServer.Framework.DataAnnotations;
using EPiServer.Security;
using EPiServer.Web.Mvc;
using EPiServer.Web.Routing;

namespace AlloyTraining.Controllers
{
    public class FavouritesController : Controller
    {
        private readonly UrlResolver resolver;
        public FavouritesController(UrlResolver resolver)
        {
            this.resolver = resolver;
        }

        public ActionResult Manager(SitePageData currentPage)
        {
            var model = new FavouriteViewModel();
            model.Favourites = FavouriteRepository
            .GetFavorites(PrincipalInfo.Current.Name);
            model.CurrentPageContentReference = currentPage.ContentLink;
            return PartialView("FavoritesManager", model);
        }

        public void Add(ContentReference page)
        {
            var favorite = FavouriteRepository.GetFavorite(
            page, PrincipalInfo.Current.Name);
            if (favorite == null)
            {
                var newFavorite = new Favourite(page, PrincipalInfo.Current.Name);
                FavouriteRepository.Save(newFavorite);
            }

            Response.Redirect(resolver.GetUrl(page));
        }
        public void Delete(ContentReference page, ContentReference fav)
        {
            var favorite = FavouriteRepository.GetFavorite(
            fav, PrincipalInfo.Current.Name);
            if (favorite != null)
            {
                FavouriteRepository.Delete(favorite);
            }
            Response.Redirect(resolver.GetUrl(page));
        }
    }
}