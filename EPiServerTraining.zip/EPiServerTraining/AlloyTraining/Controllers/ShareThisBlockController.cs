﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AlloyTraining.Models.Blocks;
using AlloyTraining.Models.ViewModels;
using EPiServer;
using EPiServer.Core;
using EPiServer.Web;
using EPiServer.Web.Mvc;
using EPiServer.Web.Routing;

namespace AlloyTraining.Controllers
{
    public class ShareThisBlockController : BlockController<ShareThisBlock>
    {
        private readonly UrlResolver resolver;
        private readonly IPageRouteHelper pageRouteHelper;

        public ShareThisBlockController(IPageRouteHelper pageRouteHelper, UrlResolver resolver)
        {
            this.pageRouteHelper = pageRouteHelper;
            this.resolver = resolver;
        }
        public override ActionResult Index(ShareThisBlock currentBlock)
        {
            var pageData = pageRouteHelper.Page;

            var viewModel = new ShareThisBlockViewModel()
            {
                Settings = currentBlock,
                FriendlyUrl = UriSupport.AbsoluteUrlBySettings(resolver.GetUrl(pageData.ContentLink))
            };

            return PartialView(viewModel);
        }
    }
}
