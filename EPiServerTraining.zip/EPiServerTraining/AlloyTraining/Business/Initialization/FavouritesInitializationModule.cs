﻿using System;
using System.Linq;
using System.Web.Routing;
using EPiServer.Framework;
using EPiServer.Framework.Initialization;
using System.Web.Mvc;

namespace AlloyTraining.Business.Initialization
{
    [InitializableModule]
    [ModuleDependency(typeof(EPiServer.Web.InitializationModule))]
    public class FavouritesInitializationModule : IInitializableModule
    {
        public void Initialize(InitializationEngine context)
        {
            //Add initialization logic, this method is called once after CMS has been initialized
            RouteTable.Routes.MapRoute(
                name: "FavouritesAdd",
                url: "favs/add",
                defaults: new { controller = "Favourites", action = "Add" }
            );

            RouteTable.Routes.MapRoute(
                name: "FavouritesDelete",
                url: "favs/del",
                defaults: new { controller = "Favourites", action = "Delete" }
            );
        }

        public void Uninitialize(InitializationEngine context)
        {
            //Add uninitialization logic
        }
    }
}