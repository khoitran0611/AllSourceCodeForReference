﻿using EPiServer;
using EPiServer.Core;
using EPiServer.Filters;
using EPiServer.ServiceLocation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AlloyStartPage = AlloyTraining.Models.Pages.StartPage;

namespace AlloyTraining.Business.ExtensionMethods
{
    public static class StartPageHtmlHelperExtensions
    {
        public static AlloyStartPage GetStartPage(this HtmlHelper htmlHelper)
        {
            var loader = ServiceLocator.Current.GetInstance<IContentLoader>();

            return loader.Get<AlloyStartPage>(ContentReference.StartPage);
        }

        public static IEnumerable<PageData> GetStartPageChidren(this HtmlHelper htmlHelper)
        {
            var loader = ServiceLocator.Current.GetInstance<IContentLoader>();
            var children = loader.GetChildren<PageData>(ContentReference.StartPage);

            return FilterForVisitor.Filter(children).Cast<PageData>().Where(x => x.VisibleInMenu);
        }

    }
}