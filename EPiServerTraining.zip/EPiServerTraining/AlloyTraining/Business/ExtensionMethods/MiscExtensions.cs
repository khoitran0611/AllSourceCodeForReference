﻿using EPiServer;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.ServiceLocation;
using EPiServer.Web;
using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace AlloyTraining.Business.ExtensionMethods
{
    public static class MiscExtensions
    {
        /// <summary>
        /// Truncate strings after n words
        /// </summary>
        /// <param name="input"></param>
        /// <param name="noWords"></param>
        /// <returns></returns>
        public static string TruncateAtWord(this string input, int noWords)
        {
            string output = string.Empty;
            string[] inputArr = input.Split(new[] { ' ' });   if (inputArr.Length <= noWords)
                return input;   if (noWords > 0)
            {
                for (int i = 0; i < noWords; i++)
                {
                    output += inputArr[i] + " ";
                }
                output += "...";
                return output;
            }
            return input;
        }

        //public static string ExternalURLFromReference(this PageReference p)
        //{
        //    var loader = ServiceLocator.Current.GetInstance<IContentLoader>();
        //    PageData page = loader.Get<PageData>(p);

        //    UrlBuilder pageURLBuilder = new UrlBuilder(page.LinkURL);

        //    UrlRewriteProvider.ConvertToExternal(pageURLBuilder, page.PageLink, Encoding.UTF8);

        //    string pageURL = pageURLBuilder.ToString();

        //    UriBuilder uriBuilder = new UriBuilder(EPiServer.Web.SiteDefinition.Current.SiteUrl);

        //    uriBuilder.Path = pageURL;

        //    return uriBuilder.Uri.AbsoluteUri;
        //}

        public static string[] GetThemeCssClassNames(this ICategorizable content)
        {
            if (content.Category == null)
            {
                return new string[0];
            }

            var cssClasses = new HashSet<string>(); // Although with some overhead, a HashSet allows us to ensure we never add a CSS class more than once
            var categoryRepository = ServiceLocator.Current.GetInstance<CategoryRepository>();

            foreach (var categoryName in content.Category.Select(category => categoryRepository.Get(category).Name.ToLower()))
            {
                switch (categoryName)
                {
                    case "meet":
                        cssClasses.Add("theme1");
                        break;
                    case "track":
                        cssClasses.Add("theme2");
                        break;
                    case "plan":
                        cssClasses.Add("theme3");
                        break;
                }
            }

            return cssClasses.ToArray();
        }
    }
}