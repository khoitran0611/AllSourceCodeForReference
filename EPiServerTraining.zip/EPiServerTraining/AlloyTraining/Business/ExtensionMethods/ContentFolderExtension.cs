﻿using EPiServer;
using EPiServer.Core;
using EPiServer.ServiceLocation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining.Business.ExtensionMethods
{
    public static class ContentFolderExtension
    {
        public static int GetItemCounts(this ContentFolder contentFolder)
        {
            using (var cache = new ContentCacheScope{ SlidingExpiration = TimeSpan.Zero })
            {
                var loader = ServiceLocator.Current.GetInstance<IContentLoader>();

                return loader.GetChildren<IContent>(contentFolder.ContentLink).Count();
            }                        
        }
    }
}