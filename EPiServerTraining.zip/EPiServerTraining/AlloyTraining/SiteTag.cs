﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining
{
    public class SiteTag
    {
        public  const string full = "Full";
        public  const string wide = "Wide";
        public  const string narrow = "Narrow";
    }
}