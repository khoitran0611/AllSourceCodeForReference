﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining
{
    public  static class SiteGroupNames
    {
        public const string Specialized = "Specialized";
        public const string Common = "Common";
        public const string News = "News";
    }
}