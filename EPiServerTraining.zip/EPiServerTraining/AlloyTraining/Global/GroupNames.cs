﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining.Global
{
    public class GroupNames
    {
        public const string Specialized = "Specialized";
    }
}