﻿using System;
using System.ComponentModel.DataAnnotations;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using EPiServer.SpecializedProperties;
using static AlloyTraining.SiteContentIcons;

namespace AlloyTraining.Models.Pages
{
    [ContentType(DisplayName = "Content Approvals Manager", 
        GUID = "c02fbcc1-9a6b-4f03-8f9e-dd6954624090", 
        Description = "Content Approvals Manager workflow")]
    [SitePageIcon]
    [AvailableContentTypes(IncludeOn = new[] { typeof(StartPage)})]
    public class ContentApprovalsManagerPage : SitePageData
    {

        //[CultureSpecific]
        //[Display(
        //    Name = "Main body",
        //    Description = "The main body will be shown in the main content area of the page, using the XHTML-editor you can insert for example text, images and tables.",
        //    GroupName = SystemTabNames.Content,
        //    Order = 1)]
        //public virtual XhtmlString MainBody { get; set; }

    }
}