﻿using System;
using System.ComponentModel.DataAnnotations;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using EPiServer.SpecializedProperties;
using System.Security.Claims;

namespace AlloyTraining.Models.Pages
{
    [ContentType(DisplayName = "Security",
        GUID = "aa396818-a56a-427f-b4fd-c2523433dfbf",
        Description = "Use this page type to see security info of system and current user")]
    [AvailableContentTypes(IncludeOn = new[] { typeof(StartPage) })]
    public class SecurityPage : SitePageData
    {
        /*
                [CultureSpecific]
                [Display(
                    Name = "Main body",
                    Description = "The main body will be shown in the main content area of the page, using the XHTML-editor you can insert for example text, images and tables.",
                    GroupName = SystemTabNames.Content,
                    Order = 1)]
                public virtual XhtmlString MainBody { get; set; }
         */
        [Ignore]
        public virtual User SecurityUser { get; set; }
        [Ignore]
        public virtual System SecuritySystem { get; set; }

        public class User
        {
            public string Name { get; set; }
            public bool IsAnonymous { get; set; }
            public bool IsAdministrator { get; set; }
            public bool IsEditor { get; set; }
            public bool HasAccessToPlugins { get; set; }
            public Claim[] Claims { get; set; }
            public string[] Roles { get; set; }
        }
        public class System
        {

            public string Provider { get; set; }
            public string[] VirtualRoles { get; set; }
            public string[] StoredRoles { get; set; }
        }
    }
}