﻿using AlloyTraining;
using AlloyTraining.Global;
using AlloyTraining.Models.Pages;
using EPiServer.DataAnnotations;
using static AlloyTraining.SiteContentIcons;

namespace AlloyTraining.Models.Pages
{
    [ContentType(DisplayName = "Send Notification", 
     GroupName = GroupNames.Specialized,
     GUID = "930d3fb0-946c-45c3-8453-6d8ab03760b2", 
     Description = "Use to send a notification to another Episerver user.")]
    [SiteImageUrl]
    [AvailableContentTypes(IncludeOn = new[] { typeof(StartPage) })]
    public class SendNotificationPage : SitePageData
    {
    }
}