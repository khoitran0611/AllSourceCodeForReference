﻿using System;
using System.ComponentModel.DataAnnotations;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using EPiServer.SpecializedProperties;
using EPiServer.Web;
using static AlloyTraining.SiteContentIcons;

namespace AlloyTraining.Models.Pages
{
    [ContentType(DisplayName = "Product", 
        GUID = "902af7e6-4060-4e0b-8f62-fc975380df69", 
        Order = 20,
        GroupName = SiteGroupNames.Specialized,
        Description = "Use this for software product that Alloy sells")]
    [SiteCommerceIcon]
    public class ProductPage : StandardPage
    {

        [CultureSpecific]
        [Display(
            Name = "Unique Selling Point",
            Description = "The main body will be shown in the main content area of the page, using the XHTML-editor you can insert for example text, images and tables.",
            GroupName = SystemTabNames.Content,
            Order = 320)]
        [Required]
        [UIHint(UIHint.Textarea)]
        public virtual string UniqueSellingPoints { get; set; }

        [CultureSpecific]
        [Display(
            Name = "Main Content Area",
            Description = "Drag and drop block and pages with partial pages with ",
            GroupName = SystemTabNames.Content,
            Order = 330)]
        public virtual ContentArea MainContentArea { get; set; }

        [CultureSpecific]
        [Display(
            Name = "Related Content Area",
            Description = "Drag and drop block and pages with partial pages with ",
            GroupName = SystemTabNames.Content,
            Order = 340)]
        public virtual ContentArea RelatedContentArea { get; set; }
    }
}