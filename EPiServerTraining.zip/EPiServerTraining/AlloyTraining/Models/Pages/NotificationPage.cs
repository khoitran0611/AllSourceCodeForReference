﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using AlloyTraining.Global;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using EPiServer.Notification;
using EPiServer.SpecializedProperties;
using static AlloyTraining.SiteContentIcons;

namespace AlloyTraining.Models.Pages
{    
    [ContentType(DisplayName = "Notifications",
     GroupName = GroupNames.Specialized,
     Description = "Use to manage user notifications.")]
    [SiteImageUrl]
    [AvailableContentTypes(IncludeOn = new[] { typeof(StartPage) })]
    public class NotificationsPage : SitePageData
    {
        [Ignore]
        public virtual Dictionary<string, PagedUserNotificationMessageResult> Notifications { get; set; }
    }
}