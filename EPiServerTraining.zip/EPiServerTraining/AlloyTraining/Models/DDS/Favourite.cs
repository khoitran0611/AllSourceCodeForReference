﻿using EPiServer.Core;
using EPiServer.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining.Models.DDS
{
    public class Favourite
    {
        #region Ctors
        public Favourite()
        {
            this.UserName = string.Empty;
            this.Id = Identity.NewIdentity(Guid.NewGuid());
            this.FavouriteContentReference = ContentReference.EmptyReference;
        }

        public Favourite(ContentReference contentReferenceToAdd, string userName) : base()
        {
            this.FavouriteContentReference = contentReferenceToAdd;
            this.UserName = userName;
        }
        #endregion

        public Identity Id { get; set; }
        public string UserName { get; set; }
        public ContentReference FavouriteContentReference { get; set; }
    }
}