﻿using EPiServer.Core;
using EPiServer.Data.Dynamic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining.Models.DDS
{
    public class FavouriteRepository
    {
        private static DynamicDataStore store
        {
            get
            {
                // creates or gets reference to the store named Favorites
                return DynamicDataStoreFactory.Instance
                    .CreateStore("Favorites", typeof(Favourite));
            }
        }

        public static void Save(Favourite fav)
        {
            if (string.IsNullOrWhiteSpace(fav.UserName))
            {
                throw new NullReferenceException(
                    "Unable to add favorite without user name");
            }
            store.Save(fav);
        }

        public static List<Favourite> GetFavorites(string userName)
        {
            return store.Items<Favourite>()
                .Where(fav => fav.UserName == userName)
                .ToList();
        }

        public static Favourite GetFavorite(
            ContentReference contentReference, string userName)
        {
            return store.Items<Favourite>()
                .Where(fav => (fav.UserName == userName) &&
                    (fav.FavouriteContentReference == contentReference))
                .FirstOrDefault();
        }

        public static void Delete(Favourite fav)
        {
            store.Delete(fav.Id);
        }
    }
}