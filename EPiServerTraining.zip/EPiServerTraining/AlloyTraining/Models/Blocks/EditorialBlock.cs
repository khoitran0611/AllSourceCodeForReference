﻿using System;
using System.ComponentModel.DataAnnotations;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using static AlloyTraining.SiteContentIcons;

namespace AlloyTraining.Models.Blocks
{
    [ContentType(DisplayName = "EditorialBlock", 
        GUID = "e0f27351-d314-4757-abaf-6d76b9a69604", 
        Description = "Editorial block")]
    [SiteBlockIcon]
    public class EditorialBlock : BlockData
    {

        [CultureSpecific]
        [Display(
            Name = "Main Body",
            Description = "The main body will be shown in the main content area of the page, using the XHTML-editor you can insert for example text, images and tables.",
            GroupName = SystemTabNames.Content,
            Order = 10)]
        public virtual XhtmlString MainBody { get; set; }

    }
}