﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Security.Policy;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using EPiServer.Shell.ObjectEditing;
using EPiServer.Web;
using EPiServer;

namespace AlloyTraining.Models.Blocks
{
    [ContentType(DisplayName = "SiteLogotypeBlock", GUID = "d77ebd1c-80b9-43c9-bd04-2b3193e1ab2b", Description = "")]
    public class SiteLogotypeBlock : BlockData
    {
        /// <summary>
        /// Gets the site logotype URL
        /// </summary>
        /// <remarks>If not specified a default logotype will be used</remarks>
        [DefaultDragAndDropTarget]
        [UIHint(UIHint.Image)]
        public virtual EPiServer.Url Url
        {
            get
            {
                var url = this.GetPropertyValue(b => b.Url);

                return url == null || url.IsEmpty()
                            ? new EPiServer.Url("/Static/gfx/logotype.png")
                            : url;
            }
            set
            {
                this.SetPropertyValue(b => b.Url, value);
            }
        }

        [CultureSpecific]
        public virtual string Title { get; set; }
    }
}