﻿using System;
using System.ComponentModel.DataAnnotations;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using EPiServer.Web;

namespace AlloyTraining.Models.Blocks
{
    [ContentType(DisplayName = "PersonBlock", GUID = "0057da58-4317-4f54-982b-7387aba0af28", Description = "")]
    public class PersonBlock : BlockData
    {

        [CultureSpecific]
        [Display(
            Name = "First Name",
            Description = "First Name of the Person",
            GroupName = SystemTabNames.Content,
            Order = 101)]
        public virtual string FirstName { get; set; }

        [CultureSpecific]
        [Display(
            Name = "Last Name",
            Description = "Last Name of the Person",
            GroupName = SystemTabNames.Content,
            Order = 102)]
        public virtual string LastName { get; set; }


        [CultureSpecific]
        [Display(
            Name = "BirthDate",
            Description = "The person's birth day",
            GroupName = SystemTabNames.Content,
            Order = 103)]
        public virtual DateTime BirthDate { get; set; }



        [CultureSpecific]
        [Display(
            Name = "Summary",
            Description = "Add some summary info about the person",
            GroupName = SystemTabNames.Content,
            Order = 104)]
        [UIHint(UIHint.Textarea)]
        public virtual string Summary { get; set; }



    }
}