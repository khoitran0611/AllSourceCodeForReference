﻿using System;
using System.ComponentModel.DataAnnotations;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using static AlloyTraining.SiteContentIcons;

namespace AlloyTraining.Models.Blocks
{
    [ContentType(DisplayName = "Share This Block",
        GUID = "1548f185-2345-4c8a-91b3-79f7f834b2cd",
        Description = "Use this block to share a link to a page")]
    [SiteBlockIcon]
    public class ShareThisBlock : BlockData
    {
        [Display(
        Name = "Display Facebook share",
        GroupName = SystemTabNames.Content,
        Order = 100)]
        public virtual bool ShareToFacebook { get; set; }
        [Display(
        Name = "Display Twitter share",
        GroupName = SystemTabNames.Content,
        Order = 200)]
        public virtual bool ShareToTwitter { get; set; }
        [Display(
        Name = "Display LinkedIn share",
        GroupName = SystemTabNames.Content,
        Order = 300)]
        public virtual bool ShareToLinkedin { get; set; }
        public override void SetDefaultValues(ContentType contentType)
        {
            base.SetDefaultValues(contentType);
            ShareToFacebook = true;
            ShareToTwitter = true;
            ShareToLinkedin = true;
        }
    }
}