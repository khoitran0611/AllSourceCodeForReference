﻿using System;
using System.ComponentModel.DataAnnotations;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;

namespace AlloyTraining.Models.Blocks
{
    [ContentType(DisplayName = "EventBlock", GUID = "deaccdd8-a4e4-4974-bd71-c6642eb94a55", Description = "")]
    public class EventBlock : BlockData
    {

        [CultureSpecific]
        [Display(
            Name = "Event title",
            Description = "Add some extra comment",
            GroupName = SystemTabNames.Content,
            Order = 100)]
        public virtual string Title { get; set; }

        [CultureSpecific]
        [Display(
            Name = "When",
            Description = "Add description to let you know when the event will occur",
            GroupName = SystemTabNames.Content,
            Order = 200)]
        public virtual DateTime When { get; set; }

        [CultureSpecific]
        [Display(
            Name = "Where",
            Description = "Where the event will happen",
            GroupName = SystemTabNames.Content,
            Order = 300)]
        public virtual string Where { get; set; }

        [CultureSpecific]
        [Display(
            Name = "Description",
            Description = "Add some descr",
            GroupName = SystemTabNames.Content,
            Order = 400)]
        public virtual string Description { get; set; }

    }
}