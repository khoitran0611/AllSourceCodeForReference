﻿using System;
using System.ComponentModel.DataAnnotations;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using EPiServer.Framework.Blobs;
using EPiServer.Framework.DataAnnotations;

namespace AlloyTraining.Models.Media
{
    [ContentType(DisplayName = "Svg", GUID = "9cc55ef1-2799-491b-b1b6-2df803fb5141", Description = "Svg")]
    [MediaDescriptor(ExtensionString = "svg")]
    public class Svg : MediaData
    {

        [CultureSpecific]
        [Editable(true)]
        [Display(
            Name = "Thumbnail",
            Description = "Generate a thumbnail for image",
            GroupName = SystemTabNames.Content,
            Order = 1)]
        public virtual Blob Blob
        {
            get
            {
                return base.Thumbnail;
            }

        }

    }
}