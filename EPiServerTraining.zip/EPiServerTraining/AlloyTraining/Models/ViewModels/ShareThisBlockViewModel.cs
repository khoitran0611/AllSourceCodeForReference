﻿using AlloyTraining.Models.Blocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining.Models.ViewModels
{
    public class ShareThisBlockViewModel
    {
        public ShareThisBlock Settings { get; set; }
        public string FriendlyUrl { get; set; }
    }
}