﻿using AlloyTraining.Models.Pages;
using EPiServer.Approvals.ContentApprovals;
using EPiServer.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining.Models.ViewModels
{
    public class ContentApprovalsManagerPageViewModel : DefaultPageViewModel<ContentApprovalsManagerPage>
    {
        public ContentApprovalsManagerPageViewModel(ContentApprovalsManagerPage currentPage) : base(currentPage)
        { } 
        
        public ContentApprovalDefinition ApprovalDefinition { get; set; }
        public ContentApproval Approval { get; set; }        
    }
}