﻿using AlloyTraining.Models.Blocks;
using AlloyTraining.Models.Pages;
using EPiServer.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining.Models.ViewModels
{
    public class CommentsPageViewModel : IPageViewModel<SitePageData>
    {
        public CommentsPageViewModel(SitePageData currentPage)
        {
            this.CurrentPage = currentPage;
        }
        public SitePageData CurrentPage { get; }
        public IContent Section { get; }
        public LayoutModel LayoutModel { get; set; }
        public bool CurrentUserCanAddComments { get; set; }
        public bool ThisPageHasAtLeastOneComment { get; set; }
        public bool StartPageHasCommentsFolder { get; set; }
        public IEnumerable<CommentBlock> Comments { get; set; }
    }
}