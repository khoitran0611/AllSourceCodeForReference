﻿using AlloyTraining.Models.Blocks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining.Models.ViewModels
{
    public class EventBlockViewModel
    {
        public EventBlock EventBlock { get; set; }
    }
}