﻿using AlloyTraining.Models.DDS;
using EPiServer.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AlloyTraining.Models.ViewModels
{
    public class FavouriteViewModel
    {
        public IEnumerable<Favourite> Favourites { get; set; }
        public ContentReference CurrentPageContentReference { get; set; }
    }
}