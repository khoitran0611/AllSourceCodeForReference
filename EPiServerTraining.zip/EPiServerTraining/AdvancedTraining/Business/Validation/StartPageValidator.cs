﻿using AdvanceTraining.Models.Pages;
using EPiServer.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdvancedTraining.Business.Validation
{
    public class StartPageValidator : IValidate<StartPage>
    {
        public IEnumerable<ValidationError> Validate(StartPage instance)
        {
            var errors = new List<ValidationError>();

            if (instance.StartDate >= instance.EndDate)
            {
                errors.Add(new ValidationError()
                {
                    ErrorMessage = "Start date can't be greater than End Date",
                    PropertyName = "Start Date",
                    RelatedProperties = new [] {"EndDate"},
                    Severity = ValidationErrorSeverity.Error,
                    ValidationType = ValidationErrorType.AttributeMatched
                });
            }

            if (instance.Name.ToLower().Contains("frak"))
            {
                errors.Add(new ValidationError()
                {
                    ErrorMessage = "Name can't contain bad words",
                    PropertyName = "Name",
                    RelatedProperties = new[] { "Name" },
                    Severity = ValidationErrorSeverity.Error,
                    ValidationType = ValidationErrorType.AttributeMatched
                });
            }
            return errors;
        }
    }
}