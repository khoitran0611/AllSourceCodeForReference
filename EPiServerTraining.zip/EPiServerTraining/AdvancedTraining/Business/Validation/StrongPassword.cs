﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;

namespace AdvanceTraining.Business.Validation
{
    public class StrongPassword : ValidationAttribute
    {
        public string SpecialCharacters { get; set; } = "!@#$%";
        public int MinimumTotalCharacters { get; set; } = 8;
        public int MinimumUpperCaseCharacters { get; set; } = 1;
        public int MinimumLowerCaseCharacters { get; set; } = 1;
        public int MinimumDigitCharaters { get; set; } = 1;
        public int MinimumSpecialCharacters { get; set; } = 1;

        public override bool IsValid(object value)
        {
            ErrorMessage = $"Password must have: {MinimumDigitCharaters} digits, {MinimumSpecialCharacters} special characters, " +
                $"{ MinimumUpperCaseCharacters} upper case, " +
                $"{MinimumLowerCaseCharacters} lower case, " +
                $"and { MinimumTotalCharacters} total length.";

            var builder = new StringBuilder();

            builder.Append("^");

            if (MinimumUpperCaseCharacters > 0)
            {
                builder.Append("(?=");
                for (int i = 0; i < MinimumUpperCaseCharacters; i++)
                {
                    builder.Append(".*[A-Z]");
                }

                builder.Append(")");
            }

            if (MinimumLowerCaseCharacters > 0)
            {
                builder.Append("(?=");
                for (int i = 0; i < MinimumUpperCaseCharacters; i++)
                {
                    builder.Append(".*[a-z]");
                }

                builder.Append(")");
            }

            if (MinimumSpecialCharacters > 0)
            {
                builder.Append("(?=");
                for (int i = 0; i < MinimumSpecialCharacters; i++)
                {
                    builder.Append(".*[");
                    builder.Append(SpecialCharacters);
                    builder.Append("]");
                }

                builder.Append(")");
            }

            if (MinimumDigitCharaters > 0)
            {
                builder.Append("(?=");
                for (int i = 0; i < MinimumDigitCharaters; i++)
                {
                    builder.Append(".*[0-9]");
                }

                builder.Append(")");
            }

            if (MinimumTotalCharacters > 0)
            {
                builder.Append(".{");
                builder.Append(MinimumTotalCharacters);
                builder.Append(",}");
            }

            builder.Append("$");


            return Regex.IsMatch((string)value, builder.ToString());
        }
    }
}