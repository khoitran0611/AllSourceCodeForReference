﻿using AdvanceTraining.Business.Validation;
using EPiServer.Core;
using EPiServer.DataAbstraction;
using EPiServer.DataAnnotations;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace AdvanceTraining.Models.Pages
{
    [ContentType(DisplayName = "Start", 
        GUID = "2ff57961-e178-4ab1-bcc5-3595b62911fe",
        Description = "The home page for a website with an area for blocks and partial pages")]    
    public class StartPage : PageData
    {
        [StrongPassword(MinimumDigitCharaters = 3, MinimumTotalCharacters = 8, MinimumSpecialCharacters = 1)]
        [CultureSpecific]
        [Display(Name = "Password",
            Description = "Password desc",
            GroupName = SystemTabNames.Content,
            Order = 10)]
        public virtual string Password { get; set; }
        [CultureSpecific]
        [Display(Name = "Start Date",
            Description = "Start Date desc",
            GroupName = SystemTabNames.Content,
            Order = 20)]
        public virtual DateTime StartDate { get; set; }

        [CultureSpecific]
        [Display(Name = "End Date",
            Description = "End Date desc",
            GroupName = SystemTabNames.Content,
            Order = 30)]
        public virtual DateTime EndDate { get; set; }

        [CultureSpecific]
        [Display(Name = "Config data",
            Description = "Config data desc",
            GroupName = "Config Tab",
            Order = 40)]
        public virtual string ConfigInfo { get; set; }
    }
}