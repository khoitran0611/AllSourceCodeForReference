﻿(function () {
    'use strict';
    angular.module("app").controller('emNewCtrl', EmNewCtrl);
    EmNewCtrl.$inject = [
        'emNewSvc', 'datetimeSvc', 'validationSvc', 'messageHandleSvc', 'permissionSvc', 'authenticationSvc', 'historyPageSvc',
        '$filter', '$state', '$stateParams', '$scope', '$timeout', '$window',
        'message', 'constants', 'uploadFileSvc', 'comparisonUtilSvc'
    ];
    function EmNewCtrl(emNewSvc, datetimeSvc, validationSvc, messageHandleSvc, permissionSvc, authenticationSvc, historyPageSvc,
            $filter, $state, $stateParams, $scope, $timeout, $window,
            message, constants, uploadFileSvc, comparisonUtilSvc) {
        /* jshint -W040 */
        var self = this;
        var candidateId = $state.params.candidateId;
        var jobApplicationId = $state.params.jobApplicationId;

        self.permissionOfCurrentUser = {
            addEmployee: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employees_AddEmployee),
            viewEmployee: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_ViewEmployeeInfo)
        };
        if (!self.permissionOfCurrentUser.addEmployee) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.avatarPath = "/Content/app/images/applicants-image-placeholder.png";
        self.displayName = "Create_Employee";
        self.id = $stateParams.candidateId;
        self.employee = {};

        self.isBirthdayValid = true;
        self.fileType = "CandidateFile";
        self.positions = [];
        self.birthdayWarning = "Age_Greater";

        self.selectPosition = selectPosition;
        self.selectStatus = selectStatus;
        self.selectGender = selectGender;
        self.onKeyDownProbationPeriod = onKeyDownProbationPeriod;
        self.saveEmployeeBasicInfo = saveEmployeeBasicInfo;
        self.cancelEmployeeBasicInfo = cancelEmployeeBasicInfo;
        self.birthdayChanged = birthdayChanged;
        self.uploadImage = uploadImage;
        self.checkFullNameValid = checkFullNameValid;

        init();

        function init() {
            $('.dateOfBirth').datepicker({
                autoclose: true, todayHighlight: true
            });
            if (self.Birthday && !comparisonUtilSvc.isNullOrUndefinedValue(self.Birthday) && self.Birthday !== '') {
                $('.dateOfBirth').datepicker('setDateOfBirth', self.Birthday);
            }
            self.genders = translateGender();
            var flag = true;
            self.statuses = constants.workingStatus;
            setDelay(true);
            emNewSvc.positions().query(function (data) {
                self.positions = data;
                var defaultPositionId = (self.positions.length > 0) ? self.positions[0].PstId : 0;
                if (flag) flag = false;
                else setDelay(false);
                self.Birthday = getCurrentDate();
                $timeout(function () {
                    $('.dateOfBirth').datepicker('setDate', self.Birthday);
                }, 0);

                if (!$stateParams.candidateId) {
                    self.employee = {
                        Gender: self.genders[0].Code,
                        PositionId: defaultPositionId,
                        Status: self.statuses[0].Name
                    };
                    setDelay(false);
                    selectGender();
                    selectPosition();
                }
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));

            });
            if ($stateParams.candidateId) {
                setDelay(true);
                self.isBirthdayValid = true;
                emNewSvc.candidate().get({ id: $stateParams.candidateId, jobApplicationId: jobApplicationId }, function (data) {
                    self.employee = data.CandidateBasicInfo;
                    self.employee.Status = self.statuses[0].Name;
                    selectPosition();
                    selectGender();
                    self.Birthday = (self.employee.Birthday) ? moment(self.employee.Birthday).format(constants.formatDateDDMMYYYY) : "";
                    if (flag) flag = false;
                    else setDelay(false);
                });
            }
            return;

            function translateGender() {
                var genderList = [];
                for (var index = 0; index < constants.genders.length; index++) {
                    genderList.push({ Code: constants.genders[index].Code, Name: $filter(constants.translate)(constants.genders[index].Name) });
                }
                return genderList;
            }

            function setDelay(isDelay) {
                if (isDelay) {
                    $(constants.loadingIcon.overlay).show();
                    $(constants.loadingIcon.indicator).show();
                    return;
                }
                $(constants.loadingIcon.overlay).hide();
                $(constants.loadingIcon.indicator).hide();
            }

            function getCurrentDate() {
                var currentDate = new Date();
                var date = parseInt(currentDate.getDate(), 10);
                var month = parseInt(currentDate.getMonth(), 10);
                var minAge = 20;
                var year = parseInt(currentDate.getFullYear(), 10) - minAge;
                date = (date < 10) ? '0' + date : date;
                month = (month < 10) ? '0' + month : month;
                return date + '-' + month + '-' + year;
            }
        }

        function selectPosition() {
            self.position = $filter('filter')(self.positions, { PstId: self.employee.PositionId });
            if (!self.position || self.position.length === 0) {
                self.employee.PositionId = "";
                self.positionName = "";
                return;
            }
            self.employee.PositionId = self.position[0].PstId;
            self.positionName = self.position[0].PstName;
        }

        function selectStatus() {
            self.status = $filter('filter')(self.statuses, { Name: self.employee.Status });
            self.employee.Status = self.status[0].Name;
        }

        function selectGender() {
            self.gender = $filter('filter')(self.genders, { Code: self.employee.Gender });
            self.employee.Gender = self.gender[0].Code;
            self.genderName = self.gender[0].Name;
        }

        function onKeyDownProbationPeriod(event) {
            validationSvc.onKeyDownTextBox(event);
        }

        function saveEmployeeBasicInfo() {
            if (!checkDateOfBirth()) return;

            self.employee.FullName = (self.employee.FirstName + " " + self.employee.LastName);
            var fileUpload = document.getElementById("EmployeeImage").value;
            if (fileUpload !== '') {
                var employeeImage = $('#EmployeeImage')[0].files[0];
                uploadFileSvc.uploadEmployeeImage(employeeImage, 'EmployeeImage', self.employee.FullName).$promise.then(function (data) {
                    if (data.value.length > 0) {
                        self.employee.Photograph = data.value;
                        self.avatarPath = constants.serverUrl + data.value;
                        saveCurrentEmployee();
                    }
                });
            } else {
                saveCurrentEmployee();
            }
            return;

            function saveCurrentEmployee() {
                self.employee.JobApplicationId = $state.params.jobApplicationId;
                self.employee.CandidateId = $state.params.candidateId;
                self.employee.Birthday = (self.Birthday) ? datetimeSvc.convertDateForServerSide(self.Birthday, false) : "";
                emNewSvc.employee().save(self.employee, function (data) {
                    var employeeId = "";
                    if (data) {
                        angular.forEach(data, function (value) {
                            if (!isNaN(value) && typeof (value) == "string") {
                                employeeId += value;
                            }
                        });
                    }
                    toastr.success($filter(constants.translate)("Add_New_Employee_Successful"));
                    $state.go('employeeDetail', { id: employeeId });
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, message.errorInSaveData);
                });
            }
        }

        function cancelEmployeeBasicInfo() {
            if (candidateId && jobApplicationId) {
                goBackInterviewsTab();
            } else {
                $state.go('employees');
            }
            return;

            function goBackInterviewsTab() {
                var url = window.location.href;
                var previousUrl = historyPageSvc.getPreviousUrl(url);
                if (previousUrl && previousUrl.indexOf("/#/candidates/") == -1) {
                    historyPageSvc.setPreviousUrl(url, "");
                    window.location.href = previousUrl;
                    return;
                }
                historyPageSvc.setPreviousUrl(url, "");
                $state.go('candidateDetail', { id: candidateId }).then(clearOverlay);
            }

            function clearOverlay() {
                $(constants.loadingIcon.overlay).hide();
                $(constants.loadingIcon.indicator).hide();
                $('.modal-backdrop').remove();
            }
        }

        function birthdayChanged() {
            checkDateOfBirth();
        }

        function checkDateOfBirth() {
            self.birthdayWarning = "";
            self.isBirthdayValid = true;
            if (comparisonUtilSvc.isNullOrUndefinedValue(self.Birthday) || self.Birthday === '') {
                self.isBirthdayValid = true;
                return true;
            }
            var dateOfBirth = self.Birthday.split('-');
            if (isNaN(dateOfBirth[2]) || isNaN(dateOfBirth[1]) || isNaN(dateOfBirth[0])) {
                self.birthdayWarning = "Birthday_InValid";
                self.isBirthdayValid = false;
                return false;
            }
            var year = parseInt(dateOfBirth[2], 10);
            var currentDate = new Date();
            var currentYear = currentDate.getFullYear();
            if (currentYear - year < 20) {
                self.birthdayWarning = "Age_Greater";
                self.isBirthdayValid = false;
                return false;
            }
            if (currentYear - year > 100) {
                self.birthdayWarning = "Birthday_InValid";
                self.isBirthdayValid = false;
                return false;
            }
            return true;
        }

        function uploadImage() {
            var fileUpload = document.getElementById("EmployeeImage");
            if (!fileUpload.files[0]) return;
            if (fileUpload.files[0].size > constants.maxFileSizeUploaded) {
                toastr.warning(String.format($filter(constants.translate)("Max_File_Size_Message"), 5));
                var control = $('#EmployeeImage');
                control.replaceWith(control = control.clone(true));
                return;
            }

            var employeeImage = fileUpload.files[0];
            uploadFileSvc.uploadEmployeeImage(employeeImage, 'EmployeeImage', self.employee.FullName).$promise.then(function (data) {
                if (data.value.length > 0) {
                    self.employee.Photograph = data.value;
                    self.avatarPath = avatarPathdata.value;
                    if (!$scope.$$phase && !$scope.$root.$$phase) {
                        $scope.$apply();
                    }
                }
            });
        }

        function checkFullNameValid() {
            return (self.employee.LastName && self.employee.FirstName) ? true : false;
        }
    }
})();