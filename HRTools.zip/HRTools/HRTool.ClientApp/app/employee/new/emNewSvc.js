﻿(function () {
    'use strict';
    angular.module("app").service('emNewSvc', emNewSvc);
    emNewSvc.$inject = ['$resource', 'emConstants', 'constants'];

    function emNewSvc($resource, emConstants, constants) {
            var revealed = {
                employee: employee,
                positions: positions,
                candidate: candidate
            };
            return revealed;

            /************************** EMPLOYEES LIST ***********************************/
            function employee() {
                    return $resource(constants.apiUrl + 'employees?page=:page', {});
            }

            function positions() {
                return $resource(constants.apiUrl + 'positions', { action: 'getAllPositions' });
            }

            function candidate() {
                return $resource(constants.apiUrl + 'appliedpositions/:jobApplicationId/candidates/:id', {});
            }
        }
})();