﻿(function () {
    'use strict';
    angular.module("app").service('emOtherInformationSvc', emOtherInformationSvc);
    emOtherInformationSvc.$inject = ['$resource', 'constants'];

    function emOtherInformationSvc($resource, constants) {
        var service = {
            getOtherInformation: getOtherInformation,
            updateOtherInformation: updateOtherInformation
        };
        return service;

        function getOtherInformation(emId) {
            return $resource(constants.apiUrl + 'employees/:id/otherinformation', { id: emId });
        }

        function updateOtherInformation(emId) {
            return $resource(constants.apiUrl + 'employees/:id/otherinformation/:id', { id: emId }, { update: { method: 'PUT' } });
        }
    }
})();