﻿(function () {
    'use strict';

    angular.module("app").controller('emOtherInformationCtrl', EmOtherInformationCtrl);
    EmOtherInformationCtrl.$inject = ['$state', '$stateParams', '$scope', '$filter', '$timeout',
        'styleSvc', 'messageHandleSvc', 'permissionSvc', 'constants', 'datetimeSvc', 'emOtherInformationSvc', 'emDetailSvc', 'emOtherInformationModel', 'loadingSvc'];

    function EmOtherInformationCtrl($state, $stateParams, $scope, $filter, $timeout,
        styleSvc, messageHandleSvc, permissionSvc, constants, datetimeSvc, otherInfoSvc, emDetailSvc,
        otherInfoModel, loadingSvc) {
        /* jshint -W040 */
        var self = this;
        var oldInfo;

        self.currentUserPermission = {
            update: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_EditEmployeeInfo)
        };
        self.title = $filter(constants.translate)("Other_Information.Title");
        self.isEditMode = false;
        self.isParentEdit = emDetailSvc.getDisplayMode();
        self.isValidDate = true;
        self.isShowMode = true;

        self.getHeaderStyle = getHeaderStyle;
        self.toogleHeader = toogleHeader;
        self.getCssHeaderClass = getCssHeaderClass;
        self.edit = edit;
        self.cancel = cancel;
        self.changeDate = changeDate;
        self.isDisableSave = isDisableSave;
        self.save = save;

        init();

        function init() {
            if (self.currentUserPermission.update) {
                otherInfoSvc.getOtherInformation($stateParams.id).get(
                    function (response) {
                        var info = new otherInfoModel(response);
                        if (info.WorkStartDate || info.WorkEndDate) formatDate(info);
                        self.otherInfo = info;
                        if (!$scope.$$phase && !$scope.$root.$$phase) {
                            $scope.$apply();
                        }
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, "Other_Information.Error_Getting");
                    });
            }

            $scope.$watch('oiCtrl.isParentEdit', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                self.isEditMode = self.isParentEdit.value ? self.isEditMode : false;
                if (!self.isParentEdit.value) self.otherInfo = oldInfo;
                if ($("#other-information-detail-view").css('display') == "none") {
                    self.toogleHeader();
                }
            }, true);
        }

        function formatDate(otherInfo) {
            otherInfo.WorkStartDate = otherInfo.WorkStartDate ? moment(otherInfo.WorkStartDate).format(constants.formatDateDDMMYYYY) : otherInfo.WorkStartDate;
            otherInfo.WorkEndDate = otherInfo.WorkEndDate ? moment(otherInfo.WorkEndDate).format(constants.formatDateDDMMYYYY) : otherInfo.WorkEndDate;
        }

        function getHeaderStyle() {
            return styleSvc.getHeaderStyle(self.isEditMode);
        }

        function toogleHeader() {
            self.isShowMode = !self.isShowMode;
            $("#other-information-detail-view").slideToggle("slow");
        }

        function getCssHeaderClass(){
            return self.isShowMode && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function edit() {
            self.isEditMode = !self.isEditMode;
            oldInfo = new otherInfoModel(self.otherInfo);
            if (self.otherInfo.WorkStartDate === '') self.otherInfo.WorkStartDate = moment(new Date()).format(constants.formatDateDDMMYYYY);
            $('.start-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.end-date').datepicker({ autoclose: true, todayHighlight: true });
            resetCheckbox();
            return;

            function resetCheckbox() {
                self.otherInfo.WorkTeams.forEach(function (team) {
                    team.IsChecked = false;
                });
                self.otherInfo.WorkingTeams.forEach(function (team) {
                    team.IsChecked = true;
                });
                self.editForm.$setPristine();
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            }
        }

        function cancel() {
            self.otherInfo = oldInfo;
            self.isEditMode = false;
        }

        function changeDate() {
            if (!self.otherInfo.WorkStartDate) {
                self.isValidDate = false;
                return;
            }
            if (!self.otherInfo.WorkEndDate) {
                self.isValidDate = true;
                return;
            }
            var startDate = moment(self.otherInfo.WorkStartDate, constants.formatDateDDMMYYYY);
            var endDate = moment(self.otherInfo.WorkEndDate, constants.formatDateDDMMYYYY);
            var diff = endDate.diff(startDate, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function isDisableSave() {
            if (self.editForm.$pristine || !self.isValidDate) return true;
            else return false;
        }

        function save() {
            self.otherInfo.WorkStartDate = datetimeSvc.convertDateForServerSide(self.otherInfo.WorkStartDate, false);
            self.otherInfo.WorkEndDate = self.otherInfo.WorkEndDate ? datetimeSvc.convertDateForServerSide(self.otherInfo.WorkEndDate, false) : '';
            loadingSvc.show();
            otherInfoSvc.updateOtherInformation($stateParams.id).update(self.otherInfo,
                function () {
                    loadingSvc.close();
                    self.isEditMode = false;
                    formatDate(self.otherInfo);
                    updateWorkTeam();
                },
                function (xhr) {
                    loadingSvc.close();
                    reload();
                    messageHandleSvc.handleResponse(xhr, "Other_Information.Error_Updating");
                });
            return;

            function updateWorkTeam() {
                for (var index = 0; index < self.otherInfo.WorkingTeams.length; index++) {
                    if (!self.otherInfo.WorkingTeams[index].IsChecked) {
                        addWorkedTeam(self.otherInfo.WorkingTeams[index], index);
                        index--;
                    }
                }

                for (var k = 0; k < self.otherInfo.WorkTeams.length; k++) {
                    if (self.otherInfo.WorkTeams[k].IsChecked) {
                        addWorkingTeam(self.otherInfo.WorkTeams[k], k);
                        k--;
                    }
                }
                toastr.success($filter(constants.translate)("Other_Information.Successful_Update"));
            }

            function addWorkedTeam(workingTeam, itemIndex) {
                workingTeam.IsChecked = false;
                if (self.otherInfo.WorkedTeams.length === 0) self.otherInfo.WorkedTeams = [];
                if (self.otherInfo.WorkTeams.length === 0) self.otherInfo.WorkTeams = [];
                self.otherInfo.WorkedTeams.push(workingTeam);
                self.otherInfo.WorkTeams.push(workingTeam);
                self.otherInfo.WorkingTeams.splice(itemIndex, 1);
            }

            function addWorkingTeam(workTeam, itemIndex) {
                workTeam.IsChecked = true;
                if (self.otherInfo.WorkingTeams.length === 0) self.otherInfo.WorkingTeams = [];
                self.otherInfo.WorkingTeams.push(workTeam);
                self.otherInfo.WorkTeams.splice(itemIndex, 1);
                removeWorkedTeam(workTeam.WgpId);
            }

            function removeWorkedTeam(workId) {
                for (var index = 0; index < self.otherInfo.WorkedTeams.length; index++) {
                    if (self.otherInfo.WorkedTeams[index].WgpId == workId) {
                        self.otherInfo.WorkedTeams.splice(index, 1);
                    }
                }
            }

            function reload() {
                if (self.currentUserPermission.update) {
                    otherInfoSvc.getOtherInformation($stateParams.id).get(
                    function (response) {
                        var info = new otherInfoModel(response);
                        if (info.WorkStartDate || info.WorkEndDate) formatDate(info);
                        self.otherInfo = info;
                        oldInfo = new otherInfoModel(self.otherInfo);
                        if (!$scope.$$phase && !$scope.$root.$$phase) {
                            $scope.$apply();
                        }
                    },
                    function () {
                        toastr.error($filter(constants.translate)("Other_Information.Error_Getting"));
                    });
                }
            }
        }
    }
})();