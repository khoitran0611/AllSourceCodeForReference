﻿(function () {
    'use strict';
    angular.module("app").factory('emOtherInformationModel', emOtherInformationModel);
    function emOtherInformationModel() {
        var resource = function (otherInfo) {
            /* jshint -W040 */
            var self = this;
            self.EmployeeId = otherInfo.EmployeeId;
            self.WorkStartDate = otherInfo.WorkStartDate || '';
            self.WorkEndDate = otherInfo.WorkEndDate || '';
            self.BankAccount = otherInfo.BankAccount || '';
            self.BankName = otherInfo.BankName || '';
            self.Note = otherInfo.Note || '';
            self.HasInsuranceAccident = otherInfo.HasInsuranceAccident || '';
            self.CreateUser = otherInfo.CreateUser || '';
            self.UpdatedUser = otherInfo.UpdatedUser || '';
            self.WorkedTeams = otherInfo.WorkedTeams || [];
            self.WorkingTeams = otherInfo.WorkingTeams || [];
            self.WorkTeams = otherInfo.WorkTeams || [];
        };
        return resource;
    }
})();

