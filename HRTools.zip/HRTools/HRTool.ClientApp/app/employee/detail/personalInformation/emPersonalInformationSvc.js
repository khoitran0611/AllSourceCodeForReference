﻿(function () {
    'use strict';
    angular.module("app").service('emPersonalInformationSvc', emPersonalInformationSvc);
    emPersonalInformationSvc.$inject = ['$resource', "emConstants", 'constants'];
    function emPersonalInformationSvc($resource, emConstants, constants) {
        var service = {
            getPersonalInformation: getPersonalInformation,
            updatePersonalInformation: updatePersonalInformation,
            checkAccountName: checkAccountName
        };
        return service;

        function getPersonalInformation(emId) {
            return $resource(constants.apiUrl + 'employees/:id/personalinformation', { id: emId });
        }

        function updatePersonalInformation(emId) {
            return $resource(constants.apiUrl + 'employees/:id/personalinformation/:id', { id: emId }, { update: { method: 'PUT' } });
        }

        function checkAccountName(emId, accountName) {
            return $resource(constants.apiUrl + 'employees/:id/personalinformation/checkaccount',
                { id: emId, accountName: accountName }, { update: { method: 'PUT' } });
        }
    }
})();