﻿(function () {
    'use strict';

    angular.module("app").controller('emPersonalInformationCtrl', EmPersonalInformationCtrl);
    EmPersonalInformationCtrl.$inject = ['$state', '$stateParams', '$scope', '$filter',
        'emPersonalInformationSvc', 'messageHandleSvc', 'permissionSvc', 'styleSvc', 'emDetailSvc', 'datetimeSvc',
        'emPersonalInformationModel', 'constants', 'loadingSvc'];

    function EmPersonalInformationCtrl($state, $stateParams, $scope, $filter,
        emPersonalInformationSvc, messageHandleSvc, permissionSvc, styleSvc, emDetailSvc, datetimeSvc,
        emPersonalInformationModel, constants, loadingSvc) {
        /* jshint -W040 */
        var self = this;
        var messages = {
            getInfoError: $filter(constants.translate)("Personal_Information.Error_Getting"),
            errorUpdate: $filter(constants.translate)("Personal_Information.Error_Updating"),
            successUpdate: $filter(constants.translate)("Personal_Information.Successful_Update")
        };
        var oldInfo;

        self.currentUserPermission = {
            update: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_EditEmployeeInfo)
        };
        self.title = $filter(constants.translate)("Personal_Information.Title");
        self.isEditMode = false;
        self.isParentEdit = emDetailSvc.getDisplayMode();
        self.maritalStatusList = [
            { status: $filter(constants.translate)("Personal_Information.Single") },
            { status: $filter(constants.translate)("Personal_Information.Married") }
        ];

        self.toogleHeader = toogleHeader;
        self.edit = edit;
        self.cancel = cancel;
        self.save = save;
        self.isDisableSave = isDisableSave;
        self.getCssHeaderClass = getCssHeaderClass;
        $state.reload = reloadState;
        self.isExistingUserId = false;

        var _currentCompanyId = '';
        var _isShowMode = true;

        init();

        function init() {
            if (self.currentUserPermission.update) {
                emPersonalInformationSvc.getPersonalInformation($stateParams.id).get(
                    function (response) {
                        var info = new emPersonalInformationModel(response);
                        if (info.IdProvidedDate) formatDate(info);
                        self.personalInformation = info;
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, "Personal_Information.Error_Getting");
                    });
            }

            $scope.$watch('piCtrl.isParentEdit', function () {
                self.isEditMode = self.isParentEdit.value ? self.isEditMode : false;
                if (!self.isParentEdit.value) self.personalInformation = oldInfo;
                if ($("#personal-information-detail-view").css('display') == "none") {
                    self.toogleHeader();
                }
            }, true);
        }

        function formatDate(personalInformation) {
            personalInformation.IdProvidedDate = moment(personalInformation.IdProvidedDate).format(constants.formatDateDDMMYYYY);
        }

        function toogleHeader() {
            _isShowMode = !_isShowMode;
            $("#personal-information-detail-view").slideToggle("slow");
        }

        function edit() {
            self.isEditMode = !self.isEditMode;
            self.isExistingUserId = false;
            oldInfo = new emPersonalInformationModel(self.personalInformation);
            _currentCompanyId = self.personalInformation.CompanyId;
            $('.provided-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function cancel() {
            self.personalInformation = oldInfo;
            self.isExistingUserId = false;
            self.isEditMode = false;
        }

        function save() {
            self.isExistingUserId = false;
            emPersonalInformationSvc.checkAccountName($stateParams.id, self.personalInformation.Account)
                .update(self.personalInformation.Account,
                 function (data) {
                    if (data.result === true) {
                        self.isExistingUserId = true;
                        return;
                    }
                    else updatePersonalInfo();
                }, function (error) {
                            loadingSvc.close();
                });
        }

        function updatePersonalInfo() {
            self.personalInformation.CompanyId = _currentCompanyId;
            var model = new emPersonalInformationModel(self.personalInformation);
            model.IdProvidedDate = datetimeSvc.convertDateForServerSide(model.IdProvidedDate, false);
            loadingSvc.show();
            emPersonalInformationSvc.updatePersonalInformation($stateParams.id).update(model,
                function () {
                    loadingSvc.close();
                    self.isEditMode = false;
                    reload();
                    toastr.success($filter(constants.translate)("Personal_Information.Successful_Update"));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, "Personal_Information.Error_Updating");
                });
            return;

            function reload() {
                if (self.currentUserPermission.update) {
                    emPersonalInformationSvc.getPersonalInformation($stateParams.id).get(
                        function (response) {
                            var info = new emPersonalInformationModel(response);
                            if (info.IdProvidedDate) formatDate(info);
                            self.personalInformation = info;
                            oldInfo = new emPersonalInformationModel(self.personalInformation);
                        },
                        function (xhr) {
                            messageHandleSvc.handleResponse(xhr, "Personal_Information.Error_Getting");
                        });
                }
            }
        }

        function isDisableSave() {
            if (self.editForm.$pristine) return true;
            else return false;
        }

        function getCssHeaderClass() {
            return _isShowMode && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function reloadState() {
            $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
        }
    }
})();