﻿(function () {
    "use strict";
    angular.module("app").factory('emPersonalInformationModel', emPersonalInformationModel);
    function emPersonalInformationModel() {
        var resource = function (personalInfo) {
            /* jshint -W040 */
            var self = this;
            self.Account = personalInfo.Account || '';
            self.BirthPlace = personalInfo.BirthPlace || '';
            self.CompanyId = personalInfo.CompanyId || '';
            self.CompanyList = personalInfo.CompanyList || '';
            self.CompanyName = personalInfo.CompanyName || '';
            self.EmployeeId = personalInfo.EmployeeId || '';
            self.FullName = personalInfo.FullName || '';
            self.IdCard = personalInfo.IdCard || '';
            self.IdProvidedDate = personalInfo.IdProvidedDate || '';
            self.IdProvidedPlace = personalInfo.IdProvidedPlace || '';
            self.MaritalStatus = personalInfo.MaritalStatus || '';
            self.OfferLeterSignedName = personalInfo.OfferLeterSignedName || '';
            self.OfferLetterAddSigned = personalInfo.OfferLetterAddSigned || '';
            self.Origin = personalInfo.Origin || '';
            self.PermanentAddress = personalInfo.PermanentAddress || '';
            self.TemporaryAddress = personalInfo.TemporaryAddress || '';
            self.TimeSheetCode = personalInfo.TimeSheetCode || '';
        };
        return resource;
    }
})();