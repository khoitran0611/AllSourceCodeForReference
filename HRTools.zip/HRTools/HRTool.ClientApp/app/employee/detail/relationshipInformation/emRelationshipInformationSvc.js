﻿(function () {
    'use strict';
    angular.module("app").service('emRelationshipInformationSvc', emRelationshipInformationSvc);
    emRelationshipInformationSvc.$inject = ['$resource', 'emConstants', 'constants'];
    function emRelationshipInformationSvc($resource, emConstants, constants) {
        var service = {
            getRelationshipInfo: getRelationshipInfo,
            updateRelationshipInfo: updateRelationshipInfo
        };
        return service;

        function getRelationshipInfo(emId) {
            return $resource(constants.apiUrl + 'employees/:id/relationshipinformation', { id: emId });
        }

        function updateRelationshipInfo(emId) {
            return $resource(constants.apiUrl + 'employees/:id/relationshipinformation/:id', { id: emId }, { update: { method: 'PUT' } });
        }
    }
})();