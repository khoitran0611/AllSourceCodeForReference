﻿(function () {
    "use strict";
    angular.module("app").factory('emRelationshipInformationModel', emRelationshipInformationModel);
    function emRelationshipInformationModel() {
        var resource = function (relationInfo) {
            /* jshint -W040 */
            var self = this;
            self.EmployeeId = relationInfo.EmployeeId || '';
            self.Phone = relationInfo.Phone || '';
            self.Mobile = relationInfo.Mobile || '';
            self.Skype = relationInfo.Skype || '';
            self.PrivateEmail = relationInfo.PrivateEmail || '';
            self.CompanyEmail = relationInfo.CompanyEmail || '';
            self.TaxCode = relationInfo.TaxCode || '';
            self.SocialInsuranceCode = relationInfo.SocialInsuranceCode || '';
            self.SocialInsuranceIssue = relationInfo.SocialInsuranceIssue ? relationInfo.SocialInsuranceIssue : '';
            self.SocialInsurancePlace = relationInfo.SocialInsurancePlace ? relationInfo.SocialInsurancePlace : '';
            self.EmergencyPhone = relationInfo.EmergencyPhone || '';
            self.EmergencyName = relationInfo.EmergencyName || '';
            self.EmergencyContact = relationInfo.EmergencyContact || '';
        };
        return resource;
    }
})();