﻿(function () {
    'use strict';
    angular.module("app").controller('emRelationshipInformationCtrl', EmRelationshipInformationCtrl);
    EmRelationshipInformationCtrl.$inject = ['$state', '$stateParams', '$scope', 'emRelationshipInformationSvc', 'styleSvc', 'messageHandleSvc', 'permissionSvc', 'emRelationshipInformationModel', 'constants', 'datetimeSvc', 'emDetailSvc', 'message', '$filter', 'loadingSvc'];
    function EmRelationshipInformationCtrl($state, $stateParams, $scope, relationInfoSvc, styleSvc, messageHandleSvc, permissionSvc, relationshipInfoModel, constants, datetimeSvc, emDetailSvc, message, $filter, loadingSvc) {
        /* jshint -W040 */
        var self = this;
        var oldInfo;

        self.title = $filter(constants.translate)("Relationship_Information.Title");
        self.isEditMode = false;
        self.isParentEdit = emDetailSvc.getDisplayMode();
        self.currentUserPermission = {
            update: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_EditEmployeeInfo)
        };

        self.toogleHeader = toogleHeader;
        self.edit = edit;
        self.cancel = cancel;
        self.changeDate = changeDate;
        self.isDisableSave = isDisableSave;
        self.save = save;
        self.getCssHeaderClass = getCssHeaderClass;
        $state.reload = reloadState;

        var _isShowMode = true;

        init();

        function init() {
            if (self.currentUserPermission.update) {
                relationInfoSvc.getRelationshipInfo($stateParams.id).get(
                    function (response) {
                        var info = new relationshipInfoModel(response);
                        if (info.SocialInsuranceIssue) formatDate(info);
                        self.relationInfo = info;
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, "Relationship_Information.Error_Getting");
                    });
            }

            $scope.$watch('riCtrl.isParentEdit', function () {
                self.isEditMode = self.isParentEdit.value ? self.isEditMode : false;
                if (!self.isParentEdit.value) self.relationInfo = oldInfo;
                if ($("#relationship-information-detail-view").css('display') == "none") {
                    self.toogleHeader();
                }
            }, true);
        }

        function formatDate(relationInfo) {
            relationInfo.SocialInsuranceIssue = moment(relationInfo.SocialInsuranceIssue).format(constants.formatDateDDMMYYYY);
        }

        function toogleHeader() {
            _isShowMode = !_isShowMode;
            $("#relationship-information-detail-view").slideToggle("slow");
        }

        function edit() {
            self.isEditMode = !self.isEditMode;
            oldInfo = new relationshipInfoModel(self.relationInfo);
            $('.si-issue').datepicker({ autoclose: true, todayHighlight: true });
        }

        function cancel() {
            self.isEditMode = false;
            self.relationInfo = oldInfo;
        }

        function changeDate() {
            formatDate(self.relationInfo);
        }

        function isDisableSave() {
            if (self.editForm.$pristine) return true;
            else return false;
        }

        function save() {
            self.relationInfo.SocialInsuranceIssue = datetimeSvc.convertDateForServerSide(self.relationInfo.SocialInsuranceIssue, false);
            self.relationInfo.Phone = formatPhoneNumber(self.relationInfo.Phone);
            self.relationInfo.Mobile = formatPhoneNumber(self.relationInfo.Mobile);
            self.relationInfo.EmergencyPhone = formatPhoneNumber(self.relationInfo.EmergencyPhone);
            loadingSvc.show();
            relationInfoSvc.updateRelationshipInfo($stateParams.id).update(self.relationInfo,
                function () {
                    loadingSvc.close();
                    self.isEditMode = false;
                    reload();
                    toastr.success($filter(constants.translate)("Relationship_Information.Successful_Update"));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, "Relationship_Information.Error_Updating");
                });
            return;

            function reload() {
                if (self.currentUserPermission.update) {
                    relationInfoSvc.getRelationshipInfo($stateParams.id).get(
                    function (response) {
                        var info = new relationshipInfoModel(response);
                        if (info.SocialInsuranceIssue) formatDate(info);
                        self.relationInfo = info;
                        oldInfo = new relationshipInfoModel(self.relationInfo);
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, "Relationship_Information.Error_Getting");
                    });
                }
            }
        }

        function getCssHeaderClass() {
            return _isShowMode && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function reloadState() {
            $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
        }
    }
})();