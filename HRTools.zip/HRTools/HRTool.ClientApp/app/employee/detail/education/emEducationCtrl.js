﻿(function () {
    "use strict";
    angular.module("app").controller("emEducationCtrl", EmEducationCtrl);
    EmEducationCtrl.$inject = [
        'emDetailSvc', 'datetimeSvc', 'styleSvc', 'messageHandleSvc', 'permissionSvc', 'objectSvc',
        'emEducationModel', 'constants', 'message', 'emMessage', '$stateParams', '$scope',
        '$timeout', '$filter', '$window', 'comparisonUtilSvc', 'loadingSvc', 'countrySvc'];
    function EmEducationCtrl(
        emDetailSvc, datetimeSvc, styleSvc, messageHandleSvc, permissionSvc, objectSvc,
        emEducationModel, constants, message, emMessage, $stateParams, $scope,
        $timeout, $filter, $window, comparisonUtilSvc, loadingSvc, countrySvc) {
        /* jshint -W040 */
        var self = this;
        var param = {};
        var initialEmployeeEducations = [];
        var educations = [];
        var rowEditing;
        var rowIndexDeleting;

        self.isCountryChanged = false;
        self.isSchoolLevelChanged = false;
        self.employeeEducations = [];
        self.schoolLevel = [{ name: '' }, { name: "Secondary School" }, { name: "High School" }, { name: "College" }, { name: "University" }, { name: "Other" }];
        self.countries = [];
        self.isEditMode = emDetailSvc.getDisplayMode();
        param.employeeId = $stateParams.id;
        self.permissionOfCurrentUser = {
            updateCV: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_UpdateCV)),
            addEmployeeInformation: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_EditEmployeeInfo),
            editEmployeeInformation: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_EditEmployeeInfo),
            deleteEmployeeInformation: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_EditEmployeeInfo),
            addEmployee: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employees_AddEmployee),
            viewEmployee: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employees_ViewEmployees),
            updateOwnInfor: JSON.parse($window.localStorage.getItem("currentuserlogin")).UserId == param.employeeId
        };
        self.hasPermission = self.permissionOfCurrentUser.updateCV || self.permissionOfCurrentUser.editEmployeeInformation || self.permissionOfCurrentUser.deleteEmployeeInformation;
        self.isAddingEducation = false;
        self.hasPermissionAddEducation = self.permissionOfCurrentUser.addEmployeeInformation || self.permissionOfCurrentUser.addEmployee || self.permissionOfCurrentUser.updateCV;
        self.isModifiedData = false;
        self.dialogConfirm = emMessage.education.dialogConfirm;
        self.dialogConfirm.dialogTitle = self.dialogConfirm.dialogTitle;
        self.dialogConfirm.dialogMessage = self.dialogConfirm.dialogMessage;
        self.isValidDate = true;

        self.onClickAddEducation = onClickAddEducation;
        self.onClickHeader = onClickHeader;
        self.onClickSaveEducation = onClickSaveEducation;
        self.isEditingRow = isEditingRow;
        self.onClickEditRow = onClickEditRow;
        self.onClickCancelEdit = onClickCancelEdit;
        self.onClickDeleteRow = onClickDeleteRow;
        self.onYes = onYes;
        self.onChangeDate = onChangeDate;
        self.getCssHeaderClass = getCssHeaderClass;
        self.schoolLevelChanged = schoolLevelChanged;
        self.countryChanged = countryChanged;

        var _isShowMode = true;

        init();

        function init() {
            $scope.$watch("emEdCtrl.employeeEducations", function (newValue, oldValue) {
                if (newValue === oldValue) return;
                if (!comparisonUtilSvc.isNullOrUndefinedValue(initialEmployeeEducations) && self.employeeEducations.length > 0 && !self.isAddingEducation) {
                    var educationsFormat = copyEducation(self.employeeEducations);
                    self.isModifiedData = JSON.stringify(educationsFormat) != JSON.stringify(initialEmployeeEducations);
                } else {
                    if (self.isAddingEducation) {
                        self.isModifiedData = true;
                    }
                }
            }, true);

            $scope.$watch('emEdCtrl.isEditMode', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                rowEditing = constants.newRowIndex;
                if (self.isAddingEducation) {
                    self.employeeEducations.pop();
                    self.isAddingEducation = false;
                }
                if (self.isModifiedData && !self.isSkillEditing) {
                    self.employeeEducations = copyEducation(initialEmployeeEducations);
                }
                // Show education detail when Education tab is being hidden
                if ($("#employee-education-detail").css("display") == 'none') {
                    self.onClickHeader();
                }
            }, true);

            countrySvc.getAllCountries().query(function (result) {
                self.countries = result;
                var countryDefault = {
                    Id: self.countries.length + 1,
                    CountryCode: "EMPTY",
                    CountryNameEN: "",
                    CountryLocalName: "",
                    ModifiedDate: new Date()
                };

                self.countries.splice(0, 0, countryDefault);
                self.countrySelected = self.countries[0].CountryLocalName;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(caConstants.translate)(caMessage.errorLoadingData));
            });

            if (objectSvc.checkPermission(self.hasPermission, '', false)) {
                educations = emDetailSvc.educationsResource(param).query(
                    function () {
                        $.each(educations, function (item, education) {
                            self.employeeEducations.push(new emEducationModel(education, true, true));
                            initialEmployeeEducations.push(new emEducationModel(education, true, true));
                        });
                        formatEducationDate(self.employeeEducations);
                        formatEducationDate(initialEmployeeEducations);
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.education.getEmployeeEducationError));
                    });
            }
            return;

            function formatEducationDate(educationsFormat) {
                $.each(educationsFormat, function (item, educationFormat) {
                    educationFormat.From = (educationFormat.From) ? moment(educationFormat.From).format(constants.formatDateDDMMYYYY) : "";
                    educationFormat.To = (educationFormat.To) ? moment(educationFormat.To).format(constants.formatDateDDMMYYYY) : "";
                    educationFormat.FromYear = (educationFormat.From) ? moment(educationFormat.From, constants.formatDateDDMMYYYY).year() : "";
                    educationFormat.ToYear = (educationFormat.To) ? moment(educationFormat.To, constants.formatDateDDMMYYYY).year() : "";
                });
            }
        }

        function copyEducation(fromEducation) {
            var educationsFormat = [];
            $.each(fromEducation, function (item, education) {
                educationsFormat.push(new emEducationModel(education, true, true));
            });
            $.each(educationsFormat, function (item, educationFormat) {
                educationFormat.FromYear = (educationFormat.From) ? moment(educationFormat.From, constants.formatDateDDMMYYYY).year() : "";
                educationFormat.ToYear = (educationFormat.To) ? moment(educationFormat.To, constants.formatDateDDMMYYYY).year() : "";
            });
            return educationsFormat;
        }

        function onClickAddEducation() {
            if (rowEditing == constants.newRowIndex) {
                self.isAddingEducation = true;
                var newEducation = new emEducationModel(null, true, false);
                self.employeeEducations.push(newEducation);
                rowEditing = self.employeeEducations.length - 1;
                self.employeeEducations[rowEditing].From = moment(self.employeeEducations[rowEditing].From).format(constants.formatDateDDMMYYYY);
                self.employeeEducations[rowEditing].To = moment(self.employeeEducations[rowEditing].To).format(constants.formatDateDDMMYYYY);
                $timeout(function () {
                    $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                    $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
                }, 0);

            } else {
                toastr.warning($filter(constants.translate)(emMessage.editingData));
            }
        }

        function onClickHeader() {
            _isShowMode = !_isShowMode;
            $("#employee-education-detail").slideToggle("slow");
        }

        function onClickSaveEducation(educationId) {
            param.educationId = educationId;
            self.employeeEducations[rowEditing].From = datetimeSvc.convertDateForServerSide(self.employeeEducations[rowEditing].From, false);
            self.employeeEducations[rowEditing].To = datetimeSvc.convertDateForServerSide(self.employeeEducations[rowEditing].To, false);

            self.employeeEducations[rowEditing].SchoolLevel = self.schoolLevelSelected;
            self.employeeEducations[rowEditing].Country = self.countrySelected;
            loadingSvc.show();
            if (self.isAddingEducation) {
                emDetailSvc.educationsResource(param).save(self.employeeEducations[rowEditing],
                    function (newEducationId) {
                        loadingSvc.close();
                        newEducationId = formatEmployeeId(newEducationId);
                        onSuccessSaveEducation(newEducationId);
                        toastr.success($filter(constants.translate)(emMessage.education.addEmployeeEducationSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.education.addEmployeeEducationError));
                    });
            } else {
                emDetailSvc.educationsResource(param).update(self.employeeEducations[rowEditing],
                    function () {
                        loadingSvc.close();
                        onSuccessSaveEducation();
                        toastr.success($filter(constants.translate)(emMessage.education.updateEmployeeEducationSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.education.updateEmployeeEducationError));
                    });
            }
            return;

            function formatEmployeeId(id) {
                id = $.map(id, function (e) {
                    return e;
                }).join("");
                return id.substring(0, id.indexOf("["));
            }

            function onSuccessSaveEducation(id) {
                self.employeeEducations[rowEditing].From = (self.employeeEducations[rowEditing].From) ? moment(self.employeeEducations[rowEditing].From).format(constants.formatDateDDMMYYYY) : "";
                self.employeeEducations[rowEditing].To = (self.employeeEducations[rowEditing].To) ? moment(self.employeeEducations[rowEditing].To).format(constants.formatDateDDMMYYYY) : "";
                self.employeeEducations[rowEditing].FromYear = (self.employeeEducations[rowEditing].From) ? moment(self.employeeEducations[rowEditing].From, constants.formatDateDDMMYYYY).year() : "";
                self.employeeEducations[rowEditing].ToYear = (self.employeeEducations[rowEditing].To) ? moment(self.employeeEducations[rowEditing].To, constants.formatDateDDMMYYYY).year() : "";
                self.employeeEducations[rowEditing].Id = id ? id : self.employeeEducations[rowEditing].Id;
                initialEmployeeEducations = copyEducation(self.employeeEducations);
                self.schoolLevelSelected = '';
                self.countrySelected = '';
                rowEditing = constants.newRowIndex;
                self.isAddingEducation = false;
                self.isModifiedData = false;
                self.isSchoolLevelChanged = false;
                self.isCountryChanged = false;
            }
        }

        function isEditingRow(rowIndex) {
            if (rowIndex == rowEditing) return true;
            return false;
        }

        function onClickEditRow(rowIndex) {
            if (!self.isAddingEducation) {
                rowEditing = rowIndex;
                self.schoolLevelSelected = self.employeeEducations[rowEditing].SchoolLevel;
                self.countrySelected = self.employeeEducations[rowEditing].Country;
            } else {
                toastr.warning($filter(constants.translate)(emMessage.addingData));
            }
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function onClickCancelEdit() {
            self.employeeEducations = copyEducation(initialEmployeeEducations);
            rowEditing = constants.newRowIndex;
            self.schoolLevelSelected = '';
            self.countrySelected = '';
            if (self.isAddingEducation) {
                self.isAddingEducation = false;
            }
            self.isValidDate = true;
            self.isSchoolLevelChanged = false;
            self.isCountryChanged = false;
            self.schoolLevelSelected = '';
            self.countrySelected = '';
        }

        function onClickDeleteRow(educationId, rowIndex) {
            if (!objectSvc.checkPermission((self.permissionOfCurrentUser.deleteEmployeeInformation || self.permissionOfCurrentUser.updateCV), message.dontHavePermissionAccess, true)) return;
            rowIndexDeleting = rowIndex;
            param.educationId = educationId;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function onYes() {
            loadingSvc.show();
            emDetailSvc.educationsResource(param).delete(
                function () {
                    loadingSvc.close();
                    self.employeeEducations.splice(rowIndexDeleting, 1);
                    initialEmployeeEducations = copyEducation(self.employeeEducations);
                    toastr.success($filter(constants.translate)(emMessage.education.deleteEmployeeEducationSuccess));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.education.deleteEmployeeEducationError));
                });
        }

        function onChangeDate() {
            var fromDate = (self.employeeEducations[rowEditing].From) ? moment(self.employeeEducations[rowEditing].From, constants.formatDateDDMMYYYY) : "";
            var toDate = (self.employeeEducations[rowEditing].To) ? moment(self.employeeEducations[rowEditing].To, constants.formatDateDDMMYYYY) : "";
            if (!fromDate || !toDate) {
                self.isValidDate = true;
                return;
            }
            var diff = toDate.diff(fromDate, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function getCssHeaderClass() {
            return _isShowMode && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function schoolLevelChanged() {
            if (rowEditing != constants.newRowIndex) {
                self.isSchoolLevelChanged = (self.schoolLevelSelected !== self.employeeEducations[rowEditing].SchoolLevel);
            }
            if (self.isAddingEducation) {
                self.isSchoolLevelChanged = (self.schoolLevelSelected !== "");
            }
        }

        function countryChanged() {
            if (rowEditing != constants.newRowIndex) {
                self.isSchoolLevelChanged = (self.countrySelected !== self.employeeEducations[rowEditing].Country);
            }
            if (self.isAddingEducation) {
                self.isCountryChanged = (self.countrySelected !== "");
            }
        }
    }
})();
