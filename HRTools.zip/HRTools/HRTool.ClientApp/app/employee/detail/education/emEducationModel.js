﻿(function () {
    "use strict";
    angular.module("app").factory('emEducationModel', emEducationModel);
    function emEducationModel() {
        var temp = function (employeeEducation, isEmployee, allowNull) {
            var self = this;
            self.Id = employeeEducation ? employeeEducation.Id : undefined;
            self.CandidateId = employeeEducation ? employeeEducation.CandidateId : undefined;
            self.EmployeeId = employeeEducation ? employeeEducation.EmployeeId : undefined;
            self.School = employeeEducation ? employeeEducation.School : '';
            self.Field = employeeEducation ? employeeEducation.Field : '';
            self.From = employeeEducation && employeeEducation.From ? employeeEducation.From : allowNull ? '' : new Date();
            self.To = employeeEducation && employeeEducation.To ? employeeEducation.To : allowNull ? '' : new Date();
            self.FromYear = employeeEducation && employeeEducation.FromYear ? employeeEducation.FromYear : '';
            self.ToYear = employeeEducation && employeeEducation.ToYear ? employeeEducation.ToYear : '';
            self.IsEmployee = isEmployee;
            self.SchoolLevel = employeeEducation ? employeeEducation.SchoolLevel : '';
            self.Degree = employeeEducation ? employeeEducation.Degree : '';
            self.Country = employeeEducation ? employeeEducation.Country : '';
            self.ShowSchoolLevelLabel = employeeEducation && (employeeEducation.SchoolLevel === null || employeeEducation.SchoolLevel === "") ? false : true;
            self.ShowCountryLabel = employeeEducation && (employeeEducation.Country === null || employeeEducation.Country === "") ? false : true;
            self.ShowFieldLabel = employeeEducation && (employeeEducation.Field === null || employeeEducation.Field === "") ? false : true;
            self.Attachments = employeeEducation && employeeEducation.Attachments ? employeeEducation.Attachments : [];
            return self;
        };
        return temp;
    }
})();