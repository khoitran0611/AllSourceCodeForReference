﻿(function () {
    'use strict';
    angular.module("app").service('emContractSvc', emContractSvc);
    emContractSvc.$inject = ['$resource', 'constants'];
    function emContractSvc($resource, constants) {
        var service = {
            getEmployeeContract: getEmployeeContract
        };
        return service;

        function getEmployeeContract(emId) {
            return $resource(constants.apiUrl + 'employees/:id/contracts', { id: emId });
        }
    }
})();