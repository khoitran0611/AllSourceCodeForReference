﻿(function () {
    'use strict';
    angular.module("app").controller('emContractCtrl', EmContractCtrl);
    EmContractCtrl.$inject = [
        '$stateParams', '$filter',
        'emContractSvc', 'styleSvc', 'permissionSvc', 'messageHandleSvc', 'emDetailSvc',
        'constants'
    ];
    function EmContractCtrl($stateParams, $filter,
            emContractSvc, styleSvc, permissionSvc, messageHandleSvc, emDetailSvc,
            constants) {
        /* jshint -W040 */
        var self = this;
        var messages = {
            getInfoError: $filter(constants.translate)("Contract.Error_Getting")
        };

        self.isEditMode = emDetailSvc.getDisplayMode();
        self.linkToCreate = '#/employees/' + $stateParams.id + '/contract/create';

        self.permissionOfCurrentUser = {
            canAddContract: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_AddContract),
            canUpdateContract: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_UpdateContract),
            canViewContract: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_ViewContract),
            canUploadFile: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_Uploadfile),
            canExportContract: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_ExportContract)
        };

        self.toogleHeader = toogleHeader;
        self.getCssHeaderClass = getCssHeaderClass;

        var _isShowMode = true;

        init();

        function init() {
            if (self.permissionOfCurrentUser.canViewContract) {
                emContractSvc.getEmployeeContract($stateParams.id).query(
                    function (response) {
                        response.forEach(function (contract) {
                            formatContractDate(contract);
                            contract.linkToContract = '#/employees/' + contract.Id + '/contract/update';
                        });
                        self.contractInfo = response;
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, messages.getInfoError);
                    });
            }
            return;

            function formatContractDate(responsedConstract) {
                responsedConstract.StartDate = responsedConstract.StartDate ? moment(responsedConstract.StartDate).format(constants.formatDateDDMMYYYY) : responsedConstract.StartDate;
                responsedConstract.EndDate = responsedConstract.EndDate ? moment(responsedConstract.EndDate).format(constants.formatDateDDMMYYYY) : responsedConstract.EndDate;
            }
        }

        function toogleHeader() {
            _isShowMode = !_isShowMode;
            $("#employee-contract-detail").slideToggle("slow");
        }

        function getCssHeaderClass() {
            return _isShowMode && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }
    }
})();