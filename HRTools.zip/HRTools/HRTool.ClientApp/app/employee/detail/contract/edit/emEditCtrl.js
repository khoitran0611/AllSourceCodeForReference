﻿(function () {
    'use strict';
    angular.module("app").controller('emEditCtrl', EmEditCtrl);
    EmEditCtrl.$inject = [
        'constants', 'emConstants', 'message', 'emMessage',
        'datetimeSvc', 'messageHandleSvc', 'validationSvc', 'employeeSvc', 'permissionSvc', 'authenticationSvc',
        '$scope', '$filter', '$state', '$window', 'uploadFileSvc', 'loadingSvc'
    ];
    function EmEditCtrl(constants, emConstants, message, emMessage,
            datetimeSvc, messageHandleSvc, validationSvc, employeeSvc, permissionSvc, authenticationSvc,
            $scope, $filter, $state, $window, uploadFileSvc, loadingSvc) {
            /* jshint -W040 */
            var employeeOrContractId = $state.params.id;
            var self = this;
            self.permissionOfCurrentUser = {
                canAddContract: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_AddContract),
                canUpdateContract: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_UpdateContract),
                canViewContract: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_ViewContract),
                canUploadFile: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_Uploadfile),
                canExportContract: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_ExportContract)
            };
            if (!self.permissionOfCurrentUser.canViewContract) {
                //authenticationSvc.logout();
                messageHandleSvc.handlePermission();
                return;
            }
            self.fileType = "Contract";
            self.isCreating = false;
            self.uploadFileName = '';
            self.uploadFilePath = '';
            self.dialogConfirm = emMessage.deleteContractDialog;
            self.contractFile = {};
            self.serverUrl = constants.serverUrl;

            self.formatDuration = formatDuration;
            self.onClickSave = onClickSave;
            self.onKeyDownSalary = onKeyDownSalary;
            self.onLostFocus = onLostFocus;
            self.linkBackToEmployeeView = linkBackToEmployeeView;
            self.exportToPDF = exportToPDF;
            self.onKeyDownYear = onKeyDownYear;
            self.removeContractFile = removeContractFile;
            self.acceptDeleteContractFile = acceptDeleteContractFile;

            $scope.uploadContractFile = uploadContractFile;

            init();
            function init() {
                var action = $state.params.action;
                if (action == emConstants.contract.createAction) {
                    self.isCreating = true;
                }
                self.pageTitle = self.isCreating ? "Contract.Create_Contract" : "Contract.Update_Contract";

                if (self.isCreating) {
                    self.contract = employeeSvc.prepareForCreateContract(employeeOrContractId, 0).get(
                        function () {
                            self.contract.CreateDate = moment(new Date()).format(constants.formatDateDDMMYYYY);
                            self.contract.StartDate = moment(new Date()).format(constants.formatDateDDMMYYYY);
                            self.contract.ContractTypeId = self.contract.ListContractType ? self.contract.ListContractType[0].Id : 0;
                            formatBeforeShowData();
                            loadingSvc.close();
                        }, function(xhr) {
                            messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                            loadingSvc.close();
                    });
                } else {
                    self.contract = employeeSvc.getDetailContract(0, employeeOrContractId).get(
                        function () {
                            self.contract.CreateDate = moment(self.contract.CreateDate).format(constants.formatDateDDMMYYYY);
                            self.contract.StartDate = moment(self.contract.StartDate).format(constants.formatDateDDMMYYYY);
                            formatBeforeShowData();
                            loadingSvc.close();
                            if (!self.contract.UrlContract) return;
                            formatUrlContractFile(self.contract.UrlContract);
                        },function(xhr) {
                            messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                            loadingSvc.close();
                    });
                }
            }

            function formatUrlContractFile(fileUrl) {
                var fileName = fileUrl.replace(/^.*[\\\/]/, '');
                var firstPosition = 0;
                var lastPosition = fileName.length;
                self.contractFile.Url = self.contract.UrlContract;
                self.contractFile.FileName = fileName.substring(firstPosition, lastPosition);
            }

            function formatBeforeShowData() {
                self.contract.Note = self.contract.Note == "null" ? "" : self.contract.Note;
                self.formatDuration();
                self.contract.ProbationSalary = (self.contract.NetSalary * self.contract.Percentage) / 100;
                $('.date').datepicker({ autoclose: true, todayHighlight: true });
                $('.date').datepicker({ autoclose: true, todayHighlight: true });
            }

            function formatDuration() {
                switch (self.contract.ContractTypeId) {
                    case emConstants.contract.permanentCode:
                        self.contract.Month = null;
                        break;
                    case emConstants.contract.probationCode:
                        self.contract.Month = emConstants.contract.probationMonth;
                        break;
                    case emConstants.contract.officialCode:
                        self.contract.Month = emConstants.contract.officialMonth;
                        break;
                }
            }

            function onClickSave() {
                formatDataBeforeSaveToServer();
                if (self.isCreating) {
                    createContract();
                } else {
                    updateContract();
                }
            }

            function formatDataBeforeSaveToServer() {
                self.contract.CreateDate = datetimeSvc.convertDateForServerSide(self.contract.CreateDate, false);
                self.contract.StartDate = datetimeSvc.convertDateForServerSide(self.contract.StartDate, false);
            }

            function createContract() {
                loadingSvc.show();
                employeeSvc.createContract(employeeOrContractId).save(self.contract,
                    function (response) {
                        var createSuccess = 't';
                        if (response[0] == createSuccess) {
                            loadingSvc.close();
                            toastr.success($filter(constants.translate)(emMessage.contract.addNewSuccessful));
                            self.linkBackToEmployeeView();
                        } else toastr.error($filter(constants.translate)(emMessage.contract.errorInSavingData));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.contract.errorInSavingData));
                    });
            }

            function updateContract() {
                loadingSvc.show();
                employeeSvc.updateContract().update(self.contract,
                    function () {
                        loadingSvc.close();
                        toastr.success($filter(constants.translate)(emMessage.contract.updateSuccessful));
                        self.linkBackToEmployeeView();
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.contract.errorInSavingData));
                    });
            }

            function onKeyDownSalary(e) {
                validationSvc.onKeyDownTextBox(e);
            }

            function onLostFocus() {
                self.contract.ProbationSalary = (self.contract.NetSalary * self.contract.Percentage) / 100;
            }

            function linkBackToEmployeeView() {
                $state.go('employeeDetail', { id: self.contract.LabourEmployeeId });
            }

            function exportToPDF() {
                employeeSvc.exportToPDF(employeeOrContractId).get(
                    function (filePath) {
                        if (filePath !== "") {
                            filePath = formatContractPath(filePath);
                            self.uploadFilePath = filePath;
                            if (filePath.length > 0) {
                                var totalFolderFilePath = (filePath.lastIndexOf('/') > 0 ? self.uploadFilePath.split('/').length : 0);
                                if (totalFolderFilePath > 0) {
                                    self.uploadFileName = filePath.split('/')[totalFolderFilePath - 1];
                                } else {
                                    self.uploadFileName = filePath;
                                }
                            }
                        } else {
                            toastr.error($filter(constants.translate)(emMessage.contract.errorInSavingData));
                        }
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.contract.errorInSavingData));
                    });
            }

            function formatContractPath(filePath) {
                filePath = $.map(filePath, function (e) {
                    return e;
                }).join("");
                return filePath.substring(1, filePath.indexOf("[") - 1);
            }

            function onKeyDownYear(event) {
                validationSvc.onKeyDownTextBox(event);
            }

            function removeContractFile() {
                $('#' + self.dialogConfirm.dialogId).modal('show');
            }

            function acceptDeleteContractFile() {
                self.contractFile = {};
                self.contract.UrlContract = null;
                document.getElementById("signedContract").value = "";
            }

            function uploadContractFile() {
                var fileUpload = document.getElementById("signedContract");
                if (!fileUpload.value) return;

                var contractFile = fileUpload.files[0];
                if (fileUpload.files[0].size > constants.maxFileSizeUploaded) {
                    toastr.warning(String.format($filter(constants.translate)("Max_File_Size_Message"), 5));
                    var control = $('#signedContract');
                    control.replaceWith(control = control.clone(true));
                    return;
                }

                uploadFileSvc.uploadFile(contractFile, "Contract", self.contract.LabourEmplFullname).$promise.then(function (data) {
                    $window.localStorage.setItem(emConstants.contract.cookieKeyEmployeeName, self.contract.LabourEmplFullname, { expires: 1 });
                    if (!data.value) return;
                    self.contract.UrlContract = data.value;
                    formatUrlContractFile(self.contract.UrlContract);
                    if (!$scope.$$phase && !$scope.$root.$$phase) {
                        $scope.$apply();
                    }
                });
            }
        }
})();