﻿(function () {
    "use strict";
    angular.module("app").factory('emDetailModel', emDetailModel);
    emDetailModel.$inject = ['datetimeSvc', 'constants', 'comparisonUtilSvc'];
    function emDetailModel(datetimeSvc, constants, comparisonUtilSvc) {
        var employeeInfoModel = function (employeeInfo) {
            /* jshint -W040 */
            var self = this;
            self.candidateId = employeeInfo.CandidateId || 0;
            self.EmployeeId = employeeInfo.EmployeeId;
            self.Id = employeeInfo.EmployeeId;
            self.FullName = employeeInfo.FullName;
            self.FirstName = employeeInfo.FirstName;
            self.LastName = employeeInfo.LastName;
            self.Profession = employeeInfo.Profession || "";
            self.BirthdayOnView = employeeInfo.Birthday ? moment(employeeInfo.Birthday).format(constants.formatDateDDMMYYYY) : null;
            self.Birthday = employeeInfo.Birthday ? datetimeSvc.convertDateForServerSide(self.BirthdayOnView, false) : null;
            self.Photograph = employeeInfo.Photograph;
            if (employeeInfo.Photograph === 'null' || employeeInfo.Photograph === '' || comparisonUtilSvc.isNullOrUndefinedValue(employeeInfo.Photograph)) {
                self.PhotographTemp = constants.noAvatar;
            } else {
                self.PhotographTemp = employeeInfo.Photograph;
            }
            self.Domain = employeeInfo.Domain || "";
            self.seletedPosition = { id: employeeInfo.PositionId, text: employeeInfo.PositionName, optionsValue: undefined, optionsText: undefined };
            self.PositionId = employeeInfo.PositionId;
            self.PositionName = employeeInfo.PositionName;
            self.Positions = employeeInfo.Positions || [];
            self.HasProbationAppraisal = employeeInfo.HasProbationAppraisal;
            self.ProbationPeriod = employeeInfo.ProbationPeriod;
            self.CvFiles = [];
            self.FileName = "";
            self.Gender = employeeInfo.Gender;
            self.Status = employeeInfo.Status;
            self.Genders = constants.genders;
            self.StatusList = employeeInfo.StatusList;
            self.DirtyFlag = true;

            return self;
        };

        return employeeInfoModel;
    }
})();