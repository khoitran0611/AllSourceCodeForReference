﻿(function () {
    'use strict';
    angular.module("app").controller('emDetailCtrl', EmDetailCtrl);
    EmDetailCtrl.$inject = [
        "validationSvc", "emDetailSvc", "permissionSvc", "positionSvc", "emailSvc", "datetimeSvc", "messageHandleSvc", "handleRequestSvc", "styleSvc", "authenticationSvc",
        "message", "emMessage", "constants", "emConstants", "emDetailModel",
        "$scope", "$filter", "$timeout", "$state", "$rootScope", "$window", "uploadFileSvc", "comparisonUtilSvc", "loadingSvc"
    ];
    function EmDetailCtrl(
        validationSvc, emDetailSvc, permissionSvc, positionSvc, emailSvc, datetimeSvc, messageHandleSvc, handleRequestSvc, styleSvc, authenticationSvc,
            message, emMessage, constants, emConstants, emDetailModel,
            $scope, $filter, $timeout, $state, $rootScope, $window, uploadFileSvc, comparisonUtilSvc, loadingSvc) {
        /* jshint -W040 */
        var hasImageUpload = false;
        var initialEmployeeBasicInfo = {};
        var param = {};
        var employeeId = $state.params.id;
        var cvFiles = [];
        var self = this;
        var employeeImage = null;

        self.pageTitle = emConstants.employeeDetailPage.title;
        self.employeeBasicInfo = {};
        self.isEditMode = emDetailSvc.getDisplayMode();
        self.isEditEmployeeBasicInfo = false;
        self.Genders = translateGender();
        self.isModifiedData = false;
        self.seletedPosition = { id: 0, text: "", optionsValue: undefined, optionsText: undefined };
        self.dialogConfirm = $filter(constants.translate)(emMessage.deleteEmployeedialogConfirm);
        self.isValidBirthday = true;
        self.serverUrl = constants.serverUrl;

        self.permissionOfCurrentUser = {
            addProbationAppraisalRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ProbationAppraisal_Addprobation),
            editProbationAppraisalRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ProbationAppraisal_Addprobation),
            sendMailWelcomeRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_SendMailWelcome),
            updateEmployee: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_EditEmployeeInfo),
            deleteEmployeeInfo: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_DeleteEmployeeInfo),
            viewContractRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Employeecontract_ViewContract),
            updateCV: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_UpdateCV),
            viewEmployeeInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_ViewEmployeeInfo),
            updateOwnInfor: JSON.parse($window.localStorage.getItem("currentuserlogin")).UserId == employeeId
        };
        if (!self.permissionOfCurrentUser.viewEmployeeInfor) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.showProbation = false;
        self.initListPostion = {
            service: positionSvc.getAllPositions(), id: "PstId", text: "PstName", option: {
                placeholder: $filter(constants.translate)("All_Positions"),
                multiple: false
            }
        };
        self.avatarPath = constants.noAvatar;

        $scope.uploadFormData = uploadFormData;
        self.toogleEditMode = toogleEditMode;
        self.createEmailWelcome = createEmailWelcome;
        self.editEmployeeBasicInfo = editEmployeeBasicInfo;
        self.selectGender = selectGender;
        self.selectStatus = selectStatus;
        self.saveEmployeeBasicInfo = saveEmployeeBasicInfo;
        self.cancelEmployeeBasicInfo = cancelEmployeeBasicInfo;
        self.acceptDeleteEmployee = acceptDeleteEmployee;
        self.deleteEmployee = deleteEmployee;
        self.backToEmployeeList = backToEmployeeList;
        self.goToTop = goToTop;
        self.onChangeDate = onChangeDate;
        self.onKeyDownProbationPeriod = onKeyDownProbationPeriod;
        self.checkFullNameValid = checkFullNameValid;
        self.toProbation = toProbation;

        init();

        function init() {
            styleSvc.hideButtonGoTop();
            hasImageUpload = false;
            param.employeeId = employeeId;
            emDetailSvc.employeeDetailResource(param).get(
            function (data) {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(data)) {
                    loadData(data, true);
                }
                loadingSvc.close();
            },
           function (xhr) {
               messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
               loadingSvc.close();
           });

            $scope.$watch("emCtrl.seletedPosition", function (newValue, oldValue) {
                if (self.seletedPosition.id != self.employeeBasicInfo.PositionId) {
                    self.isModifiedData = true;
                    return;
                }
                if (newValue == oldValue)
                    return;
                self.isModifiedData = JSON.stringify(self.employeeBasicInfo) != JSON.stringify(initialEmployeeBasicInfo);
            }, true);

            $scope.$watch("emCtrl.employeeBasicInfo", function (newValue, oldValue) {
                if (self.seletedPosition.id != self.employeeBasicInfo.PositionId) {
                    self.isModifiedData = true;
                    return;
                }
                if (newValue == oldValue)
                    return;
                self.isModifiedData = JSON.stringify(self.employeeBasicInfo) != JSON.stringify(initialEmployeeBasicInfo);
            }, true);

            $scope.$on('$stateChangeStart',
               function () {
                   if (self.isEditMode.value)
                       emDetailSvc.changeDisplayMode();
               });
            return;

            function loadData(employeeDetail) {
                self.employeeBasicInfo = new emDetailModel(employeeDetail);
                self.showProbation = self.employeeBasicInfo.HasProbationAppraisal ? self.permissionOfCurrentUser.editProbationAppraisalRole : self.permissionOfCurrentUser.addProbationAppraisalRole;
                self.seletedPosition.id = self.employeeBasicInfo.PositionId;
                self.seletedPosition.text = self.employeeBasicInfo.PositionName;
                initialEmployeeBasicInfo = new emDetailModel(employeeDetail);
                self.avatarPath = getImageLink(self.employeeBasicInfo.Photograph);
                loadCandidateFilesFromJson(employeeDetail.CvFiles);
            }
        }

        function getImageLink(link) {
            if (!link || link.toLowerCase().indexOf("image-placeholder") >= 0) return angular.copy(constants.noAvatar);
            if (link.toLowerCase().indexOf("http://") >= 0 || link.toLowerCase().indexOf("https://") >= 0 || link.toLowerCase().indexOf("www.") >= 0) return link;
            return (constants.serverUrl + link);
        }

        function loadCandidateFilesFromJson(files) {
            self.employeeBasicInfo.CvFiles = [];
            cvFiles = [];
            if (files) {
                for (var i = 0; i < files.length; i++) {
                    var dataFile = { FileId: files[i].FileId, JobApplicationId: files[i].JobApplicationId, Url: files[i].Url, FileName: files[i].FileName };
                    self.employeeBasicInfo.CvFiles.push(dataFile);
                    cvFiles.push(dataFile);
                }
            }
            self.employeeBasicInfo.FileName = self.employeeBasicInfo.CvFiles.length > 0 ? self.employeeBasicInfo.CvFiles[0].FileName || "" : "";
        }

        function translateGender() {
            var genderList = [];
            for (var index = 0; index < constants.genders.length; index++) {
                genderList.push({ Code: constants.genders[index].Code, Name: $filter(constants.translate)(constants.genders[index].Name) });
            }
            return genderList;
        }

        function uploadFormData() {
            var input = document.getElementById("EmployeeImage");
            if (input.files[0]) {
                if (input.files[0].size > constants.maxFileSizeUploaded) {
                    toastr.warning(String.format($filter(constants.translate)("Max_File_Size_Message"), 5));
                    var control = $('input#EmployeeImage');
                    control.replaceWith(control = control.clone(true));
                    self.employeeBasicInfo.PhotographTemp = self.avatarPath;
                    return;
                }
                hasImageUpload = true;
            }

            employeeImage = input.files[0];

            uploadImage();

            function uploadImage() {
                self.employeeBasicInfo.FullName = (self.employeeBasicInfo.FirstName + " " + self.employeeBasicInfo.LastName);
                if (input !== '') {
                    upload();
                }
                function upload() {

                    uploadFileSvc.uploadFile(employeeImage, 'EmployeeImage', self.employeeBasicInfo.FullName).$promise.then(function (data) {
                        if (data.value.length > 0) {
                            self.employeeBasicInfo.PhotographTemp = data.value;
                            self.avatarPath = constants.serverUrl + data.value;
                            if (!$scope.$$phase && !$scope.$root.$$phase) {
                                $scope.$apply();
                            }
                        }
                    });
                }
            }
        }

        function toogleEditMode() {
            emDetailSvc.changeDisplayMode();
            self.pageTitle = (self.isEditMode.value) ? emConstants.updateEmployeePageTitle : emConstants.employeeDetailPage.title;
        }

        function createEmailWelcome() {
            var actionId = constants.emailCode.welcomeNewComer;
            emailSvc.welcomeNewEmployeeEmail(employeeId).get(function (data) {
                self.emailData = data;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
            });
        }

        function editEmployeeBasicInfo() {
            self.isEditEmployeeBasicInfo = !self.isEditEmployeeBasicInfo;
            selectGender();
            selectStatus();
            $('.date').datepicker({ autoclose: true, todayHighlight: true });
            var resetCommand = "resetSeleted";
            self.seletedPosition = { id: self.employeeBasicInfo.PositionId, text: self.employeeBasicInfo.PositionName, optionsValue: resetCommand, optionsText: undefined };
        }

        function selectGender() {
            for (var index = 0; index < self.Genders.length; index++) {
                if (self.Genders[index].Code == self.employeeBasicInfo.Gender) {
                    self.genderName = self.Genders[index].Name;
                    return;
                }
            }
        }

        function selectStatus() {
            for (var index = 0; index < self.employeeBasicInfo.StatusList.length; index++) {
                if (self.employeeBasicInfo.StatusList[index].Code == self.employeeBasicInfo.Status) {
                    self.statusName = self.employeeBasicInfo.StatusList[index].Name;
                    return;
                }
            }
        }

        function saveEmployeeBasicInfo() {
            if (!(self.permissionOfCurrentUser.updateEmployee || self.permissionOfCurrentUser.updateCV)) {
                //authenticationSvc.logout();
                messageHandleSvc.handlePermission(true);
                return;
            }
            self.employeeBasicInfo.FullName = self.employeeBasicInfo.FirstName + " " + self.employeeBasicInfo.LastName;

            if (hasImageUpload) {
                $window.localStorage.setItem('EmployeeFullName', self.employeeBasicInfo.FullName, { expires: 1 });
                $window.localStorage.setItem('EmployeeImagePath', self.employeeBasicInfo.Photograph, { expires: 1 });
                var employeeImage = $('#EmployeeImage')[0].files[0];
                uploadFileSvc.uploadEmployeeImage(employeeImage, 'EmployeeImage', self.employeeBasicInfo.FullName, self.employeeBasicInfo.Photograph).$promise.then(function (data) {
                    if (data.value.length > 0) {
                        self.employeeBasicInfo.Photograph = data.value;
                        self.avatarPath = constants.serverUrl + data.value;
                        saveToDatabase();
                        document.getElementById("EmployeeImage").value = "";
                    }
                });
            } else {
                saveToDatabase();
            }

            self.isEditEmployeeBasicInfo = false;
        }

        function saveToDatabase() {
            loadingSvc.show();
            self.employeeBasicInfo.PositionId = self.seletedPosition.id;
            self.employeeBasicInfo.PositionName = self.seletedPosition.text;
            self.employeeBasicInfo.Birthday = datetimeSvc.convertDateForServerSide(self.employeeBasicInfo.BirthdayOnView, false);
            if (!hasImageUpload) {
                self.employeeBasicInfo.PhotographTemp = "";
            }
            emDetailSvc.employeeDetailResource(param).update(self.employeeBasicInfo,
            function () {
                var defaultPhotographValue = "null";
                initialEmployeeBasicInfo = new emDetailModel(self.employeeBasicInfo);
                self.employeeBasicInfo.PhotographTemp = (self.employeeBasicInfo.Photograph != defaultPhotographValue && self.employeeBasicInfo.Photograph !== "") ?
                    self.employeeBasicInfo.Photograph : constants.noAvatar;
                self.avatarPath = getImageLink(self.employeeBasicInfo.Photograph);
                toastr.success($filter(constants.translate)(emMessage.updateEmployeeInfoSuccess));
                self.isModifiedData = false;
                var currentUser = JSON.parse($window.localStorage.getItem("currentuserlogin"));
                if (currentUser.UserId == employeeId) { //TODO why use number and string for just one property?
                    loadingSvc.close();
                    currentUser.FirstName = self.employeeBasicInfo.FirstName;
                    currentUser.LastName = self.employeeBasicInfo.LastName;
                    currentUser.FullName = self.employeeBasicInfo.FullName;
                    $window.localStorage.setItem("currentuserlogin", JSON.stringify(currentUser));
                    $rootScope.$broadcast("currentuserlogin", {});
                }
                loadingSvc.close();
                hasImageUpload = false;
            },
            function (xhr) {
                loadingSvc.close();
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
            });
        }

        function cancelEmployeeBasicInfo() {
            hasImageUpload = false;
            self.employeeBasicInfo = new emDetailModel(initialEmployeeBasicInfo);
            self.avatarPath = getImageLink(self.employeeBasicInfo.Photograph);
            loadCandidateFilesFromJson(cvFiles);
            var resetCommand = "resetSeleted";
            self.seletedPosition = {};
            self.seletedPosition = { id: self.employeeBasicInfo.PositionId, text: self.employeeBasicInfo.PositionName, optionsValue: resetCommand, optionsText: undefined };

            $timeout(function () {
                self.isModifiedData = false;
                self.isEditEmployeeBasicInfo = false;
            });
        }

        function acceptDeleteEmployee() {
            loadingSvc.show();
            emDetailSvc.employeeDetailResource(param).delete(false,
                function (response) {
                    var result = handleRequestSvc.result(response);
                    if (result) {
                        loadingSvc.close();
                        toastr.success($filter(constants.translate)(emMessage.deleteEmployeeSuccess));
                        $(".modal-backdrop").remove();
                        $timeout(function () {
                            $state.go("employees");
                        }, 1000);
                    } else {
                        loadingSvc.close();
                        toastr.error($filter(constants.translate)(emMessage.deleteEmployeeError));
                    }
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                });
        }

        function deleteEmployee() {
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function backToEmployeeList() {
            self.isEditEmployeeBasicInfo = false;
            $state.go("employees");
        }

        function goToTop() {
            $('body,html').animate({
                scrollTop: 0
            }, 400);
        }

        function onChangeDate() {
            if (!self.employeeBasicInfo.BirthdayOnView) {
                self.isValidBirthday = true;
                return;
            }
            var now = new Date();
            var yearOld = moment(self.employeeBasicInfo.BirthdayOnView, constants.formatDateDDMMYYYY);
            var currentYear = moment(now);
            self.isValidBirthday = currentYear.diff(yearOld, 'years') >= 20 && currentYear.diff(yearOld, 'years') < 100;
        }

        function onKeyDownProbationPeriod(event) {
            validationSvc.onKeyDownTextBox(event);
        }

        function checkFullNameValid() {
            return (self.employeeBasicInfo.LastName && self.employeeBasicInfo.FirstName) ? true : false;
        }

        function toProbation(id) {
            $state.go('probation-appraisal', { id: id });
        }
    }
})();
