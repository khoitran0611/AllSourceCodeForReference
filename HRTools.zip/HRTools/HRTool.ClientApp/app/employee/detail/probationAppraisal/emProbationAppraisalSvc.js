﻿(function () {
    'use strict';
    angular.module("app").service('emProbationAppraisalSvc', emProbationAppraisalSvc);
    emProbationAppraisalSvc.$inject = ['$resource', 'constants'];
    function emProbationAppraisalSvc($resource, constants) {
        var revealed = {
            getProbationAppraisal: getProbationAppraisal,
            probationAppraisal: probationAppraisal
        };
        return revealed;

        /************************** Probation Appraisal ***********************************/
        function getProbationAppraisal(employeeId) {
            return $resource(constants.apiUrl + 'employees/:id/probationAppraisal', { id: employeeId });
        }
        function probationAppraisal(employeeId) {
            return $resource(constants.apiUrl + 'employees/:id/probationAppraisal', { id: employeeId }, { 'update': { method: 'PUT' } });
        }
    }
})();