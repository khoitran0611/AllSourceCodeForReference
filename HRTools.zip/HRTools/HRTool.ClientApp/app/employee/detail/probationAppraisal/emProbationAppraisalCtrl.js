﻿(function () {
    'use strict';

    angular.module("app").controller('emProbationAppraisalCtrl', EmProbationAppraisalCtrl);
    EmProbationAppraisalCtrl.$inject = [
        'emProbationAppraisalSvc', '$state', '$filter', 'datetimeSvc', 'messageHandleSvc', 'constants',
        'message', 'emMessage', 'permissionSvc', 'comparisonUtilSvc'];
    function EmProbationAppraisalCtrl(
        emProbationAppraisalSvc, $state, $filter, datetimeSvc, messageHandleSvc, constants,
        message, emMessage, permissionSvc, comparisonUtilSvc) {
        /* jshint -W040 */
        var self = this;
        var constantIdValue = 0;

        self.serverUrl = constants.serverUrl;
        self.permissionOfCurrentUser = {
            savePermission: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ProbationAppraisal_Editprobation),
            addPermission: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ProbationAppraisal_Addprobation),
            viewPermission: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ProbationAppraisal_Viewprobation),
        };
        if (!self.permissionOfCurrentUser.viewPermission) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.isShowSaveButton = self.permissionOfCurrentUser.savePermission || self.permissionOfCurrentUser.addPermission;
        self.employeeId = $state.params.id;
        self.isSavePermission = self.permissionOfCurrentUser.savePermission || self.permissionOfCurrentUser.addPermission;
        self.fileName = "";
        self.filePath = "";
        self.DateAppraise = "";
        self.DateStart = "";
        self.isValidDate = true;

        self.saveProbationAppraisal = saveProbationAppraisal;
        self.monthChanged = monthChanged;
        self.goBackEmployeePage = goBackEmployeePage;
        self.saveAndExportProbationAppraisalToPDF = saveAndExportProbationAppraisalToPdf;
        self.changeDateAppraise = changeDateAppraise;

        var _isSaveButtonClick = true;

        init();

        function init() {
            setDelay(true);
            emProbationAppraisalSvc.probationAppraisal(self.employeeId).get(function (data) {
                self.basicInfo = data;
                self.DateAppraise = moment(self.basicInfo.DateAppraise).format(constants.formatDateDDMMYYYY);
                self.DateStart = moment(self.basicInfo.DateStart).format(constants.formatDateDDMMYYYY);
                setDelay(false);
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
            });

            $('#appraisalDate').datepicker({
                autoclose: true, todayHighlight: true
            });
            if (self.basicInfo && !comparisonUtilSvc.isNullOrUndefinedValue(self.basicInfo.DateAppraise) && self.basicInfo.DateAppraise !== '') {
                $('#appraisalDate').datepicker('setAppraisalDate', self.basicInfo.DateAppraise);
            }
            return;

            function setDelay(isDelay) {
                if (isDelay) {
                    $(constants.loadingIcon.overlay).show();
                    $(constants.loadingIcon.indicator).show();
                    return;
                }
                $(constants.loadingIcon.overlay).hide();
                $(constants.loadingIcon.indicator).hide();
            }
        }

        function saveProbationAppraisal() {
            self.basicInfo.IsCreate = false;
            _isSaveButtonClick = true;
            saveProbation();
        }

        function saveProbation() {
            self.basicInfo.DateStart = datetimeSvc.convertDateForServerSide(self.DateStart, false) + "T00:00:00.00";
            self.basicInfo.DateAppraise = datetimeSvc.convertDateForServerSide(self.DateAppraise, false) + "T00:00:00.00";
            self.fileName = "";
            self.filePath = "";
            var constantTypeValue = "string";
            if (_isSaveButtonClick) {
                createNewProbationAppraisal(self.basicInfo);
            } else {
                if (self.basicInfo.PalId == constantIdValue) {
                    self.basicInfo.IsCreate = true;
                } else {
                    self.basicInfo.IsCreate = false;
                    setDateAppraise(true);
                }
                emProbationAppraisalSvc.probationAppraisal(self.employeeId).update({ id: self.employeeId }, self.basicInfo).$promise.then(function (data) {
                    if (data) {
                        angular.forEach(data, function (value) {
                            if (value != '"' && typeof (value) == constantTypeValue) {
                                self.filePath += value;
                            }
                        });
                        if (self.filePath !== "") {
                            var len = (self.filePath.lastIndexOf('/') > 0 ? self.filePath.split('/').length : 0);
                            if (len > 0) {
                                self.fileName = (self.filePath.split('/')[len - 1]);
                            } else {
                                self.fileName = data;
                            }
                        }
                        toastr.success($filter(constants.translate)(emMessage.probation.addProbationSuccessful));
                        if (_isSaveButtonClick) {
                            goBackEmployeePage();
                        }
                    }
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.probation.addProbationFail));
                });
            }
        }

        function createNewProbationAppraisal(probationAppraisal) {
            self.basicInfo.IsCreate = self.basicInfo.PalId == constantIdValue;

            emProbationAppraisalSvc.probationAppraisal(self.employeeId).save(probationAppraisal, function () {
                toastr.success($filter(constants.translate)(emMessage.probation.addProbationSuccessful));
                goBackEmployeePage();
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.probation.addProbationFail));
            });
        }

        function monthChanged() {
            if (self.DateStart) {
                setDateAppraise();
            }
        }

        function setDateAppraise(isExportedPdf) {
            var appraiseDate = self.DateStart.split("-");
            var date = parseInt(appraiseDate[0], 10);
            var month = parseInt(appraiseDate[1], 10) + parseInt(self.basicInfo.ProbationPeriod, 10);
            var year = parseInt(appraiseDate[2], 10);
            if (month == 2 && date > 28) date = 28;
            if (date == 31) date = 30;
            if (month > 12) {
                month = month - 12;
                year = year + 1;
            }
            if (month < 10) month = "0" + month;
            if (date < 10) date = "0" + date;
            if (!isExportedPdf) {
                self.DateAppraise = date + "-" + month + "-" + year;
            }
            self.basicInfo.ToDate = datetimeSvc.convertDateForServerSide(date + "-" + month + "-" + year, false);
        }

        function goBackEmployeePage() {
            $state.go("employeeDetail", { id: $state.params.id });
        }

        function saveAndExportProbationAppraisalToPdf() {
            self.basicInfo.IsCreate = true;
            _isSaveButtonClick = false;
            saveProbation();
        }

        function changeDateAppraise() {
            var fromDate = moment(self.DateStart, constants.formatDateDDMMYYYY);
            var toDate = moment(self.DateAppraise, constants.formatDateDDMMYYYY);
            var diff = toDate.diff(fromDate, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }
    }
})();