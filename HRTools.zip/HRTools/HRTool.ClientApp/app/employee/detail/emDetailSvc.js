﻿(function () {
    "use strict";
    angular.module("app").factory('emDetailSvc', emDetailSvc);
    emDetailSvc.$inject = ["$resource", "emConstants", "constants"];
    function emDetailSvc($resource, emConstants, constants) {
         var isEditMode = {value:false};
         var service = {
             changeDisplayMode: changeDisplayMode,
             getDisplayMode:getDisplayMode,
             employeeDetailResource: employeeDetailResource,
             summarySkillResource: summarySkillResource,
             employmentHistoryResource: employmentHistoryResource,
             outstandingProjectResource:outstandingProjectResource,
             educationsResource: educationsResource
         };
         return service;

         
         function changeDisplayMode() {
             isEditMode.value = !isEditMode.value;
         }
         function getDisplayMode() {
             return isEditMode;
         }
         function employeeDetailResource(param) {
             return $resource(
                 constants.apiUrl + 'employees/:id',
                      { id: param.employeeId}, { "update": { method: "PUT" } });
         }
         function summarySkillResource(param) {
             return $resource(
              constants.apiUrl + 'employees/:employeeId/skills/:skillId',
                   { employeeId: param.employeeId, skillId: param.skillId }, { "update": { method: "PUT" } });
         }
         function employmentHistoryResource(param) {
             return $resource(
                 constants.apiUrl + 'employees/:employeeId/employment-histories/:employmentHistoryId',
                      { employeeId: param.employeeId, employmentHistoryId: param.employmentHistoryId},
                             { "update": { method: "PUT" } });
         }
         function outstandingProjectResource(param) {
             return $resource(
                constants.apiUrl + 'employees/:employeeId/outstanding-projects/:outstandingProjectId',
                     { employeeId: param.employeeId, outstandingProjectId: param.outstandingProjectId },
                            { "update": { method: "PUT" } });
         }
         function educationsResource(param) {
             return $resource(
                 constants.apiUrl + 'employees/:employeeId/educations/:educationId',
                      { employeeId: param.employeeId, educationId: param.educationId},
                             { "update": { method: "PUT" } });
         }
     }
})();
