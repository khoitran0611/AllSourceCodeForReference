﻿(function () {
    "use strict";
    angular.module("app").controller('emSummarySkillsCtrl', EmSummarySkillsCtrl);
    EmSummarySkillsCtrl.$inject = [
        'emDetailSvc', 'validationSvc', 'styleSvc', 'datetimeSvc', 'messageHandleSvc',
        'emSkillModel', 'constants', 'emConstants', 'message', 'emMessage',
        '$stateParams', '$scope', '$filter', 'comparisonUtilSvc', 'loadingSvc'];
    function EmSummarySkillsCtrl(
        emDetailSvc, validationSvc, styleSvc, datetimeSvc, messageHandleSvc,
        emSkillModel, constants, emConstants, message, emMessage,
        $stateParams, $scope, $filter, comparisonUtilSvc, loadingSvc) {
        /* jshint -W040 */
        var self = this;
        var param = {};
        var initialEmployeeSkills = [];
        var rowIndexEditing = null;
        var invalidRowIndex = constants.newRowIndex;
        var employeeId = $stateParams.id;
        var isModifiedSkill = false;
        var initialApplicationSkills = [];
        var skillIdDeleting = null;
        var rowIndexDeleting = null;

        self.employeeSkills = [];
        self.dialogConfirm = emMessage.summarySkill.dialogConfirm;
        self.dialogConfirm.dialogTitle = $filter(constants.translate)(self.dialogConfirm.dialogTitle);
        self.dialogConfirm.dialogMessage = $filter(constants.translate)(self.dialogConfirm.dialogMessage);
        self.levels = constants.levels;
        self.isSkillEditing = emDetailSvc.getDisplayMode();
        self.years = datetimeSvc.getYears();
        self.isShowMode = true;

        self.onClickHeader = onClickHeader;
        self.isSkillRowEditing = isSkillRowEditing;
        self.onClickEditRow = onClickEditRow;
        self.onClickAddSkill = onClickAddSkill;
        self.onClickCancelEditRow = onClickCancelEditRow;
        self.onClickSaveSkill = onClickSaveSkill;
        self.isModifiedData = isModifiedData;
        self.onKeyDownYear = onKeyDownYear;
        self.onClickDeleteRow = onClickDeleteRow;
        self.onYes = onYes;
        self.getCssHeaderClass = getCssHeaderClass;

        var _isAddingSkill = false;

        init();

        function init() {
            param.employeeId = $stateParams.id;
            emDetailSvc.summarySkillResource(param).query(
            function (data) {
                $.each(data, function (index, employeeSkill) {
                    formatLevelName(employeeSkill);
                    formatLastUsed(employeeSkill);
                    self.employeeSkills.push(new emSkillModel(employeeSkill));
                    initialEmployeeSkills.push(new emSkillModel(employeeSkill));
                });
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.summarySkill.getEmployeeSkillError));
            });

            $scope.$watch('emSSCtrl.employeeSkills', function () {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(initialEmployeeSkills) && self.employeeSkills.length > 0 && !_isAddingSkill) {
                    var employeeSkillsFormat = copySkill(self.employeeSkills);
                    isModifiedSkill = JSON.stringify(employeeSkillsFormat) != JSON.stringify(initialEmployeeSkills);
                } else {
                    if (_isAddingSkill) {
                        isModifiedSkill = true;
                    }
                }
            }, true);

            $scope.$watch('emSSCtrl.isSkillEditing', function () {
                if (!self.isSkillEditing.value && isModifiedSkill) {
                    resetSkill();
                }

                rowIndexEditing = constants.newRowIndex;
                isModifiedSkill = false;
                _isAddingSkill = false;

                // Show summany skills detail when Summary Skills tab is being hidden
                if ($("#summary-skills").css("display") == 'none') {
                    self.onClickHeader();
                }
            }, true);
        }

        function formatLevelName(skill) {
            $.each(self.levels, function (index, level) {
                if (skill.LevelId == level.Id)
                    skill.LevelName = self.levels[index].Name;
            });
        }

        function formatLastUsed(skill) {
            $.each(self.years, function (index, year) {
                if (skill.LastUsed == year.value)
                    skill.LastUsed = self.years[index];
            });
        }

        function onClickHeader() {
            self.isShowMode = !self.isShowMode;
            $("#summary-skills").slideToggle("slow");
        }

        function isSkillRowEditing(rowIndex) {
            return rowIndex == rowIndexEditing;
        }

        function onClickEditRow(rowIndex) {
            if (!_isAddingSkill && rowIndexEditing == invalidRowIndex) {
                rowIndexEditing = rowIndex;
            }
        }

        function onClickAddSkill() {
            if (rowIndexEditing == constants.newRowIndex) {
                var skill = createSkill();
                self.employeeSkills.push(skill);
                rowIndexEditing = self.employeeSkills.length + constants.newRowIndex;
                _isAddingSkill = true;
            } else {
                toastr.warning($filter(constants.translate)(emMessage.editingData));
            }
            return;

            function createSkill() {
                var skill = new emSkillModel(null, true);
                skill.EmployeeId = employeeId;
                formatLevelName(skill);
                formatLastUsed(skill);
                return skill;
            }
        }

        function onClickCancelEditRow() {
            if (_isAddingSkill) {
                self.employeeSkills.pop();
            }
            resetSkill();
            rowIndexEditing = constants.newRowIndex;
            isModifiedSkill = false;
            _isAddingSkill = false;
        }

        function resetSkill() {
            self.employeeSkills = copySkill(initialEmployeeSkills);
        }

        function onClickSaveSkill(skillId, rowIndex) {
            var skillEditing = getRowEditing(rowIndex);
            skillEditing.LastUsed = skillEditing.LastUsed.value;
            param.skillId = skillId;
            loadingSvc.show();
            if (!_isAddingSkill) {
                emDetailSvc.summarySkillResource(param).update(skillEditing,
                    function () {
                        loadingSvc.close();
                        onSuccessSaveSkill();
                        toastr.success($filter(constants.translate)(emMessage.summarySkill.updateEmployeeSkillSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.summarySkill.updateEmployeeSkillError));
                    });
            } else {
                emDetailSvc.summarySkillResource(param).save(skillEditing,
                    function (newSkillId) {
                        loadingSvc.close();
                        skillEditing.Id = arrayResourceToInt(newSkillId);
                        onSuccessSaveSkill();
                        toastr.success($filter(constants.translate)(emMessage.summarySkill.addEmployeeSkillSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.summarySkill.insertEmployeeSkillError));
                    });
            }
            return;


            function onSuccessSaveSkill() {
                initialEmployeeSkills = copySkill(self.employeeSkills);
                rowIndexEditing = constants.newRowIndex;
                isModifiedSkill = false;
                _isAddingSkill = false;
            }
        }

        function getRowEditing(rowIndex) {
            var skill = new emSkillModel(null);
            skill = self.employeeSkills[rowIndex];
            return skill;
        }

        function isModifiedData(rowIndex) {
            return rowIndex == rowIndexEditing && isModifiedSkill;
        }

        function onKeyDownYear(event) {
            validationSvc.onKeyDownTextBox(event);
        }

        function onClickDeleteRow(skillId, rowIndex) {
            if (rowIndexEditing == constants.newRowIndex) {
                if (_isAddingSkill) {
                    $(".deleteIcon").attr("data-target", "");
                    return;
                }
                $(".deleteIcon").attr("data-target", "#confirmDialog");
                skillIdDeleting = skillId;
                rowIndexDeleting = rowIndex;
                $("#" + self.dialogConfirm.dialogId).modal('show');
            } else {
                toastr.warning($filter(constants.translate)(emMessage.editingData));
            }
        }

        function onYes() {
            param.skillId = skillIdDeleting;
            loadingSvc.show();
            emDetailSvc.summarySkillResource(param).delete(
                function () {
                    loadingSvc.close();
                    removeSkill();
                    toastr.success($filter(constants.translate)(emMessage.summarySkill.deleteEmployeeSkillSuccess));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.summarySkill.deleteEmployeeSkillError));
                });
            return;

            function removeSkill() {
                self.employeeSkills.splice(rowIndexDeleting, 1);
                initialEmployeeSkills = copySkill(self.employeeSkills);
                rowIndexEditing = constants.newRowIndex;
            }

            function copySkill(fromSkill) {
                var skillsFormat = [];
                $.each(fromSkill, function (item, skill) {
                    formatLevelName(skill);
                    formatLastUsed(skill);
                    skillsFormat.push(new emSkillModel(skill, false));
                });
                return skillsFormat;
            }
        }

        function getCssHeaderClass() {
            return self.isShowMode && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }
    }
})();