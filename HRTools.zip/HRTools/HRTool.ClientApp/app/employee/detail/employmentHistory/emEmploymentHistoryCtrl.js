﻿(function () {
    "use strict";
    angular.module("app").controller("emEmploymentHistoryCtrl", EmEmploymentHistoryCtrl);
    EmEmploymentHistoryCtrl.$inject = [
        'emDetailSvc', 'handleRequestSvc', 'messageHandleSvc', 'datetimeSvc',
        'styleSvc', 'validationSvc', 'emEmploymentHistoryModel', 'constants',
        'emConstants', 'message', 'emMessage', '$stateParams',
        '$scope', '$timeout', '$filter', 'loadingSvc'];
    function EmEmploymentHistoryCtrl(emDetailSvc, handleRequestSvc, messageHandleSvc, datetimeSvc,
        styleSvc, validationSvc, emEmploymentHistoryModel, constants,
        emConstants, message, emMessage, $stateParams,
        $scope, $timeout, $filter, loadingSvc) {
        /* jshint -W040 */
        var self = this;
        var param = {};
        var initialEmEmploymentHistories = [];
        var rowEditing;
        var rowIndexDeleting;

        self.isChangeData = false;
        self.employmentHistories = [];
        self.isEditMode = emDetailSvc.getDisplayMode();
        self.dialogConfirm = emMessage.employmentHistory.dialogConfirm;
        self.isAddingEmploymentHistory = false;
        self.isModifiedData = false;
        self.isValidDate = true;
        self.isShowMore = false;

        self.addEmployeeEmploymentHistory = addEmployeeEmploymentHistory;
        self.toogleHeader = toogleHeader;
        self.saveEmployeeEmploymentHistory = saveEmployeeEmploymentHistory;
        self.isEditingRow = isEditingRow;
        self.editEmploymentHistory = editEmploymentHistory;
        self.cancelEditEmploymentHistory = cancelEditEmploymentHistory;
        self.removeEmploymentHistory = removeEmploymentHistory;
        self.acceptDeleteEmEmploymentHistory = acceptDeleteEmEmploymentHistory;
        self.onChangeDate = onChangeDate;
        self.onSalaryKeyDown = onSalaryKeyDown;
        self.getCssHeaderClass = getCssHeaderClass;
        self.toggleMoreDetail = toggleMoreDetail;

        var _isShowMode = true;

        init();

        function init() {
            param.employeeId = $stateParams.id;
            var histories = emDetailSvc.employmentHistoryResource(param).query(
                function () {
                    $.each(histories, function (item, empHis) {
                        self.employmentHistories.push(new emEmploymentHistoryModel(empHis, true, true));
                        initialEmEmploymentHistories.push(new emEmploymentHistoryModel(empHis, true, true));
                    });
                    formatHistoryDate(self.employmentHistories);
                    formatHistoryDate(initialEmEmploymentHistories);
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                });

            $scope.$watch("ehCtrl.employmentHistories", function (newVal, oldVal) {
                if (newVal == oldVal)
                    return;
                else if (self.isAddingEmploymentHistory) {
                    self.isModifiedData = true;
                }
                else {
                    var employmentHistoriesFormat = copyEmploymentHistory(self.employmentHistories);
                    self.isModifiedData = JSON.stringify(employmentHistoriesFormat) != JSON.stringify(initialEmEmploymentHistories);
                }
            }, true);

            $scope.$watch('ehCtrl.isEditMode', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                rowEditing = constants.newRowIndex;
                if (self.isAddingEmploymentHistory) {
                    self.employmentHistories.pop();
                    self.isAddingEmploymentHistory = false;
                }
                if (self.isModifiedData) {
                    self.employmentHistories = copyEmploymentHistory(initialEmEmploymentHistories);
                }
                if ($("#employee-employment-history-detail").css('display') == "none") {
                    self.toogleHeader();
                }
                self.isShowMore = false;
            }, true);
            return;

            function formatHistoryDate(employmentHistoriesFormat) {
                $.each(employmentHistoriesFormat, function (item, employmentHistoryFormat) {
                    employmentHistoryFormat.StartTime = (employmentHistoryFormat.StartTime) ? moment(employmentHistoryFormat.StartTime).format(constants.formatDateDDMMYYYY) : "";
                    employmentHistoryFormat.EndTime = (employmentHistoryFormat.EndTime) ? moment(employmentHistoryFormat.EndTime).format(constants.formatDateDDMMYYYY) : "";
                });
            }
        }

        function copyEmploymentHistory(fromEmploymentHistory) {
            var employmentHistoriesFormat = [];
            $.each(fromEmploymentHistory, function (item, employmentHistory) {
                employmentHistoriesFormat.push(new emEmploymentHistoryModel(employmentHistory, true, true));
            });
            return employmentHistoriesFormat;
        }

        function addEmployeeEmploymentHistory() {
            if (rowEditing == emConstants.newRowIndex) {
                self.isChangeData = true;
                self.isAddingEmploymentHistory = true;
                var employmentHistory = new emEmploymentHistoryModel(null, true, false);
                self.employmentHistories.push(employmentHistory);
                rowEditing = self.employmentHistories.length - 1;
                self.employmentHistories[rowEditing].StartTime = moment(new Date()).format(constants.formatDateDDMMYYYY);
                self.employmentHistories[rowEditing].EndTime = moment(new Date()).format(constants.formatDateDDMMYYYY);
                $timeout(function () {
                    $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                    $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
                }, 0);

            } else {
                toastr.warning(message.editingData, message.warning);
            }
        }

        function toogleHeader() {
            _isShowMode = !_isShowMode;
            $("#employee-employment-history-detail").slideToggle("slow");
        }

        function saveEmployeeEmploymentHistory(employmentHistoryId) {
            param.employmentHistoryId = employmentHistoryId;
            self.employmentHistories[rowEditing].StartTime = datetimeSvc.convertDateForServerSide(self.employmentHistories[rowEditing].StartTime, false);
            self.employmentHistories[rowEditing].EndTime = datetimeSvc.convertDateForServerSide(self.employmentHistories[rowEditing].EndTime, false);
            loadingSvc.show();
            if (self.isAddingEmploymentHistory) {
                emDetailSvc.employmentHistoryResource(param).save(self.employmentHistories[rowEditing],
                    function (response) {
                        loadingSvc.close();
                        saveEmploymentHistorySuccess(response);
                        self.isChangeData = false;
                        toastr.success($filter(constants.translate)(emMessage.employmentHistory.addEmployeeEmploymentHistorySuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
            } else {
                emDetailSvc.employmentHistoryResource(param).update(self.employmentHistories[rowEditing],
                    function (response) {
                        loadingSvc.close();
                        saveEmploymentHistorySuccess(response);
                        self.isChangeData = false;
                        toastr.success($filter(constants.translate)(emMessage.employmentHistory.updateEmployeeEmploymentHistorySuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
            }
            return;

            function saveEmploymentHistorySuccess(responsedHistory) {
                self.employmentHistories[rowEditing].Id = responsedHistory.Id;
                self.employmentHistories[rowEditing].StartTime = (self.employmentHistories[rowEditing].StartTime) ? moment(self.employmentHistories[rowEditing].StartTime).format(constants.formatDateDDMMYYYY) : "";
                self.employmentHistories[rowEditing].EndTime = (self.employmentHistories[rowEditing].EndTime) ? moment(self.employmentHistories[rowEditing].EndTime).format(constants.formatDateDDMMYYYY) : "";
                initialEmEmploymentHistories = copyEmploymentHistory(self.employmentHistories);
                resetRowIndex();
            }
        }

        function resetRowIndex() {
            self.isAddingEmploymentHistory = false;
            self.isAddingEmploymentHistory = false;
            rowEditing = emConstants.newRowIndex;
            self.isModifiedData = false;
        }

        function isEditingRow(rowIndex) {
            return rowIndex == rowEditing;
        }

        function editEmploymentHistory(rowIndex) {
            self.isValidDate = true;
            if (!self.isAddingEmploymentHistory) { rowEditing = rowIndex; self.isChangeData = true; }
            else toastr.warning($filter(constants.translate)(message.addingData));
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function cancelEditEmploymentHistory() {
            self.employmentHistories = copyEmploymentHistory(initialEmEmploymentHistories);
            self.isChangeData = false;
            resetRowIndex();
            self.isValidDate = true;
        }

        function removeEmploymentHistory(employmentHistoryId, rowIndex, currentEmploymentHistory) {
            if (!self.isAddingEmploymentHistory) {
                rowIndexDeleting = rowIndex;
                param.employmentHistoryId = employmentHistoryId;
                param.isEmployee = currentEmploymentHistory.IsEmployee;
                $("#" + self.dialogConfirm.dialogId).modal('show');
            } else {
                toastr.warning($filter(constants.translate)(message.addingData));
            }
        }

        function acceptDeleteEmEmploymentHistory() {
            loadingSvc.show();
            emDetailSvc.employmentHistoryResource(param).delete(false,
                function (response) {
                    var result = handleRequestSvc.result(response);
                    if (result) {
                        loadingSvc.close();
                        self.employmentHistories.splice(rowIndexDeleting, 1);
                        initialEmEmploymentHistories = copyEmploymentHistory(self.employmentHistories);
                        toastr.success($filter(constants.translate)(emMessage.employmentHistory.deleteEmployeeEmploymentHistorySuccess));
                        resetRowIndex();
                    } else {
                        loadingSvc.close();
                        toastr.error($filter(constants.translate)(emMessage.employmentHistory.deleteEmployeeEmploymentHistoryError));
                    }
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                });
        }

        function onChangeDate() {
            var startTime = (self.employmentHistories[rowEditing].StartTime) ? moment(self.employmentHistories[rowEditing].StartTime, constants.formatDateDDMMYYYY) : "";
            var endTime = (self.employmentHistories[rowEditing].EndTime) ? moment(self.employmentHistories[rowEditing].EndTime, constants.formatDateDDMMYYYY) : "";
            if (!startTime || !endTime) {
                self.isValidDate = true;
                return;
            }
            var diff = endTime.diff(startTime, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function onSalaryKeyDown(event) {
            validationSvc.onKeyDownTextBox(event);
        }

        function getCssHeaderClass() {
            return _isShowMode && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function toggleMoreDetail(object) {
            object.isShowMore = !object.isShowMore;
        }
    }
})();
