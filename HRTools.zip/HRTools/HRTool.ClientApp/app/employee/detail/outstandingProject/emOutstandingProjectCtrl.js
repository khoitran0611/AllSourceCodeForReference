﻿(function () {
    "use strict";
    angular.module("app").controller("emOutstandingProjectCtrl", EmOutstandingProjectCtrl);
    EmOutstandingProjectCtrl.$inject = [
        'emDetailSvc', 'handleRequestSvc', 'messageHandleSvc',
        'datetimeSvc', 'styleSvc', 'validationSvc', 'permissionSvc',
        'emOutstandingProjectModel', 'constants',
        'emConstants', 'message', 'emMessage',
        '$stateParams', '$scope', '$timeout',
        '$filter', 'loadingSvc'];
    function EmOutstandingProjectCtrl(emDetailSvc, handleRequestSvc, messageHandleSvc, datetimeSvc, styleSvc, validationSvc, permissionSvc,
        emOutstandingProjectModel, constants, emConstants, message, emMessage,
        $stateParams, $scope, $timeout, $filter, loadingSvc) {
        /* jshint -W040 */
        var self = this;
        var param = {};
        var initialOutstandingProjects = [];
        var rowEditing;
        var rowIndexDeleting;

        self.outstandingProjects = [];
        self.isEditMode = emDetailSvc.getDisplayMode();
        self.isShowMoreDetail = {};
        self.currentUserPermission = {
            update: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_EditEmployeeInfo)
        };

        self.dialogConfirm = emMessage.outstandingProject.dialogConfirm;
        self.isModifiedData = false;
        self.isValidDate = true;

        self.getHeaderStyle = getHeaderStyle;
        self.viewMoreDetail = viewMoreDetail;
        self.addOutstandingProject = addOutstandingProject;
        self.toogleHeader = toogleHeader;
        self.saveOutstandingProject = saveOutstandingProject;
        self.isEditingRow = isEditingRow;
        self.editOutstandingProject = editOutstandingProject;
        self.cancelEditOutstandingProject = cancelEditOutstandingProject;
        self.removeOutstandingProject = removeOutstandingProject;
        self.acceptDeleteOutstandingProject = acceptDeleteOutstandingProject;
        self.onChangeDate = onChangeDate;
        self.getCssHeaderClass = getCssHeaderClass;

        var _isAddingOutstandingProject = false;
        var _isShowMode = true;

        init();

        function init() {
            param.employeeId = $stateParams.id;
            var projects = emDetailSvc.outstandingProjectResource(param).query(
                function () {
                    $.each(projects, function (item, empOst) {
                        self.outstandingProjects.push(new emOutstandingProjectModel(empOst, true));
                        initialOutstandingProjects.push(new emOutstandingProjectModel(empOst, true));
                    });
                    formatProjectDate(self.outstandingProjects);
                    formatProjectDate(initialOutstandingProjects);
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                });

            $scope.$watch("opCtrl.outstandingProjects", function (newValue, oldValue) {
                if (newValue == oldValue)
                    return;
                var outstandingProjectsFormat = copyOutstandingProject(self.outstandingProjects);
                self.isModifiedData = JSON.stringify(outstandingProjectsFormat) != JSON.stringify(initialOutstandingProjects);
            }, true);

            $scope.$watch('opCtrl.isEditMode', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                self.isChangeData = false;
                rowEditing = constants.newRowIndex;
                if (_isAddingOutstandingProject) {
                    self.outstandingProjects.pop();
                    _isAddingOutstandingProject = false;
                    self.isChangeData = false;
                }
                if (self.isModifiedData) {
                    self.outstandingProjects = copyOutstandingProject(initialOutstandingProjects);
                }
                if ($("#employee-outstanding-project-detail").css('display') == "none") {
                    self.toogleHeader();
                }
            }, true);

            return;

            function formatProjectDate(outstandingProjectsFormat) {
                $.each(outstandingProjectsFormat, function (item, outstandingProjectFormat) {
                    outstandingProjectFormat.StartTime = (outstandingProjectFormat.StartTime) ? moment(outstandingProjectFormat.StartTime).format(constants.formatDateDDMMYYYY) : "";
                    outstandingProjectFormat.EndTime = (outstandingProjectFormat.EndTime) ? moment(outstandingProjectFormat.EndTime).format(constants.formatDateDDMMYYYY) : "";
                });
            }
        }

        function copyOutstandingProject(fromOutstandingProject) {
            var outstandingProjectsFormat = [];
            $.each(fromOutstandingProject, function (item, outstandingProject) {
                outstandingProjectsFormat.push(new emOutstandingProjectModel(outstandingProject, true));
            });
            return outstandingProjectsFormat;
        }

        function getHeaderStyle() {
            return styleSvc.getHeaderStyle(self.isEditMode.value);
        }

        function viewMoreDetail(rowIndex) {
            self.isShowMoreDetail[rowIndex.toString()] = !self.isShowMoreDetail[rowIndex.toString()];
        }

        function addOutstandingProject() {
            if (self.isChangeData) return;
            if (rowEditing == emConstants.newRowIndex) {
                _isAddingOutstandingProject = true;
                self.isChangeData = true;
                var outstandingProject = new emOutstandingProjectModel(null);
                self.outstandingProjects.push(outstandingProject);
                rowEditing = self.outstandingProjects.length - 1;
                self.outstandingProjects[rowEditing].StartTime = (self.outstandingProjects[rowEditing].StartTime) ? moment(self.outstandingProjects[rowEditing].StartTime).format(constants.formatDateDDMMYYYY) : "";
                self.outstandingProjects[rowEditing].EndTime = (self.outstandingProjects[rowEditing].EndTime) ? moment(self.outstandingProjects[rowEditing].EndTime).format(constants.formatDateDDMMYYYY) : "";
                $timeout(function () {
                    $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                    $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
                }, 0);

            } else {
                toastr.warning(message.editingData);
            }
        }

        function toogleHeader() {
            _isShowMode = !_isShowMode;
            $("#employee-outstanding-project-detail").slideToggle("slow");
        }

        function saveOutstandingProject(outstandingProjectId) {
            param.outstandingProjectId = outstandingProjectId;
            self.outstandingProjects[rowEditing].StartTime = datetimeSvc.convertDateForServerSide(self.outstandingProjects[rowEditing].StartTime, false);
            self.outstandingProjects[rowEditing].EndTime = datetimeSvc.convertDateForServerSide(self.outstandingProjects[rowEditing].EndTime, false);
            loadingSvc.show();
            if (_isAddingOutstandingProject) {
                emDetailSvc.outstandingProjectResource(param).save(self.outstandingProjects[rowEditing],
                    function (response) {
                        loadingSvc.close();
                        saveOutstandingProjectSuccess(response);
                        toastr.success($filter(constants.translate)(emMessage.outstandingProject.addEmployeeOutstandingProjectSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
            } else {
                emDetailSvc.outstandingProjectResource(param).update(self.outstandingProjects[rowEditing],
                    function (response) {
                        loadingSvc.close();
                        saveOutstandingProjectSuccess(response);
                        toastr.success($filter(constants.translate)(emMessage.outstandingProject.updateEmployeeOutstandingProjectSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
            }
            return;

            function saveOutstandingProjectSuccess(responseProject) {
                self.isChangeData = false;
                _isAddingOutstandingProject = false;
                self.outstandingProjects[rowEditing].OutstandingProjectId = responseProject.OutstandingProjectId;
                self.outstandingProjects[rowEditing].StartTime = self.outstandingProjects[rowEditing].StartTime ? moment(self.outstandingProjects[rowEditing].StartTime).format(constants.formatDateDDMMYYYY) : "";
                self.outstandingProjects[rowEditing].EndTime = (self.outstandingProjects[rowEditing].EndTime) ? moment(self.outstandingProjects[rowEditing].EndTime).format(constants.formatDateDDMMYYYY) : "";
                self.outstandingProjects[rowEditing].Duration = responseProject.Duration;
                initialOutstandingProjects = copyOutstandingProject(self.outstandingProjects);
                resetRowIndex();
            }
        }

        function resetRowIndex() {
            _isAddingOutstandingProject = false;
            self.isPositionChanged = false;
            self.isProjectChanged = false;
            rowEditing = emConstants.newRowIndex;
            self.isModifiedData = false;
        }

        function isEditingRow(rowIndex) {
            return rowIndex == rowEditing;
        }

        function editOutstandingProject(rowIndex) {
            if (self.isChangeData) {
                toastr.warning($filter(constants.translate)(message.addingData));
                return;
            }
            self.isChangeData = true;
            self.isValidDate = true;
            _isAddingOutstandingProject = false;
            rowEditing = rowIndex;
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function cancelEditOutstandingProject() {
            self.isChangeData = false;
            _isAddingOutstandingProject = false;
            self.outstandingProjects = copyOutstandingProject(initialOutstandingProjects);
            resetRowIndex();
            self.isValidDate = true;
        }

        function removeOutstandingProject(rowIndex, currentOutstandingProject) {
            if (!_isAddingOutstandingProject) {
                rowIndexDeleting = rowIndex;
                param.outstandingProjectId = currentOutstandingProject.OutstandingProjectId;
                param.isEmployee = currentOutstandingProject.IsEmployee;
                $("#" + self.dialogConfirm.dialogId).modal('show');
            } else {
                toastr.warning($filter(constants.translate)(message.addingData));
            }
        }

        function acceptDeleteOutstandingProject() {
            loadingSvc.show();
            emDetailSvc.outstandingProjectResource(param).delete(false,
                function (response) {
                    var result = handleRequestSvc.result(response);
                    if (result) {
                        loadingSvc.close();
                        self.outstandingProjects.splice(rowIndexDeleting, 1);
                        initialOutstandingProjects = copyOutstandingProject(self.outstandingProjects);
                        toastr.success($filter(constants.translate)(emMessage.outstandingProject.deleteEmployeeOutstandingProjectSuccess));
                        resetRowIndex();
                    } else {
                        loadingSvc.close();
                        toastr.error($filter(constants.translate)(emMessage.outstandingProject.deleteEmployeeOutstandingProjectError));
                    }
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                });
        }

        function onChangeDate() {
            var startTime = self.outstandingProjects[rowEditing].StartTime ? moment(self.outstandingProjects[rowEditing].StartTime, constants.formatDateDDMMYYYY) : "";
            var endTime = self.outstandingProjects[rowEditing].EndTime ? moment(self.outstandingProjects[rowEditing].EndTime, constants.formatDateDDMMYYYY) : "";
            if (!startTime || !endTime) {
                self.isValidDate = true;
                return;
            }
            var diff = endTime.diff(startTime, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function getCssHeaderClass() {
            return _isShowMode && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }
    }
})();
