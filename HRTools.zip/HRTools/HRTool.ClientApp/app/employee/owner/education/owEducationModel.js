﻿(function () {
    "use strict";
    angular.module("app").factory('owEducationModel', owEducationModel);
    function owEducationModel() {
        var emEducationModel = function (employeeEducation, isEmployee, allowNull) {
            var self = this;
            self.Id = employeeEducation ? employeeEducation.Id : undefined;
            self.CandidateId = employeeEducation ? employeeEducation.CandidateId : undefined;
            self.EmployeeId = employeeEducation ? employeeEducation.EmployeeId : undefined;
            self.School = employeeEducation ? employeeEducation.School : '';
            self.Field = employeeEducation ? employeeEducation.Field : '';
            self.From = employeeEducation && employeeEducation.From ? employeeEducation.From : allowNull ? '' : new Date();
            self.To = employeeEducation && employeeEducation.To ? employeeEducation.To : allowNull ? '' : new Date();
            self.FromYear = employeeEducation && employeeEducation.FromYear ? employeeEducation.FromYear : '';
            self.ToYear = employeeEducation && employeeEducation.ToYear ? employeeEducation.ToYear : '';
            self.IsEmployee = isEmployee;
            return self;
        };
        return emEducationModel;
    }
})();