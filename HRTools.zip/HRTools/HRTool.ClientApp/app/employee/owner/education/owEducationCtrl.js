﻿(function () {
    "use strict";
    angular.module("app").controller("owEducationCtrl", OwEducationCtrl);
    OwEducationCtrl.$inject = [
        'emOwnerSvc', 'datetimeSvc', 'styleSvc', 'messageHandleSvc', 'objectSvc',
        'owEducationModel', 'constants', 'message', 'emMessage',
        '$stateParams', '$scope', '$timeout', '$filter', '$window', 'comparisonUtilSvc'
    ];
    function OwEducationCtrl(emOwnerSvc, datetimeSvc, styleSvc, messageHandleSvc, objectSvc,
            owEducationModel, constants, message, emMessage,
            $stateParams, $scope, $timeout, $filter, $window, comparisonUtilSvc) {
        /* jshint -W040 */
        var self = this;
        var param = {};
        var initialEmployeeEducations = [];
        var educations = [];
        var rowEditing;
        var rowIndexDeleting;

        self.employeeEducations = [];
        self.isEditMode = emOwnerSvc.getDisplayMode();
        self.isAddingEducation = false;
        self.isShowMode = true;
        self.isModifiedData = false;
        self.isValidDate = true;

        self.editingRow = editingRow;
        self.addEducation = addEducation;
        self.clickHeader = clickHeader;
        self.saveEducation = saveEducation;
        self.editRow = editRow;
        self.cancelEditing = cancelEditing;
        self.deleteRow = deleteRow;
        self.clickedYes = clickedYes;
        self.changeDate = changeDate;
        self.getHeaderStyle = getHeaderStyle;

        init();
        function init() {
            param.employeeId = JSON.parse($window.localStorage.getItem("currentuserlogin")).UserId;
            $scope.$watch("owEdCtrl.employeeEducations", function () {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(initialEmployeeEducations) && self.employeeEducations.length > 0 && !self.isAddingEducation) {
                    var educationsFormat = copyEducation(self.employeeEducations);
                    self.isModifiedData = JSON.stringify(educationsFormat) != JSON.stringify(initialEmployeeEducations);
                } else {
                    if (self.isAddingEducation) {
                        self.isModifiedData = true;
                    }
                }
            }, true);
            $scope.$watch('owEdCtrl.isEditMode', function () {
                rowEditing = constants.newRowIndex;
                if (self.isAddingEducation) {
                    self.employeeEducations.pop();
                    self.isAddingEducation = false;
                }
                if (self.isModifiedData && !self.isSkillEditing) {
                    self.employeeEducations = copyEducation(initialEmployeeEducations);
                }
                // Show education detail when Education tab is being hidden
                if ($("#employee-education-detail").css("display") == 'none') {
                    self.onClickHeader();
                }
            }, true);
            educations = emOwnerSvc.educationsOwnerResource(param).query(
                function () {
                    $.each(educations, function (item, education) {
                        self.employeeEducations.push(new owEducationModel(education, true, true));
                        initialEmployeeEducations.push(new owEducationModel(education, true, true));
                    });
                    formatEducationDate(self.employeeEducations);
                    formatEducationDate(initialEmployeeEducations);
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.education.getEmployeeEducationError));
                });
            self.dialogConfirm = emMessage.education.dialogConfirm;
            self.dialogConfirm.dialogTitle = $filter(constants.translate)(self.dialogConfirm.dialogTitle);
            self.dialogConfirm.dialogMessage = $filter(constants.translate)(self.dialogConfirm.dialogMessage);
            return;

            function formatEducationDate(educationsNeedToFormat) {
                $.each(educationsNeedToFormat, function (item, educationFormat) {
                    educationFormat.From = (educationFormat.From) ? moment(educationFormat.From).format(constants.formatDateDDMMYYYY) : "";
                    educationFormat.To = (educationFormat.To) ? moment(educationFormat.To).format(constants.formatDateDDMMYYYY) : "";
                    educationFormat.FromYear = (educationFormat.From) ? moment(educationFormat.From, constants.formatDateDDMMYYYY).year() : "";
                    educationFormat.ToYear = (educationFormat.To) ? moment(educationFormat.To, constants.formatDateDDMMYYYY).year() : "";
                });
            }
        }

        function editingRow(rowIndex) {
            return rowIndex == rowEditing;
        }

        function addEducation() {
            if (rowEditing == constants.newRowIndex) {
                self.isAddingEducation = true;
                var newEducation = new owEducationModel(null, true, false);
                self.employeeEducations.push(newEducation);
                rowEditing = self.employeeEducations.length - 1;
                self.employeeEducations[rowEditing].From = moment(self.employeeEducations[rowEditing].From).format(constants.formatDateDDMMYYYY);
                self.employeeEducations[rowEditing].To = moment(self.employeeEducations[rowEditing].To).format(constants.formatDateDDMMYYYY);
                $timeout(function () {
                    $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                    $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
                }, 0);

            } else {
                toastr.warning($filter(constants.translate)(emMessage.editingData));
            }
        }

        function clickHeader() {
            self.isShowMode = !self.isShowMode;
            $("#employee-education-detail").slideToggle("slow");
        }

        function saveEducation(educationId) {
            param.educationId = educationId;
            self.employeeEducations[rowEditing].From = datetimeSvc.convertDateForServerSide(self.employeeEducations[rowEditing].From, false);
            self.employeeEducations[rowEditing].To = datetimeSvc.convertDateForServerSide(self.employeeEducations[rowEditing].To, false);
            if (self.isAddingEducation) {
                emOwnerSvc.educationsOwnerResource(param).save(self.employeeEducations[rowEditing],
                    function (newEducationId) {
                        newEducationId = formatEmployeeId(newEducationId);
                        saveEducationSuccessFull(newEducationId);
                        toastr.success($filter(constants.translate)(emMessage.education.addEmployeeEducationSuccess));
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.education.addEmployeeEducationError));
                    });
            } else {
                emOwnerSvc.educationsOwnerResource(param).update(self.employeeEducations[rowEditing],
                    function () {
                        saveEducationSuccessFull();
                        toastr.success($filter(constants.translate)(emMessage.education.updateEmployeeEducationSuccess));
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.education.updateEmployeeEducationError));
                    });
            }
            return;

            function formatEmployeeId(id) {
                id = $.map(id, function (e) {
                    return e;
                }).join("");
                return id.substring(0, id.indexOf("["));
            }

            function saveEducationSuccessFull(newId) {
                self.employeeEducations[rowEditing].From = (self.employeeEducations[rowEditing].From) ? moment(self.employeeEducations[rowEditing].From).format(constants.formatDateDDMMYYYY) : "";
                self.employeeEducations[rowEditing].To = (self.employeeEducations[rowEditing].To) ? moment(self.employeeEducations[rowEditing].To).format(constants.formatDateDDMMYYYY) : "";
                self.employeeEducations[rowEditing].FromYear = (self.employeeEducations[rowEditing].From) ? moment(self.employeeEducations[rowEditing].From, constants.formatDateDDMMYYYY).year() : "";
                self.employeeEducations[rowEditing].ToYear = (self.employeeEducations[rowEditing].To) ? moment(self.employeeEducations[rowEditing].To, constants.formatDateDDMMYYYY).year() : "";
                self.employeeEducations[rowEditing].Id = newId ? newId : self.employeeEducations[rowEditing].Id;
                initialEmployeeEducations = copyEducation(self.employeeEducations);
                rowEditing = constants.newRowIndex;
                self.isAddingEducation = false;
                self.isModifiedData = false;
            }
        }

        function editRow(rowIndex) {
            if (!self.isAddingEducation) {
                rowEditing = rowIndex;
            } else {
                toastr.warning($filter(constants.translate)(emMessage.addingData));
            }
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function cancelEditing() {
            self.employeeEducations = copyEducation(initialEmployeeEducations);
            rowEditing = constants.newRowIndex;
            if (self.isAddingEducation) {
                self.isAddingEducation = false;
            }
            self.isValidDate = true;
        }

        function copyEducation(fromEducation) {
            var educationsFormat = [];
            $.each(fromEducation, function (item, education) {
                educationsFormat.push(new owEducationModel(education, true, true));
            });
            $.each(educationsFormat, function (item, educationFormat) {
                educationFormat.FromYear = (educationFormat.From) ? moment(educationFormat.From, constants.formatDateDDMMYYYY).year() : "";
                educationFormat.ToYear = (educationFormat.To) ? moment(educationFormat.To, constants.formatDateDDMMYYYY).year() : "";
            });
            return educationsFormat;
        }

        function deleteRow(educationId, rowIndex) {
            rowIndexDeleting = rowIndex;
            param.educationId = educationId;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function clickedYes() {
            emOwnerSvc.educationsOwnerResource(param).delete(
                    function () {
                        self.employeeEducations.splice(rowIndexDeleting, 1);
                        initialEmployeeEducations = copyEducation(self.employeeEducations);
                        toastr.success($filter(constants.translate)(emMessage.education.deleteEmployeeEducationSuccess));
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.education.deleteEmployeeEducationError));
                    });
        }

        function changeDate() {
            var fromDate = (self.employeeEducations[rowEditing].From) ? moment(self.employeeEducations[rowEditing].From, constants.formatDateDDMMYYYY) : "";
            var toDate = (self.employeeEducations[rowEditing].To) ? moment(self.employeeEducations[rowEditing].To, constants.formatDateDDMMYYYY) : "";
            if (toDate === "") {
                self.isValidDate = true;
                return;
            }
            var diff = toDate.diff(fromDate, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function getHeaderStyle() {
            return styleSvc.getHeaderStyle(self.isEditMode);
        }
    }
})();
