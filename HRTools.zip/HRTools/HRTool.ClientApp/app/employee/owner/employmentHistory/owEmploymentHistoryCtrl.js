﻿(function () {
    "use strict";
    angular.module("app").controller("owEmploymentHistoryCtrl", OwEmploymentHistoryCtrl);
    OwEmploymentHistoryCtrl.$inject = [
        'emOwnerSvc', 'handleRequestSvc', 'messageHandleSvc', 'datetimeSvc', 'styleSvc', 'validationSvc',
        'owEmploymentHistoryModel', 'constants', 'emConstants', 'message', 'emMessage',
        '$stateParams', '$scope', '$timeout', '$filter', "$window"
    ];
    function OwEmploymentHistoryCtrl(emOwnerSvc, handleRequestSvc, messageHandleSvc, datetimeSvc, styleSvc, validationSvc,
            owEmploymentHistoryModel, constants, emConstants, message, emMessage,
            $stateParams, $scope, $timeout, $filter, $window) {
        /* jshint -W040 */
        var param = {};
        var rowEditing;
        var initialEmEmploymentHistories = [];
        var self = this;
        var rowIndexDeleting;

        self.isChangeData = false;
        self.employmentHistories = [];
        self.isEditMode = emOwnerSvc.getDisplayMode();
        self.dialogConfirm = emMessage.employmentHistory.dialogConfirm;
        self.isAddingEmploymentHistory = false;
        self.isValidDate = true;
        self.isShowMode = true;
        self.isModifiedData = false;

        self.getHeaderStyle = getHeaderStyle;
        self.addEmployeeEmploymentHistory = addEmployeeEmploymentHistory;
        self.saveEmployeeEmploymentHistory = saveEmployeeEmploymentHistory;
        self.checkEditingRow = checkEditingRow;
        self.editEmploymentHistory = editEmploymentHistory;
        self.cancelEditEmploymentHistory = cancelEditEmploymentHistory;
        self.removeEmploymentHistory = removeEmploymentHistory;
        self.acceptDeleteEmEmploymentHistory = acceptDeleteEmEmploymentHistory;
        self.changeDate = changeDate;
        self.toogleHeader = toogleHeader;
        self.onSalaryKeyDown = onSalaryKeyDown;

        init();
        function init() {
            param.employeeId = JSON.parse($window.localStorage.getItem("currentuserlogin")).UserId;
            var employmentHistories = emOwnerSvc.employmentHistoryOwnerResource(param).query(
                          function () {
                              $.each(employmentHistories, function (item, empHis) {
                                  self.employmentHistories.push(new owEmploymentHistoryModel(empHis, true, true));
                                  initialEmEmploymentHistories.push(new owEmploymentHistoryModel(empHis, true, true));
                              });
                              formatEmployeeHistoryDate(self.employmentHistories);
                              formatEmployeeHistoryDate(initialEmEmploymentHistories);
                          },
                          function (xhr) {
                              messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                          });

            $scope.$watch("ehCtrl.employmentHistories", function (newVal, oldVal) {
                if (newVal == oldVal)
                    return;
                else if (self.isAddingEmploymentHistory) {
                    self.isModifiedData = true;
                }
                else {
                    var employmentHistoriesFormat = copyEmploymentHistory(self.employmentHistories);
                    self.isModifiedData = JSON.stringify(employmentHistoriesFormat) != JSON.stringify(initialEmEmploymentHistories);
                }
            }, true);

            $scope.$watch('ehCtrl.isEditMode', function () {
                rowEditing = constants.newRowIndex;
                if (self.isAddingEmploymentHistory) {
                    self.employmentHistories.pop();
                    self.isAddingEmploymentHistory = false;
                }
                if (self.isModifiedData) {
                    self.employmentHistories = copyEmploymentHistory(initialEmEmploymentHistories);
                }
                if ($("#employee-employment-history-detail").css('display') == "none") {
                    self.toogleHeader();
                }
            }, true);
            return;

            function formatEmployeeHistoryDate(histories) {
                $.each(histories, function (item, history) {
                    history.StartTime = (history.StartTime) ? moment(history.StartTime).format(constants.formatDateDDMMYYYY) : "";
                    history.EndTime = (history.EndTime) ? moment(history.EndTime).format(constants.formatDateDDMMYYYY) : "";
                });
            }
        }

        function getHeaderStyle() {
            return styleSvc.getHeaderStyle(self.isEditMode.value);
        }

        function addEmployeeEmploymentHistory() {
            if (rowEditing == emConstants.newRowIndex) {
                self.isChangeData = true;
                self.isAddingEmploymentHistory = true;
                var employmentHistory = new owEmploymentHistoryModel(null, true,false);
                self.employmentHistories.push(employmentHistory);
                rowEditing = self.employmentHistories.length - 1;
                self.employmentHistories[rowEditing].StartTime = moment(new Date()).format(constants.formatDateDDMMYYYY);
                self.employmentHistories[rowEditing].EndTime = moment(new Date()).format(constants.formatDateDDMMYYYY);
                $timeout(function () {
                    $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                    $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
                }, 0);

            } else {
                toastr.warning(message.editingData);
            }
        }

        function saveEmployeeEmploymentHistory(employmentHistoryId) {
            param.employmentHistoryId = employmentHistoryId;
            self.employmentHistories[rowEditing].StartTime = datetimeSvc.convertDateForServerSide(self.employmentHistories[rowEditing].StartTime, false);
            self.employmentHistories[rowEditing].EndTime = datetimeSvc.convertDateForServerSide(self.employmentHistories[rowEditing].EndTime, false);
            if (self.isAddingEmploymentHistory) {
                emOwnerSvc.employmentHistoryOwnerResource(param).save(self.employmentHistories[rowEditing],
                    function (response) {
                        saveEmploymentHistorySuccess(response);
                        self.isChangeData = false;
                        toastr.success($filter(constants.translate)(emMessage.employmentHistory.addEmployeeEmploymentHistorySuccess));
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
            } else {
                emOwnerSvc.employmentHistoryOwnerResource(param).update(self.employmentHistories[rowEditing],
                    function (response) {
                        saveEmploymentHistorySuccess(response);
                        self.isChangeData = false;
                        toastr.success($filter(constants.translate)(emMessage.employmentHistory.updateEmployeeEmploymentHistorySuccess));
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
            }
            return;

            function saveEmploymentHistorySuccess(responseHistory) {
                self.employmentHistories[rowEditing].Id = responseHistory.Id;
                self.employmentHistories[rowEditing].StartTime = (self.employmentHistories[rowEditing].StartTime) ? moment(self.employmentHistories[rowEditing].StartTime).format(constants.formatDateDDMMYYYY) : "";
                self.employmentHistories[rowEditing].EndTime = (self.employmentHistories[rowEditing].EndTime) ? moment(self.employmentHistories[rowEditing].EndTime).format(constants.formatDateDDMMYYYY) : "";
                initialEmEmploymentHistories = copyEmploymentHistory(self.employmentHistories);
                resetRowIndex();
            }
        }

        function checkEditingRow(rowIndex) {
            return rowIndex == rowEditing;
        }

        function editEmploymentHistory(rowIndex) {
            self.isValidDate = true;
            if (!self.isAddingEmploymentHistory) { rowEditing = rowIndex; self.isChangeData = true; }
            else toastr.warning($filter(constants.translate)(message.addingData));
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function cancelEditEmploymentHistory() {
            self.employmentHistories = copyEmploymentHistory(initialEmEmploymentHistories);
            self.isChangeData = false;
            resetRowIndex();
            self.isValidDate = true;
            self.isValidUrl = true;
        }

        function copyEmploymentHistory(fromEmploymentHistory) {
            var employmentHistoriesFormat = [];
            $.each(fromEmploymentHistory, function (item, employmentHistory) {
                employmentHistoriesFormat.push(new owEmploymentHistoryModel(employmentHistory, true, true));
            });
            return employmentHistoriesFormat;
        }

        function resetRowIndex() {
            self.isAddingEmploymentHistory = false;
            self.isAddingEmploymentHistory = false;
            rowEditing = emConstants.newRowIndex;
            self.isModifiedData = false;
        }

        function removeEmploymentHistory(employmentHistoryId, rowIndex, currentEmploymentHistory) {
            if (!self.isAddingEmploymentHistory) {
                rowIndexDeleting = rowIndex;
                param.employmentHistoryId = employmentHistoryId;
                param.isEmployee = currentEmploymentHistory.IsEmployee;
                $("#" + self.dialogConfirm.dialogId).modal('show');
            } else {
                toastr.warning($filter(constants.translate)(message.addingData));
            }
        }

        function acceptDeleteEmEmploymentHistory() {
            emOwnerSvc.employmentHistoryOwnerResource(param).delete(false,
                function (response) {
                    var result = handleRequestSvc.result(response);
                    if (result) {
                        self.employmentHistories.splice(rowIndexDeleting, 1);
                        initialEmEmploymentHistories = copyEmploymentHistory(self.employmentHistories);
                        toastr.success($filter(constants.translate)(emMessage.employmentHistory.deleteEmployeeEmploymentHistorySuccess));
                        resetRowIndex();
                    } else {
                        toastr.error($filter(constants.translate)(emMessage.employmentHistory.deleteEmployeeEmploymentHistoryError));
                    }
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                });
        }

        function changeDate() {
            var startTime = moment(self.employmentHistories[rowEditing].StartTime, constants.formatDateDDMMYYYY);
            var endTime = moment(self.employmentHistories[rowEditing].EndTime, constants.formatDateDDMMYYYY);
            var diff = endTime.diff(startTime, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function toogleHeader() {
            self.isShowMode = !self.isShowMode;
            $("#employee-employment-history-detail").slideToggle("slow");
        }

        function onSalaryKeyDown(event) {
            validationSvc.onKeyDownTextBox(event);
        }
    }
})();
