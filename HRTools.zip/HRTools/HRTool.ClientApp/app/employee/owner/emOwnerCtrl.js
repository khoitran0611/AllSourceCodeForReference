﻿(function () {
    'use strict';
    angular.module("app").controller('emOwnerCtrl', EmOwnerCtrl);
    EmOwnerCtrl.$inject = [
        "validationSvc", "emOwnerSvc", "permissionSvc", "positionSvc", "emailSvc", "datetimeSvc", "messageHandleSvc", "handleRequestSvc", "styleSvc", "authenticationSvc",
        "message", "emMessage", "constants", "emConstants", "emOwnerModel",
        "$scope", "$filter", "$timeout", "$state", "$window", "comparisonUtilSvc", "loadingSvc"
    ];
    function EmOwnerCtrl(validationSvc, emOwnerSvc, permissionSvc, positionSvc, emailSvc, datetimeSvc, messageHandleSvc, handleRequestSvc, styleSvc, authenticationSvc,
            message, emMessage, constants, emConstants, emOwnerModel,
            $scope, $filter, $timeout, $state, $window, comparisonUtilSvc, loadingSvc) {
        /* jshint -W040 */
        var hasImageUpload = false;
        var initialEmployeeBasicInfo = {};
        var param = {};
        var cvFiles = [];
        var self = this;

        self.pageTitle = emConstants.employeeDetailPage.title;
        self.employeeBasicInfo = {};
        self.isEditMode = emOwnerSvc.getDisplayMode();
        self.isEditEmployeeBasicInfo = false;
        self.Genders = translateGender();
        function translateGender() {
            var genderList = [];
            for (var index = 0; index < constants.genders.length; index++) {
                genderList.push({ Code: constants.genders[index].Code, Name: $filter(constants.translate)(constants.genders[index].Name) });
            }
            return genderList;
        }
        self.seletedPosition = { id: 0, text: "", optionsValue: undefined, optionsText: undefined };
        self.dialogConfirm = $filter(constants.translate)(emMessage.deleteEmployeedialogConfirm);

        self.permissionOfCurrentUser = {
            updateOwnInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_UpdateOwnerCV)
        };
        if (!self.permissionOfCurrentUser.updateOwnInfor) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }

        self.toogleEditMode = toogleEditMode;
        self.backToEmployeeList = backToEmployeeList;
        self.goToTop = goToTop;

        var _isModifiedData = false;

        init();

        function init() {
            styleSvc.hideButtonGoTop();
            hasImageUpload = false;
            param.employeeId = JSON.parse($window.localStorage.getItem("currentuserlogin")).UserId;
            emOwnerSvc.employeeOwnerResource(param).get(
            function (data) {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(data)) {
                    loadData(data, true);
                }
                loadingSvc.close();
            },
           function (xhr) {
               messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
               loadingSvc.close();
           });

            $scope.$watch("emCtrl.seletedPosition", function (newValue, oldValue) {
                if (self.seletedPosition.id != self.employeeBasicInfo.PositionId) {
                    _isModifiedData = true;
                    return;
                }
                if (newValue == oldValue)
                    return;
                _isModifiedData = JSON.stringify(self.employeeBasicInfo) != JSON.stringify(initialEmployeeBasicInfo);
            }, true);


            $scope.$watch("emCtrl.employeeBasicInfo", function (newValue, oldValue) {
                if (self.seletedPosition.id != self.employeeBasicInfo.PositionId) {
                    _isModifiedData = true;
                    return;
                }
                if (newValue == oldValue)
                    return;
                _isModifiedData = JSON.stringify(self.employeeBasicInfo) != JSON.stringify(initialEmployeeBasicInfo);
            }, true);

            $scope.$on('$stateChangeStart',
               function () {
                   if (self.isEditMode.value)
                       emOwnerSvc.changeDisplayMode();
               });

        }

        function loadData(data) {
            self.employeeBasicInfo = new emOwnerModel(data);
            self.seletedPosition.id = self.employeeBasicInfo.PositionId;
            self.seletedPosition.text = self.employeeBasicInfo.PositionName;
            initialEmployeeBasicInfo = new emOwnerModel(data);
            loadCandidateFilesFromJson(data.CvFiles);
        }

        function loadCandidateFilesFromJson(data) {
            self.employeeBasicInfo.CvFiles = [];
            cvFiles = [];
            if (data) {
                for (var i = 0; i < data.length; i++) {
                    var dataFile = { FileId: data[i].FileId, JobApplicationId: data[i].JobApplicationId, Url: data[i].Url, FileName: data[i].FileName };
                    self.employeeBasicInfo.CvFiles.push(dataFile);
                    cvFiles.push(dataFile);
                }
            }
            self.employeeBasicInfo.FileName = self.employeeBasicInfo.CvFiles.length > 0 ? self.employeeBasicInfo.CvFiles[0].FileName || "" : "";
        }

        function toogleEditMode() {
            emOwnerSvc.changeDisplayMode();
            self.pageTitle = (self.isEditMode.value) ? emConstants.updateEmployeePageTitle : emConstants.employeeDetailPage.title;
        }

        function backToEmployeeList() {
            self.isEditEmployeeBasicInfo = false;
            $state.go("employees");
        }

        function goToTop() {
            $('body,html').animate({
                scrollTop: 0
            }, 400);
        }

    }
})();
