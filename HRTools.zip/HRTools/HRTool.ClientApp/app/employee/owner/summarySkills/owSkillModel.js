﻿(function () {
    "use strict";
    angular.module("app").factory('owSkillModel', owSkillModel);
    function owSkillModel() {
        var employeeSkillModel = function (employeeSkill) {
            /* jshint -W040 */
            var self = this;
            self.Id = employeeSkill ? employeeSkill.Id : undefined;
            self.CandidateId = employeeSkill ? employeeSkill.CandidateId : undefined;
            self.EmployeeId = employeeSkill ? employeeSkill.EmployeeId : undefined;
            self.SkillGroupId = employeeSkill ? employeeSkill.SkillGroupId : 1;
            self.SkillName = employeeSkill ? employeeSkill.SkillName : '';
            self.LevelId = employeeSkill ? employeeSkill.LevelId : 1;
            self.LevelName = employeeSkill ? employeeSkill.LevelName : '';
            self.Year = employeeSkill ? employeeSkill.Year : 0;
            self.LastUsed = employeeSkill ? employeeSkill.LastUsed : (new Date()).getFullYear();
            self.IsEmployee = true;
            return self;
        };
        return employeeSkillModel;
    }
})();