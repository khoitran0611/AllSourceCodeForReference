﻿(function () {
    "use strict";
    angular.module("app").controller('owSummarySkillsCtrl', OwSummarySkillsCtrl);
    OwSummarySkillsCtrl.$inject = [
        'emOwnerSvc', 'validationSvc', 'styleSvc', 'datetimeSvc', 'messageHandleSvc',
        'owSkillModel', 'constants', 'emConstants', 'message', 'emMessage',
        '$stateParams', '$scope', '$filter', '$window', 'comparisonUtilSvc'
    ];
    function OwSummarySkillsCtrl(emOwnerSvc, validationSvc, styleSvc, datetimeSvc, messageHandleSvc,
            owSkillModel, constants, emConstants, message, emMessage,
            $stateParams, $scope, $filter, $window, comparisonUtilSvc) {
        /* jshint -W040 */
        var param = {};
        var initialDatabaseSkills = [];
        var initialToolSkills = [];
        var initialOtherSkills = [];
        var self = this;
        var rowIndexEditing = null;
        var currentSkillGroupId = null;
        var invalidRowIndex = constants.newRowIndex;
        var invalidSkillGroupId = constants.newRowIndex;
        var employeeId = $stateParams.id;
        var isModifiedSkill = false;
        var initialApplicationSkills = [];
        var skillIdDeleting = null;
        var rowIndexDeleting = null;
        var currentSkillGroupIdDeleting = null;

        self.applicationSkills = [];
        self.databaseSkills = [];
        self.toolSkills = [];
        self.othersSkills = [];
        self.dialogConfirm = emMessage.summarySkill.dialogConfirm;
        self.dialogConfirm.dialogTitle = $filter(constants.translate)(self.dialogConfirm.dialogTitle);
        self.dialogConfirm.dialogMessage = $filter(constants.translate)(self.dialogConfirm.dialogMessage);
        self.levels = constants.levels;
        self.isSkillEditing = emOwnerSvc.getDisplayMode();
        self.headerCss = styleSvc.getHeaderStyle(self.isSkillEditing.value);
        self.years = datetimeSvc.getYears();
        self.isShowMode = true;

        self.clickHeader = clickHeader;
        self.isSkillRowEditing = isSkillRowEditing;
        self.editRow = editRow;
        self.addSkill = addSkill;
        self.cancelSkill = cancelSkill;
        self.saveSkill = saveSkill;
        self.isModifiedData = isModifiedData;
        self.checkKeyDown = checkKeyDown;
        self.deleteRow = deleteRow;
        self.clickYes = clickYes;
        self.getLevelName = getLevelName;

        var _isAddingSkill = false;

        init();

        function init() {
            param.employeeId = JSON.parse($window.localStorage.getItem("currentuserlogin")).UserId;
            var employeeSkills = emOwnerSvc.summarySkillOwnerResource(param).query(
                function () {
                    $.each(employeeSkills, function (index, employeeSkill) {
                        var groupId = employeeSkill.SkillGroupId;
                        switch (groupId) {
                            case emConstants.employeeSummarySkill.applicationSkills:
                                self.applicationSkills.push(new owSkillModel(employeeSkill, true));
                                $.each(self.applicationSkills, function (skillIndex, skill) {
                                    formatLevelName(skill);
                                    formatLastUsed(skill);
                                });
                                initialApplicationSkills.push(new owSkillModel(employeeSkill, true));
                                $.each(initialApplicationSkills, function (skillIndex, skill) {
                                    formatLevelName(skill);
                                    formatLastUsed(skill);
                                });
                                break;
                            case emConstants.employeeSummarySkill.databaseSkills:
                                self.databaseSkills.push(new owSkillModel(employeeSkill, true));
                                $.each(self.databaseSkills, function (skillIndex, skill) {
                                    formatLevelName(skill);
                                    formatLastUsed(skill);
                                });
                                initialDatabaseSkills.push(new owSkillModel(employeeSkill, true));
                                $.each(initialDatabaseSkills, function (skillIndex, skill) {
                                    formatLevelName(skill);
                                    formatLastUsed(skill);
                                });
                                break;
                            case emConstants.employeeSummarySkill.toolSkills:
                                self.toolSkills.push(new owSkillModel(employeeSkill, true));
                                $.each(self.toolSkills, function (skillIndex, skill) {
                                    formatLevelName(skill);
                                    formatLastUsed(skill);
                                });
                                initialToolSkills.push(new owSkillModel(employeeSkill, false));
                                $.each(initialToolSkills, function (skillIndex, skill) {
                                    formatLevelName(skill);
                                    formatLastUsed(skill);
                                });
                                break;
                            case emConstants.employeeSummarySkill.othersSkills:
                                self.othersSkills.push(new owSkillModel(employeeSkill, true));
                                $.each(self.othersSkills, function (skillIndex, skill) {
                                    formatLevelName(skill);
                                    formatLastUsed(skill);
                                });
                                initialOtherSkills.push(new owSkillModel(employeeSkill, true));
                                $.each(initialOtherSkills, function (skillIndex, skill) {
                                    formatLevelName(skill);
                                    formatLastUsed(skill);
                                });
                                break;
                            default:
                        }
                    });
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.summarySkill.getEmployeeSkillError));
                });

            $scope.$watch('emSSCtrl.applicationSkills', function () {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(initialApplicationSkills) && self.applicationSkills.length > 0 && !_isAddingSkill) {
                    var applicationSkillsFormat = copySkill(self.applicationSkills);
                    isModifiedSkill = JSON.stringify(applicationSkillsFormat) != JSON.stringify(initialApplicationSkills);
                } else {
                    if (_isAddingSkill) {
                        isModifiedSkill = true;
                    }
                }
            }, true);

            $scope.$watch('emSSCtrl.databaseSkills', function () {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(initialDatabaseSkills) && self.databaseSkills.length > 0 && !_isAddingSkill) {
                    var databaseSkillsFormat = copySkill(self.databaseSkills);
                    isModifiedSkill = JSON.stringify(databaseSkillsFormat) != JSON.stringify(initialDatabaseSkills);
                } else {
                    if (_isAddingSkill) {
                        isModifiedSkill = true;
                    }
                }
            }, true);

            $scope.$watch('emSSCtrl.toolSkills', function () {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(initialToolSkills) && self.toolSkills.length > 0 && !_isAddingSkill) {
                    var toolSkillsFormat = copySkill(self.toolSkills);
                    isModifiedSkill = JSON.stringify(toolSkillsFormat) != JSON.stringify(initialToolSkills);
                } else {
                    if (_isAddingSkill) {
                        isModifiedSkill = true;
                    }
                }
            }, true);

            $scope.$watch('emSSCtrl.othersSkills', function () {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(initialOtherSkills) && self.othersSkills.length > 0 && !_isAddingSkill) {
                    var otherSkillsFormat = copySkill(self.othersSkills);
                    isModifiedSkill = JSON.stringify(otherSkillsFormat) != JSON.stringify(initialOtherSkills);
                } else {
                    if (_isAddingSkill) {
                        isModifiedSkill = true;
                    }
                }
            }, true);

            $scope.$watch('emSSCtrl.isSkillEditing', function () {
                if (!self.isSkillEditing.value && isModifiedSkill) {
                    resetSkill();
                }
                rowIndexEditing = constants.newRowIndex;
                currentSkillGroupId = constants.newRowIndex;
                isModifiedSkill = false;
                _isAddingSkill = false;

                if ($("#summary-skills").css("display") == 'none') {
                    self.clickHeader();
                }
            }, true);
        }

        function formatLevelName(skill) {
            $.each(self.levels, function (index, level) {
                if (skill.LevelId == level.Id)
                    skill.LevelName = self.levels[index].Name;
            });
        }

        function formatLastUsed(skill) {
            $.each(self.years, function (index, year) {
                if (skill.LastUsed == year.value)
                    skill.LastUsed = self.years[index];
            });
        }

        function clickHeader() {
            self.isShowMode = !self.isShowMode;
            $("#summary-skills").slideToggle("slow");
        }

        function isSkillRowEditing(rowIndex, skillGroupId) {
            return rowIndex == rowIndexEditing && skillGroupId == currentSkillGroupId;
        }

        function editRow(rowIndex, skillGroupId) {
            if (!_isAddingSkill && rowIndexEditing == invalidRowIndex && currentSkillGroupId == invalidSkillGroupId) {
                rowIndexEditing = rowIndex;
                currentSkillGroupId = skillGroupId;
            }
        }

        function addSkill(skillGroupId) {
            if (rowIndexEditing == constants.newRowIndex && currentSkillGroupId == constants.newRowIndex) {
                var skill = createSkill(skillGroupId);
                currentSkillGroupId = skillGroupId;
                switch (skillGroupId) {
                    case emConstants.employeeSummarySkill.applicationSkills:
                        self.applicationSkills.push(skill);
                        rowIndexEditing = self.applicationSkills.length + constants.newRowIndex;
                        break;
                    case emConstants.employeeSummarySkill.databaseSkills:
                        self.databaseSkills.push(skill);
                        rowIndexEditing = self.databaseSkills.length + constants.newRowIndex;
                        break;
                    case emConstants.employeeSummarySkill.toolSkills:
                        self.toolSkills.push(skill);
                        rowIndexEditing = self.toolSkills.length + constants.newRowIndex;
                        break;
                    case emConstants.employeeSummarySkill.othersSkills:
                        self.othersSkills.push(skill);
                        rowIndexEditing = self.othersSkills.length + constants.newRowIndex;
                        break;
                    default:
                }

                _isAddingSkill = true;
            } else {
                toastr.warning($filter(constants.translate)(emMessage.editingData));
            }
            return;

            function createSkill(groupId) {
                var skill = new owSkillModel(null, true);
                skill.EmployeeId = employeeId;
                skill.SkillGroupId = groupId;
                formatLevelName(skill);
                formatLastUsed(skill);
                return skill;
            }
        }

        function cancelSkill(skillGroupId) {
            if (_isAddingSkill) {
                switch (skillGroupId) {
                    case emConstants.employeeSummarySkill.applicationSkills:
                        self.applicationSkills.pop();
                        break;
                    case emConstants.employeeSummarySkill.databaseSkills:
                        self.databaseSkills.pop();
                        break;
                    case emConstants.employeeSummarySkill.toolSkills:
                        self.toolSkills.pop();
                        break;
                    case emConstants.employeeSummarySkill.othersSkills:
                        self.othersSkills.pop();
                        break;
                    default:
                }
            }
            resetSkill();
            rowIndexEditing = constants.newRowIndex;
            currentSkillGroupId = constants.newRowIndex;
            isModifiedSkill = false;
            _isAddingSkill = false;
            return;

            function resetSkill() {
                switch (currentSkillGroupId) {
                    case emConstants.employeeSummarySkill.applicationSkills:
                        self.applicationSkills = copySkill(initialApplicationSkills); break;
                    case emConstants.employeeSummarySkill.databaseSkills:
                        self.databaseSkills = copySkill(initialDatabaseSkills); break;
                    case emConstants.employeeSummarySkill.toolSkills:
                        self.toolSkills = copySkill(initialToolSkills); break;
                    case emConstants.employeeSummarySkill.othersSkills:
                        self.othersSkills = copySkill(initialOtherSkills); break;
                    default:
                }
            }
        }

        function saveSkill(skillId, rowIndex, groupSkillId) {
            var skillEditing = getRowEditing(rowIndex, groupSkillId);
            skillEditing.LastUsed = skillEditing.LastUsed.value;
            param.skillId = skillId;
            if (!_isAddingSkill) {
                emOwnerSvc.summarySkillOwnerResource(param).update(skillEditing,
                    function () {
                        onSuccessSaveSkill();
                        toastr.success($filter(constants.translate)(emMessage.summarySkill.updateEmployeeSkillSuccess));
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.summarySkill.updateEmployeeSkillError));
                    });
            } else {
                emOwnerSvc.summarySkillOwnerResource(param).save(skillEditing,
                    function (newSkillId) {
                        skillEditing.Id = formatSkillId(newSkillId);
                        onSuccessSaveSkill();
                        toastr.success($filter(constants.translate)(emMessage.summarySkill.addEmployeeSkillSuccess));
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.summarySkill.insertEmployeeSkillError));
                    });
            }
            return;

            function formatSkillId(id) {
                id = $.map(id, function (e) {
                    return e;
                }).join("");
                return id.substring(0, id.indexOf("["));
            }

            function onSuccessSaveSkill() {
                updateSkill();
                rowIndexEditing = constants.newRowIndex;
                currentSkillGroupId = constants.newRowIndex;
                isModifiedSkill = false;
                _isAddingSkill = false;
            }

            function updateSkill() {
                switch (currentSkillGroupId) {
                    case emConstants.employeeSummarySkill.applicationSkills:
                        initialApplicationSkills = copySkill(self.applicationSkills); break;
                    case emConstants.employeeSummarySkill.databaseSkills:
                        initialDatabaseSkills = copySkill(self.databaseSkills); break;
                    case emConstants.employeeSummarySkill.toolSkills:
                        initialToolSkills = copySkill(self.toolSkills); break;
                    case emConstants.employeeSummarySkill.othersSkills:
                        initialOtherSkills = copySkill(self.othersSkills); break;
                    default:
                }
            }
        }

        function getRowEditing(rowIndex, groupSkillId) {
            var skill = new owSkillModel(null, true);
            switch (groupSkillId) {
                case emConstants.employeeSummarySkill.applicationSkills:
                    skill = self.applicationSkills[rowIndex];
                    break;
                case emConstants.employeeSummarySkill.databaseSkills:
                    skill = self.databaseSkills[rowIndex];
                    break;
                case emConstants.employeeSummarySkill.toolSkills:
                    skill = self.toolSkills[rowIndex];
                    break;
                case emConstants.employeeSummarySkill.othersSkills:
                    skill = self.othersSkills[rowIndex];
                    break;
                default:
            }
            return skill;
        }

        function isModifiedData(rowIndex, skillGroupId) {
            return rowIndex == rowIndexEditing && skillGroupId == currentSkillGroupId && isModifiedSkill;
        }

        function checkKeyDown(e) {
            validationSvc.onKeyDownTextBox(e);
        }

        function deleteRow(skillId, rowIndex, groupSkillId) {
            if (rowIndexEditing == constants.newRowIndex && currentSkillGroupId == constants.newRowIndex) {
                if (_isAddingSkill) {
                    $(".deleteIcon").attr("data-target", "");
                    return;
                }
                $(".deleteIcon").attr("data-target", "#confirmDialog");
                skillIdDeleting = skillId;
                rowIndexDeleting = rowIndex;
                currentSkillGroupIdDeleting = groupSkillId;
                $("#" + self.dialogConfirm.dialogId).modal('show');
            } else {
                toastr.warning($filter(constants.translate)(emMessage.editingData));
            }

        }

        function clickYes() {
            param.skillId = skillIdDeleting;
            emOwnerSvc.summarySkillOwnerResource(param).delete(
                function () {
                    removeSkill();
                    toastr.success($filter(constants.translate)(emMessage.summarySkill.deleteEmployeeSkillSuccess));
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(emMessage.summarySkill.deleteEmployeeSkillError));
                });
            return;

            function removeSkill() {
                switch (currentSkillGroupIdDeleting) {
                    case emConstants.employeeSummarySkill.applicationSkills:
                        self.applicationSkills.splice(rowIndexDeleting, 1);
                        initialApplicationSkills = copySkill(self.applicationSkills);
                        break;
                    case emConstants.employeeSummarySkill.databaseSkills:
                        self.databaseSkills.splice(rowIndexDeleting, 1);
                        initialDatabaseSkills = copySkill(self.databaseSkills);
                        break;
                    case emConstants.employeeSummarySkill.toolSkills:
                        self.toolSkills.splice(rowIndexDeleting, 1);
                        initialToolSkills = copySkill(self.toolSkills);
                        break;
                    case emConstants.employeeSummarySkill.othersSkills:
                        self.othersSkills.splice(rowIndexDeleting, 1);
                        initialOtherSkills = copySkill(self.othersSkills);
                        break;
                    default:
                }
                rowIndexEditing = constants.newRowIndex;
                currentSkillGroupId = constants.newRowIndex;
            }
        }

        function copySkill(fromSkill) {
            var skillsFormat = [];
            $.each(fromSkill, function (item, skill) {
                formatLevelName(skill);
                formatLastUsed(skill);
                skillsFormat.push(new owSkillModel(skill, false));
            });
            return skillsFormat;
        }

        function getLevelName(levelId) {
            for (var index = 0; index < self.levels.length; index++) {
                if (self.levels[index].Id == levelId) return self.levels[index].Name;
            }
            return '';
        }
    }
})();