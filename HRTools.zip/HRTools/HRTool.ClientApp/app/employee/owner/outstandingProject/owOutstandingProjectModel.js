﻿(function () {
    'use strict';
    angular.module("app").factory('owOutstandingProjectModel', owOutstandingProjectModel);
    function owOutstandingProjectModel() {
        var temp = function (outstandingProject, allowNull) {
            /* jshint -W040 */
            var self = this;
            self.OutstandingProjectId = outstandingProject ? outstandingProject.OutstandingProjectId : undefined;
            self.CandidateId = outstandingProject ? outstandingProject.CandidateId : undefined;
            self.EmployeeId = outstandingProject ? outstandingProject.EmployeeId : undefined;
            self.ProjectName = outstandingProject ? outstandingProject.ProjectName : undefined;
            self.StartTime = outstandingProject && outstandingProject.StartTime ? outstandingProject.StartTime : allowNull ? "" : new Date();
            self.EndTime = outstandingProject && outstandingProject.EndTime ? outstandingProject.EndTime : allowNull ? "" : new Date();
            self.Position = outstandingProject ? outstandingProject.Position : undefined;
            self.GeneralInformation = outstandingProject ? outstandingProject.GeneralInformation : '';
            self.Description = outstandingProject ? outstandingProject.Description : '';
            self.InterfaceSystem = outstandingProject ? outstandingProject.InterfaceSystem : '';
            self.TechnologyUsed = outstandingProject ? outstandingProject.TechnologyUsed : '';
            self.Duration = outstandingProject ? outstandingProject.Duration : '';
            self.MoreDetailText = "More Detail ...";
            self.IsEmployee = true;
            return self;
        };
        return temp;
    }
})();
