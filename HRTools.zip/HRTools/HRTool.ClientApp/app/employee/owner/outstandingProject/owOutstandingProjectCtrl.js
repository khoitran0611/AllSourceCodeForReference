﻿(function () {
    "use strict";
    angular.module("app").controller("owOutstandingProjectCtrl", OwOutstandingProjectCtrl);
    OwOutstandingProjectCtrl.$inject = [
        'emOwnerSvc', 'handleRequestSvc', 'messageHandleSvc', 'datetimeSvc', 'styleSvc', 'validationSvc',
        'owOutstandingProjectModel', 'constants', 'emConstants', 'message', 'emMessage',
        '$stateParams', '$scope', '$timeout', '$filter', '$window'
    ];
    function OwOutstandingProjectCtrl(emOwnerSvc, handleRequestSvc, messageHandleSvc, datetimeSvc, styleSvc, validationSvc,
            owOutstandingProjectModel, constants, emConstants, message, emMessage,
            $stateParams, $scope, $timeout, $filter, $window) {
        /* jshint -W040 */
        var param = {};
        var initialOutstandingProjects = [];
        var self = this;
        var rowEditing;
        var rowIndexDeleting;

        self.outstandingProjects = [];
        self.isShowMoreDetail = {};
        self.isEditMode = emOwnerSvc.getDisplayMode();
        self.dialogConfirm = emMessage.outstandingProject.dialogConfirm;
        self.isModifiedData = false;
        self.isValidDate = true;
        self.isShowMode = true;

        self.addOutstandingProject = addOutstandingProject;
        self.toogleHeader = toogleHeader;
        self.saveOutstandingProject = saveOutstandingProject;
        self.checkEditingRow = checkEditingRow;
        self.editOutstandingProject = editOutstandingProject;
        self.cancelEditOutstandingProject = cancelEditOutstandingProject;
        self.removeOutstandingProject = removeOutstandingProject;
        self.acceptDeleteOutstandingProject = acceptDeleteOutstandingProject;
        self.changeDate = changeDate;
        self.getHeaderStyle = getHeaderStyle;
        self.viewMoreDetail = viewMoreDetail;

        var _isAddingOutstandingProject = false;

        init();

        function init() {
            param.employeeId = JSON.parse($window.localStorage.getItem("currentuserlogin")).UserId;
            var outstandingProjects = emOwnerSvc.outstandingProjectOwnerResource(param).query(
                function () {
                    $.each(outstandingProjects, function (item, empOst) {
                        self.outstandingProjects.push(new owOutstandingProjectModel(empOst, true));
                        initialOutstandingProjects.push(new owOutstandingProjectModel(empOst, true));
                    });
                    formatProjectDate(self.outstandingProjects);
                    formatProjectDate(initialOutstandingProjects);
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                });

            $scope.$watch("opCtrl.outstandingProjects", function (newValue, oldValue) {
                if (newValue == oldValue)
                    return;
                var outstandingProjectsFormat = copyOutstandingProject(self.outstandingProjects);
                self.isModifiedData = JSON.stringify(outstandingProjectsFormat) != JSON.stringify(initialOutstandingProjects);
            }, true);

            $scope.$watch('opCtrl.isEditMode', function () {
                self.isChangeData = false;
                rowEditing = constants.newRowIndex;
                if (_isAddingOutstandingProject) {
                    self.outstandingProjects.pop();
                    _isAddingOutstandingProject = false;
                    self.isChangeData = false;
                }
                if (self.isModifiedData) {
                    self.outstandingProjects = copyOutstandingProject(initialOutstandingProjects);
                }
                if ($("#employee-outstanding-project-detail").css('display') == "none") {
                    self.toogleHeader();
                }
            }, true);
            return;

            function formatProjectDate(projects) {
                $.each(projects, function (item, project) {
                    project.StartTime = (project.StartTime) ? moment(project.StartTime).format(constants.formatDateDDMMYYYY) : "";
                    project.EndTime = (project.EndTime) ? moment(project.EndTime).format(constants.formatDateDDMMYYYY) : "";
                });
            }
        }

        function addOutstandingProject() {
            if (self.isChangeData) return;
            if (rowEditing == emConstants.newRowIndex) {
                _isAddingOutstandingProject = true;
                self.isChangeData = true;
                var outstandingProject = new owOutstandingProjectModel(null);
                self.outstandingProjects.push(outstandingProject);
                rowEditing = self.outstandingProjects.length - 1;
                self.outstandingProjects[rowEditing].StartTime = (self.outstandingProjects[rowEditing].StartTime) ? moment(self.outstandingProjects[rowEditing].StartTime).format(constants.formatDateDDMMYYYY) : "";
                self.outstandingProjects[rowEditing].EndTime = (self.outstandingProjects[rowEditing].EndTime) ? moment(self.outstandingProjects[rowEditing].EndTime).format(constants.formatDateDDMMYYYY) : "";
                $timeout(function () {
                    $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                    $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
                }, 0);

            } else {
                toastr.warning(message.editingData);
            }
        }

        function toogleHeader() {
            self.isShowMode = !self.isShowMode;
            $("#employee-outstanding-project-detail").slideToggle("slow");
        }

        function saveOutstandingProject(outstandingProjectId) {
            param.outstandingProjectId = outstandingProjectId;
            self.outstandingProjects[rowEditing].StartTime = datetimeSvc.convertDateForServerSide(self.outstandingProjects[rowEditing].StartTime, false);
            self.outstandingProjects[rowEditing].EndTime = datetimeSvc.convertDateForServerSide(self.outstandingProjects[rowEditing].EndTime, false);
            if (_isAddingOutstandingProject) {
                emOwnerSvc.outstandingProjectOwnerResource(param).save(self.outstandingProjects[rowEditing],
                    function (response) {
                        saveOutstandingProjectSuccess(response);
                        toastr.success($filter(constants.translate)(emMessage.outstandingProject.addEmployeeOutstandingProjectSuccess));
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
            } else {
                emOwnerSvc.outstandingProjectOwnerResource(param).update(self.outstandingProjects[rowEditing],
                    function (response) {
                        saveOutstandingProjectSuccess(response);
                        toastr.success($filter(constants.translate)(emMessage.outstandingProject.updateEmployeeOutstandingProjectSuccess));
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
            }
            return;

            function saveOutstandingProjectSuccess(responseProject) {
                self.isChangeData = false;
                _isAddingOutstandingProject = false;
                self.outstandingProjects[rowEditing].OutstandingProjectId = responseProject.OutstandingProjectId;
                self.outstandingProjects[rowEditing].StartTime = self.outstandingProjects[rowEditing].StartTime ? moment(self.outstandingProjects[rowEditing].StartTime).format(constants.formatDateDDMMYYYY) : "";
                self.outstandingProjects[rowEditing].EndTime = (self.outstandingProjects[rowEditing].EndTime) ? moment(self.outstandingProjects[rowEditing].EndTime).format(constants.formatDateDDMMYYYY) : "";
                self.outstandingProjects[rowEditing].Duration = responseProject.Duration;
                initialOutstandingProjects = copyOutstandingProject(self.outstandingProjects);
                resetRowIndex();
            }
        }

        function checkEditingRow(rowIndex) {
            return rowIndex == rowEditing;
        }

        function editOutstandingProject(rowIndex) {
            if (self.isChangeData){
                toastr.warning($filter(constants.translate)(message.addingData));
                return;
            }
            self.isChangeData = true;
            self.isValidDate = true;
            _isAddingOutstandingProject = false;
            rowEditing = rowIndex;
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function cancelEditOutstandingProject() {
            self.isChangeData = false;
            _isAddingOutstandingProject = false;
            self.outstandingProjects = copyOutstandingProject(initialOutstandingProjects);
            resetRowIndex();
            self.isValidDate = true;
        }

        function copyOutstandingProject(fromOutstandingProject) {
            var outstandingProjectsFormat = [];
            $.each(fromOutstandingProject, function (item, outstandingProject) {
                outstandingProjectsFormat.push(new owOutstandingProjectModel(outstandingProject, true));
            });
            return outstandingProjectsFormat;
        }

        function removeOutstandingProject(rowIndex, currentOutstandingProject) {
            if (!_isAddingOutstandingProject) {
                rowIndexDeleting = rowIndex;
                param.outstandingProjectId = currentOutstandingProject.OutstandingProjectId;
                param.isEmployee = currentOutstandingProject.IsEmployee;
                $("#" + self.dialogConfirm.dialogId).modal('show');
            } else {
                toastr.warning($filter(constants.translate)(message.addingData));
            }
        }

        function acceptDeleteOutstandingProject() {
            emOwnerSvc.outstandingProjectOwnerResource(param).delete(false,
                function (response) {
                    var result = handleRequestSvc.result(response);
                    if (result) {
                        self.outstandingProjects.splice(rowIndexDeleting, 1);
                        initialOutstandingProjects = copyOutstandingProject(self.outstandingProjects);
                        toastr.success($filter(constants.translate)(emMessage.outstandingProject.deleteEmployeeOutstandingProjectSuccess));
                        resetRowIndex();
                    } else {
                        toastr.error($filter(constants.translate)(emMessage.outstandingProject.deleteEmployeeOutstandingProjectError));
                    }
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                });
        }

        function resetRowIndex() {
            _isAddingOutstandingProject = false;
            self.isPositionChanged = false;
            self.isProjectChanged = false;
            rowEditing = emConstants.newRowIndex;
            self.isModifiedData = false;
        }

        function changeDate() {
            var startTime = self.outstandingProjects[rowEditing].StartTime ? moment(self.outstandingProjects[rowEditing].StartTime, constants.formatDateDDMMYYYY) : "";
            var endTime = self.outstandingProjects[rowEditing].EndTime ? moment(self.outstandingProjects[rowEditing].EndTime, constants.formatDateDDMMYYYY) : "";
            var diff = endTime.diff(startTime, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function getHeaderStyle() {
            return styleSvc.getHeaderStyle(self.isEditMode.value);
        }

        function viewMoreDetail(rowIndex) {
            self.isShowMoreDetail[rowIndex.toString()] = !self.isShowMoreDetail[rowIndex.toString()];
        }
    }
})();
