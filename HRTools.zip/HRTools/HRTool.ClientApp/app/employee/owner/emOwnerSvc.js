﻿(function () {
    "use strict";
    angular.module("app").factory('emOwnerSvc', emOwnerSvc);
    emOwnerSvc.$inject = ["$resource", "emConstants", "constants"];
    function emOwnerSvc($resource, emConstants, constants) {

        var isEditMode = { value: false };

        var service = {
            changeDisplayMode: changeDisplayMode,
            getDisplayMode: getDisplayMode,
            employeeOwnerResource: employeeOwnerResource,
            summarySkillOwnerResource: summarySkillOwnerResource,
            employmentHistoryOwnerResource: employmentHistoryOwnerResource,
            outstandingProjectOwnerResource: outstandingProjectOwnerResource,
            educationsOwnerResource: educationsOwnerResource
        };
        return service;


        function changeDisplayMode() {
            isEditMode.value = !isEditMode.value;
        }
        function getDisplayMode() {
            return isEditMode;
        }
        function employeeOwnerResource(param) {
            return $resource(
                constants.apiUrl + 'employee-owner/:id',
                     { id: param.employeeId }, { "update": { method: "PUT" } });
        }
        function summarySkillOwnerResource(param) {
            return $resource(
             constants.apiUrl + 'employee-owner/:employeeId/skills/:skillId',
                  { employeeId: param.employeeId, skillId: param.skillId }, { "update": { method: "PUT" } });
        }
        function employmentHistoryOwnerResource(param) {
            return $resource(
                constants.apiUrl + 'employee-owner/:employeeId/employment-histories/:employmentHistoryId',
                     { employeeId: param.employeeId, employmentHistoryId: param.employmentHistoryId },
                            { "update": { method: "PUT" } });
        }
        function outstandingProjectOwnerResource(param) {
            return $resource(
               constants.apiUrl + 'employee-owner/:employeeId/outstanding-projects/:outstandingProjectId',
                    { employeeId: param.employeeId, outstandingProjectId: param.outstandingProjectId },
                           { "update": { method: "PUT" } });
        }
        function educationsOwnerResource(param) {
            return $resource(
                constants.apiUrl + 'employee-owner/:employeeId/educations/:educationId',
                     { employeeId: param.employeeId, educationId: param.educationId },
                            { "update": { method: "PUT" } });
        }
    }
})();
