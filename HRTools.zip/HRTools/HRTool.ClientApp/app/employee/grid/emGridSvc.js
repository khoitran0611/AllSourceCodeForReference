﻿(function () {
    'use strict';
    angular.module("app").service('emGridSvc', emGridSvc);
    emGridSvc.$inject = [
        'gridSvc', 'styleSvc', 'employeeSvc', 'messageHandleSvc', 'emGridModel', 'gridHeader',
        'message', 'constants', 'emConstants', '$filter', 'comparisonUtilSvc', 'loadingSvc'
    ];
    function emGridSvc(
        gridSvc, styleSvc, employeeSvc, messageHandleSvc, emGridModel, gridHeader,
        message, constants, emConstants, $filter, comparisonUtilSvc, loadingSvc) {
        var revealed = {
            getPagedDataAsync: getPagedDataAsync,
            gridInit: gridInit
        };
        return revealed;

        function getPagedDataAsync(self, $scope) {
            var result = self;
            result.isSearching = result.query ? true : false;
            if (!result.isSearching)
                $.jStorage.deleteKey(constants.localStorageKey.employeeSearch);
            var employeesList = employeeSvc.getEmployees(result.pageIndex, result.query, result.isSearching).get(
                function () {
                    $.jStorage.set(emConstants.jobCode, null);
                    result.data = [];
                    if (!comparisonUtilSvc.isNullOrUndefinedValue(employeesList.Data)) {
                        employeesList.Data.forEach(function (employeeData) {
                            var employee = new emGridModel(employeeData);
                            result.data.push(employee);
                        });

                    }
                    result.totalPages = employeesList.TotalPages;
                    result = gridSvc.setPagingData(result, $scope);
                    loadingSvc.close();
                    return result;
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    loadingSvc.close();
                });
            return result;
        }

        function gridInit(self, $scope) {
            var result = self;
            result.columnDefs = [
                new gridHeader('FullName', "Full_Name", '', true),
                new gridHeader("PositionName", "Position_Name", '', true),
                new gridHeader("WorkingStartDate", "Start_Working_Date", constants.formatDateTimeFilter, true),
                new gridHeader("Status", "Status", '', true),
                new gridHeader("Teams", "Team", '', true),
                new gridHeader("Profession", "Profession", '', true),
                new gridHeader("DateOfBirth", "DOB", constants.formatDateTimeFilter, false),
                new gridHeader("Domains", "Domain", '', false)
            ];
            result = gridSvc.init(result, $scope);
            return result;
        }
    }
})();