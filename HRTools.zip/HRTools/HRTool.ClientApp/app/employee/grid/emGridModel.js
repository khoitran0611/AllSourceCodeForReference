﻿(function () {
    "use strict";
    angular.module("app").factory('emGridModel', emGridModel);
    function emGridModel() {
        var temp = function (employee) {
            /* jshint -W040 */
            var self = this;
            self.EmployeeId = employee.EmployeeId || "";
            self.FullName = employee.FullName || "";
            self.Profession = employee.Profession || "";
            self.PositionName = employee.PositionName || "";
            self.WorkingStartDate = employee.WorkingStartDate || "";
            self.DateOfBirth = employee.DateOfBirth || "";
            self.Status = employee.Status || "";
            self.Skills = employee.Skills || "";
            self.Domains = employee.Domains || "";
            self.Teams = employee.Teams || "";
        };
        return temp;
    }
})();