﻿(function () {
    'use strict';
    angular.module("app").service('emSearchBoxInitialSvc', emSearchBoxInitialSvc);
    emSearchBoxInitialSvc.$inject = ['positionSvc', 'teamSvc'];
    function emSearchBoxInitialSvc(positionSvc, teamSvc) {
        var listPosition = [];
        var positions = positionSvc.getAllPositions().query(function () {
            for (var i = 0; i < positions.length; i++) {
                var item = { id: positions[i].PstId, text: positions[i].PstName };
                listPosition.push(item);
            }
        },
            function () {
            });

        var listWorkingTeam = [];
        var workingTeams = teamSvc.getTeams().query(
            function () {
                workingTeams.forEach(function (team) {
                    var item = { id: team.WgpId, text: team.WgpName };
                    listWorkingTeam.push(item);
                });
            },
            function () {

            });


        var workingStatus = [
            { key: 'probation', value: 'Probation', displayValue: 'Probation', isActive: false },
            { key: 'official', value: 'Official', displayValue: 'Official', isActive: false },
            { key: 'stoppedWorking', value: 'StoppedWorking', displayValue: 'StoppedWorking', isActive: false },
            { key: 'temporary', value: 'Temporary', displayValue: 'Temporary', isActive: false },
            { key: 'blackList', value: 'BlackList', displayValue: 'BlackList', isActive: false }
        ];

        var fieldSearch = [
            { field: 'fullName', value: 'FullName', displayName: 'Full Name', type: 'textfield', optionStyle: '', parent: '' },
            { field: 'position', value: 'PositionId', displayName: 'Position', type: 'select2', optionStyle: 'position', parent: '', initData: listPosition },
            { field: 'skill', value: 'SkillId', displayName: 'Skill(s)', type: 'textfield', optionStyle: '', parent: '' },
            { field: 'workingStartDate', value: 'WorkingStartDate', displayName: 'Work from', type: 'datepicker', optionStyle: '', parent: '' },
            { field: 'profession', value: 'Profession', displayName: 'Profession', type: 'textfield', optionStyle: '', parent: '' },
            { field: 'domain', value: 'Domain', displayName: 'Domain', type: 'textfield', optionStyle: '', parent: '' },
            { field: 'status', value: 'WorkingStatus', displayName: 'Working Status', type: 'dropdowncheckbox', optionStyle: '', parent: '', initData: workingStatus },
            { field: 'teams', value: 'WgpId', displayName: 'Working Team', type: 'select2', optionStyle: 'working team', parent: '', initData: listWorkingTeam }
        ];

        var fieldName = {
            fullName: 'fullName',
            applyPosition: 'applyPosition',
            skill: 'skill',
            workingStartDate: 'workingStartDate',
            profession: 'profession',
            domain: 'domain',
            status: 'status',
            experience: 'experience',
            workingTeams: 'workingTeams'
        };

        var listType = "employees-query-list-condition";
        var revealed = {
            fieldSearch: fieldSearch,
            fieldName: fieldName,
            listType: listType
        };

        return revealed;
    }
})();