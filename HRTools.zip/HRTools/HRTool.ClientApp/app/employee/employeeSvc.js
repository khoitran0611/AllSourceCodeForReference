﻿(function () {
    'use strict';
    angular.module("app").service('employeeSvc', employeeSvc);
    employeeSvc.$inject = ['$resource', 'emConstants', 'constants'];

    function employeeSvc($resource, emConstants, constants) {
            var revealed = {
                getEmployees: getEmployees,
                prepareForCreateContract: prepareForCreateContract,
                getDetailContract: getDetailContract,
                createContract: createContract,
                updateContract: updateContract,
                exportToPDF: exportToPDF
            };
            return revealed;

            /************************** EMPLOYEES LIST ***********************************/
            function getEmployees(pageIndex, inputQuery, isSearching) {
                if (!isSearching) {
                    return $resource(constants.apiUrl + 'employees?page=:page', { page: pageIndex, action: 'getAll' });
                } else {
                    return $resource(constants.apiUrl + 'employees?page=:page', { page: pageIndex, action: "getbysearchbox", querySearch: inputQuery });
                }
            }

            function prepareForCreateContract(employeeId, contractId) {
                return $resource(constants.apiUrl + 'employees/:employeeId/contracts/:contractId', { employeeId: employeeId, contractId: contractId, action: "prepareForCreate" });
            }

            function getDetailContract(employeeId, contractId) {
                return $resource(constants.apiUrl + 'employees/:employeeId/contracts/:contractId', { employeeId: 0, contractId: contractId });
            }

            function createContract(employeeId) {
                return $resource(constants.apiUrl + 'employees/:employeeId/contracts', { employeeId: employeeId });
            }

            function updateContract() {
                return $resource(constants.apiUrl + 'employees/:employeeId/contracts/:contractId', { employeeId: 0, contractId: 0 }, { 'update': { method: "PUT" } });
            }

            function exportToPDF(contractId) {
                return $resource(constants.apiUrl + 'employees/:employeeId/contracts/:contractId', { employeeId: 0, contractId: contractId, action: "exportContract" });
            }
        }
})();