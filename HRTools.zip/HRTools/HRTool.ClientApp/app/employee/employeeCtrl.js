﻿(function () {
    'use strict';
    angular.module("app").controller('employeeCtrl', EmployeeCtrl);
    EmployeeCtrl.$inject = ['emGridSvc', 'emSearchBoxInitialSvc', 'permissionSvc', 'authenticationSvc', 'messageHandleSvc',
        '$scope', '$filter', '$state',
        'constants', 'emConstants', 'comparisonUtilSvc'];
    function EmployeeCtrl(emGridSvc, emSearchBoxInitialSvc, permissionSvc, authenticationSvc, messageHandleSvc,
        $scope, $filter, $state,
        constants, emConstants, comparisonUtilSvc) {
        /* jshint -W040 */
        var self = this;
        self.currentUserPermissions = permissionSvc.getCurrentUserPermission();
        if (!self.currentUserPermissions.canViewEmployees) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.linktoCreateEmployee = constants.baseUrl + emConstants.linkToCreateEmployee;
        self.query = $.jStorage.get(constants.localStorageKey.employeeSearch) ? $.jStorage.get(constants.localStorageKey.employeeSearch).value : undefined;
        self.initDataSearchBox = emSearchBoxInitialSvc;
        self.pageIndex = constants.paging.firstPage;
        self.totalPages = 0;
        self.pagingOptions = {};
        self.showSelectionCheckbox = false;
        self.dataGrid = "employeeController.data";
        self.pagingEvent = "employeeController.pagingOptions";
        self.rowTemplate = "employee/grid/emGrid.html";
        self.headerCellTemplate = "employee/grid/headerCellTemplate.html";
        self.gridId = "emGrid";
        self.iconClass = "sprite-add-user-record";
        self.columnDefs = [];
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;
        self.showColumnMenu = true;
        self.collapsableSearch = true;
        self.bigMsg = self.smallMsg = 'employee';

        self.searchEmployee = searchEmployee;
        self.getPagedDataAsync = getPagedDataAsync;

        init();

        function init() {
            self = self.getPagedDataAsync(self);
            self = emGridSvc.gridInit(self, $scope);
        }

        function searchEmployee(method, query) {
            $.jStorage.set(constants.localStorageKey.employeeSearch, query);
            self.isSearching = (method == constants.callSearchApi.search) ? constants.activeSearch : !constants.activeSearch;
            self.query = (self.isSearching == constants.activeSearch) ? query.value : constants.stringEmpty;
            if (self.pagingOptions.currentPage == constants.paging.firstPage)
                self.getPagedDataAsync();
            else
                self.pageIndex = self.pagingOptions.currentPage = constants.paging.firstPage;
        }

        function getPagedDataAsync() {
            var jobCode = $.jStorage.get(emConstants.jobCode);
            if (!comparisonUtilSvc.isNullOrUndefinedValue(jobCode)) {
                self.query = emSearchBoxInitialSvc.fieldName.jobCode + ":(" + jobCode + ") " +
                    emSearchBoxInitialSvc.fieldName.isDeleted + ":(No)";
                self.isSearching = true;
            }
            self = emGridSvc.getPagedDataAsync(self, $scope);
            return self;
        }
    }
})();


