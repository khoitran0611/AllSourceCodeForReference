﻿(function () {
    "use strict";
    angular.module("app").constant('emMessage', {
        deleteEmployeeSuccess: "Delete_Employee_Error",
        deleteEmployeeError: "Delete_Employee_Error",
        updateEmployeeInfoSuccess: "Update_Employee_Info_Succcessfully",
        editingData: "Editing_Data_Warning",

        deleteEmployeedialogConfirm: {
            dialogId: "emDialogInfoConfirm",
            dialogTitle: "Confirm_Delete",
            dialogMessage: "Confirm_Delete_Employee"
        },
        deleteContractDialog: {
            dialogId: "emDeleteContract",
            dialogTitle: "Confirm_Delete",
            dialogMessage: "Contract.Confirm_Delete_Contract_File"
        },
        summarySkill: {
            dialogConfirm: {
                dialogId: "emDialogConfirmSummarySkill",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Skills.Do_You_Want_To_Delete_This_Skill"
            },
            updateEmployeeSkillSuccess: "Skills.Update_Employee_Skill_Successfully",
            updateEmployeeSkillError: "Skills.Error_When_Updating_Employee_Skill",
            getEmployeeSkillError: "Skills.Error_When_Getting_Employee_Skill",
            deleteEmployeeSkillSuccess: "Skills.Delete_Employee_Skill_Successfully",
            deleteEmployeeSkillError: "Skills.Error_When_Deleting_Employee_Skill",
            insertEmployeeSkillError: "Skills.Error_When_Adding_Employee_Skill",
            addEmployeeSkillSuccess: "Skills.Add_New_Employee_Skill_Successfully"
        },
        employmentHistory: {
            dialogConfirm: {
                dialogId: "emDialogConfirmEmploymentHistory",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Employment_History.Do_You_Want_To_Delete_This_Employment_History"
            },
            getEmployeeEmploymentHistory: "Employment_History.Error_When_Getting_Employee_Employment_History",
            addEmployeeEmploymentHistoryError: "Experience_Skills.Experience_Skills",
            updateEmployeeEmploymentHistoryError: "Employment_History.Error_When_Updating_Employee_Employment_History",
            addEmployeeEmploymentHistorySuccess: "Employment_History.Add_New_Employee_Employment_History_Successfully",
            updateEmployeeEmploymentHistorySuccess: "Employment_History.Update_Employee_Employment_History_Successfully",
            deleteEmployeeEmploymentHistoryError: "Employment_History.Error_When_Deleting_Employee_Employment_History",
            deleteEmployeeEmploymentHistorySuccess: "Experience_Skills.Delete_Employee_Employment_History_Successfully"
        },
        outstandingProject: {
            dialogConfirm: {
                dialogId: "emDialogConfirmOutstanding",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Outstanding_Project.Do_You_Want_To_Delete_This_Outstanding_Project"
            },
            getEmployeeOutstandingProject: "Outstanding_Project.Error_When_Getting_Employee_Outstanding_Project",
            addEmployeeOutstandingProjectError: "Outstanding_Project.Error_When_Adding_Employee_Outstanding_Project",
            updateEmployeeOutstandingProjectError: "Outstanding_Project.Error_When_Updating_Employee_Outstanding_Project",
            addEmployeeOutstandingProjectSuccess: "Outstanding_Project.Add_New_Employee_Outstanding_Project_Successfully",
            updateEmployeeOutstandingProjectSuccess: "Outstanding_Project.Update_Employee_Outstanding_Project_Successfully",
            deleteEmployeeOutstandingProjectError: "Outstanding_Project.Error_When_Deleting_Employee_Outstanding_Project",
            deleteEmployeeOutstandingProjectSuccess: "Outstanding_Project.Delete_Employee_Outstanding_Project_Successfully"
        },
        education: {
            dialogConfirm: {
                dialogId: "emDialogConfirmEducation",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Education.Do_You_Want_To_Delete_This_Education"
            },
            getEmployeeEducationError: "Education.Error_When_Getting_Employee_Education",
            addEmployeeEducationError: "Education.Error_When_Adding_Employee_Education",
            updateEmployeeEducationError: "Education.Error_When_Updating_Employee_Education",
            addEmployeeEducationSuccess: "Education.Add_New_Education_Successfully",
            updateEmployeeEducationSuccess: "Education.Update_Education_Successfully",
            deleteEmployeeEducationError: "Education.Error_When_Deleting_Employee_Education",
            deleteEmployeeEducationSuccess: "Education.Delete_Employee_Education_Successfully"
        },
        employee: {
            fullName: 'Full_Name',
            positionName: 'Position_Name',
            startWorkingDate: 'Start_Working_Date',
            status: 'Status',
            team: 'Team',
            profession: 'Profession',
            dateOfBirth: 'DOB',
            domain: 'Domain'
        },
        relationshipInformation: {
            headerTitle: 'Relationship_Information.Title',
            getInfoError: "Relationship_Information.Error_Getting",
            errorUpdate: "Relationship_Information.Error_Updating",
            successUpdate: "Relationship_Information.Update_Successful"
        },
        otherInformation: {
            headerTilte: "Other_Information.Title",
            getInfoError: "Other_Information.Error_Getting",
            errorUpdate: "Other_Information.Error_Updating",
            successUpdate: "Other_Information.Update_Successful"
        },
        contract: {
            getInfoError: "Contract.Error_Getting",
            headerTitle: "Contract.Contract",
            addNewSuccessful: "Contract.Add_New_Successful",
            errorInSavingData: "Contract.Error_In_Saving_Data",
            updateSuccessful: "Contract.Update_Successfull",
            errorLoadingData: "Contract.Error_In_Loading_Data"
        },
        probation: {
            addProbationSuccessful: "Probation_Apraisal.Add_Probation_Success",
            addProbationFail: "Add_Probation_Fail"
        },
        error: "Error",
        success: "Successful",
        warning: "Warning"
    });
})();
