﻿(function () {
    "use strict";

    angular.module("app").constant('emConstants', {
        pageTitle: 'Employees',
        pageDetailTitle: 'Employees',
        updateEmployeePageTitle: 'Update Employee',
        linkToCreateEmployee: '#employees/create',
        actionDelete: "Delete",
        actionRestore: "Restore",
        actionUndoResponsible: "UndoResponsible",
        actionMakeResponsible: "MakeResponsible",
        editModeHeader: 'row bg-info',
        viewModeHeader: 'row bg-primary',
        generalInformationBodyCssEditing: 'panel-body bg-default',
        generalInformationBodyCss: 'panel-body bg-info',
        employeeFullName: "employeeFullName",
        deleteemployeeString: "Delete employee",
        restoreemployeeString: "Restore employee",
        employeeImagePath: "employeeImagePath",
        jobCode: "JobCodeFilter",
        newRowIndex: -1,
        employeeSummarySkill: {
            applicationSkills: 1,
            databaseSkills: 2,
            toolSkills: 3,
            othersSkills: 4
        },
        employeeDetailPage:{
            title: 'Employee'
        },
        contract:
        {
            probationCode: 1,
            officialCode: 2,
            permanentCode: 3,
            probationMonth: 2,
            officialMonth: 12,
            netSalary: 5000000,
            insuranceSalary: 4000000,
            createAction: "create",
            updateAction: "update",
            cookieKeyEmployeeName: "LabourEmplFullname"
        }
        //urlResource:
        //{
        //    getEmployees: '../api/employees?page=:page',
        //    generalInfo: '../api/employees/:id',
        //    getContracts:'../api/employees/:id/contracts',
        //    getContract: '../api/employees/:employeeId/contracts/:contractId',
        //    createContract : '../api/employees/:employeeId/contracts',
        //    getProbationAppraisal: '../api/employees/:id/probationAppraisal',
        //    getPersonalInformation: '../api/employees/:id/personalinformation',
        //    updatePersonalInformation: '../api/employees/:id/personalinformation/:id',
        //    summarySkill:'../api/employees/:employeeId/skills/:skillId',
        //    employmentHistory: "../api/employees/:employeeId/employment-histories/:employmentHistoryId",
        //    outstandingProject: "../api/employees/:employeeId/outstanding-projects/:outstandingProjectId",
        //    education: "../api/employees/:employeeId/educations/:educationId",
        //    relationshipInformation: '../api/employees/:id/relationshipinformation',
        //    getRelationshipInformation: '../api/employees/:id/relationshipinformation/:id',
        //    ownerGeneralInfo: '../api/employee-owner/:id',
        //    ownerSummarySkill:'../api/employee-owner/:employeeId/skills/:skillId',
        //    ownerEmploymentHistory: "../api/employee-owner/:employeeId/employment-histories/:employmentHistoryId",
        //    ownerOutstandingProject: "../api/employee-owner/:employeeId/outstanding-projects/:outstandingProjectId",
        //    ownerEducation: "../api/employee-owner/:employeeId/educations/:educationId"
        //}
    });
})();
