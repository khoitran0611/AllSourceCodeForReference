﻿(function () {
    'use strict';
    angular.module('app').controller('indexCtrl', IndexCtrl);
    IndexCtrl.$inject = ['authSvc', '$rootScope', 'indexSvc', 'constants', 'authenticationSvc'];
    function IndexCtrl(authSvc, $rootScope, indexSvc, constants, authenticationSvc) {
        var vm = this;
        vm.logout = logout;
        vm.init = init;

        var _userLoggedIn;

        init();

        function init() {
            vm.isShowNavigation = false;
            _userLoggedIn = indexSvc.getDefaultUserLoggedIn();
            setupOnLoggedIn();
            setupLoggedInData();
            checkPermissions();
            $("#applicationHost").append('<script src="' + constants.signalRUrl + 'Signalr/hubs"></script>');
            return;

            function setupOnLoggedIn() {
                $rootScope.$on('loggedIn', function () {
                    var loginData = authSvc.getLoginData();
                    if (loginData) {
                        authenticationSvc.getPermissions();
                    }
                });
            }

            function setupLoggedInData() {
                authSvc.ensureLogin();
                var loginData = authSvc.getLoginData();
                if (loginData) setUserLoggedInData(loginData);
            }

            function setUserLoggedInData(loginData) {
                _userLoggedIn.userName = loginData.userName;
                _userLoggedIn.isAdmin = loginData.userRole === 'Admin';
                _userLoggedIn.isAuthenticated = true;
                vm.isShowNavigation = true;
            }

            function checkPermissions() {
                $rootScope.$on('gotPermissions', function (event, rootScopeParams) {
                    if (rootScopeParams.permissionState) {
                        vm.isShowNavigation = true;
                        return;
                    }
                    vm.isShowNavigation = false;
                    //authSvc.clearLoginData();
                    _userLoggedIn = indexSvc.getDefaultUserLoggedIn();
                });
            }
        }

        function logout() {
            $rootScope.$on('loggedOut', function () {
                _userLoggedIn = indexSvc.getDefaultUserLoggedIn();
            });
        }
    }
})();

