﻿(function () {
    'use strict';
    angular.module('app').controller('loginCtrl', LoginCtrl);
    LoginCtrl.$inject = ['$stateParams', '$location', '$route', 'authSvc'];
    function LoginCtrl($stateParams, $location, $route, authSvc) {
        init();

        function init() {
            processTokenCallback();
            if (authSvc.getLoginData()) {
                $location.path('/');
                $route.reload();
            }
        }

        function processTokenCallback() {
            var hash = $stateParams.response;
            if (hash.charAt(0) === "&") {
                hash = hash.substr(1);
            }
            authSvc.processTokenCallback(hash);
        }
    }
})();




