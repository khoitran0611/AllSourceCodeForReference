﻿(function () {
    'use strict';
    angular.module('app').factory('authSvc', authSvc);
    authSvc.$inject = ['OidcTokenManager', 'constants', '$window', '$rootScope'];
    function authSvc(OidcTokenManager, constants, $window, $rootScope) {
        var oidcTokenManager = createOidcTokenManager();
        var service = {
            ensureLogin: ensureLogin,
            processTokenCallback: processTokenCallback,
            processTokenCallbackSilent: processTokenCallbackSilent,
            logout: logout,
            getLoginData: getLoginData,
            clearLoginData: clearLoginData
        };
        return service;


        function createOidcTokenManager() {
            var config = {
                authority: constants.authorityUrl,
                client_id: constants.ssoClientId,
                redirect_uri: constants.baseUrl + "#/login/",
                silent_redirect_uri: constants.baseUrl + "silent_renew.html",
                silent_renew: true,
                post_logout_redirect_uri: constants.baseUrl,
                response_type: "id_token token",
                scope: "openid profile roles hrtoolInternalApi"
            };

            var tokenManager = new OidcTokenManager(config);
            return tokenManager;
        }


        function ensureLogin() {
            if (!getLoginData()) {
                var hash = $window.location.hash;
                if (!hash || hash.indexOf('id_token') === -1) {
                    oidcTokenManager.redirectForToken();
                    $rootScope.digest();
                }
            }
        }

        function processTokenCallback(hash) {
            if (!hash || hash.indexOf('id_token') === -1) {
                return;
            }
            oidcTokenManager.processTokenCallbackAsync(hash).then(function () {
                $rootScope.$apply(function () {
                    $rootScope.$broadcast('loggedIn');
                });
            });
        }

        function processTokenCallbackSilent() {
            oidcTokenManager.processTokenCallbackSilent();
        }

        function logout() {
            if (getLoginData() === null) {
                window.location.href = constants.baseUrl;
                return;
            }

            oidcTokenManager.redirectForLogout();
            $rootScope.digest();
        }

        function clearLoginData() {
            oidcTokenManager.removeToken();
        }

        function getLoginData() {
            if (oidcTokenManager.access_token && oidcTokenManager.profile) {
                var loginData = {
                    token: oidcTokenManager.access_token,
                    userName: oidcTokenManager.profile.preferred_username,
                    userRole: oidcTokenManager.profile.role
                };
                return loginData;
            } else {
                return null;
            }

        }
    }
})();