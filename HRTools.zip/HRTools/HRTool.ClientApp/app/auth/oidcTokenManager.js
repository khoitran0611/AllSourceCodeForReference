﻿(function () {
    'use strict';
    angular.module('app').constant('OidcTokenManager', OidcTokenManager);
})();