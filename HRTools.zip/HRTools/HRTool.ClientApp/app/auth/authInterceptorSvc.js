﻿(function () {
    'use strict';

    angular.module('app').factory('authInterceptorSvc', authInterceptorSvc);

    authInterceptorSvc.$inject = ['$q', '$injector', 'authSvc', '$rootScope'];

    function authInterceptorSvc($q, $injector, authSvc, $rootScope) {
        var service = {
            request: request,
            responseError: responseError
        };
        return service;

        function request(config) {
            config.headers = config.headers || {};
            var authData = authSvc.getLoginData();
            if (authData) {
                config.headers.Authorization = 'Bearer ' + authData.token;
            }
            return config;
        }

        function responseError(rejection) {
            if (rejection.status === 401) {
                var authService = $injector.get('authSvc');
                authService.logout();
                $rootScope.digest();
            }
            return $q.reject(rejection);
        }
    }
})();