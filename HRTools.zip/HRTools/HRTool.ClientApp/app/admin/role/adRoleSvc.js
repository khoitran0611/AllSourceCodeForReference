﻿(function () {
    'use strict';
    angular.module("app").service('adRoleSvc', adRoleSvc);
    adRoleSvc.$inject = ['$resource', 'adConstants', 'constants'];
    function adRoleSvc($resource, adConstants, constants) {

        return {
            getRoles: getRoles,
            getRole: getRole,
            newRole: newRole,
            updateRole: updateRole,
            deleteRole: deleteRole,
            convertRoleData: convertRoleData
        };

        function getRoles(pageIndex) {
            return $resource(constants.apiUrl + 'Roles?page=:page', {page: pageIndex});
        }

        function getRole(id) {
            return $resource(constants.apiUrl + 'Roles/:id', { id: id });
        }

        function newRole() {
            return $resource(constants.apiUrl + 'Roles');
        }

        function updateRole(id) {
            return $resource(constants.apiUrl + 'Roles/:id', { id: id }, { 'update': { method: 'PUT' } });
        }

        function deleteRole(id) {
            return $resource(constants.apiUrl + 'Roles/:id', { id: id });
        }

        /**
         * @name convertRoleData
         * @desc  Converts role data to another format that match with the parameters on the Role API's post method
         * @param {Object} role will be converted
         * @param {Array} list of permission ids
         * @return {Object}
         */
        function convertRoleData(role, permissionIds) {
            var data = {
                RoleId: role.RoleId,
                RoleName: role.RoleName,
                Note: role.Note,
                PermissionIDs: []
            };

            role.ListForms.forEach(function (form) {
                form.ListPermissions.forEach(function (permission) {
                    if (permissionIds.indexOf(permission.Id) >= 0 || permission.IsChecked) {
                        var tempPermission = {
                            PermissionId: permission.Id,
                            IsChecked: permission.IsChecked
                        };
                        data.PermissionIDs.push(tempPermission);
                    }
                });
            });

            return data;
        }
    }
})();