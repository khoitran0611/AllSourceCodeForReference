﻿(function () {
    'use strict';
    angular.module("app").controller('adNewRoleCtrl', AdNewRoleCtrl);
    AdNewRoleCtrl.$inject = ['$filter', '$state', 'adRoleSvc', 'permissionSvc', 'messageHandleSvc', 'objectSvc', 'adMessage', 'adConstants', 'constants'];
    function AdNewRoleCtrl($filter, $state, adRoleSvc, permissionSvc, messageHandleSvc, objectSvc, adMessage, adConstants, constants) {

        // Properties
        /* jshint -W040 */
        var self = this;
        self.adMessage = adMessage;
        var _virtualRoleId = 0;
        self.roleId = $state.params.id || _virtualRoleId;
        self.model = {};
        var _permissionIds = [];
        self.isHaveEditPermission = false;
        self.isHaveAddPermission = false;
        self.isHaveDeletePermission = false;
        self.dialogConfirm = adMessage.role.dialogConfirm;

        // Methods
        self.init = init;
        self.saveRole = saveRole;
        self.deleteRole = deleteRole;
        self.acceptDeleteRole = acceptDeleteRole;
        self.backToRolesList = backToRolesList;

        function init() {
            self.isHaveDeletePermission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Roles_DeleteRole);
            self.isHaveAddPermission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Roles_AddRole);
            self.isHaveEditPermission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Roles_EditRole);
            self.hasAccessPemission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Roles_ViewRoles);
            self.hasPermission = self.isHaveEditPermission || self.isHaveAddPermission || self.isHaveDeletePermission;
            if (!objectSvc.checkPermission(self.hasPermission, adMessage.role.dontHavePermissionAccess, true)) return;
            getRole();

            // DOM tree manipulate
            $('#ajax-overlay').hide();
            $('#ajax-indicator').hide();
        }

        function getRole() {
            if (!objectSvc.checkPermission((self.hasPermission), adMessage.role.dontHavePermissionAccess, true)) return;
            adRoleSvc.getRole(self.roleId).get(function (role) {
                self.model = role;
                role.ListForms.forEach(function (form) {
                    form.ListPermissions.forEach(function (permission) {
                        if (permission.IsChecked) {
                            _permissionIds.push(permission.Id);
                        }
                    });
                });
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.role.failedToGetRole);
            });
        }

        function saveRole() {
            var role = adRoleSvc.convertRoleData(self.model, _permissionIds);
            if (role.RoleId == _virtualRoleId) {
                // Create new
                if (!objectSvc.checkPermission(self.isHaveAddPermission, adMessage.role.dontHaveAddPermission, true)) return;
                adRoleSvc.newRole().save(role).$promise.then(
                    function (response) {
                        if (response.isDuplicateName) {
                            toastr.warning($filter(constants.translate)(adMessage.role.duplicatedRoleName));
                        } else {
                            toastr.success($filter(constants.translate)(adMessage.role.createdRoleSuccessfully));
                            self.backToRolesList();
                        }
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, adMessage.role.failedToCreateRole);
                    });
            } else {
                // Update
                if (!objectSvc.checkPermission(self.isHaveEditPermission, adMessage.role.dontHaveEditPermission, true)) return;
                adRoleSvc.updateRole(role.RoleId).update(role).$promise.then(
                    function (response) {
                        if (response.isDuplicateName) {
                            toastr.warning($filter(constants.translate)(adMessage.role.duplicatedRoleName));
                        } else {
                            toastr.success($filter(constants.translate)(adMessage.role.updatedRoleSuccessfully));
                            self.backToRolesList();
                        }
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, adMessage.role.failedToUpdateRole);
                    });
            }
        }

        function deleteRole() {
            if (!objectSvc.checkPermission(self.isHaveDeletePermission, adMessage.role.dontHaveEditPermission, true)) return;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function acceptDeleteRole() {
            adRoleSvc.deleteRole(self.roleId).delete().$promise.then(
                function () {
                    toastr.success($filter(constants.translate)(adMessage.role.deletedRoleSuccessfully));
                    self.backToRolesList();
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.role.failedToDeletedRole);
                });
        }

        function backToRolesList() {
            $state.go(adConstants.role.stateName.viewRoles);
        }
    }
})();



