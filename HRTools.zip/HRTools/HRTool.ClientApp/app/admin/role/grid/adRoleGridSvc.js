﻿(function () {
    'use strict';
    angular.module("app").service('adRoleGridSvc', adRoleGridSvc);
    adRoleGridSvc.$inject = [
        '$filter', 'gridSvc', 'adRoleSvc', 'messageHandleSvc', 'gridHeader', 'adRoleGridModel',
        'adMessage', 'constants', 'comparisonUtilSvc'];
    function adRoleGridSvc(
        $filter, gridSvc, adRoleSvc, messageHandleSvc, gridHeader, adRoleGridModel,
        adMessage, constants, comparisonUtilSvc) {
        return {
            gridInit: gridInit,
            getPagedDataAsync: getPagedDataAsync
        };

        function gridInit(self, $scope) {
            var result = self;
            result.columnDefs = [
                new gridHeader('RoleName', adMessage.role.roleName, '', true),
                new gridHeader("Note", adMessage.role.description, '', true)
            ];
            result = gridSvc.init(result, $scope);
            return result;
        }

        function getPagedDataAsync(self, $scope) {
            var result = self;
            var rolesList = adRoleSvc.getRoles(self.pageIndex).get(function () {
                result.data = [];
                if (!comparisonUtilSvc.isNullOrUndefinedValue(rolesList.Data)) {
                    rolesList.Data.forEach(function (roleData) {
                        var role = new adRoleGridModel(roleData);
                        role.Url = constants.baseUrl;
                        result.data.push(role);
                    });
                }
                result.totalPages = rolesList.TotalPages;
                result = gridSvc.setPagingData(result, $scope);
                return result;
            },function(xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.role.failedToGetRole);
            });
            return result;
        }
    }
})();