﻿(function () {
    "use strict";
    angular.module("app").factory('adRoleGridModel', adRoleGridModel);
    function adRoleGridModel() {
        var temp = function (role) {
            /* jshint -W040 */
            var self = this;
            self.RoleId = role.RoleId || "";
            self.RoleName = role.RoleName || "";
            self.Note = role.Note || "";
        };
        return temp;
    }
})();