﻿(function () {
    'use strict';
    angular.module("app").controller('adRoleCtrl', AdRoleCtrl);
    AdRoleCtrl.$inject = ['$scope', '$filter', '$state', 'adRoleGridSvc', 'permissionSvc', 'adMessage', 'adConstants', 'constants'];
    function AdRoleCtrl($scope, $filter, $state, adRoleGridSvc, permissionSvc, adMessage, adConstants, constants) {
        // Properties
        /* jshint -W040 */
        var self = this;
        self.adMessage = adMessage;
        self.pageTitle = "Roles";
        self.pageIndex = 1;
        self.totalPages = 0;
        self.pagingOptions = {};
        self.showSelectionCheckbox = false;
        self.dataGrid = "roCtrl.data";
        self.pagingEvent = "roCtrl.pagingOptions";
        self.rowTemplate = "admin/role/grid/adRoleGrid.html";
        self.gridId = "roGrid";
        self.columnDefs = [];
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;
        self.isHaveAddPermission = false;

        // Methods
        self.init = init;
        self.getPagedDataAsync = getPagedDataAsync;
        self.goToNewRolePage = goToNewRolePage;

        function init() {
            self = adRoleGridSvc.gridInit(self, $scope);
            self.isHaveAddPermission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Roles_AddRole);
            if (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Roles_ViewRoles)) {
                self = self.getPagedDataAsync();
            } else {
                toastr.warning($filter(constants.translate)(adMessage.role.dontHaveViewPermission));
            }

            // DOM tree manipulate
            $('#ajax-overlay').hide();
            $('#ajax-indicator').hide();
        }

        function getPagedDataAsync() {
            self = adRoleGridSvc.getPagedDataAsync(self, $scope);
            return self;
        }

        function goToNewRolePage() {
            $state.go(adConstants.role.stateName.newRole);
        }
    }
})();
