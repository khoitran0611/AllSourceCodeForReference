(function () {
    "use strict";

    angular.module("app").service('adUsersSvc', serviceFactory);

    serviceFactory.$inject = ['$resource', '$filter', 'constants', 'messageHandleSvc', '$window',
        'message', 'adMessage', 'gridSvc', 'adUsersGridModel', 'gridHeader', 'permissionSvc'];

    function serviceFactory($resource, $filter, constants, messageHandleSvc, $window, message, adMessage,
        gridSvc, adUsersGridModel, gridHeader, permissionSvc) {

        var usersData = {
            users: [],
            user: null
        };

        var userNameExisted = {
            value: false
        };

        var service = {
            usersData: usersData,
            userNameExisted: userNameExisted,
            getPagedDataAsync: getPagedDataAsync,
            gridInit: gridInit,
            findUserById: findUserById,
            addUser: addUser,
            importUser: importUser,
            changeUserCompany: changeUserCompany,
            updateUser: updateUser,
            deleteUser: deleteUser,
            getTemplateUser: getTemplateUser,
            updateTemplateUser: updateTemplateUser,
            searchUser: searchUser,
            activateUsers: activateUsers,
            deactivateUsers: deactivateUsers,
            getRoles: getRoles
        };

        var url = constants.apiUrl + 'users/:actionName/:id';

        var resourceSvc = $resource(url, {}, {
            'getUsers': { method: 'GET', isArray: true },
            'getUser': { method: 'GET', id: '@id' },
            'addUser': { method: 'POST', params: { actionName: 'create' } },
            'importUser': { method: 'POST', params: { actionName: 'import' } },
            'changeUserCompany': { method: 'POST', params: { actionName: 'changeCompany' } },
            'updateUser': { method: 'PUT', id: '@id', headers: { ActionName: 'UpdateUser' } },
            'deleteUser': { method: 'DELETE', id: '@id' },
            'updateTemplateUser': { method: 'Patch', id: '@id', headers: { ActionName: 'UpdateTemplateUser' } },
            'getTemplateUser': { method: 'GET', id: '@id' },
            'activateUsers': { method: 'POST', headers: { ActionName: 'ActivateUsers' } },
            'deactivateUsers': { method: 'POST', headers: { ActionName: 'DeactivateUsers' } }
        });
        var rolesResource = $resource(constants.apiUrl + 'roles/:id');

        return service;

        function getRoles(){
            return rolesResource.query().$promise;
        }

        function getPagedDataAsync(self, $scope) {
            var result = self;
            var data = [];

            resourceSvc.getUsers().$promise.then(function (responseData) {
                usersData.isAlreadyGetServerData = true;
                responseData.forEach(function (obj) {
                    var userModel = new adUsersGridModel(obj);
                    userModel.Url = constants.baseUrl;
                    data.push(userModel);
                });
                usersData.users = responseData;

                $window.localStorage.setItem((constants.localStorageKey.currentUsersListPage), self.pageIndex);
                result = gridSvc.setPagingDataFullLoad(self, data, $scope);
                return result;

            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.getUserDataFail);
            });
            return result;
        }

        function gridInit(gridOptions, $scope) {
            var rights = permissionSvc.getCurrentUserPermission();
            gridOptions.columnDefs = [
                new gridHeader("Id", "Id", '', false),
                new gridHeader("UserName", "UserName", '', true),
                new gridHeader("FirstName", "FirstName", '', true),
                new gridHeader("CompanyName", "CompanyName", '', rights.canCreateUsersForOtherCompanies),
                new gridHeader("LastName", "LastName", '', true),
                new gridHeader("Email", "Email", '', true),
                new gridHeader("IsActive", "Status", '', true),
            ];
            return gridSvc.init(gridOptions, $scope);
        }

        function findUserById(id) {
            if (usersData.users) {
                usersData.users.forEach(function (obj) {
                    if (obj.ComId == parseInt(id, 10)) {
                        usersData.user = obj;
                        usersData.user.Website = (usersData.user.Website) ? usersData.user.Website : "";
                        $.jStorage.set('CurrentUser', JSON.stringify(usersData.user));
                        return;
                    }
                });
            }

            if (!usersData.user) {
                searchUser(id).$promise.then(function (responseData) {
                    usersData.user = responseData;
                    $.jStorage.set('CurrentUser', JSON.stringify(usersData.user));
                });
            }
        }

        function searchUser(id) {
            return resourceSvc.getUser({ id: id });
        }

        function addUser(userDto) {
            return resourceSvc.addUser(userDto).$promise;
        }

        function importUser(userDto) {
            return resourceSvc.importUser(userDto).$promise;
        }
        
        function changeUserCompany(userDto) {
            return resourceSvc.changeUserCompany(userDto).$promise;
        }

        function updateUser(id, userDetailDto, callback) {
            return resourceSvc.updateUser({ id: id }, userDetailDto).$promise;
        }

        function deleteUser(id, callback) {
            resourceSvc.deleteUser({ id: id }).$promise.then(function (response) {
                messageHandleSvc.handleResponse(response, adMessage.users.deleteUserSuccess);
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.users.deleteUserFail);
            }).then(callback);
        }

        function getTemplateUser(comId, callback) {
            resourceSvc.getTemplateUser({ id: comId }).$promise.then(function (response) {
                usersData.user = response;
                formatTemplatePathView();
                if (callback) callback();
                return usersData.user;
            }, function (xhr) {
                if (callback) callback();
                messageHandleSvc.handleResponse(xhr, adMessage.users.getUserTemplateFail);
            });
        }

        function formatTemplatePathView() {
            var user = usersData.user;
            user.OffterTemplatePathView = user.OffterTemplatePathLink !== "" ? user.OffterTemplatePathLink.split('/')[user.OffterTemplatePathLink.split('/').length - 1] : user.OffterTemplatePathLink;
            user.AgreementTemplatePathView = user.AgreementTemplatePathLink !== "" ? user.AgreementTemplatePathLink.split('/')[user.AgreementTemplatePathLink.split('/').length - 1] : user.AgreementTemplatePathLink;
            user.ProbationTemplatePathView = user.ProbationTemplatePathLink !== "" ? user.ProbationTemplatePathLink.split('/')[user.ProbationTemplatePathLink.split('/').length - 1] : user.ProbationTemplatePathLink;
            user.ContractTemplatePathView = user.ContractTemplatePathLink !== "" ? user.ContractTemplatePathLink.split('/')[user.ContractTemplatePathLink.split('/').length - 1] : user.ContractTemplatePathLink;
            return user;
        }

        function updateTemplateUser(id, userDetailDto, callback) {
            resourceSvc.updateTemplateUser({ id: id }, userDetailDto).$promise.then(function (response) {
                messageHandleSvc.handleResponse(response, adMessage.users.updateUserTemplateSuccessful);
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.users.updateUserTemplateFail);
            }).then(callback);
        }

        function activateUsers(ids, callback) {
            resourceSvc.activateUsers(ids).$promise.then(function (response) {
                var successfulMessage = ids.length > 1 ? adMessage.users.updateUsersSuccessful : adMessage.users.updateUserSuccessful;
                messageHandleSvc.handleResponse(response, successfulMessage);
            }, function (xhr) {
                var failureMessage = ids.length > 1 ? adMessage.users.updateUsersFail : adMessage.user.updateUserFail;
                messageHandleSvc.handleResponse(xhr, failureMessage);
            }).then(callback);
        }

        function deactivateUsers(ids, callback) {
            resourceSvc.deactivateUsers(ids).$promise.then(function (response) {
                var successfulMessage = ids.length > 1 ? adMessage.users.updateUsersSuccessful : adMessage.users.updateUserSuccessful;
                messageHandleSvc.handleResponse(response, successfulMessage);
            }, function (xhr) {
                var failureMessage = ids.length > 1 ? adMessage.users.updateUsersFail : adMessage.user.updateUserFail;
                messageHandleSvc.handleResponse(xhr, failureMessage);
            }).then(callback);
        }
    }
})();