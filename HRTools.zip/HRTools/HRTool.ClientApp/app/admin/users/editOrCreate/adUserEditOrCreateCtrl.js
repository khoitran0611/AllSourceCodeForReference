﻿(function () {
  "use strict";
  angular.module("app").controller('adUserEditOrCreateCtrl', controllerFactory);

  controllerFactory.$inject = [
    '$state', '$window', '$scope', '$stateParams', '$filter', '$q', '$location', 'constants',
    'adConstants', 'adMessage', 'adSubscriptionServiceConfigurationSvc',
    'adUsersSvc', 'messageHandleSvc', 'permissionSvc', 'countrySvc', 'locationSvc', 'adCompanySvc', 'keyboardSvc'
  ];
  function controllerFactory(
    $state, $window, $scope, $stateParams, $filter, $q, $location, constants,
    adConstants, adMessage, adSubscriptionServiceConfigurationSvc,
    adUsersSvc, messageHandleSvc, permissionSvc, countrySvc, locationSvc, adCompanySvc, keyboardSvc) {
    /* jshint -W040 */
    var self = this;
    var userId = $state.params.id;
    self.isEdit = (userId) ? true : false;
    self.model = { ReturnUrl: $location.$$protocol + '://' + $location.$$host };
    self.isShowLoading = false;
    self.availableRoles = [];

    self.cancel = cancel;
    self.save = save;
    self.edit = edit;
    self.backToGridPage = backToGridPage;
    self.importConfirmed = importConfirmed;

    init();

    function init() {
      $('#ajax-overlay').hide();
      $('#ajax-indicator').hide();

      if (!checkPermissions()) {
        messageHandleSvc.handlePermission();
        return;
      }

      if (self.isEdit) {
        self.model = adUsersSvc.searchUser(userId);
      }
      adCompanySvc.getCompanies()
        .then(function (data) { self.companies = data; })
        .catch(function (err) { toastr.error(err); });

      /**** Tempolary disabled ****/
      /*
      adUsersSvc.getRoles()
        .then(function (data) {
          self.availableRoles = data.filter(function (item) {
            return item.RoleName !== 'Super Admin';
          });
        })
        .catch(function (err) { toastr.error(err); });
      */
    }

    function checkPermissions() {
      self.rights = permissionSvc.getCurrentUserPermission();
      return self.isEdit ? self.rights.canEditUser : self.rights.canAddUser;
    }

    function showImportConfirm() {
      $('#importUserConfirmModal').modal('show');
    }

    function hideModalConfirm() {
      var deferred = $q.defer();
      var dom = $('#importUserConfirmModal');

      dom.modal('hide');
      dom.one('hidden.bs.modal', function () { deferred.resolve(); });
      return deferred.promise;
    }

    function importConfirmed() {
      adUsersSvc.importUser(self.model)
        .then(hideModalConfirm)
        .then(function () {
          $state.go(adConstants.usersUrlKey);
        });
    }
    
    function changeCompanyConfirmed() {
      adUsersSvc.changeUserCompany(self.model)
        .then(hideModalConfirm)
        .then(function () {
          $state.go(adConstants.usersUrlKey);
        });
    }

    function backToGridPage() {
      $state.go(adConstants.usersUrlKey);
    }

    function cancel() {
      self.backToGridPage();
    }

    function save() {

      var errMsg = validateUser();
      if (errMsg) {
        toastr.error(translate(errMsg));
        return;
      }

      self.isShowLoading = true;
      var promise = adUsersSvc.addUser(self.model);

      return promise
        .then(function (a) {
          toastr.success(translate('Users.Creating_Successful'));

          self.backToGridPage();
        })
        .catch(function (e) {
          var errorMsg = e.data.Message;
          toastr.error(errorMsg);
          if (errorMsg === 'Account already exists, please import if nescessary') {
            self.modalConfirmTitle = 'Users.Import.Title';
            self.modalConfirmContent = 'Users.Import.Description';
            self.modalConfirmOk = importConfirmed;
            showImportConfirm();
          }
          if (errorMsg === 'User already in system but in difference company') {
            self.modalConfirmTitle = 'Users.ChangeCompany.Title';
            self.modalConfirmContent = 'Users.ChangeCompany.Description';
            self.modalConfirmOk = changeCompanyConfirmed;
            showImportConfirm();
          }
        })
        .then(function () {
          self.isShowLoading = false;
        });
    }

    function edit() {
      self.isShowLoading = true;

      var promise = adUsersSvc.updateUser(userId, self.model);

      return promise
        .then(function (a) {
          toastr.success(translate('Users.Update_User_Successfully'));

          self.backToGridPage();
        })
        .catch(function (e) {
          var errorMsg = e.data.Message;
          toastr.error(translate('Users.Update_User_Fail'));
        })
        .then(function () {
          self.isShowLoading = false;
        });
    }

    function validateUser() {
      var m = self.model;
      if (!m.UserName || m.UserName.length < 4) return "Users.Username_Too_Short";

      if (m.Password !== m.PasswordConfirm) return "Users.Errors.Password_Mismatch";

      return validatePassword(m.Password);
    }

    function validatePassword(password) {
      if (password.length < 6) return 'Users.Errors.Password_Too_Short';

      if (!/[0-9]/.test(password)) return 'Users.Errors.Password_Must_Have_Number';

      if (!/[a-z]/.test(password)) return 'Users.Errors.Password_Must_Have_Lowercase_Letter';

      if (!/[A-Z]/.test(password)) return 'Users.Errors.Password_Must_Have_Uppercase_Letter';

      if (!/[!@#$%^&*]/.test(password)) return 'Users.Errors.Password_Must_Have_Special_Character';

      return "";
    }

    function translate(key) {
      return $filter(constants.translate)(key);
    }
  }
})();