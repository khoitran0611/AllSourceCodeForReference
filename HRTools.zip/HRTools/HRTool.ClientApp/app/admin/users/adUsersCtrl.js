(function () {
    "use strict";

    angular.module("app").controller('adUsersCtrl', controllerFactory);

    controllerFactory.$inject = ['$scope', '$state', '$stateParams', '$window', 'constants',
        'adUsersSvc', 'permissionSvc', 'messageHandleSvc', 'loadingSvc'];

    function controllerFactory($scope, $state, $stateParams, $window, constants, adUsersSvc, permissionSvc,
        messageHandleSvc, loadingSvc) {
        /* jshint -W040 */
        var self = this;
        self.pageIndex = constants.firstPage;
        self.totalPages = 0;
        self.pagingOptions = {};
        self.dataGrid = "ctrl.data";
        self.pagingEvent = "ctrl.pagingOptions";
        self.rowTemplate = "admin/users/grid/adUsersGrid.html";
        self.gridId = "adUsersGrid";
        self.columnDefs = [];
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;
        self.isDisableActiveIcon = true;
        self.isDisableEditIcon = true;
        self.isDisableDeactiveIcon = true;
        self.rights = permissionSvc.getCurrentUserPermission();

        var currentUser = "";

        if (!self.rights.canViewUsers) { // TODO: change to user permissions
            messageHandleSvc.handlePermission();
            return;
        }

        self.showSelectionCheckbox =
            self.rights.canDeleteUser ||
            self.rights.canToggleUserActiveStatus;

        self.getPagedDataAsync = getPagedDataAsync;
        self.createUser = createUser;
        self.updateUsersState = updateUsersState;
        self.hideCheckbox = hideCheckbox;
        self.handleSelectedItems = handleSelectedItems;

        init();

        function init() {
            self = adUsersSvc.gridInit(self, $scope);
            self = self.getPagedDataAsync();

            var currentPage = Number($window.localStorage.getItem(constants.localStorageKey.currentUsersListPage));
            self.pageIndex = (currentPage > 0) ? currentPage : constants.paging.firstPage;

            currentUser = JSON.parse($window.localStorage.getItem(constants.currentUserLoginCookie));
        }

        function getPagedDataAsync() {
            self = adUsersSvc.getPagedDataAsync(self, $scope);
            return self;
        }

        function createUser() {
            $state.go("userEditOrCreate");
        }

        function updateUsersState(isActive) {
            loadingSvc.show();
            var selected = self.gridOptions.selectedItems;
            var selectedUserIds = [];
            selected.forEach(function (selectedUser) {
                selectedUserIds.push(selectedUser.Id);
            });
            if (selectedUserIds.length <= 0) {
                return;
            }
            isActive
                ? adUsersSvc.activateUsers(selectedUserIds, reloadUsersList)
                : adUsersSvc.deactivateUsers(selectedUserIds, reloadUsersList);
        }

        function reloadUsersList() {
            $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
            loadingSvc.close();
        }

        function hideCheckbox(id) {
            if (id == currentUser.UserId) {
                return "userGrid__hide-current-user-checkbox";
            }
            return "";
        }

        function handleSelectedItems() {
            self.isDisableActiveIcon = true;
            self.isDisableEditIcon = true;
            self.isDisableDeactiveIcon = true;
            var selected = self.gridOptions.selectedItems;
            if (selected.length <= 0) return;
            for (var i = 0; i < selected.length; i++) {
                if (selected[i].Id == currentUser.UserId) {
                    selected.splice(i, 1);
                    i--;
                    continue;
                }
                selected[i].IsActive ? self.isDisableDeactiveIcon = false : self.isDisableActiveIcon = false;
            }
        }
    }
})();