(function () {
  "use strict";

  angular.module("app").factory('adUsersGridModel', serviceFactory);

  function serviceFactory() {
    var model = function (data) {
      /* jshint -W040 */
      var self = this;
      self.Id = data.Id;
      self.UserName = data.UserName;
      self.FirstName = data.FirstName;
      self.LastName = data.LastName;
      self.Email = data.Email;
      self.CompanyId = data.CompanyId;
      self.CompanyName = data.CompanyName;
      self.IsActive = data.IsActive;
      self.CreatedDate = data.CreatedDate;
      self.CreatedByUserId = data.CreatedByUserId;
      self.EmployeeId = data.EmployeeId;
    };
    return model;
  }
})();