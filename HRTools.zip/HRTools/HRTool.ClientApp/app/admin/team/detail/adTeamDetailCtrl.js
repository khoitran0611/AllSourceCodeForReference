﻿(function () {
    "use strict";
    angular.module("app").controller('adTeamDetailCtrl', AdTeamDetailCtrl);
    AdTeamDetailCtrl.$inject = [
        'datetimeSvc', 'permissionSvc', 'adTeamSvc', 'adTeamDetailGridSvc', 'objectSvc', 'messageHandleSvc', 'authenticationSvc',
        'adTeamDetailGridModel', 'adMessage', 'constants', 'message',
        '$scope', '$state', '$stateParams', "$filter", 'comparisonUtilSvc', 'loadingSvc'];
    function AdTeamDetailCtrl(datetimeSvc, permissionSvc, adTeamSvc, adTeamDetailGridSvc, objectSvc, messageHandleSvc, authenticationSvc,
        adTeamDetailGridModel, adMessage, constants, message,
        $scope, $state, $stateParams, $filter, comparisonUtilSvc, loadingSvc) {
        /* jshint -W040 */
        var self = this;

        self.permissionOfCurrentUser = {
            canAddNewTeam: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.WorkingTeam_AddTeam),
            canEditTeam: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.WorkingTeam_EditTeam),
            canViewTeam: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.WorkingTeam_ViewTeam)
        };
        if (!self.permissionOfCurrentUser.canViewTeam) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.data = "";
        self.isAddNew = isNaN($stateParams.teamId);
        self.teamId = $stateParams.teamId;
        self.assignEmployees = [];
        self.unAssignEmployees = [];
        self.team = "";
        self.selectedItems = "";
        self.selectedItemsAssign = "";
        self.filter = {};
        self.pageIndex = 1;
        self.totalPages = 0;
        self.pagingOptions = {};
        self.columnDefs = [];
        self.dataGrid = "tdCtrl.data";
        self.pagingEvent = "tdCtrl.pagingOptions";
        self.rowTemplate = "admin/team/detail/grid/adTeamDetailGrid.html";
        self.gridId = "adTeamDetailGrid";
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;
        self.dataShow = [];
        self.selectedUnAssign = "";
        self.selectedAssign = "";
        self.isTeamNameChange = false;
        self.isUpdateData = false;
        self.employeeData = "";
        self.assignEmployeesFilter = {};
        self.unAssignEmployeesFilter = {};
        self.icon = {
            addAllItem: 'content/app/images/add-all-item.jpg',
            addItem: 'content/app/images/add-item.jpg',
            removeItem: 'content/app/images/remove-item.jpg',
            removeAllItem: 'content/app/images/remove-all-item.jpg'
        };
        self.isTeamChanged = false;

        var initialEmployees = [];
        var teamConstant = { default_team_id: '0' };

        self.addTeamMember = addTeamMember;
        self.cancelChangeEmployeeInformation = cancelChangeEmployeeInformation;
        self.saveTeamInfo = saveTeamInfo;
        self.teamNameChanged = teamNameChanged;
        self.saveEmployeeAssign = saveEmployeeAssign;
        self.addAllEmployee = addAllEmployee;
        self.addEmployee = addEmployee;
        self.removeAllEmployee = removeAllEmployee;
        self.removeEmployeeAssign = removeEmployeeAssign;
        self.searchEmployee = searchEmployee;
        self.searchEmployeeAssign = searchEmployeeAssign;
        self.goToTeamPage = goToTeamPage;
        self.editRow = editRow;
        self.cancelEmployeeAssign = cancelEmployeeAssign;
        self.getPagedDataAsync = getPagedDataAsync;
        self.updateRow = updateRow;
        self.onChangeDate = onChangeDate;
        self.getImageLink = getImageLink;

        init();

        function init() {
            self = adTeamDetailGridSvc.gridInit(self, $scope);
            if (!isNaN($stateParams.teamId)) {
                pageLoad();
                createGrid();
            } else {
                loadingSvc.close();
            }

        }

        function addTeamMember() {
            self.selectedUnAssign = [];
            self.selectedAssign = [];
            $('#popupAddNew').modal('show');
        }

        function pageLoad() {
            if (isNaN($stateParams.teamId)) return;
            setDelay(true);
            adTeamSvc.team().get({ id: $stateParams.teamId },
                function (data) {
                    if (self.permissionOfCurrentUser.canAddNewTeam)
                        self.team = data;
                    self.initTeam = JSON.stringify(data);
                    loadingSvc.close();
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.teams.loadDataError);
                    loadingSvc.close();
                });
            setDelay(false);
        }

        function cancelChangeEmployeeInformation(row) {
            self.gridOptions.$gridScope.isEditingRow[row.$$hashKey] = !self.gridOptions.$gridScope.isEditingRow[row.$$hashKey];
            initialEmployees = copyEmployeesFromRow(self.data);
            self.startDate = row.entity.StartDate;
            self.endDate = row.entity.EndDate;
        }

        function saveTeamInfo() {
            if (isNaN($stateParams.teamId)) {
                if (!objectSvc.checkPermission(self.permissionOfCurrentUser.canAddNewTeam, message.dontHavePermissionAccess, true)) {
                    //authenticationSvc.logout();
                    return;
                }
                adTeamSvc.teams().save(self.team,
                    function (success) {
                        var teamId = "";
                        angular.forEach(success, function (detail) {
                            if (!isNaN(detail) && typeof (detail) == 'string') {
                                teamId += '' + detail;
                            }
                        });
                        if (teamId == teamConstant.default_team_id) {
                            toastr.warning($filter(constants.translate)(adMessage.teams.teamNameHasExisted));
                            return;
                        }

                        toastr.success($filter(constants.translate)(adMessage.teams.teamAddSuccessful));
                        $state.go('team', { teamId: teamId });
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, adMessage.teams.saveDataError);

                    });
            } else {
                self.team.WgpId = $stateParams.teamId;
                if (!objectSvc.checkPermission(self.permissionOfCurrentUser.canEditTeam, message.dontHavePermissionAccess, true)) {
                    //authenticationSvc.logout();
                    return;
                }
                adTeamSvc.teamUpdate().update(self.team, function (success) {
                    var successValue = "t";
                    if (success[0] != successValue) {
                        toastr.warning($filter(constants.translate)(adMessage.teams.teamNameHasExisted));
                        return;
                    }
                    toastr.success($filter(constants.translate)(adMessage.teams.teamUpdateSuccessful));
                    self.initTeam = JSON.stringify(self.team);
                    self.isTeamChanged = false;
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.teams.saveDataError);
                });
            }
        }

        function teamNameChanged() {
            self.isTeamNameChange = true;
        }

        function filterEmployee(employees, text) {
            if (employees.length === 0) return employees;
            if (!text) return employees;
            var list = [];
            var length = employees.length;
            for (var index = 0; index < length; index++) {
                if (employees[index].Name.toLowerCase().indexOf(text.toLowerCase()) > -1) {
                    list.push(employees[index]);
                }
            }
            return list;
        }

        function getEmployee(employees, wgeEmplId) {
            var length = employees.length;
            for (var index = 0; index < length; index++) {
                if (employees[index].WgeEmplId == wgeEmplId) {
                    return employees[index];
                }
            }
            return null;
        }

        function saveEmployeeAssign() {
            var temp = [];
            var length = self.tempAssignEmployees.length;
            for (var index = 0; index < length; index++) {
                var employee = getEmployee(self.assignEmployeeDetails, self.tempAssignEmployees[index].Id);
                if (comparisonUtilSvc.isNullOrUndefinedValue(employee)) {
                    employee = {
                        WgeEmplId: self.tempAssignEmployees[index].Id,
                        Name: self.tempAssignEmployees[index].Name
                    };
                }
                temp.push(employee);
            }
            self.tempAssignEmployees = temp;
            self.employeeData.AssignEmployeeDetails = temp;
            adTeamSvc.teamEmployees().save({ id: $stateParams.teamId }, self.employeeData,
                function () {
                    createGrid();
                    toastr.success($filter(constants.translate)(adMessage.teams.addEmployeeSuccess));
                    self.searchNameAssign = "";
                    self.searchName = "";
                },
                function () {
                    messageHandleSvc.handleResponse(xhr, adMessage.teams.saveDataError);
                });

            $('#popupAddNew').modal('hide');
        }

        function addAllEmployee() {
            var length = self.unAssignEmployeesFilter.length;
            var removeItems = [];
            while (length > 0) {
                self.tempAssignEmployees.push(self.unAssignEmployeesFilter[0]);
                removeItems.push(self.unAssignEmployeesFilter[0].Id);
                self.unAssignEmployeesFilter.splice(0, 1);
                length = self.unAssignEmployeesFilter.length;
            }

            for (var itemIndex = 0; itemIndex < removeItems.length; itemIndex++) {
                for (var unAssignEmployeesIndex = 0; unAssignEmployeesIndex < self.tempUnAssignEmployees.length; unAssignEmployeesIndex++) {
                    if (removeItems[itemIndex] == self.tempUnAssignEmployees[unAssignEmployeesIndex].Id) {
                        self.tempUnAssignEmployees.splice(unAssignEmployeesIndex, 1);
                        break;
                    }
                }
            }
            self.assignEmployeesFilter = filterEmployee(self.tempAssignEmployees, self.searchNameAssign);
            self.unAssignEmployeesFilter = filterEmployee(self.tempUnAssignEmployees, self.searchName);
            self.selectedUnAssign = [];
            self.selectedAssign = [];
        }

        function addEmployee() {
            var selectedUnAssignLength = self.selectedUnAssign.length;
            for (var unAssignIndex = 0; unAssignIndex < selectedUnAssignLength; unAssignIndex++) {
                var unAssignEmployeesLength = self.tempUnAssignEmployees.length;
                for (var unAssignEmployeesIndex = 0; unAssignEmployeesIndex < unAssignEmployeesLength; unAssignEmployeesIndex++) {
                    if (self.selectedUnAssign[unAssignIndex] == self.tempUnAssignEmployees[unAssignEmployeesIndex].Id) {
                        self.tempAssignEmployees.push(self.tempUnAssignEmployees[unAssignEmployeesIndex]);
                        self.tempUnAssignEmployees.splice(unAssignEmployeesIndex, 1);
                        break;
                    }
                }
            }
            self.assignEmployeesFilter = filterEmployee(self.tempAssignEmployees, self.searchNameAssign);
            self.unAssignEmployeesFilter = filterEmployee(self.tempUnAssignEmployees, self.searchName);
            self.selectedUnAssign = [];
            self.selectedAssign = [];
        }

        function removeAllEmployee() {
            var length = self.assignEmployeesFilter.length;
            var removeItems = [];
            while (length > 0) {
                self.tempUnAssignEmployees.push(self.assignEmployeesFilter[0]);
                removeItems.push(self.assignEmployeesFilter[0].Id);
                self.assignEmployeesFilter.splice(0, 1);
                length = self.assignEmployeesFilter.length;
            }

            for (var itemIndex = 0; itemIndex < removeItems.length; itemIndex++) {
                for (var assignEmployeesIndex = 0; assignEmployeesIndex < self.tempAssignEmployees.length; assignEmployeesIndex++) {
                    if (removeItems[itemIndex] == self.tempAssignEmployees[assignEmployeesIndex].Id) {
                        self.tempAssignEmployees.splice(assignEmployeesIndex, 1);
                        break;
                    }
                }
            }

            self.assignEmployeesFilter = filterEmployee(self.tempAssignEmployees, self.searchNameAssign);
            self.unAssignEmployeesFilter = filterEmployee(self.tempUnAssignEmployees, self.searchName);
            self.selectedUnAssign = [];
            self.selectedAssign = [];
        }

        function removeEmployeeAssign() {
            var selectedAnAssignLength = self.selectedAssign.length;
            for (var assignIndex = 0; assignIndex < selectedAnAssignLength; assignIndex++) {
                var assignEmployeesLength = self.tempAssignEmployees.length;
                for (var assignEmployeesIndex = 0; assignEmployeesIndex < assignEmployeesLength; assignEmployeesIndex++) {
                    if (self.selectedAssign[assignIndex] == self.tempAssignEmployees[assignEmployeesIndex].Id) {
                        self.tempUnAssignEmployees.push(self.tempAssignEmployees[assignEmployeesIndex]);
                        self.tempAssignEmployees.splice(assignEmployeesIndex, 1);
                        break;
                    }
                }
            }
            self.assignEmployeesFilter = filterEmployee(self.tempAssignEmployees, self.searchNameAssign);
            self.unAssignEmployeesFilter = filterEmployee(self.tempUnAssignEmployees, self.searchName);
            self.selectedUnAssign = [];
            self.selectedAssign = [];
        }

        function searchEmployee() {
            self.unAssignEmployeesFilter = filterEmployee(self.tempUnAssignEmployees, self.searchName);
        }

        function searchEmployeeAssign() {
            self.assignEmployeesFilter = filterEmployee(self.tempAssignEmployees, self.searchNameAssign);
        }

        function goToTeamPage() {
            $state.go("teams");
        }

        function editRow(row) {
            var flag = isUpdatingEmployee();
            if (flag) return;
            self.gridOptions.$gridScope.isErrorDataRow[row.$$hashKey] = false;
            self.gridOptions.$gridScope.isEditingRow[row.$$hashKey] = !self.gridOptions.$gridScope.isEditingRow[row.$$hashKey];
            initialEmployees = copyEmployeesFromRow(self.data);
            self.startDate = row.entity.StartDate === '' ? '' : moment(row.entity.StartDate).format(constants.formatDateDDMMYYYY);
            var fromDate = $('.from-date');
            var toDate = $('.to-date');
            fromDate.datepicker({ autoclose: true, todayHighlight: true });
            if (self.startDate !== '')
                fromDate.datepicker('setDate', self.startDate);
            self.endDate = row.entity.EndDate === '' ? '' : moment(row.entity.EndDate).format(constants.formatDateDDMMYYYY);
            toDate.datepicker({ autoclose: true, todayHighlight: true });
            if (self.endDate !== '')
                toDate.datepicker('setDate', self.endDate);
        }

        function copyEmployeesFromRow(data) {
            $.each(data, function (item, employee) {
                initialEmployees.push(new adTeamDetailGridModel(employee));
            });
            return initialEmployees;
        }

        function isUpdatingEmployee() {
            var isUpdating = false;
            angular.forEach(self.gridOptions.$gridScope.isEditingRow, function (row) {
                if (row) isUpdating = true;
            });
            return isUpdating;
        }

        function cancelEmployeeAssign() {
            self.assignEmployeeDetails = self.employeeData.AssignEmployeeDetails;
            self.tempAssignEmployees = objectSvc.getArray(self.employeeData.AssignEmployees);
            self.tempUnAssignEmployees = objectSvc.getArray(self.employeeData.UnassignEmployees);
            self.assignEmployeesFilter = objectSvc.getArray(self.employeeData.AssignEmployees);
            self.unAssignEmployeesFilter = objectSvc.getArray(self.employeeData.UnassignEmployees);
            self.searchNameAssign = "";
            self.searchName = "";
            self.selectedUnAssign = [];
            self.selectedAssign = [];
            $('#popupAddNew').modal('hide');
        }

        function getPagedDataAsync() {
            self = adTeamDetailGridSvc.getPagedDataAsync(self, $scope);
            return self;
        }

        function isEndDateInvalid() {
            var startDate = moment(self.startDate, constants.formatDateDDMMYYYY);
            var endDate = moment(self.endDate, constants.formatDateDDMMYYYY);

            var diff = endDate.diff(startDate, 'days');
            if (diff < 0) {
                toastr.warning($filter(constants.translate)(adMessage.teams.endDateError));
                return true;
            }
            return false;
        }

        function updateRow(row) {
            if (!self.startDate) {
                return;
            }
            if (self.endDate) {
                if (isEndDateInvalid()) return;
            }
            var startDate = datetimeSvc.convertDateForServerSide(self.startDate);
            var endDate = datetimeSvc.convertDateForServerSide(self.endDate);
            for (var index = 0; index < self.employeeData.AssignEmployees.length; index++) {
                if (self.employeeData.AssignEmployeeDetails[index].WgeEmplId == row.entity.WgeEmplId) {
                    self.employeeData.AssignEmployeeDetails[index].StartDate = startDate;
                    self.employeeData.AssignEmployeeDetails[index].EndDate = endDate;
                    break;
                }
            }
            saveInformationtoSever(row);
        }

        function saveInformationtoSever(row) {
            adTeamSvc.teamEmployees().save({ id: $stateParams.teamId }, self.employeeData, function () {
                toastr.success($filter(constants.translate)(adMessage.teams.saveDataSuccess));
                row.entity.StartDate = datetimeSvc.convertDateForServerSide(self.startDate);
                row.entity.EndDate = datetimeSvc.convertDateForServerSide(self.endDate);
                self.gridOptions.$gridScope.isEditingRow[row.$$hashKey] = !self.gridOptions.$gridScope.isEditingRow[row.$$hashKey];
            },
            function () {
                messageHandleSvc.handleResponse(xhr, adMessage.teams.saveDataError);
            });
        }

        function createGrid() {
            self = adTeamDetailGridSvc.getPagedDataAsync(self, $scope);
        }

        function setDelay(isDelay) {
            if (isDelay) {
                $(constants.loadingIcon.overlay).show();
                $(constants.loadingIcon.indicator).show();
                return;
            }
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
        }

        function onChangeDate(date) {
            return (date) ? true : false;
        }

        $scope.$watch('tdCtrl.team', function (newValue, oldValue) {
            if (newValue === oldValue) return;
            var initTeam = (angular.fromJson(self.initTeam));
            if (!initTeam) initTeam = { WgpName: null, Note: null };
            self.isTeamChanged = (initTeam.WgpName != self.team.WgpName || initTeam.Note != self.team.Note);
        }, true);

        function getImageLink(image) {
            return '../' + image;
        }
    }
})();

