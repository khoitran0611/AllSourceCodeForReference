﻿(function () {
    "use strict";
    angular.module('app').factory('adTeamDetailGridModel', adTeamDetailGridModel);
    function adTeamDetailGridModel() {
        var temp = function (employee) {
            /* jshint -W040 */
            var self = this;
            self.Id = employee.Id || "";
            self.Name = employee.Name || "";
            self.WgeEmplId = employee.WgeEmplId || "";
            self.WgeWgpId = employee.WgeWgpId || "";
            self.StartDate = employee.StartDate || "";
            self.EndDate = employee.EndDate || "";
            self.EditButton = "";
            self.SaveButton = "";
            self.CancelButton = "";
        };
        return temp;
    }
})();