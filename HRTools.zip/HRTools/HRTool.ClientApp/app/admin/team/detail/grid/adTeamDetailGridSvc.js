﻿(function () {
    "use strict";
    angular.module("app").factory('adTeamDetailGridSvc', adTeamDetailGridSvc);
    adTeamDetailGridSvc.$inject = [
        'adTeamSvc', 'gridSvc', 'styleSvc', 'objectSvc', 'messageHandleSvc',
        'adTeamDetailGridModel', 'gridHeader', 'constants', 'adMessage', '$filter', 'comparisonUtilSvc'];
    function adTeamDetailGridSvc(
        adTeamSvc, gridSvc, styleSvc, objectSvc, messageHandleSvc,
        adTeamDetailGridModel, gridHeader, constants, adMessage, $filter, comparisonUtilSvc) {
        var data = [];
        return {
            getPagedDataAsync: getPagedDataAsync,
            gridInit: gridInit
        };

        function getPagedDataAsync(self, $scope) {
            setDelay(true);
            var result = self;
            data.length = 0;
            if (isNaN(self.teamId)) return result;
            adTeamSvc.teamEmployees().get({ id: self.teamId },
                function (success) {
                    setData(self, success);
                    result = gridSvc.setPagingDataFullLoad(self, data, $scope);
                    setDelay(false);
                    return result;
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.teams.loadDataError);
                });
            setDelay(false);
            return result;
        }

        function setDelay(isDelay) {
            if (isDelay) {
                $(constants.loadingIcon.overlay).show();
                $(constants.loadingIcon.indicator).show();
                return;
            }
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
        }

        function setData(self, success) {
            self.assignEmployeeDetails = success.AssignEmployeeDetails;
            self.employeeData = success;
            self.tempAssignEmployees = objectSvc.getArray(success.AssignEmployees);
            self.tempUnAssignEmployees = objectSvc.getArray(success.UnassignEmployees);
            self.assignEmployeesFilter = objectSvc.getArray(success.AssignEmployees);
            self.unAssignEmployeesFilter = objectSvc.getArray(success.UnassignEmployees);
            var teamEmployees = self.assignEmployeeDetails;
            if (!comparisonUtilSvc.isNullOrUndefinedValue(teamEmployees)) {
                teamEmployees.forEach(function (teamEmployeeData) {
                    var teamEmployee = new adTeamDetailGridModel(teamEmployeeData);
                    data.push(teamEmployee);
                });
            }
        }

        function gridInit(self, $scope) {
            var result = self;
            result.columnDefs = [
                new gridHeader("Name", adMessage.teams.fullName, "", true),
                new gridHeader("StartDate", adMessage.teams.startDate, constants.formatDateTimeFilter, true),
                new gridHeader("EndDate", adMessage.teams.endDate, constants.formatDateTimeFilter, true),
            new gridHeader("EditButton", '', '', true)
            ];
            result.customCss.setStatusNameCss = styleSvc.setJobStatus;
            result = gridSvc.init(result, $scope);
            return result;
        }
    }
})();