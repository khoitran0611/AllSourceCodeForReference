﻿(function () {
    "use strict";
    angular.module("app").factory('adTeamGridModel', adTeamGridModel);
    function adTeamGridModel() {
        var temp = function (team) {
            /* jshint -W040 */
            var self = this;
            self.WgpId = team.WgpId || "";
            self.WgpName = team.WgpName || "";
            self.Note = team.Note || "";
        };
        return temp;
    }
})();