﻿(function () {
    "use strict";
    angular.module("app").factory('adTeamGridSvc', adTeamGridSvc);
    adTeamGridSvc.$inject = [
        'adTeamSvc', 'gridSvc', 'styleSvc', 'messageHandleSvc', 'adTeamGridModel', 'gridHeader',
        'adMessage', 'constants', '$filter', 'comparisonUtilSvc', 'loadingSvc'];
    function adTeamGridSvc(
        adTeamSvc, gridSvc, styleSvc, messageHandleSvc, adTeamGridModel, gridHeader,
        adMessage, constants, $filter, comparisonUtilSvc, loadingSvc) {
        var isAlreadyGetServerData = false;
        var data = [];
        return {
            getPagedDataAsync: getPagedDataAsync,
            gridInit: gridInit
        };

        function getPagedDataAsync(self, $scope) {
            setDelay(true);
            var result = self;
            var teams = adTeamSvc.teams().query(
                function () {
                    return getDataFromServer(teams, result, self, $scope);
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.teams.loadDataError);
                    loadingSvc.close();
                });
            setDelay(false);
            return result;
        }

        function setDelay(isDelay) {
            if (isDelay) {
                $(constants.loadingIcon.overlay).show();
                $(constants.loadingIcon.indicator).show();
                return;
            }
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
        }

        function getDataFromServer(teams, result, self, $scope) {
            isAlreadyGetServerData = true;
            if (!comparisonUtilSvc.isNullOrUndefinedValue(teams)) {
                data.length = 0;
                teams.forEach(function (teamData) {
                    if (teamData.WgpName.toLowerCase().indexOf(self.filter.toLowerCase()) > -1) {
                        var team = new adTeamGridModel(teamData);
                        team.Url = constants.baseUrl;
                        data.push(team);
                    }
                });
                result = gridSvc.setPagingDataFullLoad(self, data, $scope);
                setDelay(false);
                loadingSvc.close();
                return result;
            } else {
                return filterData(self, result, $scope);
            }
        }

        function filterData(self, result, $scope) {
            var dataShow = [];
            if (self.filter) {
                data.forEach(function (team) {
                    if (team.WgpName.toLowerCase().indexOf(self.filter.toLowerCase()) > -1)
                        dataShow.push(team);
                });
            } else {
                dataShow = data;
            }
            result = gridSvc.setPagingDataFullLoad(self, dataShow, $scope);
            setDelay(false);
            return result;
        }

        function gridInit(self, $scope) {
            var result = self;
            result.columnDefs = [
                new gridHeader("WgpName", adMessage.teams.teamName, "", true),
                new gridHeader("Note", adMessage.teams.note, "", true)
            ];
            result.customCss.setStatusNameCss = styleSvc.setJobStatus;
            result = gridSvc.init(result, $scope);
            return result;
        }
    }
})();