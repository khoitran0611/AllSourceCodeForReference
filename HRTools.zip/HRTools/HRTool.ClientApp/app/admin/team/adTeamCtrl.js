﻿(function () {
    "use strict";
    angular.module("app").controller('adTeamCtrl', AdTeamCtrl);
    AdTeamCtrl.$inject = [
        'constants', 'adMessage',
        'permissionSvc', 'adTeamGridSvc', 'authenticationSvc', 'messageHandleSvc',
        '$scope', '$state', "$filter"
    ];
    function AdTeamCtrl(constants, adMessage,
            permissionSvc, adTeamGridSvc, authenticationSvc, messageHandleSvc,
            $scope, $state, $filter) {
        /* jshint -W040 */
        var self = this;

        self.permissionOfCurrentUser = {
            canAddNewTeam: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.WorkingTeam_AddTeam),
            canViewTeam: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.WorkingTeam_ViewTeam)
        };
        if (!self.permissionOfCurrentUser.canViewTeam) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.pageIndex = 1;
        self.totalPages = 0;
        self.pagingOptions = {};
        self.columnDefs = [];
        self.dataGrid = "ctrl.data";
        self.pagingEvent = "ctrl.pagingOptions";
        self.rowTemplate = "admin/team/grid/adTeamGrid.html";
        self.gridId = "adTeamGrid";
        self.iconClass = "sprite-add-new-record";
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;
        self.dataShow = [];
        self.filter = "";
        self.bigMsg = adMessage.teams.textMessage;
        self.smallMsg = self.bigMsg;

        self.searchTeam = searchTeam;
        self.goToAddNewTeamPage = goToAddNewTeamPage;
        self.getPagedDataAsync = getPagedDataAsync;

        init();

        function init() {
            self = adTeamGridSvc.gridInit(self, $scope);
            self = adTeamGridSvc.getPagedDataAsync(self, $scope);
        }

        function goToAddNewTeamPage() {
            $state.go("new-team");
        }

        function searchTeam() {
            self.filter = self.searchName;
            if (self.pagingOptions.currentPage != constants.paging.firstPage)
                self.pagingOptions.currentPage = constants.paging.firstPage;
            self = adTeamGridSvc.getPagedDataAsync(self, $scope);
            adTeamGridSvc.getPagedDataAsync(self, $scope);
        }

        function getPagedDataAsync() {
            self = adTeamGridSvc.getPagedDataAsync(self, $scope);
            return self;
        }
    }
})();

