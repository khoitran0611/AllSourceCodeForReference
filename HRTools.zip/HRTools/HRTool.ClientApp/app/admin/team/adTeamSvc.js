﻿(function () {
    'use strict';
    angular.module("app").factory('adTeamSvc', adTeamSvc);
    adTeamSvc.$inject = ['$resource', 'adConstants', 'constants'];
    function adTeamSvc($resource, adConstants, constants) {
        return {
            teams: teams,
            team: team,
            teamUpdate: teamUpdate,
            teamEmployees: teamEmployees
        };

        function teams() {
            return $resource(constants.apiUrl + 'teams', {});
        }

        function team() {
            return $resource(constants.apiUrl + 'teams/:id', {});
        }

        function teamUpdate() {
            return $resource(constants.apiUrl + 'teams', {}, { 'update': { method: 'PUT' } });
        }

        function teamEmployees() {
            return $resource(constants.apiUrl + 'teams/:id/team-employees', {});
        }

    }
})();