﻿(function () {
    "use strict";
    angular.module("app").factory('adLetterTemplateGridModel', adLetterTemplateGridModel);
    function adLetterTemplateGridModel() {
            var adLetterTemplateGridModelTemp = function (letterTemplate) {
                /* jshint -W040 */
                var self = this;
                self.LetTempId = letterTemplate.LetTempId || 0;
                self.Type = letterTemplate.Type || "";
                self.Note = letterTemplate.Note || "";
                self.Subject = letterTemplate.Subject || "";
                self.Detail = letterTemplate.Detail || "";
            };
            return adLetterTemplateGridModelTemp;
        }
})();