﻿(function () {
    'use strict';
    angular.module("app").service('adLetterTemplateGridSvc', adLetterTemplateGridSvc);
    adLetterTemplateGridSvc.$inject = [
        'gridSvc', 'adLetterTemplateSvc', 'messageHandleSvc',
        'adLetterTemplateGridModel', 'gridHeader', 'constants', 'adConstants', 'adMessage', '$filter', 'comparisonUtilSvc'];
    function adLetterTemplateGridSvc(
        gridSvc, adLetterTemplateSvc, messageHandleSvc,
        adLetterTemplateGridModel, gridHeader, constants, adConstants, adMessage, $filter, comparisonUtilSvc) {
        var revealed = {
            getPagedDataAsync: getPagedDataAsync,
            gridInit: gridInit
        };
        return revealed;

        function getPagedDataAsync(self, $scope) {
            var result = self;
            adLetterTemplateSvc.getLetterTemplate().then(
                function (letterTemplateList) {
                    return popularDataToGrid(result, $scope, letterTemplateList);
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.letterTemplate.loadLetterTemplateFailed);

                });
            return result;
        }

        function popularDataToGrid(result, $scope, letterTemplateList) {
            result.data = [];
            var pageSize = 10;
            if (!comparisonUtilSvc.isNullOrUndefinedValue(letterTemplateList.ListData)) {
                var maxIndexPage = letterTemplateList.ListData.length < (result.pageIndex * pageSize) ? letterTemplateList.ListData.length : (result.pageIndex * pageSize);
                var minIndexPage = (maxIndexPage % pageSize) === 0 ? maxIndexPage - pageSize : maxIndexPage - (maxIndexPage % pageSize);
                for (var i = minIndexPage; i < maxIndexPage; i++) {
                    var employee = new adLetterTemplateGridModel(letterTemplateList.ListData[i]);
                    employee.Url = constants.baseUrl;
                    result.data.push(employee);
                }
            }
            result.totalPages = Math.ceil(letterTemplateList.ListData.length / pageSize);
            result = gridSvc.setPagingData(result, $scope);
            return result;
        }

        function gridInit(self, $scope) {
            var result = self;
            result.columnDefs = [
                new gridHeader(adConstants.letterTemplateGrid.Type, adConstants.letterTemplateGrid.Type, '', true),
                new gridHeader(adConstants.letterTemplateGrid.Note, adConstants.letterTemplateGrid.Description, '', true)
            ];
            result = gridSvc.init(result, $scope);
            return result;
        }

    }
})();