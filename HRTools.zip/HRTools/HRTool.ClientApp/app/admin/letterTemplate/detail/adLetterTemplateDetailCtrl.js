﻿(function () {
    'use strict';
    angular.module("app").controller('adDetailCtrl', AdDetailCtrl);
    AdDetailCtrl.$inject = ['adLetterTemplateSvc', 'messageHandleSvc',
        '$stateParams', '$filter', '$scope', '$state', '$timeout',
        'constants', 'adMessage', 'loadingSvc'];
    function AdDetailCtrl(adLetterTemplateSvc, messageHandleSvc,
            $stateParams, $filter, $scope, $state, $timeout,
            constants, adMessage, loadingSvc) {
        var letterTemplateId = $stateParams.id;
        var isRenderedCkeditor = false;
        var oldLetterTemplate = {};
        /* jshint -W040 */
        var self = this;
        self.editorOptions = { height: '200px' };
        self.isEditing = false;
        self.isModified = false;
        self.letterTemplate = {};

        self.save = save;
        self.goBackToListPage = goBackToListPage;
        self.cancel = cancel;

        init();

        function init() {
            adLetterTemplateSvc.getLetterTemplate(letterTemplateId).then(
                function (data) {
                    var tempData = angular.copy(data);
                    self.letterTemplate = data;
                    $timeout(function () {
                        self.letterTemplate = angular.copy(tempData);
                        loadingSvc.close();
                    }, 1000);
                }, function (error) {
                    messageHandleSvc.handleResponse(error, adMessage.letterTemplate.loadLetterTemplateFailed);
                    loadingSvc.close();
                });

            $scope.$watch('ctrl.letterTemplate', function (newValue, oldValue) {
                if (!self.letterTemplate.$resolved) return;
                if (!oldValue.$resolved && newValue.$resolved) {
                    isRenderedCkeditor = true;
                    oldLetterTemplate = copyLetterTemplate();
                    return;
                }
                if (isRenderedCkeditor) {
                    isRenderedCkeditor = false;
                }
                self.isModified = (oldLetterTemplate.Subject != self.letterTemplate.Detail.Subject ||
                    oldLetterTemplate.Detail != self.letterTemplate.Detail.Detail ||
                    oldLetterTemplate.Note != self.letterTemplate.Detail.Note) ? true : false;
            }, true);

            function copyLetterTemplate() {
                return {
                    Subject: self.letterTemplate.Detail.Subject,
                    Detail: self.letterTemplate.Detail.Detail,
                    Note: self.letterTemplate.Detail.Note
                };
            }
        }

        function save() {
            adLetterTemplateSvc.updateLetterTemplate(letterTemplateId, self.letterTemplate.Detail).then(
                function () {
                    goBackToListPage();
                },
                function (error) {
                    messageHandleSvc.handleResponse(error, adMessage.letterTemplate.updateLetterTemplateFail);
                });
        }

        function goBackToListPage() {
            $state.go('letterTemplate');
        }

        function cancel() {
            self.isEditing = false;
            reload();
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
        }

        function reload() {
            $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
        }
    }
})();