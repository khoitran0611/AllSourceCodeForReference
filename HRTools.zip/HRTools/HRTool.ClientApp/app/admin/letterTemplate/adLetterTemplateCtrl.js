﻿(function () {
    "use strict";
    angular.module("app").controller('adLetterTemplateCtrl', AdLetterTemplateCtrl);
    AdLetterTemplateCtrl.$inject = ["adLetterTemplateGridSvc", "$scope"];
    function AdLetterTemplateCtrl(adLetterTemplateGridSvc, $scope) {
        /* jshint -W040 */
        var self = this;
        self.query = {};
        self.pageIndex = 1;
        self.totalPages = 0;
        self.pagingOptions = {};
        self.showSelectionCheckbox = false;
        self.dataGrid = "ctrl.data";
        self.pagingEvent = "ctrl.pagingOptions";
        self.rowTemplate = "admin/letterTemplate/grid/adLetterTemplateGrid.html";
        self.gridId = "adLetterTemplateGrid";
        self.columnDefs = [];
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;

        self.getPagedDataAsync = getPagedDataAsync;

        init();

        function init() {
            self = self.getPagedDataAsync(self);
            self = adLetterTemplateGridSvc.gridInit(self, $scope);
        }

        function getPagedDataAsync() {
            self = adLetterTemplateGridSvc.getPagedDataAsync(self, $scope);
            return self;
        }
    }
})();

