﻿(function () {
    'use strict';
    angular.module("app").service('adLetterTemplateSvc', adLetterTemplateSvc);
    adLetterTemplateSvc.$inject = ["$resource", "adConstants", "$q", "constants"];
    function adLetterTemplateSvc($resource, adConstants, $q, constants) {
        var service = {
            getLetterTemplate: getLetterTemplate,
            updateLetterTemplate: updateLetterTemplate,
        };

        var letterTemplateResource = $resource(constants.apiUrl + 'lettertemplates/:letterTemplateId', {}, {
            get: { method: 'GET', params: { letterTemplateId: '@letterTemplateId' } },
            update: { method: 'PUT', params: { letterTemplateId: '@letterTemplateId' } }
        });

        function getLetterTemplate(letterTemplateId) {
            var deferred = $q.defer();
            letterTemplateResource.get({ letterTemplateId: letterTemplateId }).$promise.then(
                function (value) {
                    deferred.resolve(value);
                }, function (reason) {
                    deferred.reject(reason);
                });
            return deferred.promise;
        }

        function updateLetterTemplate(letterTemplateId, letterTemplate) {
            var deferred = $q.defer();
            letterTemplateResource.update({ letterTemplateId: letterTemplateId }, letterTemplate).$promise.then(
                function (value) {
                    deferred.resolve(value);
                }, function (reason) {
                    deferred.reject(reason);
                });

            return deferred.promise;
        }
        return service;
    }
})();