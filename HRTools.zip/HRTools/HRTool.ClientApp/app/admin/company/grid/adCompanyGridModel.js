﻿(function () {
    "use strict";
    angular.module("app").factory('adCompanyGridModel', adCompanyGridModel);
    function adCompanyGridModel() {
        var adCompanyGridModelTemp = function (company) {
            /* jshint -W040 */
            var self = this;
            self.ComId = company.ComId || "";
            self.ComName = company.ComName || "";
            self.ShortName = company.ShortName || "";
            self.Phone = company.Phone || "";
            self.Address = company.Address || "";
        };
        return adCompanyGridModelTemp;
    }
})();