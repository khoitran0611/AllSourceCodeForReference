﻿(function () {
    "use strict";
    angular.module("app").controller('adCompanyCtrl', AdCompanyCtrl);
    AdCompanyCtrl.$inject = ['$state', '$filter', '$scope', 'constants', 'adCompanySvc', 'permissionSvc', 'messageHandleSvc'];
    function AdCompanyCtrl($state, $filter, $scope, constants, adCompanySvc, permissionSvc, messageHandleSvc) {
        /* jshint -W040 */
        var self = this;
        self.pageIndex = constants.firstPage;
        self.totalPages = 1;
        self.pagingOptions = {};
        self.showSelectionCheckbox = false;
        self.dataGrid = "ctrl.data";
        self.pagingEvent = "ctrl.pagingOptions";
        self.rowTemplate = "admin/company/grid/adCompanyGrid.html";
        self.gridId = "adCompanyGrid";
        self.columnDefs = [];
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;
        self.permissionOfCurrentUser = permissionSvc.getCurrentUserPermission();
        if (!self.permissionOfCurrentUser.canViewCompanies) {
            messageHandleSvc.handlePermission();
            return;
        }

        self.getPagedDataAsync = getPagedDataAsync;
        self.createCompany = createCompany;

        init();

        function init() {
            self = adCompanySvc.gridInit(self, $scope);
            self = self.getPagedDataAsync();
        }

        function getPagedDataAsync() {
            self = adCompanySvc.getPagedDataAsync(self, $scope);
            return self;
        }

        function createCompany() {
            adCompanySvc.companiesData.company = null;
            $state.go("companiesDetail");
        }
    }
})();