﻿(function () {
    "use strict";
    angular.module("app").service('adCompanySvc', adCompanySvc);
    adCompanySvc.$inject = ['$resource', '$filter', 'constants', 'messageHandleSvc', 'message', 'adMessage', 'gridSvc', 'adCompanyGridModel', 'gridHeader'];
    function adCompanySvc($resource, $filter, constants, messageHandleSvc, message, adMessage, gridSvc, adCompanyGridModel, gridHeader) {

        var companiesData = {
            companies: [],
            company: null
        };

        var userNameExisted = {
            value: false
        };

        var service = {
            companiesData: companiesData,
            userNameExisted: userNameExisted,
            getPagedDataAsync: getPagedDataAsync,
            gridInit: gridInit,
            findCompanyById: findCompanyById,
            addCompany: addCompany,
            updateCompany: updateCompany,
            deleteCompany: deleteCompany,
            getTemplateCompany: getTemplateCompany,
            updateTemplateCompany: updateTemplateCompany,
            searchCompany: searchCompany,
            getCompanies: getCompanies,
        };

        var url = constants.apiUrl + 'companies/:id';

        var resourceSvc = $resource(url, {}, {
            'getCompanies': { method: 'GET', isArray: true },
            'getCompany': { method: 'GET', id: '@id' },
            'addCompany': { method: 'POST' },
            'updateCompany': { method: 'Patch', id: '@id', headers: { ActionName: 'UpdateCompany' } },
            'deleteCompany': { method: 'DELETE', id: '@id' },
            'updateTemplateCompany': { method: 'Patch', id: '@id', headers: { ActionName: 'UpdateTemplateCompany' } },
            'getTemplateCompany': { method: 'GET', id: '@id' }
        });

        return service;
        function getCompanies(){
            return resourceSvc.getCompanies().$promise;
        }
        function getPagedDataAsync(self, $scope) {
            var result = self;
            var data = [];

            resourceSvc.getCompanies().$promise.then(function (responseData) {
                companiesData.isAlreadyGetServerData = true;
                responseData.forEach(function (obj) {
                    var companyModel = new adCompanyGridModel(obj);
                    companyModel.Url = constants.baseUrl;
                    data.push(companyModel);
                });
                companiesData.companies = responseData;

                result = gridSvc.setPagingDataFullLoad(self, data, $scope);
                return result;

            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.getCompanyDataFail);
            });
            return result;
        }

        function gridInit(self, $scope) {
            var result = self;
            result.columnDefs = [
                new gridHeader("ComName", "Companies.Name", '', true),
                new gridHeader("ShortName", "Companies.Short_Name", '', true),
                new gridHeader("Phone", "Companies.Phone", '', true),
                new gridHeader("Address", "Address", '', true)
            ];
            result = gridSvc.init(result, $scope);
            return result;
        }

        function findCompanyById(id) {
            if (companiesData.companies) {
                companiesData.companies.forEach(function (obj) {
                    if (obj.ComId == parseInt(id, 10)) {
                        companiesData.company = obj;
                        companiesData.company.Website = (companiesData.company.Website) ? companiesData.company.Website : "";
                        $.jStorage.set('CurrentCompany', JSON.stringify(companiesData.company));
                        return;
                    }
                });
            }

            if (!companiesData.company) {
                searchCompany(id).$promise.then(function (responseData) {
                    companiesData.company = responseData;
                    $.jStorage.set('CurrentCompany', JSON.stringify(companiesData.company));
                });
            }
        }

        function searchCompany(id) {
            return resourceSvc.getCompany({ id: id });
        }

        function addCompany(companyDetailDto, callback) {
            resourceSvc.addCompany(companyDetailDto).$promise.then(function (response) {
                if (response[0] == 0) {
                    userNameExisted.value = true;
                    return;
                }
                userNameExisted.value = false;
                messageHandleSvc.handleResponse(response, adMessage.companies.addCompanySuccessful);
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.companies.addCompanyFail);
            }).then(callback);
        }

        function updateCompany(id, companyDetailDto, callback) {
            resourceSvc.updateCompany({ id: id }, companyDetailDto).$promise.then(function (response) {
                messageHandleSvc.handleResponse(response, adMessage.companies.updateCompanySuccessful);
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.companies.updateFail);
            }).then(callback);
        }

        function deleteCompany(id, callback) {
            resourceSvc.deleteCompany({ id: id }).$promise.then(function (response) {
                messageHandleSvc.handleResponse(response, adMessage.companies.deleteCompanySuccess);
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.companies.deleteCompanyFail);
            }).then(callback);
        }

        function getTemplateCompany(comId, callback) {
            resourceSvc.getTemplateCompany({ id: comId }).$promise.then(function (response) {
                companiesData.company = response;
                formatTemplatePathView();
                if (callback) callback();
                return companiesData.company;
            }, function (xhr) {
                if (callback) callback();
                messageHandleSvc.handleResponse(xhr, adMessage.companies.getCompanyTemplateFail);
            });
        }

        function formatTemplatePathView() {
            var company = companiesData.company;
            company.OffterTemplatePathView = company.OffterTemplatePathLink !== "" ? company.OffterTemplatePathLink.split('/')[company.OffterTemplatePathLink.split('/').length - 1] : company.OffterTemplatePathLink;
            company.AgreementTemplatePathView = company.AgreementTemplatePathLink !== "" ? company.AgreementTemplatePathLink.split('/')[company.AgreementTemplatePathLink.split('/').length - 1] : company.AgreementTemplatePathLink;
            company.ProbationTemplatePathView = company.ProbationTemplatePathLink !== "" ? company.ProbationTemplatePathLink.split('/')[company.ProbationTemplatePathLink.split('/').length - 1] : company.ProbationTemplatePathLink;
            company.ContractTemplatePathView = company.ContractTemplatePathLink !== "" ? company.ContractTemplatePathLink.split('/')[company.ContractTemplatePathLink.split('/').length - 1] : company.ContractTemplatePathLink;
            return company;
        }

        function updateTemplateCompany(id, companyDetailDto, callback) {
            resourceSvc.updateTemplateCompany({ id: id }, companyDetailDto).$promise.then(function (response) {
                messageHandleSvc.handleResponse(response, adMessage.companies.updateCompanyTemplateSuccessful);
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.companies.updateCompanyTemplateFail);
            }).then(callback);
        }
    }
})();