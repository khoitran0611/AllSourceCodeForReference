﻿(function () {
    "use strict";
    angular.module("app").controller('adSubscriptionServiceConfigurationCtrl', AdSubscriptionServiceConfigurationCtrl);
    AdSubscriptionServiceConfigurationCtrl.$inject = ['$state', '$filter', '$scope',
        'constants', 'adConstants',
        'permissionSvc', 'messageHandleSvc', 'loadingSvc', 'adSubscriptionServiceConfigurationSvc'];
    function AdSubscriptionServiceConfigurationCtrl($state, $filter, $scope,
        constants, adConstants,
        permissionSvc, messageHandleSvc, loadingSvc, adSubscriptionServiceConfigurationSvc) {
        var self = this;
        var companyId = $state.params.id;
        self.company = {};
        self.subscriptionType = adConstants.subscriptionType;
        self.publishingJobPortal = adConstants.publishingJobPortal;

        self.permissionOfCurrentUser = {
            canEditCompanyDetail: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Company_EditCompany)
        };
        if (!self.permissionOfCurrentUser.canEditCompanyDetail) {
            messageHandleSvc.handlePermission();
            return;
        }

        self.save = save;
        self.cancel = cancel;
        self.isNotDataChanged = isNotDataChanged;
        init();
        var data = {};
        function init() {
            adSubscriptionServiceConfigurationSvc.get(companyId).get().$promise.then(
                function (response) {
                    data = {
                        SubscriptionTypeId: response.SubscriptionTypeId + '',
                        ComId: response.ComId,
                        PublishingPortalId: response.PublishingPortalId ? response.PublishingPortalId +'': ""
                    };
                    self.company = angular.copy(data);
                    self.companyName = response.ComName;
                    loadingSvc.close();
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, "Subscription_Services.Loading_Subscription_Fail");
                    loadingSvc.close();
                });
        }

        function save() {
            loadingSvc.show();
            var requestData = angular.copy(self.company);
            requestData.PublishingPortalId = requestData.PublishingPortalId ? requestData.PublishingPortalId : null;
            adSubscriptionServiceConfigurationSvc.save(companyId).save(requestData).$promise.then(
              function () {
                  toastr.success($filter(constants.translate)("Subscription_Services.Update_Subscription_Successfully"));
                  $state.go('companiesDetail', { id: companyId });
                  loadingSvc.close();
              },
              function (xhr) {
                  loadingSvc.close();
                  messageHandleSvc.handleResponse(xhr, "Subscription_Services.Update_Subscription_Fail");
              });
        }

        function cancel() {
            $state.go('companiesDetail', { id: companyId });
        }

        function isNotDataChanged() {
            return JSON.stringify(self.company) === JSON.stringify(data);
        }
    }
})();