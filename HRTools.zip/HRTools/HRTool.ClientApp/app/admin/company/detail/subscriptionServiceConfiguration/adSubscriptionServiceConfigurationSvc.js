﻿(function () {
    "use strict";
    angular.module("app").factory('adSubscriptionServiceConfigurationSvc', AdSubscriptionServiceConfigurationSvc);
    AdSubscriptionServiceConfigurationSvc.$inject = ['$resource', 'adConstants', 'constants'];
    function AdSubscriptionServiceConfigurationSvc($resource, adConstants, constants) {
        return {
            get: get,
            save: save
        };

        function get(companyId) {
            return $resource(constants.apiUrl + 'companies/:companyId', { companyId: companyId });
        }

        function save(companyId) {
            return $resource(constants.apiUrl + 'companies/:companyId', { companyId: companyId }, { 'save': { method: 'PATCH', headers: { ActionName: 'ConfigSubscriptionService' } } });
        }
    }
})();
