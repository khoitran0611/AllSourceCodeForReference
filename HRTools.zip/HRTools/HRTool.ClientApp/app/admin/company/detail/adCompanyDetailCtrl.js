﻿(function () {
    "use strict";
    angular.module("app").controller('adCompanyDetailCtrl', AdCompanyDetailCtrl);
    AdCompanyDetailCtrl.$inject = ['$state', '$window', '$scope', '$stateParams',
        'adConstants', 'adMessage', 'adSubscriptionServiceConfigurationSvc',
        'adCompanySvc', 'messageHandleSvc', 'permissionSvc', 'countrySvc', 'locationSvc', 'accountSvc', 'keyboardSvc'];
    function AdCompanyDetailCtrl($state, $window, $scope, $stateParams,
        adConstants, adMessage, adSubscriptionServiceConfigurationSvc,
        adCompanySvc, messageHandleSvc, permissionSvc, countrySvc, locationSvc, accountSvc, keyboardSvc) {
        /* jshint -W040 */
        var self = this;
        var _virtualCompanyId = 0;
        self.permissionOfCurrentUser = {
            canViewCompanyDetail: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Company_ViewDetail)
        };
        if (!self.permissionOfCurrentUser.canViewCompanyDetail) {
            messageHandleSvc.handlePermission();
            return;
        }

        var companyId = $state.params.id;
        self.isEdit = (companyId && companyId != _virtualCompanyId) ? true : false;
        self.isShowLoading = false;
        self.companiesData = adCompanySvc.companiesData;
        self.isCanceled = false;
        self.isChangedMarkerOnMap = false;
        self.countries = [];
        self.googleMapLink = "";
        self.subscriptionType = "";
        self.publishingJobPortal = "";

        self.cancel = cancel;
        self.save = save;
        self.delete = showDeleteModal;
        self.deleteConfirmed = deleteConfirmed;
        self.changeMode = changeMode;
        self.backToGridPage = backToGridPage;
        self.goToConfigEmail = goToConfigEmail;
        self.goToUploadTemplate = goToUploadTemplate;
        self.goToSubscriptionServiceConfiguration = goToSubscriptionServiceConfiguration;
        self.combineAddress = combineAddress;
        self.changeAddress = changeAddress;
        self.checkGeoCode = keyboardSvc.checkGeoCode;
        self.getSubscriptionServiceInfo = getSubscriptionServiceInfo;

        init();

        function init() {
            $('#ajax-overlay').hide();
            $('#ajax-indicator').hide();

            if (self.isEdit) {
                self.isEditMode = false;
                adCompanySvc.findCompanyById(companyId);
            } else {
                self.isEditMode = true;
            }

            self.dialogConfirm = adMessage.companies.dialogConfirm;
            self.dialogConfirm.dialogTitle = self.dialogConfirm.dialogTitle;
            self.dialogConfirm.dialogMessage = self.dialogConfirm.dialogMessage;

            countrySvc.getAllCountries().query(function (result) {
                self.countries = result;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, caMessage.errorLoadingData);
            });

            self.getSubscriptionServiceInfo();
        }

        function getSubscriptionServiceInfo() {
            if (!companyId) return;
            adSubscriptionServiceConfigurationSvc.get(companyId).get().$promise.then(
               function (response) {
                   angular.forEach(adConstants.subscriptionType, function (value) {
                       if (value.id === response.SubscriptionTypeId)
                           self.subscriptionType = value.name;
                   });
                   angular.forEach(adConstants.publishingJobPortal, function (value) {
                       if (value.id === response.PublishingPortalId)
                           self.publishingJobPortal = value.name;
                   });
               });
        }

        function showDeleteModal() {
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function deleteConfirmed() {
            adCompanySvc.deleteCompany(companyId, function () {
                $state.go(adConstants.companiesUrlKey);
                $(".modal-backdrop").remove();
            });
        }

        function changeMode() {
            self.isEditMode = true;
            self.isCanceled = false;
            setGoogleMapLink(self.companiesData.company);
        }

        function backToGridPage() {
            $state.go(adConstants.companiesUrlKey);
        }

        function goToConfigEmail() {
            $state.go("companyConfigEmail", { id: companyId });
        }

        function goToUploadTemplate() {
            $state.go("uploadTemplate", { companyId: companyId });
        }

        function goToSubscriptionServiceConfiguration() {
            $state.go("subscriptionServiceConfig", { id: companyId });
        }
        function cancel() {
            if (!$state.params.id) self.backToGridPage();
            $scope.companyDetailForm.$pristine = true;
            self.isEditMode = false;
            self.isCanceled = true;
            self.companiesData.company = JSON.parse($.jStorage.get('CurrentCompany'));
        }

        function save() {
            self.companiesData.company.Phone = formatPhoneNumber(self.companiesData.company.Phone);
            self.companiesData.company.Mobile = formatPhoneNumber(self.companiesData.company.Mobile);
            if (self.isEdit) {
                editCompanyInfo();
            } else {
                addNewCompany();
            }
        }

        function editCompanyInfo() {
            self.isShowLoading = true;
            adCompanySvc.updateCompany(companyId, self.companiesData.company, function () {
                var currentUserInfo = JSON.parse($window.localStorage.getItem("currentuserlogin"));
                if (companyId == currentUserInfo.CompanyId) {
                    currentUserInfo.CompanyName = self.companiesData.company.ComName;
                    $window.localStorage.setItem("currentuserlogin", JSON.stringify(currentUserInfo));
                    var companyName = angular.element(document.querySelector('.company-name'));
                    companyName.text(JSON.parse($window.localStorage.getItem("currentuserlogin")).CompanyName);
                }
                $.jStorage.set('CurrentCompany', JSON.stringify(self.companiesData.company));
                $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
            }, function (xhr) {
                self.isShowLoading = false;
                messageHandleSvc.handleResponse(xhr, adMessage.companies.updateCompanyFail);
            });
        }

        function addNewCompany() {
            self.isShowLoading = true;
            adCompanySvc.addCompany(self.companiesData.company, function (result) {
                $scope.companyDetailForm.$pristine = true;
                $state.go(adConstants.companiesUrlKey);
            }, function (xhr) {
                self.isShowLoading = false;
                messageHandleSvc.handleResponse(xhr, adMessage.companies.addCompanyFail);
            });
        }
                
        function combineAddress(company) {
            if (!company) return "";
            return locationSvc.combineAddress(company);
        }

        function setGoogleMapLink(company) {
            self.googleMapLink = (!company) ? "" : locationSvc.generateGoogleMapLink(company);
        }

        function changeAddress() {
            setGoogleMapLink(self.companiesData.company);
        }
    }
})();