﻿(function () {
    "use strict";
    angular.module("app").factory('adConfigEmailSvc', adConfigEmailSvc);
    adConfigEmailSvc.$inject = ['$resource', 'adConstants', 'constants'];
    function adConfigEmailSvc($resource, adConstants, constants) {
        return {
            getConfigEmail: getConfigEmail,
            saveConfigEmail: saveConfigEmail
        };

        function getConfigEmail(companyId) {
            return $resource(constants.apiUrl + 'companies/:companyId', { companyId: companyId });
        }

        function saveConfigEmail(companyId) {
            return $resource(constants.apiUrl + 'companies/:companyId', { companyId: companyId }, { 'save': { method: 'PATCH', headers: { ActionName: 'ConfigEmailCompany' } } });
        }
    }
})();
