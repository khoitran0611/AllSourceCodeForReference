﻿(function () {
    "use strict";
    angular.module("app").controller('adConfigEmailCtrl', AdConfigEmailCtrl);
    AdConfigEmailCtrl.$inject = ['$filter', '$state', 'adConfigEmailSvc', 'messageHandleSvc', 'adConstants', 'adMessage', 'constants'];
    function AdConfigEmailCtrl($filter, $state, adConfigEmailSvc, messageHandleSvc, adConstants, adMessage, constants) {
        /* jshint -W040 */
        var self = this;
        var companyId = $state.params.id;
        // Properties
        self.adMessage = adMessage;
        self.model = {}; // company's information

        // Methods
        self.init = init;
        self.saveConfigEmail = saveConfigEmail;
        self.cancelConfigEmail = cancelConfigEmail;
        self.personalTitles = adConstants.personalTitles;

        function init() {
            adConfigEmailSvc.getConfigEmail(companyId).get(companyId).$promise.then(
                function (response) {
                    self.model = response;
                    self.model.EmailAllEmpl = self.model.EmailAllEmpl || "";
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.configEmail.failedToConfigEmail);
                });
            clearOverlay();

            function clearOverlay() {
                $('#ajax-overlay').hide();
                $('#ajax-indicator').hide();
            }
        }

        function saveConfigEmail() {
            adConfigEmailSvc.saveConfigEmail(companyId).save(self.model).$promise.then(
                function () {
                    toastr.success($filter(constants.translate)(adMessage.configEmail.configEmailSuccessfully));
                    $state.go('companiesDetail', { id: companyId });
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.configEmail.failedToConfigEmail);
                });
        }

        function cancelConfigEmail() {
            $state.go(adConstants.configEmail.stateName.companyDetail, { id: companyId });
        }
    }
})();

