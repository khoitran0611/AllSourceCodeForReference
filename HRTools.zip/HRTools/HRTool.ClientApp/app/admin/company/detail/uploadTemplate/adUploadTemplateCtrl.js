﻿(function () {
    'use strict';
    angular.module("app").controller('adUploadTemplateCtrl', AdUploadTemplateCtrl);
    AdUploadTemplateCtrl.$inject = [
        '$state', '$scope', '$filter',
        'adCompanySvc', 'permissionSvc', 'comparisonUtilSvc', 'loadingSvc',
        'adUploadTemplateModel', 'constants', 'adConstants'];
    function AdUploadTemplateCtrl(
        $state, $scope, $filter,
        adCompanySvc, permissionSvc, comparisonUtilSvc, loadingSvc,
        uploadTemplateModel, constants, adConstants) {
        var companyId = $state.params.companyId;
        adCompanySvc.getTemplateCompany(companyId, function () {
            loadingSvc.close();
        });
        /* jshint -W040 */
        var self = this;
        self.isDisableSave = true;
        self.companyInfo = adCompanySvc.companiesData;
        self.serverUrl = constants.serverUrl;

        self.save = save;
        self.goBackToCompany = goBackToCompany;
        self.isEditCompanyPermission = isEditCompanyPermission;

        $scope.updatePath = updatePath;

        var companyInfo = null;

        init();

        function init() {
            $scope.$watch('upCtrl.companyInfo.company', function (newData, oldData) {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(oldData)) {
                    var strNewData = new uploadTemplateModel(newData);
                    var strOldData = new uploadTemplateModel(oldData);
                    if (angular.toJson(strNewData) != angular.toJson(strOldData)) {
                        self.isDisableSave = false;
                    }
                }
            }, true);
        }

        function updatePath(fileType, fileName, url) {
            if (!companyInfo) {
                companyInfo = new uploadTemplateModel(self.companyInfo.company);
            }
            switch (fileType) {
                case adConstants.uploadTemplate.offer:
                    self.companyInfo.company.OffterTemplatePathView = fileName;
                    self.companyInfo.company.OffterTemplatePathLink = url;
                    break;
                case adConstants.uploadTemplate.agree:
                    self.companyInfo.company.AgreementTemplatePathView = fileName;
                    self.companyInfo.company.AgreementTemplatePathLink = url;
                    break;
                case adConstants.uploadTemplate.probation:
                    self.companyInfo.company.ProbationTemplatePathView = fileName;
                    self.companyInfo.company.ProbationTemplatePathLink = url;
                    break;
                case adConstants.uploadTemplate.contract:
                    self.companyInfo.company.ContractTemplatePathView = fileName;
                    self.companyInfo.company.ContractTemplatePathLink = url;
                    break;
            }
        }

        function save() {
            var companyDetailDto = new uploadTemplateModel(self.companyInfo.company);
            adCompanySvc.updateTemplateCompany(companyId, companyDetailDto, function() {
                self.isDisableSave = true;
            });
        }

        function goBackToCompany() {
            $state.go('companiesDetail', {id: companyId});
        }

        function isEditCompanyPermission() {
            var result = _.find($.jStorage.get('ListPermissions'), function (item) {
                return item.FormName + '_' + item.PermissionName == permissionSvc.permissionNameConstant.Company_EditCompany;
            });
            return !comparisonUtilSvc.isNullOrUndefinedValue(result);
        }
    }
})();