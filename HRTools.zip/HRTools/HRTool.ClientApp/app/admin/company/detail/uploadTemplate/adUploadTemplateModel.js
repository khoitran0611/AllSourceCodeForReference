﻿(function () {
    "use strict";
    angular.module("app").factory('adUploadTemplateModel', adUploadTemplateModel);
    function adUploadTemplateModel() {
        var resource = function (templateInfo) {
            /* jshint -W040 */
            var self = this;
            self.ComId = templateInfo.ComId || '';
            self.ComName = templateInfo.ComName || '';

            self.OffterTemplatePathLink = templateInfo.OffterTemplatePathLink || '';
            self.AgreementTemplatePathLink = templateInfo.AgreementTemplatePathLink || '';
            self.ProbationTemplatePathLink = templateInfo.ProbationTemplatePathLink || '';
            self.ContractTemplatePathLink = templateInfo.ContractTemplatePathLink || '';

            self.OffterTemplatePathView = templateInfo.OffterTemplatePathView || '';
            self.AgreementTemplatePathView = templateInfo.AgreementTemplatePathView || '';
            self.ProbationTemplatePathView = templateInfo.ProbationTemplatePathView || '';
            self.ContractTemplatePathView = templateInfo.ContractTemplatePathView || '';
        };
        return resource;
    }
})();