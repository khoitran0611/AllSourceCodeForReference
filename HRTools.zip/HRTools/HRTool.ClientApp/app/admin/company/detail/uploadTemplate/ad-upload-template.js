﻿(function () {
    'use strict';
    angular.module("app").directive('adUploadTemplate', adUploadTemplate);
    adUploadTemplate.$inject = ['$filter', 'messageHandleSvc', 'constants', 'adConstants', 'adMessage', 'uploadFileSvc'];
    function adUploadTemplate($filter, messageHandleSvc, constants, adConstants, adMessage, uploadFileSvc) {
            return {
                restrict: 'AE',
                controller: 'adUploadTemplateCtrl',
                controllerAs: 'upCtrl',
                templateUrl: 'admin/company/detail/uploadTemplate/ad-upload-template.html',
                scope: {
                    "formId": "@"
                },
                link: function (scope, element, attrs) {
                    element.bind("change", function () {
                        var fileType = attrs.id;

                        var companyTemplate = $('#' + scope.formId+"-load")[0].files[0];
                        uploadFileSvc.uploadFile(companyTemplate, adConstants.uploadTemplate.company).$promise.then(function (item) {
                            var url = '';
                            var fileName = '';
                            var array = item.value.split(',');
                            if (array.length > 1) {
                                url = array[0];
                                fileName = array[1];
                            }
                            scope.updatePath(fileType, fileName, url);
                            if (!scope.$$phase) scope.$apply();
                        });
                    });
                }
            };
        }
})();
