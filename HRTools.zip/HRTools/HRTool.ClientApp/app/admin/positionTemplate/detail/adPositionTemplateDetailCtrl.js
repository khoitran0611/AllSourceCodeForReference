﻿(function () {
    "use strict";
    angular.module("app").controller('adPositionTemplateDetailCtrl', AdPositionTemplateDetailCtrl);
    AdPositionTemplateDetailCtrl.$inject = ["adPositionTemplateSvc", "messageHandleSvc", "adMessage", "$stateParams", "$state",
        "$filter", "$scope", "constants", "loadingSvc"];
    function AdPositionTemplateDetailCtrl(adPositionTemplateSvc, messageHandleSvc, adMessage, $stateParams, $state,
        $filter, $scope, constants, loadingSvc) {
        var companyId = $stateParams.companyId;
        var positionTemplateId = $stateParams.positionTemplateId;
        var action = $stateParams.action;
        var actionEdit = 'edit';
        var ckeditorGeneralCount = 2;
        var ckeditorCompletedGenerate = 4;
        var oldPositionTemplate = {};

        var self = this;
        self.isEditing = action == actionEdit;
        self.positionTemplate = adPositionTemplateSvc.getPositionTemplateDetailResource(companyId, positionTemplateId).get();

        self.goBackToListPage = goBackToListPage;
        self.save = save;

        init();

        function init() {
            $scope.$watch('ctrl.positionTemplate', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                ckeditorGeneralCount++;
                if (!self.positionTemplate.$resolved) {
                    return;
                }
                if (ckeditorGeneralCount == ckeditorCompletedGenerate) {
                    oldPositionTemplate = copyPositionTemplate();
                }
                var newPositonTemplate = copyPositionTemplate();
                self.isModified = (oldPositionTemplate.JobTitle != newPositonTemplate.JobTitle ||
                    oldPositionTemplate.JobDescription != newPositonTemplate.JobDescription ||
                    oldPositionTemplate.JobRequirements != newPositonTemplate.JobRequirements ||
                    oldPositionTemplate.Note != newPositonTemplate.Note) ? true : false;
                loadingSvc.close();
            }, true);
        }

        function goBackToListPage() {
            var positionTemplateStateName = "positionTemplate";
            $state.go(positionTemplateStateName);
        }

        function save() {
            if (!self.positionTemplate.IsCreate) {
                adPositionTemplateSvc.getPositionTemplateDetailResource(companyId, positionTemplateId).update(self.positionTemplate,
                    function () {
                        toastr.success($filter(constants.translate)(adMessage.positionTemplate.updatePositionSuccess),
                        $filter(constants.translate)(adMessage.positionTemplate.successful));
                        goBackToListPage();
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, adMessage.positionTemplate.updatePositionFail);
                    });
            } else {
                self.positionTemplate.PstTempPstId = positionTemplateId;
                adPositionTemplateSvc.getPositionTemplateDetailResource(companyId).save(self.positionTemplate,
                    function () {
                        toastr.success($filter(constants.translate)(adMessage.positionTemplate.addPositionSuccess),
                        $filter(constants.translate)(adMessage.positionTemplate.successful));
                        goBackToListPage();
                    }, function () {
                        messageHandleSvc.handleResponse(xhr, adMessage.positionTemplate.addPositionFail);
                        goBackToListPage();
                    });
            }
        }

        function copyPositionTemplate() {
            return {
                JobTitle: self.positionTemplate.JobTitle ? self.positionTemplate.JobTitle : '',
                JobDescription: self.positionTemplate.JobDescription ? self.positionTemplate.JobDescription : '',
                JobRequirements: self.positionTemplate.JobRequirements ? self.positionTemplate.JobRequirements : '',
                Note: self.positionTemplate.Note ? self.positionTemplate.Note : ''
            };
        }
    }
})();

