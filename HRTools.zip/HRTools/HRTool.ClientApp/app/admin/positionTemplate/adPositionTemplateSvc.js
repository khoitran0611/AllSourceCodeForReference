﻿(function () {
    "use strict";
    angular.module("app").factory('adPositionTemplateSvc', adPositionTemplateSvc);
    adPositionTemplateSvc.$inject = ["adConstants", "$resource", "constants"];
    function adPositionTemplateSvc(adConstants, $resource, constants) {

        return {
            getAllPositionTemplateResource: getAllPositionTemplateResource,
            getPositionTemplateDetailResource: getPositionTemplateDetailResource
        };

        function getAllPositionTemplateResource(positionName) {
            return $resource(constants.apiUrl + 'positiontemplates', { positionName: positionName });
        }

        function getPositionTemplateDetailResource(companyId, positionTemplateId) {
            return $resource(constants.apiUrl + 'companies/:companyId/positiontemplates/:positionTemplateId', { companyId: companyId, positionTemplateId: positionTemplateId }, { 'update': { method: 'PUT' } });
        }
    }
})();
