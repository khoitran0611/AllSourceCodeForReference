﻿(function () {
    "use strict";
    angular.module("app").factory('adPositionTemplateGridModel', adPositionTemplateGridModel);
    function adPositionTemplateGridModel() {
        var adPositionTemplateGridModelTemp = function (positionTemplate) {
            var self = this;
            self.PstTempPstId = positionTemplate.PstTempPstId || 0;
            self.PstTempComId = positionTemplate.PstTempComId || 0;
            self.No = positionTemplate.No || "";
            self.PstName = positionTemplate.PstName || "";
            self.ComName = positionTemplate.ComName || "";
            self.JobTitle = positionTemplate.JobTitle || "";
            self.JobDescription = positionTemplate.JobDescription || "";
            self.JobRequirements = positionTemplate.JobRequirements || "";
            self.IsCreate = positionTemplate.IsCreate || "";
            self.Note = positionTemplate.Note || "";
            self.EditRow = '';
        };
        return adPositionTemplateGridModelTemp;
    }
})();