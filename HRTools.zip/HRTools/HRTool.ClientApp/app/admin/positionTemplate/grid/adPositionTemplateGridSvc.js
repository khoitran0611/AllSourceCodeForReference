﻿(function () {
    'use strict';
    angular.module("app").service('adPositionTemplateGridSvc', adPositionTemplateGridSvc);
    adPositionTemplateGridSvc.$inject = [
        'gridSvc', 'adPositionTemplateSvc', 'messageHandleSvc', 'adPositionTemplateGridModel',
        'gridHeader', '$filter', 'constants', 'adMessage', 'comparisonUtilSvc', 'loadingSvc'];
    function adPositionTemplateGridSvc(
        gridSvc, adPositionTemplateSvc, messageHandleSvc, adPositionTemplateGridModel,
        gridHeader, $filter, constants, adMessage, comparisonUtilSvc, loadingSvc) {
        return {
            getPagedDataAsync: getPagedDataAsync,
            popularDataToGrid: popularDataToGrid,
            initializeGrid: initializeGrid
        };

        function getPagedDataAsync(self, $scope) {
            var result = self;
            result.positionTemplateList = adPositionTemplateSvc.getAllPositionTemplateResource(self.positionName).get(
                function () {
                    return popularDataToGrid(result, $scope);
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.positionTemplate.getPositionFailed);
                    loadingSvc.close();
                });
            return result;
        }

        function popularDataToGrid(result, $scope) {
            result.data = [];
            var pageSize = 10;
            if (!comparisonUtilSvc.isNullOrUndefinedValue(result.positionTemplateList.ListData) && result.positionTemplateList.ListData.length > 0) {
                var maxIndexPage = result.positionTemplateList.ListData.length < (result.pageIndex * pageSize) ? result.positionTemplateList.ListData.length : (result.pageIndex * pageSize);
                var minIndexPage = (maxIndexPage % pageSize) === 0 ? maxIndexPage - pageSize : maxIndexPage - (maxIndexPage % pageSize);
                for (var i = minIndexPage; i < maxIndexPage; i++) {
                    var employee = new adPositionTemplateGridModel(result.positionTemplateList.ListData[i]);
                    employee.Url = constants.baseUrl;
                    result.data.push(employee);
                }
            }
            result.totalPages = Math.ceil(result.positionTemplateList.ListData.length / pageSize);
            result = gridSvc.setPagingData(result, $scope);
            loadingSvc.close();
            return result;
        }

        function initializeGrid(self, $scope) {
            var result = self;
            var translate = "translate";
            var positionName = "PstName";
            var companyName = "ComName";
            var note = "Note";
            var editRow = "EditRow";
            result.columnDefs = [
                new gridHeader(positionName, "Position_Template.Position_Name", '', true),
                new gridHeader(companyName, "Position_Template.Company_Name", '', true),
                new gridHeader(note, "Position_Template.Description", '', true),
                new gridHeader(editRow, '', '', true)
            ];
            result = gridSvc.init(result, $scope);
            return result;
        }
    }
})();