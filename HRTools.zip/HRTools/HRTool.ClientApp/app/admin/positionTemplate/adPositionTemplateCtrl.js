﻿(function () {
    "use strict";
    angular.module("app").controller('adPositionTemplateCtrl', AdPositionTemplateCtrl);
    AdPositionTemplateCtrl.$inject = ["adPositionTemplateGridSvc", "enumGlyphicon", "$scope", "$state"];
    function AdPositionTemplateCtrl(adPositionTemplateGridSvc, enumGlyphicon, $scope, $state) {
        var actionEdit = "edit";
        /* jshint -W040 */
        var self = this;
        self.query = {};
        self.pageIndex = 1;
        self.totalPages = 0;
        self.pagingOptions = {};
        self.showSelectionCheckbox = false;
        self.dataGrid = "ctrl.data";
        self.pagingEvent = "ctrl.pagingOptions";
        self.rowTemplate = "admin/positionTemplate/grid/adPositionTemplateGrid.html";
        self.gridId = "adPositionTemplateGrid";
        self.columnDefs = [];
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;
        self.searchByPositionName = searchByPositionName;
        self.redirectToDetailPage = redirectToDetailPage;
        self.getCssButtonEditRow = getCssButtonEditRow;
        self.getPagedDataAsync = getPagedDataAsync;
        self.positionName = '';
        self.isSearching = false;
        self.positionTemplateList = null;

        init();

        function init() {
            self = self.getPagedDataAsync(self);
            self = adPositionTemplateGridSvc.initializeGrid(self, $scope);
        }

        function searchByPositionName() {
            self.isSearching = !!(self.positionName);
            adPositionTemplateGridSvc.getPagedDataAsync(self, $scope);
        }

        function redirectToDetailPage(companyId, positionTemplateId) {
            var positionTemplateDetailStateName = "positionTemplateDetail";
            $state.go(positionTemplateDetailStateName, { companyId: companyId, positionTemplateId: positionTemplateId, action: actionEdit });
        }

        function getCssButtonEditRow(isCreate) {
            return (isCreate ? enumGlyphicon.glyphiconNewWindowButton : enumGlyphicon.glyphiconEditButton);
        }

        function getPagedDataAsync() {
            self = !self.positionTemplateList ? adPositionTemplateGridSvc.getPagedDataAsync(self, $scope) : adPositionTemplateGridSvc.popularDataToGrid(self, $scope);
            return self;
        }
    }
})();

