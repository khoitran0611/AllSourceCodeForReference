﻿(function () {
    "use strict";
    angular.module("app").constant('adConstants', {
        letterTemplateGrid: {
            Type: "Type",
            Note: "Note",
            Description: "Description"
        },
        //urlResource:
        //{
        //    letterTemplates: '../api/lettertemplates',
        //    letterTemplateDetail: '../api/lettertemplates/:letterTemplateId',
        //    positionTemplates: '../api/positiontemplates',
        //    positionTemplate: '../api/companies/:companyId/positiontemplates/:positionTemplateId',
        //    positionCategory: "../api/positions/:id",
        //    teamEmployee: "../api/teams/:id/team-employees",
        //	roles: '../api/roles',
        //    employeeRole: '../api/roles/:id/employee-role',
        //	teams: "../api/teams",
        //    team: "../api/teams/:id"
        //},
        role: {
            //urlResource: {
            //    getRoles: '../api/Roles?page=:page',
            //    getRole: '../api/Roles/:id',
            //    newRole: '../api/Roles',
            //    updateRole: '../api/Roles/:id',
            //    deleteRole: '../api/Roles/:id'
            //},
            stateName: {
                viewRoles: "roles",
                newRole: "new-role",
                editRole: "edit-role"
            }
        },
        remindCaUpdateCV: {
            //urlResource: {
            //    getReminds: '../api/remindupdatecv',
            //    getRemind: '../api/remindupdatecv/:id',
            //    postRemind: '../api/remindupdatecv/',
            //    putRemind: '../api/remindupdatecv/:id',
            //    deleteRemind: '../api/remindupdatecv/:id'
            //},
            stateName: {
                remindCandidate: 'remindCandidate'
            }
        },
        configEmail: {
            //urlResource: {
            //    getConfigEmai: '../api/companies/:companyId',
            //    patchConfigEmail: '../api/companies/:companyId'
            //},
            stateName: {
                companyDetail: 'companiesDetail'
            }
        },
        uploadTemplate: {
            offer: 'fileOfferLetter',
            agree: 'fileAgree',
            probation: 'fileProbation',
            contract: 'fileContract',
            company: 'Company'
        },
        companiesUrlKey: 'companies',
        usersUrlKey: 'users',
        ActionName: 'ActionName',
        personalTitles: [
            { id: "Mr.", name: "Mr." },
            { id: "Ms.", name: "Ms." },
            { id: "Mrs.", name: "Mrs." }
        ],
        subscriptionType: [
            { id: 1, name: "Free" },
            { id: 2, name: "Full" }
        ],
        publishingJobPortal: [
            { id: null, name: "NONE" },
            { id: 1, name: "Jobs Central" },
            { id: 2, name: "Talent Corp" }
        ]
    });
})();
