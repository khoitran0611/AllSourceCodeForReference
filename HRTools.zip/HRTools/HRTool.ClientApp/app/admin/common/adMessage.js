﻿(function () {
    "use strict";
    angular.module("app").constant('adMessage', {
        thisFieldIsRequired: "This_Field_Is_Required",
        thisIsNotAValidEmail: "This_Is_Not_A_Valid_Email",
        save: "Save",
        cancel: "Cancel",
        error: "Error",
        successful: "Successful",
        warning: "Warning",
        role: {
            pageTitle: "Role.Page_Title",
            roleName: "Role.Role_Name",
            description: "Role.Description",
            role: "Role.Role",
            Permissions: "Role.Permissions",
            updatedRoleSuccessfully: "Role.Updated_Role_Successfully",
            createdRoleSuccessfully: "Role.Created_Role_Successfully",
            deletedRoleSuccessfully: "Role.Deleted_Role_Successfully",
            failedToCreateRole: "Role.Failed_To_Create_Role",
            failedToUpdateRole: "Role.Failed_To_Update_Role",
            failedToDeletedRole: "Role.Failed_To_Delete_Role",
            failedToGetRole: "Role.Failed_To_Get_Role",
            duplicatedRoleName: "Role.Duplicated_Role_Name",
            dontHaveViewPermission: "Role.Dont_Have_View_Permission",
            dontHavePermissionAccess: "Dont_Have_Permission_Access",
            dontHaveEditPermission: "Role.Dont_Have_Edit_Permission",
            dontHaveAddPermission: "Role.Dont_Have_Add_Permission",
            dontHaveDeletePermission: "Role.Dont_Have_Delete_Permission",
            dialogConfirm: {
                dialogId: "adDialogConfirmRole",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Role.Do_You_Want_To_Delete_This_Role"
            }
        },
        remindCandidate: {
            dialogConfirm: {
                dialogId: "adRemindConfirmDialog",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Remind_Candidate.Do_You_Want_To_Delete_Remind_Update_Cv"
            },
            pageTitle: "Remind_Candidate.Page_Title",
            status: "Remind_Candidate.Status",
            totalEmailSent: "Remind_Candidate.Total_Email_Sent",
            dateSent: "Remind_Candidate.Date_Sent",
            failedToGetRemind: "Remind_Candidate.Failed_To_Get_Remind",
            addNewRemindSuccessfull: "Remind_Candidate.Add_New_Remind_Successfully",
            failedToAddNewRemind: "Remind_Candidate.Failed_To_Add_New_Remind",
            deleteRemindSuccessfully: "Remind_Candidate.Delete_Remind_Successfully",
            failedToDeleteRemind: "Remind_Candidate.Failed_To_Delete_Remind",
            dontHaveViewPermission: "Remind_Candidate.Dont_Have_View_Permission",
            invalidDateSent: "Remind_Candidate.Invalid_Date_Sent"
        },
        companies: {
            uploadTempateError: "UploadTemplate.Error",
            dialogConfirm: {
                dialogId: "adCompanyConfirmDialog",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Companies.Do_You_Want_To_Delete"
            },
            getCompanyDataFail: "Companies.Get_Company_Data_Fail",
            addCompanySuccessful: "Companies.Add_Company_Successful",
            addCompanyFail: "Companies.Add_Company_Fail",
            updateCompanySuccessful: "Companies.Update_Company_Successful",
            updateCompanyFail: "Companies.Update_Company_Fail",
            deleteCompanySuccess: "Companies.Delete_Company_Success",
            deleteCompanyFail: "Companies.Delete_Company_Fail",
            updateCompanyTemplateSuccessful: "Companies.Update_Company_Template_Successful",
            updateCompanyTemplateFail: "Companies.Update_Company_Template_Fail",
            getCompanyTemplateFail: "Companies.Get_Company_Template_Fail",

        },
        configEmail: {
            pageTitle: "Config_Email.Page_Title",
            groupEmail: "Config_Email.Group_Email",
            emailSendAllMembers: "Config_Email.Email_Send_All_Members",
            emailHr: "Config_Email.Email_HR",
            emailIt: "Config_Email.Email_IT",
            smtpConfig: "Config_Email.Smtp_Config",
            emailSenders:"Config_Email.Email_Senders",
            emailForSend: "Config_Email.Email_For_Send",
            emailNameForSend: "Config_Email.Email_Name_For_Send",
            host: "Config_Email.Host",
            hrDepartmentDisplayName: "Config_Email.Hr_Department_Display_Name",
            hrDepartmentEmail: "Config_Email.Hr_Department_Email",
            userName: "Config_Email.User_Name",
            password: "Password",
            configEmailSuccessfully: "Config_Email.Config_Email_Successfully",
            failedToConfigEmail: "Config_Email.Failed_To_Config_Email"
        },
        companyConfiguration: {
            contactDetails: "Company_Configuration.Contact_Details",
            contactPerson: "Company_Configuration.Contact_Person",
            contactPersonTitle: "Company_Configuration.Contact_Person_Title",
            premiumServiceTitle: "Company_Configuration.Premium_Services",
            hasPaidForService: "Company_Configuration.Has_Paid_For_Service",
            allowToReceiveMail: "Company_Configuration.Allow_To_Receive_Mail"
        },
        letterTemplate: {
            loadLetterTemplateFailed: "Letter_Template.Load_Letter_Template_Failed",
            updateLetterTemplateSuccessful: "Letter_Template.Update_Letter_Template_Successful",
            updateLetterTemplateFail: "Letter_Template.Update_Letter_Template_Fail"
        },
        positionCategory: {
            dialogConfirm: {
                dialogId: "adDialogConfirmPositionCategory",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Position_Category.Do_You_Want_To_Delete_This_Position_Category"
            },
            updatePositionCategorySuccess: "Position_Category.Update_Position_Category_Successfully",
            updatePositionCategoryError: "Position_Category.Error_When_Updating_Position_Category",
            getPositionCategoryError: "Position_Category.Error_When_Getting_Position_Category",
            deletePositionCategorySuccess: "Position_Category.Delete_Position_Category_Successfully",
            deletePositionCategoryError: "Position_Category.Error_When_Deleting_Position_Category",
            insertPositionCategoryError: "Position_Category.Error_When_Adding_Position_Category",
            addPositionCategorySuccess: "Position_Category.Add_New_Position_Category_Successfully",
            cantDeletePositionCategory: "Position_Category.Cant_Delete_Position_Category",
            addPositionCategoryNameError: "Position_Category.Error_Add_Position_Name",
            addPositionCategoryCodeError: "Position_Category.Error_Add_Position_Code",
            textMessage: "Position_Category.Text_Message"
        },
        teams: {
            pageTeamTitle: 'Teams',
            loadDataError: 'Team.Load_Data_Error',
            error: 'Error',
            warning: 'Warning',
            success: 'Success',
            teamNameHasExisted: 'Team.Team_Name_Has_Existed',
            saveDataError: 'Team.Save_Data_Error',
            saveDataSuccess: 'Team.Team_Is_Updated_Successfully',
            endDateError: 'Team.End_Date_Error',
            addEmployeeSuccess: 'Team.Add_Employee_Success',
            startDateNotEmpty: 'Team.Start_Date_Not_Empty',
            fullName: 'Team.Full_Name',
            startDate: 'Team.Start_Date',
            endDate: 'Team.End_Date',
            teamName: 'Team.Team_Name',
            note: 'Team.Note',
            teamAddSuccessful: 'Team.Team_Is_Added_Successfully',
            teamUpdateSuccessful: 'Team.Team_Is_Updated_Successfully',
            employeeName: 'Team.Employee_Name',
            textMessage: 'Team.Text_Message'
        },
        positionTemplate: {
            getPositionFailed: "Position_Template.Get_Position_Template_Failed",
            updatePositionSuccess: "Position_Template.Update_Position_Successful",
            updatePositionFail: "Position_Template.Update_Position_Failed",
            addPositionSuccess: "Position_Template.Add_Position_Successful",
            addPositionFail: "Position_Template.Add_Position_Failed",
            error: "Error",
            successful: "Successful"
        },
        users: {
            updateUserSuccessful: "Users.Update_User_Successfully",
            updateUsersSuccessful: "Users.Update_Users_Successfully",
            updateUserFail: "Users.Update_User_Fail",
            updateUsersFail: "Users.Update_Users_Fail"
        }
    });
})();


