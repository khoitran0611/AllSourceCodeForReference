﻿(function () {
    'use strict';
    angular.module("app").service('adRemindCandidateGridSvc', adRemindCandidateGridSvc);
    adRemindCandidateGridSvc.$inject = [
        '$filter', 'gridSvc', 'adRemindCandidateSvc', 'messageHandleSvc',
        'gridHeader', 'adRemindCandidateGridModel', 'adMessage', 'constants', 'comparisonUtilSvc'];

    function adRemindCandidateGridSvc(
        $filter, gridSvc, adRemindCandidateSvc, messageHandleSvc,
        gridHeader, adRemindCandidateGridModel, adMessage, constants, comparisonUtilSvc) {

        return {
            gridInit: gridInit,
            getPagedDataAsync: getPagedDataAsync
        };

        function gridInit(self, $scope) {
            var result = self;
            result.columnDefs = [
                new gridHeader('SentDate', adMessage.remindCandidate.dateSent, '', true),
                new gridHeader('Status', adMessage.remindCandidate.status, '', true),
                new gridHeader('TotalEmailSent', adMessage.remindCandidate.totalEmailSent, '', true),
                new gridHeader('Command', '', '', true)
            ];
            result = gridSvc.init(result, $scope);
            return result;
        }

        function getPagedDataAsync(self, $scope) {
            self.editingRow = null;
            var result = self;
            adRemindCandidateSvc.getRemindCandidate().query(function (reminds) {
                result.data = [];
                var totalItems = 0;
                if (!comparisonUtilSvc.isNullOrUndefinedValue(reminds)) {
                    totalItems = reminds.length;
                    var skip = (self.pageIndex - 1) * self.itemsPerPage;
                    reminds = reminds.splice(skip, self.itemsPerPage);
                    reminds.forEach(function (remind) {
                        var remindTemp = new adRemindCandidateGridModel(remind);
                        result.data.push(remindTemp);
                    });
                }
                result.totalPages = Math.ceil(totalItems / self.itemsPerPage);
                result = gridSvc.setPagingData(result, $scope);
                return result;
            },function(xhr) {
                messageHandleSvc.handleResponse(xhr, adMessage.remindCandidate.failedToGetRemind);
            });
            return result;
        }
    }
})();