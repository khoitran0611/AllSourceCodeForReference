﻿(function () {
    "use strict";
    angular.module("app").factory('adRemindCandidateGridModel', adRemindCandidateGridModel);
    adRemindCandidateGridModel.$inject = ['datetimeSvc'];

    function adRemindCandidateGridModel(datetimeSvc) {
        var temp = function (remind) {
            var self = this;
            self.Id = remind.Id || '';
            self.SentDate = datetimeSvc.convertDateHour(remind.SentDate, false);
            self.Status = remind.Status || '';
            self.TotalEmailSent = remind.TotalEmailSent || 0;
            self.Command = null;
        };
        return temp;
    }
})();