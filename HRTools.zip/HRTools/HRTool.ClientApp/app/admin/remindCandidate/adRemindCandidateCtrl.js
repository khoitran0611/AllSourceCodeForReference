﻿(function () {
    'use strict';
    angular.module("app").controller('adRemindCandidateCtrl', AdRemindCandidateCtrl);
    AdRemindCandidateCtrl.$inject = ['$scope', '$filter', '$timeout',
        'adRemindCandidateGridSvc', 'messageHandleSvc', 'permissionSvc', 'adRemindCandidateSvc', 'datetimeSvc',
        'adMessage', 'constants', 'comparisonUtilSvc'];
    function AdRemindCandidateCtrl($scope, $filter, $timeout,
        adRemindCandidateGridSvc, messageHandleSvc, permissionSvc, adRemindCandidateSvc, datetimeSvc,
        adMessage, constants, comparisonUtilSvc) {
        /* jshint -W040 */
        var self = this;
        // Properties
        self.adMessage = adMessage;
        self.pageIndex = 1;
        self.totalPages = 0;
        self.pagingOptions = {};
        self.showSelectionCheckbox = false;
        self.dataGrid = "rcCtrl.data";
        self.pagingEvent = "rcCtrl.pagingOptions";
        self.rowTemplate = "admin/remindCandidate/grid/adRemindCandidateGrid.html";
        self.gridId = "rcGrid";
        self.iconClass = "sprite-add-new-record";
        self.columnDefs = [];
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;
        self.itemsPerPage = 10;
        self.editingRow = null;
        var _responseCode = { ERROR: -1, INVALID_DATE: -2 };
        self.dialogConfirm = adMessage.remindCandidate.dialogConfirm;
        self.showMessageGridEmpty = true;

        self.bigMsg = 'remind';
        self.smallMsg = 'remind';

        // Methods
        self.init = init;
        self.getPagedDataAsync = getPagedDataAsync;
        self.addRemind = addRemind;
        self.saveRemind = saveRemind;
        self.deleteRemind = deleteRemind;
        self.cancelRemind = cancelRemind;
        self.removeGridRowByIndex = removeGridRowByIndex;
        self.onYes = onYes;

        var deleteRemindId;

        function init() {
            self = adRemindCandidateGridSvc.gridInit(self, $scope);

            self.isHaveViewPermission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.RemindCandidates_View);
            self.isHaveAddPermission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.RemindCandidates_Add);
            self.isHaveEditPermission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.RemindCandidates_Edit);
            self.isHaveDeletePermission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.RemindCandidates_Delete);

            if (self.isHaveViewPermission) {
                self = self.getPagedDataAsync();
            } else {
                toastr.warning($filter(constants.translate)(adMessage.remindCandidate.dontHaveViewPermission));
            }
        }

        function getPagedDataAsync() {
            self = adRemindCandidateGridSvc.getPagedDataAsync(self, $scope);
            return self;
        }

        function addRemind() {
            self.showMessageGridEmpty = false;
            self.gridOptions.$gridScope.isEmpty = false;
            if (comparisonUtilSvc.isNullOrUndefinedValue(self.editingRow)) {
                self.editingRow = {
                    SentDate: '',
                    Status: 'New',
                    TotalEmailSent: 0,
                    Command: true,
                };
                self.data.unshift(self.editingRow);
                $timeout(function () {
                    $('.date').datepicker({ autoclose: true, todayHighlight: true });
                    if (!self.data[1].Status) {
                        self.data.pop();
                    }
                }, 100);
            }
        }

        function saveRemind() {
            var data = {
                SentDate: datetimeSvc.convertDateForServerSide(self.editingRow.dateSent, false)
            };
            adRemindCandidateSvc.createRemindCandidate().save(data).$promise.then(
                function (response) {
                    var code = parseInt(response[0] + response[1], 10);
                    if (code == _responseCode.ERROR)
                        toastr.error($filter(constants.translate)(adMessage.remindCandidate.failedToAddNewRemind));
                    else if (code == _responseCode.INVALID_DATE)
                        toastr.warning($filter(constants.translate)(adMessage.remindCandidate.invalidDateSent));
                    else {
                        self.getPagedDataAsync();
                        toastr.success($filter(constants.translate)(adMessage.remindCandidate.addNewRemindSuccessfull));
                        self.editingRow = null;
                    }
                },
                function () {
                    messageHandleSvc.handleResponse(xhr, adMessage.remindCandidate.failedToAddNewRemind);
                });
        }

        function deleteRemind(remindId) {
            deleteRemindId = remindId;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function onYes() {
            self.data.forEach(function (remind, index) {
                if (remind.Id == deleteRemindId) {
                    adRemindCandidateSvc.deleteRemindCandidate(deleteRemindId).delete().$promise.then(
                        function () {
                            self.removeGridRowByIndex(index);
                            if (self.data.length === 0) {
                                self.showMessageGridEmpty = true;
                            }
                            if (self.data.length === 0) self.pageIndex = self.pageIndex - 1;
                            self.getPagedDataAsync();
                            toastr.success($filter(constants.translate)(adMessage.remindCandidate.deleteRemindSuccessfully));
                        },
                        function () {
                            messageHandleSvc.handleResponse(xhr, adMessage.remindCandidate.failedToDeleteRemind);
                        });
                }
            });
        }

        function cancelRemind() {
            self.data.shift();
            self.editingRow = null;
            if (self.data.length === 0) {
                self.data.push({
                    SentDate: null,
                    Status: null,
                    TotalEmailSent: null,
                    Command: null
                });
            }
            self.showMessageGridEmpty = true;
            self.gridOptions.$gridScope.isEmpty = true;
        }

        function removeGridRowByIndex(index) {
            var temp = self.data[index];
            var lastIndex = self.data.length - 1;
            self.data[index] = self.data[lastIndex];
            self.data[lastIndex] = temp;
            self.data.pop();
        }

        // DOM tree manipulate
        $('#ajax-overlay').hide();
        $('#ajax-indicator').hide();
    }
})();



