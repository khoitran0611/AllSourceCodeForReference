﻿(function () {
    'use strict';
    angular.module("app").service('adRemindCandidateSvc', adRemindCandidateSvc);
    adRemindCandidateSvc.$inject = ['$resource', 'adConstants', 'constants'];
    function adRemindCandidateSvc($resource, adConstants, constants) {

        return {
            getRemindCandidate: getRemindCandidate,
            createRemindCandidate: createRemindCandidate,
            updateRemindCandidate: updateRemindCandidate,
            deleteRemindCandidate: deleteRemindCandidate
        };

        function getRemindCandidate() {
            return $resource(constants.apiUrl + 'remindupdatecv');
        }

        function createRemindCandidate() {
            return $resource(constants.apiUrl + 'remindupdatecv');
        }

        function updateRemindCandidate() {
            return $resource(constants.apiUrl + 'remindupdatecv/:id');
        }

        function deleteRemindCandidate(id) {
            return $resource(constants.apiUrl + 'remindupdatecv/:id', { id: id });
        }

    }
})();