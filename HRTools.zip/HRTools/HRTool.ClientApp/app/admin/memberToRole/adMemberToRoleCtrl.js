﻿(function () {
    'use strict';
    angular.module("app").controller('adMemberToRoleCtrl', AdMemberToRoleCtrl);
    AdMemberToRoleCtrl.$inject = [
        '$filter', 'permissionSvc', 'adMemberToRoleSvc', 'authenticationSvc', 'messageHandleSvc',
        'message', 'constants', 'adMessage', 'comparisonUtilSvc', 'loadingSvc'];
    function AdMemberToRoleCtrl(
        $filter, permissionSvc, memberRoleSvc, authenticationSvc, messageHandleSvc,
        message, constants, adMessage, comparisonUtilSvc, loadingSvc) {
        /* jshint -W040 */
        var self = this;
        self.listTeam = [];
        self.listRole = [];
        self.leftList = [];
        self.rightList = [];
        self.permissionOfCurrentUser = permissionSvc.getCurrentUserPermission();
        if (!self.permissionOfCurrentUser.canViewRoleMember) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.selectedWgpId = null;
        self.chooseTeam = chooseTeam;
        self.isDisableAdd = isDisableAdd;
        self.isDisableAddAll = isDisableAddAll;
        self.selectLeftItem = selectLeftItem;
        self.addMember = addMember;
        self.addAllMember = addAllMember;
        self.chooseRole = chooseRole;
        self.isDisableRemove = isDisableRemove;
        self.isDisableRemoveAll = isDisableRemoveAll;
        self.selectRightItem = selectRightItem;
        self.removeMember = removeMember;
        self.removeAllMember = removeAllMember;
        self.isDisableSave = isDisableSave;
        self.save = save;

        var assignList = [];
        var assignedList = [];
        var leftChanged = false;

        init();

        function init() {
            memberRoleSvc.getTeams().query().$promise.then(
                function (response) {
                    self.listTeam.push({ WgpId: 0 });
                    response.forEach(function (team) {
                        self.listTeam.push(team);
                    });
                    self.selectedWgpId = self.listTeam[0].WgpId;
                    memberRoleSvc.getEmployeeByTeam(self.selectedWgpId).get().$promise.then(
                        function (data) {
                            self.leftList = data.UnassignEmployees;
                            loadingSvc.close();
                        });
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, "Member_To_Role.Load_Teams_Fail");
                });

            memberRoleSvc.getRoles().query().$promise.then(
                function (response) {
                    response.forEach(function (role) {
                        self.listRole.push(role);
                    });
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, "Member_To_Role.Load_Roles_Fail");
                });
        }

        function chooseTeam() {
            memberRoleSvc.getEmployeeByTeam(self.selectedWgpId).get().$promise.then(
                function (response) {
                    if (self.selectedWgpId != self.listTeam[0].WgpId) {
                        self.leftList = response.AssignEmployees;
                    } else {
                        self.leftList = response.UnassignEmployees;
                    }
                });
        }

        function isDisableAdd() {
            if (assignList.length === 0 || self.leftList.length === 0 || comparisonUtilSvc.isNullOrUndefinedValue(self.listRole.RoleId)) {
                return true;
            }
            return false;
        }

        function isDisableAddAll() {
            if (self.leftList.length === 0 || comparisonUtilSvc.isNullOrUndefinedValue(self.listRole.RoleId)) {
                return true;
            }
            return false;
        }

        function selectLeftItem(selectedMembers) {
            assignList = [];
            selectedMembers.forEach(function (member) {
                assignList.push(member);
            });
        }

        function addMember() {
            assignedList = memberRoleSvc.addMember(assignList, self);
            assignList = [];
            leftChanged = true;
        }

        function addAllMember() {
            assignedList = memberRoleSvc.addAllMember(self);
            leftChanged = true;
        }

        function chooseRole() {
            memberRoleSvc.getEmployeeByRole(self.listRole.RoleId).get().$promise.then(
                function (response) {
                    self.rightList = response.AssignEmployees;
                });
        }

        function isDisableRemove() {
            if (assignedList.length === 0 || self.rightList.length === 0) {
                return true;
            }
            return false;
        }

        function isDisableRemoveAll() {
            if (self.rightList.length === 0) {
                return true;
            }
            return false;
        }

        function selectRightItem(selectedMembers) {
            assignedList = [];
            selectedMembers.forEach(function (member) {
                assignedList.push(member);
            });
        }

        function removeMember() {
            assignList = memberRoleSvc.removeMember(assignedList, self);
            assignedList = [];
            leftChanged = true;
        }

        function removeAllMember() {
            assignList = memberRoleSvc.removeAllMember(self);
            leftChanged = true;
        }

        function isDisableSave() {
            if (!leftChanged) {
                return true;
            }
            return false;
        }

        function save() {
            if (!self.permissionOfCurrentUser.canAddRoleMember) {
                //authenticationSvc.logout();
                messageHandleSvc.handlePermission(true);
                return;
            }
            var dataPost = {};
            var result = {
                true: 't',
                false: 'f'
            };
            dataPost.AssignEmployees = self.rightList;
            dataPost.RoleId = self.listRole.RoleId;
            dataPost.TeamId = self.selectedWgpId;
            memberRoleSvc.saveAssign(self.listRole.RoleId).save(dataPost).$promise.then(
                function (response) {
                    if (response[0] == result.true) {
                        toastr.success($filter(constants.translate)("Member_To_Role.Save_Success"));
                    } else {
                        toastr.error($filter(constants.translate)("Member_To_Role.Save_Error"));
                    }
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, "Member_To_Role.Server_Fail");
                });
        }
    }
})();