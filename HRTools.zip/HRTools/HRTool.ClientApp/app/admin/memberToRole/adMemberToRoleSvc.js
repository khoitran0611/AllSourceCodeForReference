﻿(function () {
    'use strict';
    angular.module("app").service('adMemberToRoleSvc', adMemberToRoleSvc);
    adMemberToRoleSvc.$inject = ['$resource', 'message', '$filter', 'constants', 'adConstants'];
    function adMemberToRoleSvc($resource, message, $filter, constants, adConstants) {
        var service = {
            getTeams: getTeams,
            getRoles: getRoles,
            getEmployeeByTeam: getEmployeeByTeam,
            getEmployeeByRole: getEmployeeByRole,
            saveAssign: saveAssign,
            addMember: addMember,
            removeMember: removeMember,
            addAllMember: addAllMember,
            removeAllMember: removeAllMember
        };
        return service;

        function getTeams() {
            return $resource(constants.apiUrl + 'teams', {});
        }

        function getRoles() {
            return $resource(constants.apiUrl + 'roles', {});
        }

        function getEmployeeByTeam(teamId) {
            return $resource(constants.apiUrl + 'teams/:id/team-employees', { id: teamId });
        }

        function getEmployeeByRole(roleId) {
            return $resource(constants.apiUrl + 'roles/:id/employee-role', { id: roleId });
        }

        function saveAssign(roleId) {
            return $resource(constants.apiUrl + 'roles/:id/employee-role', { id: roleId });
        }

        function isExisted(item, list) {
            var existed = false;
            list.forEach(function (lst) {
                if (item.Id == lst.Id) existed = true;
            });
            return existed;
        }

        function addMember(assignList, self) {
            var items = [];
            assignList.forEach(function (member) {
                if (!isExisted(member, self.rightList)) {
                    var index = self.leftList.indexOf(member);
                    self.leftList.splice(index, 1);
                    self.rightList.push(member);
                    items.push(member);
                } else {
                    toastr.warning(member.Name + ' ' + $filter(constants.translate)("Member_To_Role.Already_Existed"));
                }
            });
            return items;
        }

        function removeMember(assignedList, self) {
            var items = [];
            assignedList.forEach(function (member) {
                var index = self.rightList.indexOf(member);
                self.rightList.splice(index, 1);
                if (!isExisted(member, self.leftList)) {
                    self.leftList.push(member);
                    items.push(member);
                }
            });
            return items;
        }

        function addAllMember(self) {
            var leftList = self.leftList;
            var items = [];
            leftList.forEach(function (member) {
                if (!isExisted(member, self.rightList)) {
                    items.push(member);
                    self.rightList.push(member);
                } else {
                    toastr.warning(member.Name + ' ' + $filter(constants.translate)("Member_To_Role.Already_Existed"));
                }
            });
            items.forEach(function (member) {
                var index = self.leftList.indexOf(member);
                self.leftList.splice(index, 1);
            });
            return items;
        }

        function removeAllMember(self) {
            var rightList = self.rightList;
            var items = [];
            rightList.forEach(function (member) {
                if (!isExisted(member, self.leftList)) {
                    self.leftList.push(member);
                    items = [];
                }
            });
            self.rightList = [];
            return items;
        }
    }
})();