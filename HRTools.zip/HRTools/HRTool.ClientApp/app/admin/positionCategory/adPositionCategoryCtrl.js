﻿(function () {
    "use strict";
    angular.module("app").controller('adPositionCategoryCtrl', AdPositionCategoryCtrl);
    AdPositionCategoryCtrl.$inject = ['adPositionCategorySvc', 'adPositionCategoryGridSvc', 'permissionSvc', 'messageHandleSvc',
        'adPositionCategoryGridModel', 'constants', 'message', 'adMessage',
        '$scope', '$filter', '$timeout'];
    function AdPositionCategoryCtrl(adPositionCategorySvc, adPositionCategoryGridSvc, permissionSvc, messageHandleSvc,
        adPositionCategoryGridModel, constants, message, adMessage,
        $scope, $filter, $timeout) {
        /* jshint -W040 */
        var self = this;
        self.pageIndex = constants.paging.firstPage;
        self.totalPages = constants.paging.totalPagesInitial;
        self.pagingOptions = {};
        self.showSelectionCheckbox = false;
        self.showFooter = true;
        self.enablePaging = true;
        self.enableCellEdit = true;
        self.showColumnMenu = false;
        self.dataGrid = "pscCtrl.data";
        self.pagingEvent = "pscCtrl.pagingOptions";
        self.rowTemplate = "admin/positionCategory/grid/adPositionCategoryGrid.html";
        self.gridId = "adPositionCategoryGrid";
        self.iconClass = "sprite-add-new-record";
        self.bigMsg = adMessage.positionCategory.textMessage;
        self.smallMsg = self.bigMsg;
        self.columnDefs = [];
        self.customCss = {};
        self.isSearching = false;
        self.dialogConfirm = adMessage.positionCategory.dialogConfirm;
        self.permissionOfCurrentUser = {
            addPositions: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Positions_Add),
            editPositions: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Positions_Edit),
            deletePositions: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Positions_Delete)
        };

        self.getPagedDataAsync = getPagedDataAsync;
        self.addNewPosition = addNewPosition;
        self.editPositionCategory = editPositionCategory;
        self.deletePositionCategory = deletePositionCategory;
        self.acceptDeletePositionCategory = acceptDeletePositionCategory;
        self.cancelEditPositionCategory = cancelEditPositionCategory;
        self.updatePositionCategory = updatePositionCategory;
        self.searchPositionByName = searchPositionByName;
        self.reloadPaging = reloadPaging;

        $scope.editCellGrid = editCellGrid;

        var initialPositionCategory = [];
        var rowIndexDeleting = null;
        var param = {};

        init();

        function init() {
            self = adPositionCategoryGridSvc.gridInit(self, $scope);
            self = self.getPagedDataAsync();
        }

        function getPagedDataAsync() {
            self.isSearching = !!(self.textSearchPositionByName);
            self = adPositionCategoryGridSvc.getPagedDataAsync(self, $scope);
            $timeout(function () {
                resetRowIndex();
            });
            return self;
        }

        function addNewPosition() {
            if (adPositionCategoryGridSvc.checkIsEditingDataRow(self)) {
                toastr.warning($filter(constants.translate)(message.addingData));
                return;
            }
            else {
                rebuildAfterAddNewRowGrid();
            }
        }

        function editPositionCategory(row) {
            if (adPositionCategoryGridSvc.checkIsEditingDataRow(self)) {
                toastr.warning($filter(constants.translate)(message.addingData));
                return;
            }
            initialPositionCategory = copyPositionCategories(self.data);
            self.gridOptions.$gridScope.isErrorDataRow[row.$$hashKey] = false;
            self.gridOptions.$gridScope.isEditingRow[row.$$hashKey] = !self.gridOptions.$gridScope.isEditingRow[row.$$hashKey];
            self.gridOptions.$gridScope.isModifiedDataRow[row.$$hashKey] = false;
        }

        function deletePositionCategory(row) {
            param.PstId = row.entity.PstId;
            rowIndexDeleting = row.rowIndex;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function acceptDeletePositionCategory() {
            toggleLoading(true);
            adPositionCategorySvc.getPositionCategoryResource(param).delete(false,
                function (response) {
                    if (response.$resolved) {
                        adPositionCategoryGridSvc.removeLocalData(param.PstId);
                        toastr.success($filter(constants.translate)(adMessage.positionCategory.deletePositionCategorySuccess));
                    } else {
                        toastr.error($filter(constants.translate)(adMessage.positionCategory.deletePositionCategoryError));
                    }
                    self.getPagedDataAsync();
                    toggleLoading(false);
                },
                function (xhr) {
                    if (xhr.status == constants.httpCodes.serverError) {
                        messageHandleSvc.handleResponse(xhr, adMessage.positionCategory.cantDeletePositionCategory);
                        toggleLoading(false);
                        return;
                    }
                    self.reloadPaging();
                    toggleLoading(false);
                });
        }

        function toggleLoading(isDelay) {
            if (isDelay) {
                $(constants.loadingIcon.overlay).show();
                $(constants.loadingIcon.indicator).show();
                return;
            }
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
        }

        function updatePositionCategory(row) {
            self.gridOptions.$gridScope.isEditingRow[row.$$hashKey] = !self.gridOptions.$gridScope.isEditingRow[row.$$hashKey];
            if (row.entity.PstId) {
                updatePostionCategory(row);
            } else {
                insertNewPostionCategory(row);
            }
        }

        function cancelEditPositionCategory(row) {
            if (self.gridOptions.$gridScope.isAddNewRow[row.$$hashKey]) {
                self.gridOptions.$gridScope.isAddNewRow[row.$$hashKey] = false;
                self.data.splice(0, 1);
                return;
            } else {
                self.data[row.rowIndex] = new adPositionCategoryGridModel(initialPositionCategory[row.rowIndex]);
                row.entity = new adPositionCategoryGridModel(initialPositionCategory[row.rowIndex]);
                self.gridOptions.$gridScope.isEditingRow[self.gridOptions.$gridScope.renderedRows[row.rowIndex].$$hashKey] = false;
            }
            if (!self.data || self.data.length === 0) {
                self.gridOptions.$gridScope.isEmpty = true;
            }
            self.getPagedDataAsync();
        }

        function searchPositionByName() {
            self.isSearching = !!(self.textSearchPositionByName);
            goToFirstPage();
        }

        function editCellGrid(row) {
            if (adPositionCategoryGridSvc.checkErrorDataRow(self, row)) {
                self.gridOptions.$gridScope.isErrorDataRow[row.$$hashKey] = true;
            } else {
                self.gridOptions.$gridScope.isErrorDataRow[row.$$hashKey] = false;
            }
            self.gridOptions.$gridScope.isModifiedDataRow[row.$$hashKey] = JSON.stringify(row.entity) != JSON.stringify(initialPositionCategory[row.rowIndex]);
        }

        function insertNewPostionCategory(row) {
            toggleLoading(true);
            param.PstId = undefined;
            adPositionCategorySvc.getPositionCategoryResource(param).save(row.entity,
                function (response) {
                    self.gridOptions.$gridScope.isEditingRow[row.$$hashKey] = false;
                    self.gridOptions.$gridScope.isAddNewRow[row.$$hashKey] = false;
                    row.entity.PstId = arrayResourceToInt(response);
                    adPositionCategoryGridSvc.updateLocalData(row.entity);
                    self.reloadPaging();
                    messageHandleSvc.handleResponse(response, adMessage.positionCategory.addPositionCategorySuccess);
                    toggleLoading(false);
                },
                function (error) {
                    cancelEditPositionCategory(row);
                    resetPage(row);
                    showPositionError(error);
                    toggleLoading(false);
                });
        }

        function updatePostionCategory(row) {
            toggleLoading(true);
            param.PstId = row.entity.PstId;
            adPositionCategorySvc.getPositionCategoryResource(param).update(row.entity,
                function (response) {
                    initialPositionCategory = copyPositionCategories(self.data);
                    self.gridOptions.$gridScope.isModifiedDataRow[row.$$hashKey] = false;
                    messageHandleSvc.handleResponse(response, adMessage.positionCategory.updatePositionCategorySuccess);
                    toggleLoading(false);
                },
                function (error) {
                    resetPage(row);
                    showPositionError(error);
                    toggleLoading(false);
                });
        }

        function resetPage(row) {
            goToFirstPage();
            row.entity = new adPositionCategoryGridModel(initialPositionCategory[row.rowIndex]);
            self.gridOptions.$gridScope.isEditingRow[self.gridOptions.$gridScope.renderedRows[row.rowIndex].$$hashKey] = false;
            self.data = copyPositionCategories(initialPositionCategory);
        }

        function showPositionError(error) {
            if (error.status == constants.httpCodes.conflict) {
                toastr.warning($filter(constants.translate)(adMessage.positionCategory.addPositionCategoryNameError));
            } else if (error.status == constants.httpCodes.serverError) {
                toastr.warning($filter(constants.translate)(adMessage.positionCategory.addPositionCategoryCodeError));
            } else {
                messageHandleSvc.handleResponse(error, message.errorLoadingData);
            }
        }

        function reloadPaging() {
            goToFirstPage();
            initialPositionCategory = copyPositionCategories(self.data);
        }

        /*
        * local method only
        */

        function rebuildAfterAddNewRowGrid() {
            if (self.gridOptions.$gridScope.isEmpty) {
                self.data = [];
                self.gridOptions.$gridScope.isEmpty = false;
                initialPositionCategory = copyPositionCategories(self.data);
            } else {
                initialPositionCategory = copyPositionCategories(self.data);

                for (var i = 0; i < self.gridOptions.$gridScope.renderedRows.length; i++) {
                    self.data[i] = new adPositionCategoryGridModel(self.gridOptions.$gridScope.renderedRows[i].entity);
                }
            }
            var newPostion = new adPositionCategoryGridModel(null);
            self.data.unshift(newPostion);
            $timeout(function () {
                for (var j = 0; j < self.gridOptions.$gridScope.renderedRows.length; j++) {
                    self.gridOptions.$gridScope.renderedRows[j].entity = new adPositionCategoryGridModel(self.data[j]);
                }
                self.gridOptions.$gridScope.isAddNewRow[self.gridOptions.$gridScope.renderedRows[0].$$hashKey] = true;
                self.gridOptions.$gridScope.isEditingRow[self.gridOptions.$gridScope.renderedRows[0].$$hashKey] = false;
            });

        }

        function resetRowIndex() {
            if (self.gridOptions.$gridScope) {
                for (var i = 0; i < self.gridOptions.$gridScope.renderedRows.length; i++) {
                    self.gridOptions.$gridScope.isErrorDataRow[self.gridOptions.$gridScope.renderedRows[i].$$hashKey] = false;
                    self.gridOptions.$gridScope.isEditingRow[self.gridOptions.$gridScope.renderedRows[i].$$hashKey] = false;
                    self.gridOptions.$gridScope.isAddNewRow[self.gridOptions.$gridScope.renderedRows[i].$$hashKey] = false;
                }
            }
        }

        function goToFirstPage() {
            if (self.pagingOptions.currentPage != constants.paging.firstPage)
                self.pagingOptions.currentPage = constants.paging.firstPage;
            self.getPagedDataAsync();
        }

        function copyPositionCategories(data) {
            initialPositionCategory = [];
            $.each(data, function (item, position) {
                initialPositionCategory.push(new adPositionCategoryGridModel(position));
            });
            return initialPositionCategory;
        }
    }
})();

