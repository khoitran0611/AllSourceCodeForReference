﻿(function () {
    'use strict';
    angular.module("app").service('adPositionCategorySvc', adPositionCategorySvc);
    adPositionCategorySvc.$inject = ["$resource", "adConstants", "constants"];
    function adPositionCategorySvc($resource, adConstants, constants) {
        var revealed = {
            getPositionCategoryResource: getPositionCategoryResource
        };
        return revealed;
        function getPositionCategoryResource(param) {
            return $resource(
                constants.apiUrl + 'positions/:id',
                     { id: param.PstId, action: param.action }, { "update": { method: "PUT" } });
        }
    }
})();