﻿(function () {
    'use strict';
    angular.module("app").service('adPositionCategoryGridSvc', adPositionCategoryGridSvc);
    adPositionCategoryGridSvc.$inject = [
        'gridSvc', 'adPositionCategorySvc', 'objectSvc', 'messageHandleSvc',
        'enumGlyphicon', 'adPositionCategoryGridModel', 'gridHeader', 'constants', '$filter', 'adMessage', 'comparisonUtilSvc', 'loadingSvc'];
    function adPositionCategoryGridSvc(
        gridSvc, adPositionCategorySvc, objectSvc, messageHandleSvc,
        enumGlyphicon, adPositionCategoryGridModel, gridHeader, constants, $filter, adMessage, comparisonUtilSvc, loadingSvc) {
     var revealed = {
            getPagedDataAsync: getPagedDataAsync,
            gridInit: gridInit,
            checkErrorDataRow: checkErrorDataRow,
            checkIsEditingDataRow: checkIsEditingDataRow,
            removeLocalData: removeLocalData,
            updateLocalData: updateLocalData
        };
        var isAlreadyGetServerData = false;
        var data = [];
        var tempData = [];
        return revealed;
        function getPagedDataAsync(self, $scope) {
            var result = self;
            var param = { action: "getPositionByName", PstName: "" };
            var gridData;
            var positionCategories = adPositionCategorySvc.getPositionCategoryResource(param).get(
                function () {
                    if (!comparisonUtilSvc.isNullOrUndefinedValue(positionCategories.ListView)) {
                        data = [];
                        positionCategories.ListView.forEach(function (positionData) {
                            var position = new adPositionCategoryGridModel(positionData);
                            data.push(position);
                        });
                    }
                    gridData = self.textSearchPositionByName ?
                            objectSvc.findAllItemsInArray(self.textSearchPositionByName, "PstName", data) : data;
                    result = gridSvc.setPagingDataFullLoad(self, gridData, $scope);
                    loadingSvc.close();
                    return result;
                }, function(xhr) {
                    messageHandleSvc.handleResponse(xhr, adMessage.positionCategory.getPositionCategoryError);
                    loadingSvc.close();
            });
            gridData = self.textSearchPositionByName ?
                          objectSvc.findAllItemsInArray(self.textSearchPositionByName, "PstName", data) : data;
            result = gridSvc.setPagingDataFullLoad(self, gridData, $scope);
            return result;
        }

        function gridInit(self, $scope) {
            var result = self;
            result.columnDefs = [
                new gridHeader("PstName", "Position_Name", '', true, { isRequired: true }),
                new gridHeader("Code", "Code", '', true, { isRequired: true }),
                new gridHeader("Note", "Description", '', true, { isRequired: false }),
                new gridHeader("EditButton", '', '', true, { isRequired: false }),
                new gridHeader("DeleteButton", '', '', true, { isRequired: false }),
                new gridHeader("SaveButton", '', '', false, { isRequired: false }),
                new gridHeader("CancelButton", '', '', false, { isRequired: false })
            ];
            result.customCss.showButtonEditRow = enumGlyphicon.glyphiconEditButton;
            result.customCss.showButtonDeleteRow = enumGlyphicon.glyphiconDeleteButton;
            result.customCss.showButtonUpdateRow = enumGlyphicon.glyphiconSaveButton;
            result.customCss.showButtonCancelEditRow = enumGlyphicon.glyphiconCancelButton;
            result.customCss.showButtonDisableUpdateRow = enumGlyphicon.glyphiconDisableSaveButton;
            result = gridSvc.init(result, $scope);
            return result;
        }

        function checkErrorDataRow(self, row) {
            return gridSvc.checkErrorDataRow(self, row);
        }

        function checkIsEditingDataRow(self) {
            return gridSvc.checkIsEditingDataRow(self);
        }

        function removeLocalData(item) {
            var indexOfItem = findWithAttr(data, "PstId", item);
            data.splice(indexOfItem, 1);
        }

        function updateLocalData(item) {
            data.unshift(item);
        }
    }
})();