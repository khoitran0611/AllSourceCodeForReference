﻿(function () {
    "use strict";
    angular.module("app").factory('adPositionCategoryGridModel', adPositionCategoryGridModel);
    function adPositionCategoryGridModel() {
        var adPositionCategoryGridModelTemp = function (positionCategory) {
            /* jshint -W040 */
            var self = this;
            self.PstId = positionCategory ? positionCategory.PstId : undefined;
            self.PstName = positionCategory ? positionCategory.PstName : undefined;
            self.Code = positionCategory ? positionCategory.Code : undefined;
            self.Note = positionCategory ? positionCategory.Note : '';
            self.EditButton = "";
            self.DeleteButton = "";
            self.SaveButton = "";
            self.CancelButton = "";
        };
        return adPositionCategoryGridModelTemp;
    }
})();