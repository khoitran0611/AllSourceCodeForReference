﻿(function () {
    angular.module('app').controller('errorCtrl', errorCtrl);
    errorCtrl.$inject = ['authSvc'];

    function errorCtrl(authSvc) {
        var vm = this;
        vm.logout = logout;
        init();

        function init() {
            $("#ajax-overlay").hide();
            $("#ajax-indicator").hide();
        }

        function logout() {
            authSvc.logout();
        }
    }
})();