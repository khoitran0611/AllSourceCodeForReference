﻿(function () {
    'use strict';
    angular.module('app').factory('caJobInvitationSvc', caJobInvitationSvc);
    caJobInvitationSvc.$inject = ['$resource', 'caConstants', 'constants'];
    function caJobInvitationSvc($resource, caConstants, constants) {
        return {
            getEmailDataForSendJobInvitation: getEmailDataForSendJobInvitation,
            createJobDescriptionPDF: createJobDescriptionPDF,
            jobApplicationJobInvitationEmail: jobApplicationJobInvitationEmail,
            sendJobInvitationTemplateTextUpdated: sendJobInvitationTemplateTextUpdated,
            sendMultiMailJobInvitation: sendMultiMailJobInvitation
        };

        function getEmailDataForSendJobInvitation() {
            return $resource(constants.apiUrl + 'email/email-job-invitation', {});
        }

        function createJobDescriptionPDF(id) {
            return $resource(constants.apiUrl + 'job-description/:id', { id: id }, { 'update': { method: "PUT" } });
        }

        function jobApplicationJobInvitationEmail(jobApplicationId) {
            return $resource(constants.apiUrl + 'job-applications/:id/email-job-invitation', { id: jobApplicationId });
        }

        function sendJobInvitationTemplateTextUpdated(jobApplicationId) {
            return $resource(constants.apiUrl + 'job-applications/:id/email-job-invitation-letter-first-candidate', { id: jobApplicationId });
        }

        function sendMultiMailJobInvitation(param, jobId) {
            return $resource(constants.apiUrl + 'emails/', {}, {
                "sendMultiMailJobInvitation": { method: "POST", headers: { ActionName: "sendMultiMailJobInvitation", DataJsonFormat: JSON.stringify(param), JobId: JSON.stringify(jobId) } }
            });
        }
    }
})();
