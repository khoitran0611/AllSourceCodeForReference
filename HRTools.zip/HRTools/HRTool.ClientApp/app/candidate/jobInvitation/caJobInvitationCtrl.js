﻿(function () {
    'use strict';
    angular.module('app').controller('caJobInvitationCtrl', CaJobInvitationCtrl);
    CaJobInvitationCtrl.$inject = [
        'caJobInvitationSvc', 'messageHandleSvc', 'message', '$filter', 'constants',
        '$rootScope', '$scope', 'candidateSvc', 'caMessage', '$timeout', 'emailSvc', 'comparisonUtilSvc', 'loadingSvc'];
    function CaJobInvitationCtrl(
        caJobInvitationSvc, messageHandleSvc, message, $filter, constants,
        $rootScope, $scope, candidateSvc, caMessage, $timeout, emailSvc, comparisonUtilSvc, loadingSvc) {
        var self = this;
        var indexCandidate = 0;
        var originContentText = "";
        var originSubjectText = "";
        var originContent = "";
        var originSubject = "";
        var jobApplicationList = {};
        var fileAttachName = "";
        var fileAttachPath = "";
        var fileAttach = "";
        var selectedJobName = "";
        var currentPositionSelect = null;

        self.emailData = {};
        self.emailData.jobDescription = {};
        self.emailData.dataForPreview = {};
        self.emailData.listOfJobApplication = {};
        self.positionList = [];
        self.selectedJob = null;
        self.hidePlaceHolder = false;
        self.isDisablePrevious = true;
        self.isDisableNext = false;
        self.selectJobAlready = true;
        self.positions = candidateSvc.getSendMailOpenPositions().query();
        self.serverUrl = constants.serverUrl;

        self.cancelSendJobInvitation = cancelSendJobInvitation;
        self.selectPosition = selectPosition;
        self.previewEmailSendJobInvitation = previewEmailSendJobInvitation;
        self.previousCandidate = previousCandidate;
        self.nextCandidate = nextCandidate;
        self.sendMail = sendMail;
        self.closeReviewEmail = closeReviewEmail;

        init();
        function init() {
            $scope.$on(constants.broadCastTile.sendJobInvitation, function (event, rootScopeParams) {
                jobApplicationList = rootScopeParams.jobApplicationIdList;
                if (rootScopeParams.jobApplicationIdList.length == 1) {
                    var firstJobApplication = jobApplicationList[0].JobApplicationId;
                    indexCandidate = 0;
                    loadingSvc.show();
                    caJobInvitationSvc.jobApplicationJobInvitationEmail(firstJobApplication).get(function (data) {
                        self.emailData = data;
                        self.emailData.JobDescription = !comparisonUtilSvc.isNullOrUndefinedValue(currentPositionSelect) ? currentPositionSelect : null;
                        originContent = angular.copy(self.emailData.Content);
                        originSubject = angular.copy(self.emailData.Subject);
                        self.isDisablePrevious = true;
                        self.isDisableNext = false;
                        self.emailData.listOfJobApplication = jobApplicationList;
                        loadingSvc.close();
                    }, function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                    });
                } else {
                    getEmailData();
                    if (!$scope.$$phase && !$scope.$root.$$phase) {
                        $scope.$apply();
                    }
                }
            });

            $scope.$watch("jobInCtrl.positions", function (value) {
                if (!value || value.length === 0) return;
                self.positionList = self.positions;
            }, true);

            $scope.$watch("caCtrl.isSendJobInvitation", function (value) {
                if (value === true) return;
                cancelSendJobInvitation();
            }, true);

            $("#open-postion-select1").select2({});

            $(document).bind('click', function (event) {
                var $clicked = $(event.target);
                if (!$clicked.hasClass("job-select")) {
                    if (!self.selectedJob) {
                        self.hidePlaceHolder = false;
                    }
                }
            });
        }

        function createJobDescriptionPDF(id) {
            caJobInvitationSvc.createJobDescriptionPDF(id).get(function (data) {
                currentPositionSelect = data;
                self.emailData.JobDescription = data;
                fileAttach = data.FilePath;
                fileAttachName = data.FileName;
                fileAttachPath = data.FilePathToViewOnBrowser;
                self.selectJobAlready = false;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
            });
        }

        function getEmailData() {
            caJobInvitationSvc.getEmailDataForSendJobInvitation().get(function (data) {
                self.emailData = data;
                self.emailData.listOfJobApplication = jobApplicationList;
                self.originContent = JSON.stringify(self.emailData.Content);
                self.emailData.originContent = self.originContent;
                self.originSubject = JSON.stringify(self.emailData.Subject);
                self.emailData.originSubject = self.originSubject;
                self.emailData.To = $filter(constants.translate)(caMessage.updateCvMessage) + jobApplicationList.length + $filter(constants.translate)('candidates');
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
            });
        }

        function cancelSendJobInvitation() {
            removeHoverElement('.sprite-invitation');
            if (!comparisonUtilSvc.isNullOrUndefinedValue($scope.$parent.$parent.caCtrl)) {
                $scope.$parent.$parent.caCtrl.isSendJobInvitation = false;
            }
            if (!comparisonUtilSvc.isNullOrUndefinedValue($scope.$parent.$parent.cdCtrl)) {
                $scope.$parent.$parent.cdCtrl.isSendJobInvitation = false;
            }
            self.hidePlaceHolder = false;
            self.selectJobAlready = true;
            self.emailData = {};
            self.emailData.dataForPreview = {};
            self.emailData.listOfJobApplication = {};
            self.emailData.JobDescription = {};
            $timeout(function () {
                $("#s2id_open-postion-select .select2-choice .select2-chosen").text();
            }, 100);
            self.selectedJob = "";
        }

        function selectPosition() {
            for (var index = 0; index < self.positions.length; index++) {
                if (self.positions[index].JobId == self.selectedJob) {
                    self.position = self.positions[index];
                    break;
                }
            }
            self.selectedJob = self.position.JobId;
            selectedJobName = self.position.JobTitle;
            createJobDescriptionPDF(self.selectedJob);
            if (jobApplicationList.length == 1) {
                self.emailData.listOfJobApplication[0].Position = selectedJobName;
                self.emailData.Subject = placeholderTextInLetterTemplate(originSubject, self.emailData.listOfJobApplication[0]);
                self.emailData.Content = placeholderTextInLetterTemplate(originContent, self.emailData.listOfJobApplication[0]);
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            }
            $timeout(function () {
                $("#s2id_open-postion-select .select2-choice .select2-chosen").text(self.position.JobTitle);
            }, 100);
        }

        function previewEmailSendJobInvitation() {
            self.emailData.listOfJobApplication = jobApplicationList;
            for (var index = 0; index < self.emailData.listOfJobApplication.length; index++) {
                self.emailData.listOfJobApplication[index].Position = selectedJobName;
            }
            var firstJobApplication = self.emailData.listOfJobApplication[0].JobApplicationId;
            indexCandidate = 0;
            originContent = JSON.stringify(self.emailData.Content);
            originSubject = JSON.stringify(self.emailData.Subject);
            caJobInvitationSvc.sendJobInvitationTemplateTextUpdated(firstJobApplication).save(self.emailData, function (data) {
                self.isDisablePrevious = true;
                self.isDisableNext = false;
                self.emailData.dataForPreview = data;
                originContentText = angular.copy(self.emailData.dataForPreview.Content);
                originSubjectText = angular.copy(self.emailData.dataForPreview.Subject);
                self.emailData.listOfJobApplication[0].Title = convertGenderToTitle(self.emailData.listOfJobApplication[0].Title);
                self.emailData.dataForPreview.Subject = placeholderTextInLetterTemplate(originSubjectText, self.emailData.listOfJobApplication[0]);
                self.emailData.dataForPreview.Content = placeholderTextInLetterTemplate(originContentText, self.emailData.listOfJobApplication[0]);
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
            });
            $("#previewSendJobInvitation").modal('show');
        }

        function previousCandidate() {
            if (indexCandidate <= 0) return;
            self.isDisableNext = false;
            indexCandidate--;
            $timeout(function () {
                self.emailData.dataForPreview.To = self.emailData.listOfJobApplication[indexCandidate].Email;
                self.emailData.dataForPreview.Subject = placeholderTextInLetterTemplate(originSubjectText, self.emailData.listOfJobApplication[indexCandidate]);
                self.emailData.listOfJobApplication[indexCandidate].Title = convertGenderToTitle(self.emailData.listOfJobApplication[indexCandidate].Gender);
                self.emailData.dataForPreview.Content = placeholderTextInLetterTemplate(originContentText, self.emailData.listOfJobApplication[indexCandidate]);
            }, 200);
            if (indexCandidate === 0) {
                self.isDisablePrevious = true;
            }
        }

        function nextCandidate() {
            if (indexCandidate >= self.emailData.listOfJobApplication.length - 1) return;
            self.isDisablePrevious = false;
            indexCandidate++;
            $timeout(function () {
                self.emailData.dataForPreview.To = self.emailData.listOfJobApplication[indexCandidate].Email;
                self.emailData.dataForPreview.Subject = placeholderTextInLetterTemplate(originSubjectText, self.emailData.listOfJobApplication[indexCandidate]);
                self.emailData.listOfJobApplication[indexCandidate].Title = convertGenderToTitle(self.emailData.listOfJobApplication[indexCandidate].Gender);
                self.emailData.dataForPreview.Content = placeholderTextInLetterTemplate(originContentText, self.emailData.listOfJobApplication[indexCandidate]);
            }, 200);
            if (indexCandidate === self.emailData.listOfJobApplication.length - 1) {
                self.isDisableNext = true;
            }
        }

        function sendMail() {
            var jobApplicationIdList = [];
            $.each(jobApplicationList, function (i, item) {
                jobApplicationIdList.push(item.JobApplicationId);
            });
            self.emailData.FileAttach = fileAttach;
            self.emailData.FileNameAttach = fileAttachName;
            self.emailData.FilePathToViewOnBrowser = fileAttachPath;
            caJobInvitationSvc.sendMultiMailJobInvitation(jobApplicationIdList, self.selectedJob).sendMultiMailJobInvitation(self.emailData,
                    function () {
                        if (jobApplicationIdList.length == 1) {
                            toastr.success($filter(constants.translate)(caMessage.SendEmailsSuccessFull));
                            self.emailData.Content = angular.copy(originContent);
                            self.emailData.Subject = angular.copy(originSubject);
                        } else {
                            toastr.success($filter(constants.translate)(caMessage.SendMultiEmailsSuccessFull));
                            self.emailData.Content = angular.copy(self.emailData.originContent);
                            self.emailData.Subject = angular.copy(self.emailData.originSubject);
                        }
                        $rootScope.$broadcast(constants.broadCastTile.requestUpdateCV, {});
                        cancelSendJobInvitation();
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.sendMailUpdateCvError));
                    });

        }

        function closeReviewEmail() {
            self.emailData.Subject = angular.copy(originSubject);
            self.emailData.Content = angular.copy(originContent);
            self.emailData.dataForPreview = {};
        }
    }
})();
