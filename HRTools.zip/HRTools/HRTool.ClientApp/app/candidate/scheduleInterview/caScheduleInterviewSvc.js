﻿(function () {
    'use strict';
    angular.module('app').factory('caScheduleInterviewSvc', caScheduleInterviewSvc);
    caScheduleInterviewSvc.$inject = ['$resource', '$state', '$filter', '$timeout', 'messageHandleSvc', 'datetimeSvc', 'historyPageSvc', 'message', 'caMessage', 'constants', 'caConstants'];
    function caScheduleInterviewSvc($resource, $state, $filter, $timeout, messageHandleSvc, datetimeSvc, historyPageSvc, message, caMessage, constants, caConstants) {
        var data = {
            // Holds all data in the notification step
            notification: {
                candidateName: "",
                candidateEmail: {},
                interviewerEmail: {},
                sendEmailToCandidate: false,
                sendEmailToInterviewer: false
            },
            dateTimeChosen: {
                selectedRoomId: 0, addedEvent: null,
                start: null,
                end: null,
                levelRound: caConstants.levelRound.firstRound
            },
            scheduleInterviewDto: null,
            currentTab: 1,
            scheduleInterview: null,
            selectedInterviewerId: null,
            selectedRoomId: null,
            interviewerEmail: null,
            interviewerName: null,
            candidateEmail: null,
            events: null,
            levelRound: caConstants.levelRound.firstRound,
            jobId: 0,
            positionId: 0,
            interviews: null,
            currentLevelRound: null
        };
        var validRooms = [];

        var url = constants.apiUrl + 'candidates/:candidateId/appliedpositions/:jobApplicationId/InterviewSchedules/:scheduleInterviewId';

        var urlAppointment = constants.apiUrl + 'interview-schedules/appointments';
        var urlValidRooms = constants.apiUrl + 'interview-schedules/valid-room';

        var resourceAppointmentSvc = $resource(urlAppointment, {}, {
            'getAppoitments': { method: 'GET', isArray: true, startDate: '@startDate', endDate: '@endDate', roomId: '@roomId', interviewId: '@interviewId' }
        });

        var resourceValidRoomSvc = $resource(urlValidRooms, {}, {
            'getValidRooms': { method: 'GET', isArray: true, startTime: '@startTime', endTime: '@endTime', interviewId: '@interviewId' }
        });

        var resourceSvc = $resource(url, {}, {
            'getScheduleInterviews': { method: 'GET', candidateId: '@candidateId', jobApplicationId: '@jobApplicationId' },
            'addInterviewSchedule': { method: 'POST', candidateId: '@candidateId', jobApplicationId: '@jobApplicationId' },
            'updateInterviewShedule': { method: 'PUT', candidateId: '@candidateId', jobApplicationId: '@jobApplicationId', scheduleInterviewId: '@scheduleInterviewId' }
        });

        return {
            data: data,
            getData: getData,
            setData: setData,
            resetDateTimeChosenData: resetDateTimeChosenData,
            setInterviewerInfo: setInterviewerInfo,
            getScheduleInterviews: getScheduleInterviews,
            getAppointments: getAppointments,
            getEvents: getEvents,
            addInterviewSchedule: addInterviewSchedule,
            updateInterviewSchedule: updateInterviewSchedule,
            backToInterviewsTab: backToInterviewsTab,
            stringifyLevelRound: stringifyLevelRound,
            rooms: rooms,
            getValidRooms: getValidRooms,
            getCurrentValidRooms: getCurrentValidRooms,
            setCurrentValidRooms: setCurrentValidRooms,
            interviewInfoForCanceling: interviewInfoForCanceling
        };

        function getData() {
            return data;
        }

        function setData(newData) {
            data = newData;
        }

        function resetDateTimeChosenData() {
            data.dateTimeChosen.addedEvent = null;
            data.dateTimeChosen.selectedRoomId = 0;
            data.dateTimeChosen.start = null;
            data.scheduleInterviewDto = null;
            data.currentLevelRound = "";
        }

        function getScheduleInterviews(candidateId, jobApplicationId, scheduleInterviewId) {
            resourceSvc.getScheduleInterviews({ candidateId: candidateId, jobApplicationId: jobApplicationId }).$promise.then(function (result) {
                data.scheduleInterview = result;

                //update
                if (scheduleInterviewId && scheduleInterviewId !== 0) {
                    setDefaultInterviewerInfo(scheduleInterviewId, result.ScheduleList);
                } else {
                    if (data.selectedInterviewerId <= 0)
                        data.selectedInterviewerId = result.InterviewersList[0].Id;
                }

                setInterviewerInfo(data.selectedInterviewerId, result.InterviewersList);

            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                clearOverlay();
            });
            return data;
        }

        function getAppointments(startDate, endDate, roomId, interviewId) {
            var start = moment(startDate).format('YYYY-MM-DD');
            var end = moment(endDate).format('YYYY-MM-DD');

            resourceAppointmentSvc.getAppoitments({ startDate: start, endDate: end, roomId: roomId, interviewId: interviewId }).$promise.then(function (result) {
                data.events = result;

            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
            });
            return data;
        }

        function getEvents(startDate, endDate, roomId, interviewId) {
            var start = moment(startDate).format('YYYY-MM-DD');
            var end = moment(endDate).format('YYYY-MM-DD');
            return resourceAppointmentSvc.getAppoitments({ startDate: start, endDate: end, roomId: roomId, interviewId: interviewId });
        }

        var isSendMailCandidate, isSendMailEmployee;
        function addInterviewSchedule(candidateId, jobApplicationId, scheduleInterviewDto, callback) {
            isSendMailCandidate = scheduleInterviewDto.IsSendMailToCandidate;
            isSendMailEmployee = scheduleInterviewDto.IsSendMailToEmployee;
            scheduleInterviewDto.IsSendMailToCandidate = false;
            scheduleInterviewDto.IsSendMailToEmployee = false;
            resourceSvc.addInterviewSchedule({ candidateId: candidateId, jobApplicationId: jobApplicationId }, scheduleInterviewDto).$promise.then(function (result) {
                sendEmail(jobApplicationId);
                $(constants.loadingIcon.overlay).hide();
                $(constants.loadingIcon.indicator).hide();
                backToInterviewsTab(candidateId, jobApplicationId, 0);
                toastr.success($filter(constants.translate)(caMessage.scheduleInterview.addScheduleSuccessful));
            },
            function (xhr) {
                toastr.error($filter(constants.translate)(caMessage.scheduleInterview.addScheduleFail));
                callback();
            });
        }

        function updateInterviewSchedule(candidateId, jobApplicationId, scheduleInterviewId, scheduleInterviewDto, callback) {
            isSendMailCandidate = scheduleInterviewDto.IsSendMailToCandidate;
            isSendMailEmployee = scheduleInterviewDto.IsSendMailToEmployee;
            scheduleInterviewDto.IsSendMailToCandidate = false;
            scheduleInterviewDto.IsSendMailToEmployee = false;
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
            resourceSvc.updateInterviewShedule({ candidateId: candidateId, jobApplicationId: jobApplicationId, scheduleInterviewId: scheduleInterviewId }, scheduleInterviewDto).$promise.then(function (result) {
                sendEmail(jobApplicationId);
                backToInterviewsTab(candidateId, jobApplicationId, scheduleInterviewDto.InterviewId);
                toastr.success($filter(constants.translate)(caMessage.scheduleInterview.updateScheduleSuccessful));
            },
            function (xhr) {
                toastr.error($filter(constants.translate)(caMessage.scheduleInterview.updateScheduleFail));
                callback();
            });
        }

        function sendEmail(jobApplicationId) {
            //Send email to candidate
            data.notification.candidateEmail.jobApplicationId = jobApplicationId;
            if (isSendMailCandidate) {
                data.notification.candidateEmail.IsCandidate = true;
                scheduleEmail().sendScheduleEmail(data.notification.candidateEmail,
                    function () {

                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    }
                 );
            }
            // Send email to interview
            if (isSendMailEmployee) {
                data.notification.interviewerEmail.IsCandidate = false;
                scheduleEmail().sendScheduleEmail(data.notification.interviewerEmail,
                    function () {

                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    }
                 );
            }
        }

        function scheduleEmail() {
            return $resource(constants.apiUrl + 'emails/', {},
                { "sendScheduleEmail": { method: "POST", headers: { ActionName: "sendScheduleEmail" } } });
        }

        function setDefaultInterviewerInfo(scheduleInterviewId, scheduleList) {
            window.angular.forEach(scheduleList, function (obj) {
                if (scheduleInterviewId == obj.InterviewId) {
                    data.selectedInterviewerId = obj.InterviewerId;
                    data.candidateEmail = obj.EmailCandidate;
                    data.levelRound = obj.LevelRound;
                }
            });
        }

        function setInterviewerInfo(selectedInterviewerId, interviewersList) {
            window.angular.forEach(interviewersList, function (obj) {
                if (selectedInterviewerId == obj.Id) {
                    data.interviewerEmail = obj.Code;
                    data.interviewerName = obj.Name;
                    data.selectedInterviewerId = selectedInterviewerId;
                }
            });
            $timeout(function () {
                clearOverlay();
            }, 1000);
        }

        function backToInterviewsTab(candidateId, jobApplicationId, InterviewId) {
            var url = constants.baseUrl + "#/candidates/" + candidateId + "/job-application/" + jobApplicationId + "/schedule-interview/" + InterviewId;
            var previousUrl = historyPageSvc.getPreviousUrl(url);
            if (previousUrl && previousUrl.indexOf("/#/candidates/") == -1) {
                $timeout(function () {
                    historyPageSvc.setPreviousUrl(url, "");
                    window.location.href = previousUrl;
                }, 1500);
                return;
            }
            historyPageSvc.setPreviousUrl(url, "");
            if ((constants.baseUrl + "#/candidates") === previousUrl) {
                $state.go("candidate", { id: candidateId }).then(clearOverlay());
                return;
            }
            $state.go("candidateDetail", { id: candidateId }).then(clearOverlay());
            return;
        }

        function clearOverlay() {
            $('#ajax-overlay').hide();
            $('#ajax-indicator').hide();
            $('.modal-backdrop').remove();
        }

        function stringifyLevelRound(levelRound) {
            switch (levelRound) {
                case 1:
                    return "Quiz Test";
                case 2:
                    return "First";
                case 3:
                    return "Second";
                case 4:
                    return "Third";
                default:
                    return "First";
            }
        }

        function rooms(startTime, endTime, interviewId) {
            return resourceValidRoomSvc.getValidRooms({ startTime: startTime, endTime: endTime, interviewId: interviewId });
        }

        function getValidRooms(startTime, endTime, interviewId) {
            var start = datetimeSvc.convertDateForServer(startTime, true);
            var end = datetimeSvc.convertDateForServer(endTime, true);
            rooms(start, end, interviewId).$promise.then(function (result) {
                validRooms = result;
            }, function (error) {
                messageHandleSvc.handleResponse(error, $filter(constants.translate)(message.errorLoadingData));
            });
        }

        function getCurrentValidRooms() {
            return validRooms;
        }

        function setCurrentValidRooms(roomData) {
            validRooms = [];
            angular.copy(roomData, validRooms);
        }

        function interviewInfoForCanceling(interviewId) {
            return $resource(constants.apiUrl + 'interviews/:interviewId', { interviewId: interviewId }, { "update": { method: "PUT" } });
        }
    }
})();
