﻿(function () {
    'use strict';
    angular.module('app').controller('caConfirmationCtrl', CaConfirmationCtrl);
    CaConfirmationCtrl.$inject = ['constants', '$state', '$filter',
        'caScheduleInterviewSvc', 'permissionSvc', 'objectSvc', 'authenticationSvc', 'messageHandleSvc', 'datetimeSvc',
        'caConstants', 'message'];
    function CaConfirmationCtrl(constants, $state, $filter,
            caScheduleInterviewSvc, permissionSvc, objectSvc, authenticationSvc, messageHandleSvc, datetimeSvc,
            caConstants, message) {
        var newId = 0;
        var interviewId = $state.params.interviewId;
        var data = caScheduleInterviewSvc.getData();
        var isFinish = false;
        var self = this;

        self.currentUserPermission = permissionSvc.getCurrentUserPermission();

        self.backToPreviousStep = backToPreviousStep;
        self.finish = finish;

        init();

        function init() {
            if (!self.currentUserPermission.canViewSchedule) {
                messageHandleSvc.handlePermission();
                return;
            }
            self.canShowFinish = self.currentUserPermission.canEditSchedule || self.currentUserPermission.canAddSchedule;
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
            self.scheduleInterviewData = data;
            self.interviewDate = datetimeSvc.convertDateToLongDate12HourFormat(data.scheduleInterviewDto.FromBookRoomDate);
        }

        function backToPreviousStep() {
            $state.go(caConstants.scheduleInterviewTabName.notification);
        }

        function finish() {
            $(constants.loadingIcon.overlay).show();
            $(constants.loadingIcon.indicator).show();
            var scheduleInterviewDto = data.scheduleInterviewDto;
            if (isFinish) return;
            isFinish = true;
            if (interviewId == newId) {
                if (!objectSvc.checkPermission(self.currentUserPermission.canAddSchedule, message.dontHavePermissionAccess, true)) {
                    return;
                }
                caScheduleInterviewSvc.addInterviewSchedule(scheduleInterviewDto.CandidateId, scheduleInterviewDto.CanDtlId, scheduleInterviewDto, addFail);
            } else {
                if (!objectSvc.checkPermission(self.currentUserPermission.canEditSchedule, message.dontHavePermissionAccess, true)) {
                    return;
                }
                caScheduleInterviewSvc.updateInterviewSchedule(scheduleInterviewDto.CandidateId, scheduleInterviewDto.CanDtlId, scheduleInterviewDto.ScheduleInterviewId, scheduleInterviewDto, addFail);
            }
        }

        function addFail() {
            isFinish = false;
        }
    }
})();

