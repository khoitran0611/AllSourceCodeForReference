﻿(function () {
    'use strict';
    angular.module('app').controller('caScheduleInterviewCtrl', CaScheduleInterviewCtrl);
    CaScheduleInterviewCtrl.$inject = ['$rootScope', '$scope', '$filter', '$state',
        'constants', 'caConstants', 'message', 'caMessage',
        'caScheduleInterviewSvc', 'candidateSvc', 'permissionSvc', 'objectSvc', 'authenticationSvc', 'historyPageSvc', 'messageHandleSvc'];
    function CaScheduleInterviewCtrl($rootScope, $scope, $filter, $state,
            constants, caConstants, message, caMessage,
            caScheduleInterviewSvc, candidateSvc, permissionSvc, objectSvc, authenticationSvc, historyPageSvc, messageHandleSvc) {
        var self = this;
        self.currentUserPermission = permissionSvc.getCurrentUserPermission();
        if (!self.currentUserPermission.canViewSchedule) {
            //authenticationSvc.logout();
            return;
        }
        self.candidateId = $state.params.id;
        self.jobApplicationId = $state.params.jobApplicationId;
        self.interviewId = $state.params.interviewId;

        self.isActivatedTab = isActivatedTab;
        self.clearOverlay = clearOverlay;
        self.openConfirmModal = openConfirmModal;
        self.backToInterviewsTab = backToInterviewsTab;

        init();

        function init() {
            $state.go(caConstants.scheduleInterviewTabName.overallInformation);
            clearOverlay(true);
            caScheduleInterviewSvc.resetDateTimeChosenData();
            candidateSvc.interviewResource(self.candidateId, self.jobApplicationId).get(function (result) {
                var candidateInterview = result;
                caScheduleInterviewSvc.data.jobId = candidateInterview.JobId;
                caScheduleInterviewSvc.data.positionId = candidateInterview.PositionId;
                caScheduleInterviewSvc.data.interviews = candidateInterview.Interviews;

                // case: user doesn't book room, get levelRound to send email to candidate
                var newId = 0;
                if (self.interviewId != newId) {
                    //udpate case
                    for (var i = 0; i < candidateInterview.Interviews.length; i++) {
                        var interview = candidateInterview.Interviews[i];
                        if (interview.InterviewRound.CanRndId == self.interviewId) {
                            caScheduleInterviewSvc.data.dateTimeChosen.selectedRoomId = interview.InterviewRound.RoomId;
                            caScheduleInterviewSvc.data.dateTimeChosen.start = interview.InterviewRound.FromBookRoomDate;
                            caScheduleInterviewSvc.data.dateTimeChosen.end = interview.InterviewRound.ToBookRoomDate;
                            caScheduleInterviewSvc.data.dateTimeChosen.levelRound = interview.InterviewRound.LevelRound;
                            // case: we have interview but no room, must select .addEvent to bind info to calendar
                            if (!interview.InterviewRound.RoomId || interview.InterviewRound.RoomId == -1)
                                caScheduleInterviewSvc.data.dateTimeChosen.addedEvent = {
                                    start: interview.InterviewRound.FromBookRoomDate,
                                    end: interview.InterviewRound.ToBookRoomDate,
                                    levelRound: caScheduleInterviewSvc.data.dateTimeChosen.levelRound,
                                    roomId: -1,
                                    interviewId: interview.InterviewRound.CanRndId,
                                    scheduleInterviewId: interview.InterviewRound.ScheduleInterviewId,
                                    className: 'current-schedule-interview'
                                };
                            caScheduleInterviewSvc.getValidRooms(interview.InterviewRound.FromBookRoomDate, interview.InterviewRound.ToBookRoomDate, self.interviewId);
                        }
                    }
                } else {
                    if (candidateInterview.Interviews.length > 0) {
                        var hasCancelInterview = false;
                        var cancelInterview = null;
                        for (var j = 0; j < candidateInterview.Interviews.length; j++) {
                            if (candidateInterview.Interviews[j].InterviewRound.IsCanceled) {
                                hasCancelInterview = true;
                                cancelInterview = candidateInterview.Interviews[j];
                                break;
                            }
                        }
                        if (hasCancelInterview) {
                            if (cancelInterview.InterviewRound.CanRndCanDtllId != self.jobApplicationId) return;
                            caScheduleInterviewSvc.data.dateTimeChosen.levelRound = cancelInterview.InterviewRound.LevelRound;
                        } else {
                            var lastInterview = candidateInterview.Interviews[candidateInterview.Interviews.length - 1];
                            if (lastInterview.InterviewRound.CanRndCanDtllId != self.jobApplicationId) return;
                            caScheduleInterviewSvc.data.dateTimeChosen.levelRound = lastInterview.InterviewRound.LevelRound + 1;
                        }
                    } else {
                        if (!(candidateInterview.ScreeningCVHistories && candidateInterview.ScreeningCVHistories.length > 0 && candidateInterview.ScreeningCVHistories[0].JobApplicationId == self.jobApplicationId)) return;
                        var defaultLevelRow = 2;
                        caScheduleInterviewSvc.data.dateTimeChosen.levelRound = defaultLevelRow;
                    }
                }
                // Clear overlay and spinner
                caScheduleInterviewSvc.data.currentLevelRound = caScheduleInterviewSvc.stringifyLevelRound(caScheduleInterviewSvc.data.dateTimeChosen.levelRound);
            },
            function () {
                caScheduleInterviewSvc.data = [];
                clearOverlay();
                toastr.error($filter(constants.translate)(caMessage.interview.getCandidateInterviewError));
            });

            $rootScope.$on('$stateChangeStart', function (event, toState) {
                if (toState.name == 'scheduleInterview') {
                    $state.go(caConstants.scheduleInterviewTabName.overallInformation);
                }
            });

            $scope.$on('$locationChangeStart', function (event) {
                if ((window.location.href.indexOf('view/interviews') > -1 ||
                    window.location.href.indexOf('view/general-info') > -1) &&
                    $state.current.name == 'scheduleInterview.overallInformation') {
                    self.backToInterviewsTab(function () { self.clearOverlay(); });
                    event.preventDefault();
                }
            });
        }

        function isActivatedTab(id) {
            var tabId = 1;
            switch ($state.current.name) {
                case caConstants.scheduleInterviewTabName.overallInformation:
                    tabId = 1;
                    break;
                case caConstants.scheduleInterviewTabName.dateTimeChosen:
                    tabId = 2;
                    break;
                case caConstants.scheduleInterviewTabName.notification:
                    tabId = 3;
                    break;
                case caConstants.scheduleInterviewTabName.confirmation:
                    tabId = 4;
                    break;
                default:
                    tabId = 1;
                    break;
            }
            return tabId == id;
        }

        function clearOverlay(isShow) {
            if (isShow) {
                $(constants.loadingIcon.overlay).show();
                $(constants.loadingIcon.indicator).show();
            } else {
                $(constants.loadingIcon.overlay).hide();
                $(constants.loadingIcon.indicator).hide();
                $('.modal-backdrop').remove();
            }
        }

        function openConfirmModal() {
            self.backToInterviewsTab();
        }

        function backToInterviewsTab() {
            var url = constants.baseUrl + "#/candidates/" + $state.params.id + "/job-application/" + $state.params.jobApplicationId + "/schedule-interview/" + $state.params.interviewId;
            var previousUrl = historyPageSvc.getPreviousUrl(url);
            if (previousUrl && previousUrl.indexOf("/#/candidates/") == -1) {
                historyPageSvc.getPreviousUrl(url, "");
                window.location.href = previousUrl;
                return;
            }
            historyPageSvc.setPreviousUrl(url, "");
            $state.go('candidateDetail', {
                id: self.candidateId
            }).then(function () {
                clearOverlay(false);
            });
            return;
        }
    }
})();