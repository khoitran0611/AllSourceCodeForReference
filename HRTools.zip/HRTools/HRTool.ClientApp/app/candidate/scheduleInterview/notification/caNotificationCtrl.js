﻿(function () {
    'use strict';
    angular.module('app').controller('caNotificationCtrl', CaNotificationCtrl);
    CaNotificationCtrl.$inject = ['$state', '$filter', '$timeout', 'constants', 'caConstants', 'message', 'styleSvc', 'emailSvc', 'caScheduleInterviewSvc', 'permissionSvc', 'objectSvc', 'messageHandleSvc'];
    function CaNotificationCtrl($state, $filter, $timeout, constants, caConstants, message, styleSvc, emailSvc, caScheduleInterviewSvc, permissionSvc, objectSvc, messageHandleSvc) {
        var emailInterviewType = 2;
        var interviewId = $state.params.interviewId;
        var data = caScheduleInterviewSvc.getData();
        var previewEmailType = { Candidate: 1, Interviewer: 2 };
        var candidateActionType = "Preview email (Candidate)";
        var interviewerActionType = "Preview email (Interviewer)";
        var self = this;
        var candidateTemMail = {}, employeeTemMail = {};
        var candidateToogle = true;
        var interviewerToogle = true;
        var newId = 0;
        var isFinish = false;

        self.currentUserPermission = permissionSvc.getCurrentUserPermission();
        if (!self.currentUserPermission.canViewSchedule) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.emailDisabled = true;
        self.isSendMailToCandidateChecked = true;
        self.isSendMailToInterviewerChecked = true;
        self.interviewerEmail = data.interviewerEmail;
        self.candidateName = data.notification.candidateName;
        self.interviewerName = data.interviewerName;
        self.interviewerEmailContent = {};
        self.candidateEmailContent = {};
        self.classForCandidateHeader = "";
        self.classForInterviewerHeader = "";

        self.getHeaderStyle = getHeaderStyle;
        self.copyEmail = copyEmail;
        self.previewCandidateEmail = previewCandidateEmail;
        self.previewInterviewerEmail = previewInterviewerEmail;
        self.next = next;
        self.backToPreviousStep = backToPreviousStep;
        self.finish = finish;
        self.openPreviewEmailModal = openPreviewEmailModal;
        self.onClickHeader = onClickHeader;
        self.getCssHeaderClass = getCssHeaderClass;
        self.onClickCollapseButton = onClickCollapseButton;

        init();

        function init() {
            self.canShowFinish = self.currentUserPermission.canEditSchedule || self.currentUserPermission.canAddSchedule;

            getEmail(data.scheduleInterviewDto, candidateActionType);
            getEmail(data.scheduleInterviewDto, interviewerActionType);

            self.emailData = emailSvc.data;
            self.previewEmail = {};
            self.classForCandidateHeader = getCssHeaderClass(candidateToogle);
            self.classForInterviewerHeader = getCssHeaderClass(interviewerToogle);

            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
        }

        function getEmail(scheduleInterview, emailType) {
            scheduleInterview.ActionType = emailType;
            emailSvc.getEmailTempateByIdType(emailInterviewType, scheduleInterview, function () {
                if (emailType == candidateActionType) {
                    candidateTemMail = {};
                    if (emailSvc.data.emailDto) angular.copy(emailSvc.data.emailDto, candidateTemMail);
                    self.candidateEmail = {};
                    if (emailSvc.data.emailDto) angular.copy(emailSvc.data.emailDto, self.candidateEmail);
                    $timeout(function () {
                        angular.copy(candidateTemMail, self.candidateEmail);
                    }, 1000);
                }
                if (emailType == interviewerActionType) {
                    employeeTemMail = {};
                    if (emailSvc.data.emailDto) angular.copy(emailSvc.data.emailDto, employeeTemMail);
                    self.interviewerEmail = {};
                    if (emailSvc.data.emailDto) angular.copy(emailSvc.data.emailDto, self.interviewerEmail);
                    $timeout(function () {
                        angular.copy(employeeTemMail, self.interviewerEmail);
                        self.interviewerEmail.Cc = JSON.parse(JSON.stringify(data.interviewerEmail));
                    }, 1000);
                }
            }, function (error) {
                messageHandleSvc.handleResponse(error, $filter(constants.translate)(message.errorLoadingData));
            });
        }

        function getHeaderStyle() {
            return styleSvc.getHeaderStyle(self.isSkillEditing);
        }

        function copyEmail(source, target) {
            target.subject = source.Subject;
            target.emailTo = source.To;
            target.content = source.Content;
        }

        function previewCandidateEmail() {
            self.emailData.emailDto.Content = self.candidateEmailContent;
            self.copyEmail(self.emailData.emailDto, self.previewEmail);
            self.previewEmail.type = previewEmailType.Candidate;
            self.openPreviewEmailModal();
        }

        function previewInterviewerEmail() {
            self.emailData.emailDto.Content = self.interviewerEmailContent;
            self.copyEmail(self.emailData.emailDto, self.previewEmail);
            self.previewEmail.type = previewEmailType.Interviewer;
            self.openPreviewEmailModal();
        }

        function next() {
            updateScheduleInterviewDto();
            $state.go(caConstants.scheduleInterviewTabName.confirmation);
        }

        function backToPreviousStep() {
            $state.go(caConstants.scheduleInterviewTabName.dateTimeChosen);
        }

        function finish() {
            if (isFinish) return;
            isFinish = true;
            updateScheduleInterviewDto();
            var scheduleInterviewDto = data.scheduleInterviewDto;
            if (interviewId == newId) {
                if (!objectSvc.checkPermission(self.currentUserPermission.canAddSchedule, message.dontHavePermissionAccess, true)) {
                    return;
                }
                caScheduleInterviewSvc.addInterviewSchedule(scheduleInterviewDto.CandidateId, scheduleInterviewDto.CanDtlId, scheduleInterviewDto, addFail);
            } else {
                if (!objectSvc.checkPermission(self.currentUserPermission.canEditSchedule, message.dontHavePermissionAccess, true)) {
                    return;
                }
                caScheduleInterviewSvc.updateInterviewSchedule(scheduleInterviewDto.CandidateId, scheduleInterviewDto.CanDtlId, scheduleInterviewDto.ScheduleInterviewId, scheduleInterviewDto, addFail);
            }
        }

        function addFail() {
            isFinish = false;
        }

        function updateScheduleInterviewDto() {
            data.notification.candidateEmail = self.candidateEmail;
            data.notification.interviewerEmail = self.interviewerEmail;
            data.scheduleInterviewDto.IsSendMailToCandidate = self.isSendMailToCandidateChecked;
            data.scheduleInterviewDto.IsSendMailToEmployee = self.isSendMailToInterviewerChecked;
            caScheduleInterviewSvc.setData(data);
        }

        function openPreviewEmailModal() {
            $('#preview-email-modal').modal('show');
        }

        function onClickCollapseButton(event) {
            var target = $(event.target);
            self.isCandidate = !self.isCandidate;
            candidateActionType = "Preview email (Candidate)";
            interviewerActionType = "Preview email (Interviewer)";
            data.scheduleInterviewDto.ActionType = candidateActionType;

            if (!self.isCandidate) {
                data.scheduleInterviewDto.ActionType = interviewerActionType;
            }
            caScheduleInterviewSvc.setData(data);
            if (target.attr('id') == "candidate-email-part-collapse") {
                candidateToogle = !candidateToogle;
                $("#candidate-email-tab").slideToggle("slow");
                $('#cke_CandidateEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                self.classForCandidateHeader = getCssHeaderClass(candidateToogle);
            } else {
                interviewerToogle = !interviewerToogle;
                $("#interviewer-email-tab").slideToggle("slow");
                $('#cke_InterviewerEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                self.classForInterviewerHeader = getCssHeaderClass(interviewerToogle);
            }
        }

        function onClickHeader(event) {
            var target = $(event.target);
            self.isCandidate = !self.isCandidate;
            candidateActionType = "Preview email (Candidate)";
            interviewerActionType = "Preview email (Interviewer)";
            data.scheduleInterviewDto.ActionType = candidateActionType;

            if (!self.isCandidate) {
                data.scheduleInterviewDto.ActionType = interviewerActionType;
            }
            caScheduleInterviewSvc.setData(data);
            if (target.attr('id') == "candidate-email-part-header" || target.attr('id') == "candidate-mail-checkbox") {
                if ($("#candidate-email-tab").css('display') == 'none' && $('#candidate-mail-checkbox').is(':checked')) {
                    candidateToogle = true;
                    $("#candidate-email-tab").slideToggle("slow");
                    $('#cke_CandidateEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                    self.classForCandidateHeader = getCssHeaderClass(candidateToogle);
                }
                if ($("#candidate-email-tab").css('display') == 'block' && !$('#candidate-mail-checkbox').is(':checked')) {
                    candidateToogle = false;
                    $("#candidate-email-tab").slideToggle("slow");
                    $('#cke_CandidateEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                    self.classForCandidateHeader = getCssHeaderClass(candidateToogle);
                }
            } else {
                if ($("#interviewer-email-tab").css('display') == 'none' && $('#interviewer-mail-checkbox').is(':checked')) {
                    interviewerToogle = true;
                    $("#interviewer-email-tab").slideToggle("slow");
                    $('#cke_InterviewerEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                    self.classForInterviewerHeader = getCssHeaderClass(interviewerToogle);
                }
                if ($("#interviewer-email-tab").css('display') == 'block' && !$('#interviewer-mail-checkbox').is(':checked')) {
                    interviewerToogle = false;
                    $("#interviewer-email-tab").slideToggle("slow");
                    $('#cke_InterviewerEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                    self.classForInterviewerHeader = getCssHeaderClass(interviewerToogle);
                }
            }
            event.stopPropagation();
        }

        function getCssHeaderClass(state) {
            return state && 'col-xs-1 fa fa-2x fa-caret-down' || 'col-xs-1 fa fa-2x fa-caret-right';
        }
    }
})();

