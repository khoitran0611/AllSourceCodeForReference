﻿(function () {
    'use strict';
    angular.module('app').controller('caDateTimeChosenCtrl', CaDateTimeChosenCtrl);
    CaDateTimeChosenCtrl.$inject = ['$state', '$scope', '$filter', '$window',
        'constants', 'caConstants', 'message',
        'datetimeSvc', 'caScheduleInterviewSvc', 'permissionSvc', 'objectSvc', 'authenticationSvc', 'messageHandleSvc'];
    function CaDateTimeChosenCtrl($state, $scope, $filter, $window,
        constants, caConstants, message,
        datetimeSvc, caScheduleInterviewSvc, permissionSvc, objectSvc, authenticationSvc, messageHandleSvc) {
        var newId = 0;
        var mountainRoomId = 5;
        var candidateId = $state.params.id;
        var jobApplicationId = $state.params.jobApplicationId;
        var interviewId = $state.params.interviewId;
        var data = caScheduleInterviewSvc.getData();
        var levelRound = data.dateTimeChosen.levelRound;
        var currentEvent = 0;
        var self = this;
        var listRooms = [];
        var isFinish = false;

        self.currentUserPermission = permissionSvc.getCurrentUserPermission();
        self.isLoadingRoom = true;

        self.finish = finish;
        self.next = next;
        self.backToPreviousStep = backToPreviousStep;
        self.checkConditions = checkConditions;

        $scope.selectRoom = selectRoom;
        $scope.onEventClick = onEventClick;
        $scope.onDrop = onDrop;
        $scope.onResize = onResize;
        $scope.addRemoveEventSource = addRemoveEventSource;
        $scope.remove = remove;
        $scope.changeView = changeView;
        $scope.renderCalender = renderCalender;
        $scope.changeLang = changeLang;
        $scope.focusSelectbox = focusSelectbox;

        var calendarDefaultDate = (data.dateTimeChosen.start ||
                                   (data.dateTimeChosen.addedEvent && interviewId == data.dateTimeChosen.addedEvent.interviewId)) ?
                                  data.dateTimeChosen.start :
                                  moment().format('YYYY-MM-DD');
        init();

        function init() {
            if (!self.currentUserPermission.canViewSchedule) {
                messageHandleSvc.handlePermission();
                return;
            }
            self.canShowFinish = self.currentUserPermission.canEditSchedule || self.currentUserPermission.canAddSchedule;

            $('#calendar').fullCalendar('removeEvents');

            $scope.selectedRoomId = (data.dateTimeChosen.selectedRoomId != newId ||
                (data.dateTimeChosen.addedEvent && interviewId == data.dateTimeChosen.addedEvent.interviewId)) ?
                data.dateTimeChosen.selectedRoomId : -1;
            if (!$scope.selectedRoomId) $scope.selectedRoomId = -1;
            $scope.scheduleInterviewData = data;
            if (data.scheduleInterview)
                angular.copy(data.scheduleInterview.RoomList, listRooms);
            if ($scope.selectedRoomId == -1) {
                if (data.scheduleInterview) caScheduleInterviewSvc.setCurrentValidRooms(data.scheduleInterview.RoomList);
                self.isLoadingRoom = false;
                if (!$scope.$$phase) $scope.$apply();
            }
            if ($scope.scheduleInterviewData.scheduleInterview)
                $scope.scheduleInterviewData.scheduleInterview.RoomList = caScheduleInterviewSvc.getCurrentValidRooms();
            $scope.changeTo = 'Hungarian';
            $scope.eventSource = {};
            $scope.events = [];
            if (interviewId === 0) {
                self.isLoadingRoom = false;
                if (!$scope.$$phase) $scope.$apply();
            }

            initCalendar();
        }

        function selectRoom() {
            // remove all current events
            showLoading(true);
            $('#calendar').fullCalendar('removeEvents');
            var start = $('#calendar').fullCalendar('getView').start;
            var end = $('#calendar').fullCalendar('getView').end;
            data.dateTimeChosen.selectedRoomId = $scope.selectedRoomId;
            data.dateTimeChosen.start = start;
            caScheduleInterviewSvc.setData(data);
            if (data.dateTimeChosen.addedEvent) {
                currentEvent = data.dateTimeChosen.addedEvent;
                currentEvent.start = currentEvent.start ? currentEvent.start : currentEvent.Start;
                currentEvent.end = currentEvent.end ? currentEvent.end : currentEvent.End;
            }

            caScheduleInterviewSvc.getEvents(start, end, $scope.selectedRoomId, interviewId).$promise.then(function (result) {
                window.angular.forEach(result, function (obj) {
                    addEvent(obj);
                });
                addSelectEvent();
                showLoading(false);
            }, function (error) {
                messageHandleSvc.handleResponse(error, $filter(constants.translate)(message.errorLoadingData));
                showLoading(false);
            });
        }

        function showLoading(isDelay) {
            if (isDelay) {
                $(constants.loadingIcon.overlay).show();
                $(constants.loadingIcon.indicator).show();
                return;
            }
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
        }

        function addCurrentEvent(start, end) {
            var currentUser = $window.localStorage.getItem(constants.currentUserLoginCookie);
            if (!currentUser) {
                return;
            }
            getValidRooms(start, end);
            var eventData = {
                title: 'Interview - ' + data.interviewerName,
                start: start,
                end: end,
                Start: start,
                End: end,
                //levelRound: 1,
                roomId: $scope.selectedRoomId,
                className: ['current-schedule-interview']
            };
            data.dateTimeChosen.selectedRoomId = $scope.selectedRoomId;
            eventData.levelRound = levelRound;
            if (data.dateTimeChosen.addedEvent) {
                for (var j = 0; j < $scope.events.length; j++) {
                    var isCreating = $scope.events[j].levelRound == levelRound;
                    var isUpdating = $scope.events[j].interviewId && interviewId == $scope.events[j].interviewId;
                    if (isCreating || isUpdating) {
                        if ($scope.events[j].interviewId) {
                            //update case
                            eventData.interviewId = $scope.events[j].interviewId;
                            eventData.appointmentId = $scope.events[j].appointmentId;
                            eventData.levelRound = $scope.events[j].levelRound;
                            eventData.scheduleInterviewId = $scope.events[j].scheduleInterviewId;
                        }
                        $scope.events.splice(j, 1);
                        j--;
                    }
                }
            }
            data.dateTimeChosen.addedEvent = eventData;
            currentEvent = eventData;
            caScheduleInterviewSvc.setData(data);
            $scope.events.push(eventData);
            $(".fc-event-container").hide();
        }

        function finish() {
            if (!data.dateTimeChosen.addedEvent) {
                toastr.warning($filter(constants.translate)(message.requireSelectRoom));
                return;
            }
            var scheduleInterviewDto = initScheduleInterviewDto();
            scheduleInterviewDto.FromBookRoomDate = scheduleInterviewDto.FromBookRoomDate ? scheduleInterviewDto.FromBookRoomDate : angular.copy(data.dateTimeChosen.addedEvent.Start);
            scheduleInterviewDto.ToBookRoomDate = scheduleInterviewDto.ToBookRoomDate ? scheduleInterviewDto.ToBookRoomDate : angular.copy(data.dateTimeChosen.addedEvent.End);
            if (isFinish) return;
            isFinish = true;
            if (interviewId == newId) {
                if (!objectSvc.checkPermission(self.currentUserPermission.canAddSchedule, message.dontHavePermissionAccess, true)) {
                    return;
                }
                caScheduleInterviewSvc.addInterviewSchedule(scheduleInterviewDto.CandidateId, scheduleInterviewDto.CanDtlId,
                    scheduleInterviewDto, addFail);
            } else {
                if (!objectSvc.checkPermission(self.currentUserPermission.canEditSchedule, message.dontHavePermissionAccess, true)) {
                    return;
                }
                caScheduleInterviewSvc.updateInterviewSchedule(scheduleInterviewDto.CandidateId, scheduleInterviewDto.CanDtlId,
                    scheduleInterviewDto.ScheduleInterviewId, scheduleInterviewDto, addFail);
            }
        }

        function addFail() {
            isFinish = false;
        }

        function initScheduleInterviewDto() {

            var scheduleInterviewDto = {};
            scheduleInterviewDto.CanDtlId = jobApplicationId;

            scheduleInterviewDto.RcmPstId = data.jobId;

            // booking info
            setBookingScheduleInterviewDto(scheduleInterviewDto);

            scheduleInterviewDto.CandidateId = candidateId;
            scheduleInterviewDto.InterviewerId = data.selectedInterviewerId;
            setRoomScheduleInterviewDto(scheduleInterviewDto);

            // Emails don't send at this step, this should be updated when moving to next step
            scheduleInterviewDto.IsSendMailToCandidate = false;
            scheduleInterviewDto.IsSendMailToEmployee = false;

            scheduleInterviewDto.ComId = JSON.parse($window.localStorage.getItem("currentuserlogin")).CompanyId;
            scheduleInterviewDto.PstId = data.positionId;
            caScheduleInterviewSvc.setData(data);
            return scheduleInterviewDto;
        }

        function setRoomScheduleInterviewDto(scheduleInterviewDto) {
            // get current select room
            scheduleInterviewDto.RoomId = data.dateTimeChosen.selectedRoomId;
            for (var i = 0; i < $scope.scheduleInterviewData.scheduleInterview.RoomList.length; i++) {
                if (scheduleInterviewDto.RoomId == $scope.scheduleInterviewData.scheduleInterview.RoomList[i].Id) {
                    scheduleInterviewDto.Location = $scope.scheduleInterviewData.scheduleInterview.RoomList[i].Name;
                }
            }
        }

        function setBookingScheduleInterviewDto(scheduleInterviewDto) {
            if (interviewId == newId) {
                //create
                scheduleInterviewDto.LevelRound = data.dateTimeChosen.levelRound;
                for (var i = 0; i < $scope.events.length; i++) {
                    if (!$scope.events[i].interviewId && $scope.events[i].levelRound == levelRound) {
                        scheduleInterviewDto.FromBookRoomDate = datetimeSvc.convertDateForServer($scope.events[i].start, true);
                        scheduleInterviewDto.ToBookRoomDate = datetimeSvc.convertDateForServer($scope.events[i].end, true);
                        scheduleInterviewDto.ContentSchedule = $scope.events[i].title;
                        scheduleInterviewDto.LevelRound = $scope.events[i].levelRound;
                    }
                }
            } else {
                // update
                for (var j = 0; j < $scope.events.length; j++) {
                    if ($scope.events[j].interviewId && interviewId == $scope.events[j].interviewId) {
                        scheduleInterviewDto.FromBookRoomDate = datetimeSvc.convertDateForServer($scope.events[j].start, true);
                        scheduleInterviewDto.ToBookRoomDate = datetimeSvc.convertDateForServer($scope.events[j].end, true);
                        scheduleInterviewDto.ContentSchedule = $scope.events[j].title;
                        scheduleInterviewDto.LevelRound = $scope.events[j].levelRound;
                        scheduleInterviewDto.InterviewId = $scope.events[j].interviewId;
                        scheduleInterviewDto.AppointmentId = $scope.events[j].appointmentId;
                        scheduleInterviewDto.ScheduleInterviewId = $scope.events[j].scheduleInterviewId;
                    }
                }

                // case: user create schedule without booking room, then update booking room
                if (!scheduleInterviewDto.FromBookRoomDate) {
                    scheduleInterviewDto.InterviewId = interviewId;
                    window.angular.forEach(data.interviews, function (obj) {
                        if (obj.InterviewRound.CanRndId == interviewId) {
                            scheduleInterviewDto.ScheduleInterviewId = obj.InterviewRound.ScheduleInterviewId;
                            scheduleInterviewDto.LevelRound = obj.InterviewRound.LevelRound;
                        }
                    });
                    for (var k = 0; k < $scope.events.length; k++) {
                        if ($scope.events[k].levelRound == levelRound) {
                            scheduleInterviewDto.FromBookRoomDate = datetimeSvc.convertDateForServer($scope.events[k].start, true);
                            scheduleInterviewDto.ToBookRoomDate = datetimeSvc.convertDateForServer($scope.events[k].end, true);
                            scheduleInterviewDto.ContentSchedule = $scope.events[k].title;
                        }
                    }
                }
            }
        }

        function initCalendar() {
            $scope.eventsF = function (start, end, timezone, callback) {
                var s = new Date(start).getTime() / 1000;
                var m = new Date(start).getMonth();
                var events = [{ title: 'Feed Me ' + m, start: s + (50000), end: s + (100000), allDay: false, className: ['customFeed'] }];
                callback(events);
            };

            $scope.calEventsExt = {
            };

            /* event source that calls a function on every view switch */
            $scope.eventsF = function () {
            };

            $scope.calEventsExt = {
            };
            $scope.uiConfig = {
                calendar: {
                    height: 580,
                    defaultDate: calendarDefaultDate,
                    defaultView: 'agendaWeek',
                    editable: true,
                    eventLimit: true,
                    minTime: '08:00:00',
                    maxTime: '18:00:00',
                    header: {
                        left: 'title',
                        center: '',
                        right: 'today prev,next'
                    },
                    selectable: true,
                    selectHelper: true,
                    select: addCurrentEvent,
                    events: function () {
                    },
                    eventClick: $scope.onEventClick,
                    eventDrop: $scope.onDrop,
                    eventResize: $scope.onResize,
                    viewRender: viewRender
                }
            };
            /* event sources array*/
            $scope.eventSources = [$scope.events, $scope.eventSource, $scope.eventsF];
            $scope.eventSources2 = [$scope.calEventsExt, $scope.eventsF, $scope.events];
        }

        function onEventClick(event) {
            data.dateTimeChosen.selectedRoomId = $scope.selectedRoomId;
            for (var j = 0; j < $scope.events.length; j++) {
                if ($scope.events[j]._id == event._id &&
                    ((levelRound == $scope.events[j].levelRound && !$scope.events[j].interviewId) ||
                     ($scope.events[j].interviewId && interviewId == $scope.events[j].interviewId))) {
                    $scope.events.splice(j, 1);
                    data.dateTimeChosen.addedEvent = null;
                    $scope.scheduleInterviewData.scheduleInterview.RoomList = listRooms;
                    caScheduleInterviewSvc.setData(data);
                }
            }
        }

        function onDrop(event) {
            if (event.allDay) {
                event.end = {};
                angular.copy(event.start, event.end);
                event.start._d.setHours(7);
                event.end._d.setHours(31);
            }
            if (!event.end) {
                event.end = {};
                angular.copy(event.start, event.end);
                event.end._d.setHours(event.end._d.getHours() + 2);
            }
            $scope.alertMessage = ('Event Droped on ' + event.start.format());
            data.dateTimeChosen.selectedRoomId = $scope.selectedRoomId;
            var isCurrentUserEvent = false;
            for (var j = 0; j < $scope.events.length; j++) {
                if ($scope.events[j]._id == event._id &&
                    ((levelRound == $scope.events[j].levelRound && !$scope.events[j].interviewId) ||
                     ($scope.events[j].interviewId && interviewId == $scope.events[j].interviewId))) {
                    $scope.events.splice(j, 1);
                    j--;
                    isCurrentUserEvent = true;
                }
            }
            if (isCurrentUserEvent) {
                $scope.events.push(event);
                data.dateTimeChosen.addedEvent = event;
                currentEvent = event;
                getValidRooms(event.start, event.end);
                caScheduleInterviewSvc.setData(data);
            }
        }

        function addSelectEvent() {
            if (data.dateTimeChosen.addedEvent) {
                var event = angular.copy(data.dateTimeChosen.addedEvent);
                event.Subject = 'Interview - ' + data.interviewerName;
                event.Start = event.Start ? event.Start : event.start;
                event.End = event.End ? event.End : event.end;
                event.InterviewId = event.InterviewId ? event.InterviewId : event.interviewId;
                event.LevelRound = event.LevelRound ? event.LevelRound : event.levelRound;
                event.RoomId = event.RoomId ? event.RoomId : event.roomId;
                event.Location = event.Location ? event.Location : event.location;
                event.AppointmentId = event.AppointmentId ? event.AppointmentId : event.appointmentId;
                event.ScheduleInterviewId = event.ScheduleInterviewId ? event.ScheduleInterviewId : event.scheduleInterviewId;

                $scope.events.push({
                    title: event.Subject,
                    start: event.Start,
                    end: event.End,
                    interviewId: event.InterviewId,
                    levelRound: event.LevelRound,
                    roomId: event.RoomId,
                    location: event.Location,
                    appointmentId: event.AppointmentId,
                    scheduleInterviewId: event.ScheduleInterviewId,
                    className: [event.className]
                });
            }
        }

        function onResize(event) {
            var isCurrentUserEvent = false;
            data.dateTimeChosen.selectedRoomId = $scope.selectedRoomId;
            for (var j = 0; j < $scope.events.length; j++) {
                if ($scope.events[j]._id == event._id &&
                    ((levelRound == $scope.events[j].levelRound && !$scope.events[j].interviewId) ||
                     ($scope.events[j].interviewId && interviewId == $scope.events[j].interviewId))) {
                    $scope.events.splice(j, 1);
                    j--;
                    isCurrentUserEvent = true;
                }
            }
            if (isCurrentUserEvent) {
                $scope.events.push(event);
                data.dateTimeChosen.addedEvent = event;
                currentEvent = event;
                getValidRooms(event.start, event.end);
                caScheduleInterviewSvc.setData(data);
            }
        }

        function getValidRooms(startTime, endTime) {
            ////Just temporary - we will open it if we have room in database
            self.isLoadingRoom = true;
            showLoading(true);
            var start = datetimeSvc.convertDateForServer(startTime, true);
            var end = datetimeSvc.convertDateForServer(endTime, true);
            caScheduleInterviewSvc.rooms(start, end, interviewId).$promise.then(function (result) {
                $scope.scheduleInterviewData.scheduleInterview.RoomList = result;
                caScheduleInterviewSvc.setCurrentValidRooms(result);
                self.isLoadingRoom = false;
                if (!$scope.$$phase) $scope.$apply();
                showLoading(false);
            }, function (error) {
                messageHandleSvc.handleResponse(error, $filter(constants.translate)(message.errorLoadingData));
                self.isLoadingRoom = false;
                if (!$scope.$$phase) $scope.$apply();
                showLoading(false);
            });
        }

        function addRemoveEventSource(sources, source) {
            var canAdd = 0;
            angular.forEach(sources, function (value, key) {
                if (sources[key] == source) {
                    sources.splice(key, 1);
                    canAdd = 1;
                }
            });
            if (canAdd === 0) {
                sources.push(source);
            }
        }

        function remove(index) {
            $scope.events.splice(index, 1);
        }

        function changeView(view, calendar) {
            calendar.fullCalendar('changeView', view);
        }

        function renderCalender(calendar) {
            if (calendar) {
                calendar.fullCalendar('render');
            }
        }

        function viewRender() {
            var start = $('#calendar').fullCalendar('getView').start;
            var end = $('#calendar').fullCalendar('getView').end;

            var roomId = $scope.selectedRoomId;
            if (data.dateTimeChosen.selectedRoomId !== 0)
                roomId = data.dateTimeChosen.selectedRoomId;

            ////Just temporary -  we will use it after we added room to database
            if (!roomId) roomId = -1;
            caScheduleInterviewSvc.getEvents(start, end, roomId, interviewId).$promise.then(function (result) {
                window.angular.forEach(result, function (obj) {
                    addEvent(obj);
                });
                addSelectEvent();

                $('#ajax-overlay').hide();
                $('#ajax-indicator').hide();
                self.isLoadingRoom = false;
                if (!$scope.$$phase) $scope.$apply();
            });

            data.dateTimeChosen.start = start;
            caScheduleInterviewSvc.setData(data);
        }

        function addEvent(event) {
            if (event.InterviewId) {
                event.className = 'current-schedule-interview';
                event.Subject = 'Interview - ' + data.interviewerName;
                if (data.dateTimeChosen.addedEvent) {
                    data.dateTimeChosen.addedEvent.Start = data.dateTimeChosen.addedEvent.Start ? data.dateTimeChosen.addedEvent.Start : data.dateTimeChosen.addedEvent.start;
                    data.dateTimeChosen.addedEvent.End = data.dateTimeChosen.addedEvent.End ? data.dateTimeChosen.addedEvent.End : data.dateTimeChosen.addedEvent.end;
                    if (data.dateTimeChosen.addedEvent.Start && data.dateTimeChosen.addedEvent.End) {
                        event.Start = data.dateTimeChosen.addedEvent.Start;
                        event.End = data.dateTimeChosen.addedEvent.End;
                    }
                }
                data.dateTimeChosen.addedEvent = JSON.parse(JSON.stringify(event));
                getValidRooms(event.Start, event.End);
                data.dateTimeChosen.addedEvent.Start = moment(event.Start).format('YYYY-MM-DD HH:mm');
                data.dateTimeChosen.addedEvent.End = moment(event.End).format('YYYY-MM-DD HH:mm');
                caScheduleInterviewSvc.setData(data);
            }
            if (!event.InterviewId)
                $scope.events.push({
                    title: event.Subject,
                    start: moment(event.Start).format('YYYY-MM-DD HH:mm'),
                    end: moment(event.End).format('YYYY-MM-DD HH:mm'),
                    interviewId: event.InterviewId,
                    levelRound: event.LevelRound,
                    roomId: event.RoomId,
                    location: event.Location,
                    appointmentId: event.AppointmentId,
                    scheduleInterviewId: event.ScheduleInterviewId,
                    className: [event.className]
                });
        }

        function changeLang() {
            if ($scope.changeTo === 'Hungarian') {
                $scope.uiConfig.calendar.dayNames = ["Vasárnap", "Hétfő", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat"];
                $scope.uiConfig.calendar.dayNamesShort = ["Vas", "Hét", "Kedd", "Sze", "Csüt", "Pén", "Szo"];
                $scope.changeTo = 'English';
            } else {
                $scope.uiConfig.calendar.dayNames = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
                $scope.uiConfig.calendar.dayNamesShort = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
                $scope.changeTo = 'Hungarian';
            }
        }

        function next() {
            if (!data.dateTimeChosen.addedEvent) {
                toastr.warning($filter(constants.translate)(message.requireSelectRoom));
                return;
            }
            var scheduleInterviewDto = initScheduleInterviewDto();
            var actionType = "Preview email (Candidate)";
            scheduleInterviewDto.ActionType = actionType;
            data.scheduleInterviewDto = scheduleInterviewDto;
            data.scheduleInterviewDto.FromBookRoomDate = data.scheduleInterviewDto.FromBookRoomDate ? data.scheduleInterviewDto.FromBookRoomDate : angular.copy(data.dateTimeChosen.addedEvent.Start);
            data.scheduleInterviewDto.ToBookRoomDate = data.scheduleInterviewDto.FromBookRoomDate ? data.scheduleInterviewDto.FromBookRoomDate : angular.copy(data.dateTimeChosen.addedEvent.End);
            caScheduleInterviewSvc.setData(data);
            $state.go(caConstants.scheduleInterviewTabName.notification, {
                id: candidateId, jobApplicationId: jobApplicationId, interviewId: interviewId
            });
        }

        function backToPreviousStep() {
            $state.go(caConstants.scheduleInterviewTabName.overallInformation, {
                id: candidateId, jobApplicationId: jobApplicationId, interviewId: interviewId
            });
        }

        function checkConditions() {
            return $scope.selectedRoomId == -1;
        }

        function focusSelectbox() {
            $('#room-list').focus();
        }
    }
})();