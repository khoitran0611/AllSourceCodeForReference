﻿(function () {
    'use strict';
    angular.module('app').controller('caOverallInformationCtrl', CaOverallInformationCtrl);
    CaOverallInformationCtrl.$inject = ['$state', 'constants', 'caConstants', 'caAppliedPositionSvc', 'candidateSvc', 'caScheduleInterviewSvc', 'styleSvc', 'permissionSvc', 'messageHandleSvc'];
    function CaOverallInformationCtrl($state, constants, caConstants, caAppliedPositionSvc, candidateSvc, caScheduleInterviewSvc, styleSvc, permissionSvc, messageHandleSvc) {
        var self = this;
        self.currentUserPermission = permissionSvc.getCurrentUserPermission();
        if (!self.currentUserPermission.canViewSchedule) {
            messageHandleSvc.handlePermission();
            return;
        }
        var data = caScheduleInterviewSvc.getData();
        var candidateId = $state.params.id;
        var jobApplicationId = $state.params.jobApplicationId;
        var interviewId = $state.params.interviewId;
        self.appliedPositionsData = caAppliedPositionSvc.appliedPositionsData;

        self.selectInterviewer = selectInterviewer;
        self.next = next;
        self.isDisableNextButton = isDisableNextButton;

        init();

        function init() {
            if (!caAppliedPositionSvc.appliedPositionsData.appliedPositions ||
                (caAppliedPositionSvc.appliedPositionsData.appliedPositions && caAppliedPositionSvc.appliedPositionsData.appliedPositions.$promise) ||
                caAppliedPositionSvc.appliedPositionsData.appliedPositions[0].CandidateId != candidateId) {
                caAppliedPositionSvc.getAppliedPositions(candidateId, jobApplicationId);
            }
            if (!candidateSvc.candidateInforData.candidateBasicInfo ||
                (candidateSvc.candidateInforData.candidateBasicInfo && candidateSvc.candidateInforData.candidateBasicInfo.$promise) ||
                candidateSvc.candidateInforData.candidateBasicInfo.CandidateId != candidateId) {
                candidateSvc.getCandidateInforData(candidateId);
            }
            self.candidateInforData = candidateSvc.candidateInforData;

            if (!candidateSvc.candidateInforData.candidateBasicInfo) {
                caScheduleInterviewSvc.backToInterviewsTab(candidateId, jobApplicationId, interviewId);
            } else {
                data.notification.candidateName = candidateSvc.candidateInforData.candidateBasicInfo.FullName;
                caScheduleInterviewSvc.setData(data);
            }
            caScheduleInterviewSvc.getScheduleInterviews(candidateId, jobApplicationId, interviewId);
            self.scheduleInterviewData = data;
            if (!self.scheduleInterviewData.selectedInterviewerId) {
                self.scheduleInterviewData.interviewerEmail = "";
            }
        }

        function selectInterviewer() {
            caScheduleInterviewSvc.setInterviewerInfo(self.scheduleInterviewData.selectedInterviewerId, self.scheduleInterviewData.scheduleInterview.InterviewersList);
        }

        function next() {
            $state.go(caConstants.scheduleInterviewTabName.dateTimeChosen, {
                id: candidateId, jobApplicationId: jobApplicationId, interviewId: interviewId
            });
        }

        function isDisableNextButton() {
            return (self.scheduleInterviewData.scheduleInterview === null || self.scheduleInterviewData.selectedInterviewerId === null ||
                self.scheduleInterviewData.scheduleInterview === undefined || self.scheduleInterviewData.selectedInterviewerId === undefined);
        }
    }
})();