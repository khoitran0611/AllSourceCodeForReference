﻿(function () {
    "use strict";
    angular.module('app').constant('caConstants', {
        translate: "translate",
        recruitmentStatus: {
            All: { id: "-1", name: "All" },
            New: { id: "0", name: "New" },
            Published: { id: "3", name: "Published" },
            Closed: { id: "4", name: "Closed" }
        },
        commentIcons: {
            comment: 1,
            dontUnderstand: 2,
            edit: 3,
            fun: 4,
            like: 5,
            smile: 6,
            success: 7
        },
        pageTitle: "Candidates",
        mainPage: "candidates",
        actionView: "view",
        linktoCreateCandidate: "../#/candidates/create",
        actionSendMail: "SendMail",
        actionDelete: "Delete",
        actionRestore: "Restore",
        actionUndoResponsible: "UndoResponsible",
        actionMakeResponsible: "MakeResponsible",
        generalInformationBodyCssEditing: 'panel-body bg-default',
        generalInformationBodyCss: 'panel-body bg-info',
        candidateFullName: "CandidateFullName",
        candidateCVFullName: "CandidateCVFullName",
        candidateFile: "CandidateFile",
        deleteCandidateString: "Delete_Candidate",
        restoreCandidateString: "Restore_Candidate",
        offerJob: "Interviews.Offer_Job",
        updateOfferLetter: "Interviews.Update_Offer_Letter",
        candidateImagePath: "CandidateImagePath",
        candidateImageTempPath: "CandidateImageTempPath",
        settingAppliedPositionColumn: "SettingColumnAppliedPostionList",
        jobCode: "JobCodeFilter",
        offerLetterEmployee: "OfferLetterEmployee",
        candidateImage: "CandidateImage",
        candidateImageTemp: "CandidateImageTemp",
        candidateImageTempToCandidateImage: "MoveCandidateImageTempToCandidateImage",
        candidateDetailPage:
        {
            generalInfomation: "info",
            applicationRecords: "position",
            experienceSkills: "skill",
            interviews: "interview",
            administration: "log"
        },
        //urlResource: {
        //    getCandidatePage: "../api/candidates?page=:page",
        //    sendMultiMailUpdateToCv: "../api/emails/",
        //    currentOpenPositions: "../api/openpositions",
        //    getCandidateInforById: "../api/candidates/:id",
        //    addNewCandidateInfo: "../api/candidates",
        //    getCandidateByAppliedPositions: "../api/appliedpositions/:jobApplicationId/candidates/:candidateId",
        //    saveCandidateImage: "../api/files",
        //    candidateInterview: "../api/candidates/:id/job-application/:jobApplicationId",
        //    candidateNote: "../api/candidates/:id/candidate-note",
        //    addNewScreeningCVHistory: "../api/candidates/:candidateId/job-application/:jobApplicationId/cscreening-cv-history",
        //    saveOfferLetter: "../api/offer-letters?actionName=:actionName",
        //    offerLetter: "../api/candidates/:candidateId/job-application/:jobApplicationId/offer-letters/:id",
        //    getcandidates: '../api/candidates?page=:page',
        //    generalInfo: '../api/candidates/:id',
        //    candidateResource: "../api/candidates/:id",
        //    summarySkill: '../api/candidates/:candidateId/skills/:skillId',
        //    employmentHistory: "../api/candidates/:candidateId/employment-histories/:employmentHistoryId",
        //    outstandingProject: "../api/candidates/:candidateId/outstanding-projects/:outstandingProjectId",
        //    education: "../api/candidates/:candidateId/educations/:educationId",
        //    fileAjax: "api/files",
        //    moveFileToOriginal: "api/files/move-candidate-image-to-origin",
        //    appliedPosition: "../api/candidates/:candidateId/appliedpositions/:jobApplicationId",
        //    checkPassword: "../api/candidates/:id/hash-password",
        //    getCvSources: "../api/candidates/cv-source",
        //    tags: "../api/tags/:id",
        //    getAllCountries: "../api/countries",
        //    getInterviewInfoForCanceling: "../api/interviews/:interviewId",
        //    candidateEmailTracking: "../api/candidates/:id/job-application/:jobApplicationId/email-tracking",
        //    getEmailSendJobInvitation: "../api/email/email-job-invitation",
        //    getJobDescriptionPdf: "../api/job-description/:id",
        //    getEmailJobInvitationBaseOnJobApplication: "../api/job-applications/:id/email-job-invitation",
        //    getEmailJobInvitationOfFirstCandidate: "../api/job-applications/:id/email-job-invitation-letter-first-candidate"
        //},

        administrationSource: {
            general: "General",
            administration: "Administration_Text",
            interview: "Interview",
            Screening: "Interviews.Screening",
            Restore: 'Restore',
            Delete: 'Delete'
        },

        candidateDetailTabName: {
            appliedPosition: "candidateDetail.appliedPosition",
            experienceSkills: "candidateDetail.experienceSkills",
            interviews: "candidateDetail.interviews",
            candidateAdministration: "candidateDetail.candidateAdministration",
            generalInformation: "candidateDetail"
        },
        scheduleInterviewTabName: {
            overallInformation: 'scheduleInterview.overallInformation',
            dateTimeChosen: 'scheduleInterview.dateTimeChosen',
            notification: 'scheduleInterview.notification',
            confirmation: 'scheduleInterview.confirmation'
        },
        scheduleInterview: {
            openStatus: 2097153,
            passStatus: 8388609
        },

        offerLetter: {
            passStatus: 1
        },

        experienceAndSkills: {
            maxLengthCharacterError: "Experience_Skills.This_Field_Must_Be_Less_Than_{0}_Characters"
        },

        candidateSummarySkill: {
            applicationSkills: 1,
            databaseSkills: 2,
            toolSkills: 3,
            othersSkills: 4
        },

        candidateDetails: {
            validForm: {
                StatusId: 4,
                PositionId: 0,
                ValidForm_StatusId: 5
            }
        },

        candidateInterview: {
            StatusCss: {
                LabelWarning: 0,
                LabelSuccess: 1,
                labelInfo: 2,
                LabelDanger: 3,
                LabelDefault: 4,
                LabelPrimary: 5
            },

            FormatCVStatus: {
                InterviewResultRejectText: 0,
                InterviewResultPassText: 1,
                InterviewResultOnHoldText: 2,
                InterviewResultBlackListText: 3,
                InterviewResultNewText: 4,
                InterviewResultOpenText: 5,
                InterviewResultShorlistText: 8,
            },

            FormatOverallStatus: {
                rejectStatus: 0,
                passStatus: 1,
                onholdStatus: 2,
                blacklistStatus: 3,
                newStatus: 4,
                openStatus: 5,
                successStatus: 6,
                shortlist: 8
            }
        },
        levelRound: {
            quizTest: 1,
            firstRound: 2,
            secondRound: 3,
            thirdRound: 4
        },
        conductInterview: {
            red: 'red',
            green: '#50B400',
            lightGreen: '#9AD400',
            greenLine:'#ACDE04',
            white: 'white',
            black: 'black',
            pink: 'pink'
        },
        // Map to CommonConstants class
        conductInterviewResult: [{
            id: 1,
            text: "Pass"
        },
        {
            id: 0,
            text: "Fail"
        },
        {
            id: 2,
            text: "On Hold"
        }],

        candidatesUrl: {
            latestCvUpdates: "/candidates/latest-cv-updates"
        },

        candidatesAction: {
            getAllBySortColumnModifiedDate: "getbysortcolumnmodifieddate"
        },
        events: {
            showLoadingEvent: 'showLoadingEvent',
            updateCVTab: 'updateCVTab',
            updateCandidateName: 'updateCandidateName',
            updateCandidateGeneralInformation: 'updateCandidateGeneralInformation',
            updateCropImageSource: 'updateCropImageSource'
        },
        maxFileSizeUploaded: 2097152,
        updateCurrentPosition: "UpdateCurrentPosition"
    });
})();
