﻿(function () {
    "use strict";
    angular.module('app').constant('caMessage', {
        editingData: "Adding_Data_Warning",
        addingData: "Adding_Data_Warning",
        titleSuccessful: "Successful",
        warning: "Warning",
        error: "Error",
        checkInputField: "Check_Input_Field",
        dontHavePermission: "Update_Offer_Letter_Permission_Warning",
        deleteCandidateConfirm: "Do_You_Want_To_Delete_Candidate",
        sendMailUpdateCVConfirm: "Are_You_Sure_You_Want_To_Send_Email_Update_CV_To_Selected_Candidates",
        restoreDeletedItemConfirm: 'Do_You_Want_To_Restore_Candidate',
        setUsersResponseItemConfirm: 'Do_You_Want_To_Set_Make_Responsible_Of_These_Candidates',
        removeUsersResponseItemConfirm: 'Do_you_Want_To_Remove_Make_Responsible_Of_These_Candidates',
        sendMailUpdateCVSuccess: "Send_Email_Successfully",
        sendMailUpdateCvError: "Error_In_Sending_Email",
        deleteCandidateSuccess: "Administration.Delete_Candidate_Success",
        deleteCandidateError: "Administration.Error_When_Deleting_Candidate",
        restoreDeletedCandidateSuccess: "Administration.Restore_Candidate_Successfully",
        restoreCandidateError: "Administration.Error_When_Restoring_Candidate",
        makeUserResponseCandidateSuccess: "Update_reponsive_for_candidates_successfully",
        makeUserResponseCandidateError: "Error_In_Updating_Responsive_For_Candidates",
        uploadCVError: "Upload_CV_error!",
        applicationPosition: {
            getAppliedPositionFailed: "Application_Records.Get_Applied_Position_Failed",
            addNewAppliedPositionSuccessful: "Application_Records.Add_New_Applied_Position_Successful",
            updateAppliedPositionSuccessful: "Application_Records.Update_Applied_Position_Successful",
            deleteAppliedPositionSuccessful: "Application_Records.Delete_Applied_Position_Successful",
            addNewAppliedPositionFail: "Application_Records.Error_When_Add_Application",
            updateAppliedPositionFail: "Application_Records.Error_When_Update_Application",
            deleteAppliedPositionFail: "Application_Records.Error_When_Delete_Application",
            addCurrentAppliedPositionFail: "Application_Records.Error_Add_Current_Position_Exist"
        },
        dialogConfirm: {
            dialogId: "caDialogConfirm",
            dialogTitle: "Confirm",
            dialogMessage: "Do_You_Want_To_Delete_Candidate"
        },

        candidateEmploymentHistory: {
            dialogConfirm: {
                dialogId: "caDialogConfirmEmploymentHistory",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Employment_History.Do_You_Want_To_Delete_This_Employment_History"
            },
            addCandidateEmploymentHistoryError: "Employment_History.Add_New_Candidate_Employment_History_Fail",
            addCandidateEmploymentHistorySuccess: "Employment_History.Add_New_Candidate_Employment_History_Successfully",

            updateCandidateEmploymentHistoryError: "Employment_History.Update_Candidate_Employment_History_Fail",
            updateCandidateEmploymentHistorySuccess: "Employment_History.Update_Candidate_Employment_History_Successfully",

            deleteCandidateEmploymentHistoryError: "Employment_History.Delete_Candidate_Employment_History_Fail",
            deleteCandidateEmploymentHistorySuccess: "Employment_History.Delete_Candidate_Employment_History_Successfully"
        },

        administration: {
            dialogConfirmDelete: {
                dialogId: "caDialogConfirmDelete",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Administration.Are_You_Sure_To_Delete_This_Candidate"
            },
            deleteCandidateError: "Administration.Error_When_Deleting_Candidate",
            restoreCandidateError: "Administration.Error_When_Restoring_Candidate",
            restoreCandidateSuccess: "Administration.Restore_Candidate_Successfully",
            deleteCandidateSuccess: "Administration.Delete_Candidate_Success"
        },

        notes: {
            addNewNoteSuccessfully: 'Administration.Add_New_Note_Successfully',
            addNewNoteError: 'Administration.Error_When_Adding_New_Note'
        },

        generalInformation: {
            updatePosition: "General_Information.You_Must_Update_A_Position_For_This_Candidate",
            firstNameRequire: "General_Information.First_Name_Is_Required",
            lastNameRequire: "General_Information.Last_Name_Is_Required",
            emailRequire: "General_Information.Email_Is_Required",
            emailInvalid: "General_Information.This_Is_Not_A_Valid_Email",
            checkEmailError: "General_Information.Error_In_Checking_Email",
            updateCandidateInformationError: "General_Information.Error_In_Updating_Candidate_Information",
            updateCandidateInformationSuccess: "General_Information.Update_Candidate_General_Information_Successfully",
            updateCvStatusError: "General_Information.Error_in_Update_Cv_Status",
            updateCvStatusSuccess: "General_Information.Update_Cv_Status_Successfully",
            updateCandidateImageError: "General_Information.Error_In_Updating_Candidate_Image",
            duplicateEmailError: "General_Information.Email_Already_Exists",
            birthdayInvalid: "General_Information.Must_Be_Greater_Or_Equal_20_Years_Old",
            addCandidateInformationSuccessfully: "General_Information.Add_Candidate_General_Information_Successfully",
            addCandidateInformationError: "General_Information.Error_In_Add_Candidate_General_Information",
            addCandidateImageError: "General_Information.Error_In_Add_Candidate_Image",
            importImage: "General_Information.Please_Choose_Image_File",
            updateExperienceSuccess: "General_Information.Update_Experience_Successfully"
        },

        education: {
            dialogConfirm: {
                dialogId: "caDialogConfirmEducation",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Education.Do_You_Want_To_Delete_This_Education"
            },
            getCandidateEducationError: "Education.Error_When_Getting_Candidate_Education",
            addCandidateEducationError: "Education.Error_When_Adding_Candidate_Education",
            updateCandidateEducationError: "Education.Error_When_Updating_Candidate_Education",
            addCandidateEducationSuccess: "Education.Add_New_Education_Successfully",
            updateCandidateEducationSuccess: "Education.Update_Education_Successfully",
            deleteCandidateEducationError: "Education.Error_When_Deleting_Candidate_Education",
            deleteCandidateEducationSuccess: "Education.Delete_Candidate_Education_Successfully",
            errorLoadingCountry: "Error_Loading_Country"
        },

        summarySkill: {
            dialogConfirm: {
                dialogId: "caDialogConfirmSummarySkill",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Skills.Do_You_Want_To_Delete_This_Skill"
            },
            updateCandidateSkillSuccess: "Skills.Update_Candidate_Skill_Successfully",
            updateCandidateSkillError: "Skills.Error_When_Updating_Candidate_Skill",
            getCandidateSkillError: "Skills.Error_When_Getting_Candidate_Skill",
            deleteCandidateSkillSuccess: "Skills.Delete_Candidate_Skill_Successfully",
            deleteCandidateSkillError: "Skills.Error_When_Deleting_Candidate_Skill",
            insertCandidateSkillError: "Skills.Error_When_Adding_Candidate_Skill",
            addCandidateSkillSuccess: "Skills.Add_New_Candidate_Skill_Successfully",
            addDataWarning: "Adding_Data_Warning"
        },

        course: {
            dialogConfirm: {
                dialogId: "caDialogConfirmCourse",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Courses.Do_You_Want_To_Delete_This_Course"
            },
            updateCandidateCourseSuccess: "Courses.Update_Candidate_Course_Successfully",
            updateCandidateCourseError: "Courses.Error_When_Updating_Candidate_Course",
            getCandidateCourseError: "Courses.Error_When_Getting_Candidate_Course",
            deleteCandidateCourseSuccess: "Courses.Delete_Candidate_Course_Successfully",
            deleteCandidateCourseError: "Courses.Error_When_Deleting_Candidate_Course",
            insertCandidateCourseError: "Courses.Error_When_Adding_Candidate_Course",
            addCandidateCourseSuccess: "Courses.Add_New_Candidate_Course_Successfully",
            addDataWarning: "Adding_Data_Warning"
        },

        certification: {
            dialogConfirm: {
                dialogId: "caDialogConfirmCertification",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Certifications.Do_You_Want_To_Delete_This_Certification"
            },
            updateCandidateCertificationSuccess: "Certifications.Update_Candidate_Certification_Successfully",
            updateCandidateCertificationError: "Certifications.Error_When_Updating_Candidate_Certification",
            getCandidateCertificationError: "Certifications.Error_When_Getting_Candidate_Certification",
            deleteCandidateCertificationSuccess: "Certifications.Delete_Candidate_Certification_Successfully",
            deleteCandidateCertificationError: "Certifications.Error_When_Deleting_Candidate_Certification",
            insertCandidateCertificationError: "Certifications.Error_When_Adding_Candidate_Certification",
            addCandidateCertificationSuccess: "Certifications.Add_New_Candidate_Certification_Successfully",
            addDataWarning: "Adding_Data_Warning"
        },

        reference: {
            dialogConfirm: {
                dialogId: "caDialogConfirmReference",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "References.Do_You_Want_To_Delete_This_Reference"
            },
            updateCandidateReferenceSuccess: "References.Update_Candidate_Reference_Successfully",
            updateCandidateReferenceError: "References.Error_When_Updating_Candidate_Reference",
            getCandidateReferenceError: "References.Error_When_Getting_Candidate_Reference",
            deleteCandidateReferenceSuccess: "References.Delete_Candidate_Reference_Successfully",
            deleteCandidateReferenceError: "References.Error_When_Deleting_Candidate_Reference",
            insertCandidateReferenceError: "References.Error_When_Adding_Candidate_Reference",
            addCandidateReferenceSuccess: "References.Add_New_Candidate_Reference_Successfully",
            addDataWarning: "Adding_Data_Warning"
        },

        languageSkill: {
            dialogConfirm: {
                dialogId: "caDialogConfirmLanguageSkill",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Language_Skills.Do_You_Want_To_Delete_This_Language_Skill"
            },
            updateCandidateSkillSuccess: "Language_Skills.Update_Candidate_Language_Skill_Successfully",
            updateCandidateSkillError: "Language_Skills.Error_When_Updating_Candidate_Language_Skill",
            getCandidateSkillError: "Language_Skills.Error_When_Getting_Candidate_Language_Skill",
            deleteCandidateSkillSuccess: "Language_Skills.Delete_Candidate_Language_Skill_Successfully",
            deleteCandidateSkillError: "Language_Skills.Error_When_Deleting_Candidate_Language_Skill",
            insertCandidateSkillError: "Language_Skills.Error_When_Adding_Candidate_Language_Skill",
            addCandidateSkillSuccess: "Language_Skills.Add_New_Candidate_Language_Skill_Successfully",
            addDataWarning: "Adding_Data_Warning"
        },



        outstandingProject: {
            dialogConfirm: {
                dialogId: "caDialogConfirmOutstanding",
                dialogTitle: "Confirm_Delete",
                dialogMessage: "Outstanding_Project.Do_You_Want_To_Delete_This_Outstanding_Project"
            },
            addOutstandingSuccessfully: "Outstanding_Project.Add_Outstanding_Project_Successfully",
            editOutstandingSuccessfully: "Outstanding_Project.Edit_Outstanding_Project_Successfully",
            deleteOutstandingSuccessfully: "Outstanding_Project.Delete_Outstanding_Project_Successfully",
            addOutstandingFail: "Outstanding_Project.Add_Outstanding_Project_Fail",
            editOutstandingFail: "Outstanding_Project.Edit_Outstanding_Project_Fail",
            deleteOutstandingFail: "Outstanding_Project.Delete_Outstanding_Project_Fail",
            getOutstandingFail: "Outstanding_Project.Error_When_Getting_Candidate_Outstanding_Project"
        },

        interview: {
            getCandidateInterviewError: "Interviews.Error_when_getting_candidate_interview",
            dialogConfirm: {
                dialogId: "conductInterviewConfirmDialog",
                dialogTitle: "Interviews.Confirm_Finished",
                dialogMessage: "Interviews.Confirm_Finished_Message"
            },
            dialogSkipConfirm: {
                dialogId: "conductInterviewSkipConfirmDialog",
                dialogTitle: "Interviews.Confirm_Skip",
                dialogMessage: "Interviews.Confirm_Skip_Message"
            },
            updateInterViewSummarySuccessful: "Update_Interview_Summary_Successful",
            updateInterViewSummaryFail: "Update_Interview_Summary_Fail",
            updateInterViewRatingSuccessful: "Update_Interview_Rating_Successful",
            updateInterViewRatingFail: "Update_Interview_Rating_Fail",
            updateInterViewResultSuccessful: "Update_Interview_Result_Successful",
            updateInterViewResultFail: "Update_Interview_Result_Fail",
            updateInterViewCommentSuccessful: "Update_Interview_Comment_Successful",
            updateInterViewCommentFail: "Update_Interview_Comment_Fail",
            updateSalaryInformationSuccessful: "Update_Salary_Information_Successful",
            updateSalaryInformationFail: "Update_Salary_Information_Fail",
            addConductInterviewSuccessful: "Add_Conduct_Interview_Successful",
            addConductInterviewFail: "Add_Conduct_Interview_Fail",
            loadInterViewFail: "Load_Interview_Fail",
            interviewFinish: "Interviews.Interview_Finish",
            cancelInterviewSuccessful: "Interviews.Cancel_Interview_Successful",
            cancelInterviewFail: "Interviews.Cancel_Interview_Fail"
        },
        offerLetter: {
            updateOfferLetterStatusPageTitle: "Offer_Letter.Update_Offer_Status",
            close: "Close",
            createOfferLetter: "Create_Offer_Letter",
            updateSuccessful: "Offer_Letter.Update_Offer_Letter_Successful",
            updateFail: "Offer_Letter.Update_Offer_Letter_Successful"
        },
        scheduleInterview: {
            addScheduleSuccessful: "Schedule_Interview.Add_Schedule_Success",
            addScheduleFail: "Schedule_Interview.Add_Schedule_Fail",
            updateScheduleSuccessful: "Schedule_Interview.Update_Schedule_Success",
            updateScheduleFail: "Schedule_Interview.Update_Schedule_Fail"
        },
        candidateHas: "Candidate_Has",
        already: "Already",
        uploadFileLessThan: "Please_Upload_File_Less_Than",
        sizeOfImage: "Size_Of_Image",
        emailTrackingLoadingError: "Email_Tracking_Loading_Error",
        SendMultiEmailsSuccessFull: "Send_Multi_Emails_Successfully",
        SendEmailsSuccessFull: "Send_Email_Successfully",
        updateCvMessage: "Update_Cv_Message",
    });
})();


