﻿(function () {
    'use strict';
    angular.module('app').controller('candidateCtrl', CandidateCtrl);
    CandidateCtrl.$inject = ['authenticationSvc',
        'caDetailSvc', 'languageHelperSvc', 'candidateSvc', 'permissionSvc', 'messageHandleSvc', 'caGridSvc',
        'caSearchBoxInitialSvc', 'objectSvc', 'historyPageSvc', 'emailSvc', 'switchCandidateSvc',
        'constants', 'caConstants', 'message', 'caMessage',
        '$scope', '$filter', '$state', '$timeout', '$rootScope', '$location', '$compile', '$window', '$document', 'loadingSvc'];
    function CandidateCtrl(authenticationSvc, caDetailSvc, languageHelperSvc, candidateSvc, permissionSvc, messageHandleSvc, caGridSvc,
        caSearchBoxInitialSvc, objectSvc, historyPageSvc, emailSvc, switchCandidateSvc,
        constants, caConstants, message, caMessage,
        $scope, $filter, $state, $timeout, $rootScope, $location, $compile, $window, $document, loadingSvc) {
        var self = this;
        self.isDisabledIcon = true;
        self.isDisabledRestoreIcon = true;
        self.jobApplicationIdList = [];

        self.candidateIdList = [];
        self.candidateIdRestoreList = [];
        self.listId = [];
        self.query = $.jStorage.get(constants.localStorageKey.candidateSearch) ? $.jStorage.get(constants.localStorageKey.candidateSearch).value : undefined;

        self.initDataSearchBox = new caSearchBoxInitialSvc();
        self.isSearching = !constants.activeSearch;

        self.totalPages = 0;
        self.pagingOptions = {};
        self.dataGrid = "caCtrl.data";
        self.pagingEvent = "caCtrl.pagingOptions";
        self.rowTemplate = "candidate/grid/caRowGrid.html";
        self.headerCellTemplate = "candidate/grid/headerCellTemplate.html";
        self.gridId = "caGrid";
        self.iconClass = "sprite-add-user-record";
        self.candidateGetByAction = "";
        self.columnDefs = [];
        self.customCss = {};
        self.showFooter = true;
        self.enablePaging = true;
        self.collapsableSearch = true;
        self.isCreateNewCandidate = false;
        self.isSendJobInvitation = false;
        self.isAskUpdateCv = false;
        self.i18n = languageHelperSvc.getLanguage();
        self.smallMsg = self.bigMsg = 'candidate';
        self.emailData = {};
        self.dataForPreview = {};
        self.permissionOfCurrentUser = {
            viewCandidates: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_ViewCandidates),
            addCandidate: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_AddCandidate),
            sendMailUpdateCV: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SendMailUpdateCV),
            deleteCandidates: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_DeleteCandidates),
            restoreDeletedCandidates: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_RestoreCandidates),
            setResponseCandidates: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SetResponseCandidates),
            removeResponseCandidates: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_RemoveResponseCandidates),
            viewCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewCandidateInfo),
            canViewInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview),
            canViewSchedule: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_ViewScheduleInterview),
            canEditSchedule: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_EditSchedule),
            sendJobInvitation: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SendJobInvitation),
            canViewJobsSnapshot: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewJobsSnapshot),
            canViewOpenPositionDetail: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.OpenPositions_ViewOpenPositionDetail),
            canViewDashboard: permissionSvc.checkGroupOfPermissionCondition([permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewLatestApplications),
                                                            permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewLatestCvUpdates),
                                                            permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewJobsSnapshot),
                                                            permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewJobActivity)]),
            canSettingColumn: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_CustomizeColumnsOnCandidatesListing)
        };
        if (!self.permissionOfCurrentUser.viewCandidates) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.lockColumnsCustomization = !self.permissionOfCurrentUser.canSettingColumn;
        self.showColumnMenu = self.permissionOfCurrentUser.canSettingColumn;
        self.showSelectionCheckbox = !self.lockColumnsCustomization;
        self.dialogConfirm = caMessage.dialogConfirm;
        self.isSendMultiMailUpdateCV = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SendMailUpdateCV);
        self.isLoadingInfor = false;
        self.isComeFromDashboard = false;

        self.onYes = onYes;
        self.onClickSendMail = onClickSendMail;
        self.onClickDelete = onClickDelete;
        self.onClickRestore = onClickRestore;
        self.onClickMakeUserResponse = onClickMakeUserResponse;
        self.handleSelectedItems = handleSelectedItems;
        self.activeApi = activeApi;
        self.getPagedDataAsync = getPagedDataAsync;
        self.setHistory = setHistory;
        self.selectExpand = selectExpand;
        self.checkExpand = checkExpand;
        self.getExpandIcon = getExpandIcon;
        self.goToDashboardJobDetail = goToDashboardJobDetail;
        self.getGridCss = getGridCss;
        self.createNewCandidate = createNewCandidate;
        self.onClickSendJobInvitation = onClickSendJobInvitation;
        self.goToJobDetail = goToJobDetail;

        var getUserLoginFromCookie = JSON.parse($window.localStorage.getItem("currentuserlogin"));
        var currentUser = { UserId: getUserLoginFromCookie.UserId, FullName: getUserLoginFromCookie.FullName };
        var expandList = [];
        var candidateListElement = angular.element('#candidate-list');

        init();

        function init() {
            $scope.lockColumnsCustomization = self.lockColumnsCustomization;
            caDetailSvc.setCandidateId(0);
            caDetailSvc.setCurrentPosition(0);
            caDetailSvc.updateSelectedJobApplication(0);

            historyPageSvc.setPreviousQuery(constants.baseUrl + "#/candidates", self.query);

            var currentPage = Number($window.localStorage.getItem(constants.localStorageKey.currentCandidateListPage));
            self.pageIndex = (currentPage > 0) ? currentPage : constants.paging.firstPage;

            if ($location.path() === caConstants.candidatesUrl.latestCvUpdates) {
                self.candidateGetByAction = caConstants.candidatesAction.getAllBySortColumnModifiedDate;
            }

            self = self.getPagedDataAsync();
            self = caGridSvc.gridInit(self, $scope);

            getEventTranferFromDashboard();

            $scope.$on(constants.broadCastTile.requestUpdateCV, function () {
                self.jobApplicationIdList = [];
                self.gridOptions.selectAll(false);
            });
            $document.bind('click', function (event) {
                var isClickedCandidateList = candidateListElement.find(event.target).length > 0;
                if (isClickedCandidateList) {
                    if (self.isCreateNewCandidate || self.isSendJobInvitation) {
                        $rootScope.$broadcast(constants.broadCastTile.createNewCandidate, { createNewCandidateStatus: self.isCreateNewCandidate });
                    }
                    self.isSendJobInvitation = false;
                    self.isCreateNewCandidate = false;
                    self.isAskUpdateCv = false;
                    removeHoverElement('.sprite-invitation');
                    removeHoverElement('.sprite-add-user');
                    removeHoverElement('.sprite-chat');
                }
            });

        }

        function goToJobDetail(id) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/jobs/" + id, window.location.href);
            historyPageSvc.setPreviousTag(constants.baseUrl + "#/jobs/" + id, constants.invitationMenuIndex.all);
            $rootScope.$broadcast(constants.broadCastTile.storeJobFilter, {});
            $.jStorage.set(constants.localStorageKey.jobSearch, self.filter);
        }

        function onYes() {
            switch (self.action) {
                case caConstants.actionDelete:
                    {
                        loadingSvc.show();
                        if (!objectSvc.checkPermission(self.permissionOfCurrentUser.deleteCandidates, message.dontHavePermissionAccess, true)) return;
                        var deleteActionParams = { "id": "0", "listCandidateId": self.candidateIdList, "action": 'deleteCandidate' };
                        candidateSvc.deleteCandidates(deleteActionParams).DeleteCandidates(
                            function () {
                                loadingSvc.close();
                                toastr.success($filter(constants.translate)(caMessage.deleteCandidateSuccess));
                                $timeout(function () {
                                    $state.go($state.current, {}, { reload: true });
                                    $(".modal-backdrop").remove();
                                }, 1000);
                            },
                            function (xhr) {
                                loadingSvc.close();
                                messageHandleSvc.handleResponse(xhr, caMessage.deleteCandidateError);
                            });
                        break;
                    }
                case caConstants.actionRestore:
                    {
                        if (!objectSvc.checkPermission(self.permissionOfCurrentUser.restoreDeletedCandidates, message.dontHavePermissionAccess, true)) return;
                        var restoreActionParams = { "id": "0", "listCandidateId": self.candidateIdRestoreList, "action": 'restoreCandidate' };
                        candidateSvc.restoreDeleteCandidates(restoreActionParams).RestoreDeleteCandidate(
                            function () {
                                toastr.success($filter(constants.translate)(caMessage.restoreDeletedCandidateSuccess));
                                $timeout(function () {
                                    $state.go($state.current, {}, { reload: true });
                                    $(".modal-backdrop").remove();
                                }, 1000);
                            },
                            function (xhr) {
                                messageHandleSvc.handleResponse(xhr, caMessage.restoreCandidateError);
                            });
                        break;
                    }
                case caConstants.actionUndoResponsible:
                    {
                        if (!objectSvc.checkPermission(self.permissionOfCurrentUser.removeResponseCandidates, message.dontHavePermissionAccess, true)) return;
                        var makeUndoResponsibleActionParams = { "listCandidateId": self.candidateIdList, "action": 'makeUndoResponsive' };
                        candidateSvc.makeUserResponseCandidates(makeUndoResponsibleActionParams, currentUser).MakeUserResponseCandidate(
                            function () {
                                toastr.success($filter(constants.translate)(caMessage.makeUserResponseCandidateSuccess));
                                for (var i = 0; i < self.data.length; i++) {
                                    for (var j = 0; j < self.candidateIdList.length; j++) {
                                        if (self.data[i].CandidateId == self.candidateIdList[j]) {
                                            self.data[i].ResponsibleEmployeeFullName = '';
                                        }
                                    }
                                }
                            },
                            function (xhr) {
                                messageHandleSvc.handleResponse(xhr, caMessage.makeUserResponseCandidateError);
                            });
                        break;
                    }
                case caConstants.actionMakeResponsible:
                    {
                        if (!objectSvc.checkPermission(self.permissionOfCurrentUser.setResponseCandidates, message.dontHavePermissionAccess, true)) return;
                        var makeResponsibleActionParams = { "listCandidateId": self.candidateIdList, "action": 'makeResponsive' };
                        candidateSvc.makeUserResponseCandidates(makeResponsibleActionParams, currentUser).MakeUserResponseCandidate(
                            function () {
                                toastr.success($filter(constants.translate)(caMessage.makeUserResponseCandidateSuccess));
                                for (var i = 0; i < self.data.length; i++) {
                                    for (var j = 0; j < self.candidateIdList.length; j++) {
                                        if (self.data[i].CandidateId == self.candidateIdList[j]) {
                                            self.data[i].ResponsibleEmployeeFullName = getUserLoginFromCookie.FullName;
                                        }
                                    }
                                }
                            },
                            function (xhr) {
                                messageHandleSvc.handleResponse(xhr, caMessage.makeUserResponseCandidateError);
                            });
                        break;
                    }
                default:
                    break;
            }
        }

        function onClickSendMail() {
            if (self.jobApplicationIdList.length === 1) {
                var jobApplicationIdOfCandidate = self.jobApplicationIdList[0].JobApplicationId;
                emailSvc.jobApplicationUpdateCvEmail(jobApplicationIdOfCandidate).get(function (data) {
                    self.emailData = data;
                    self.originContent = angular.copy(self.emailData.Content);
                    self.emailData.originContent = self.originContent;
                    self.originSubject = angular.copy(self.emailData.Subject);
                    self.emailData.originSubject = self.originSubject;
                    self.emailData.listOfJobApplication = self.jobApplicationIdList;
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                });
            } else {
                emailSvc.getEmailDataForRequestUpdateCv().get(function (data) {
                    self.emailData = data;
                    self.originContent = angular.copy(self.emailData.Content);
                    self.emailData.originContent = self.originContent;
                    self.originSubject = angular.copy(self.emailData.Subject);
                    self.emailData.originSubject = self.originSubject;
                    self.emailData.To = $filter(constants.translate)(caMessage.updateCvMessage) + self.candidateIdList.length + $filter(constants.translate)('candidates');
                    self.emailData.listOfJobApplication = self.jobApplicationIdList;
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                });
            }
            self.isSendJobInvitation = false;
            self.isCreateNewCandidate = false;
            removeHoverElement('.sprite-invitation');
            removeHoverElement('.sprite-add-user');
            $rootScope.$broadcast(constants.broadCastTile.createNewCandidate, { createNewCandidateStatus: self.isCreateNewCandidate });
            $rootScope.$broadcast(constants.broadCastTile.clearSearch, {});
            self.isAskUpdateCv = true;
            addHoverElement('.sprite-chat');
        }

        function showDialog(dialogMessage, action) {
            self.dialogConfirm.dialogMessage = dialogMessage;
            self.action = action;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function onClickDelete() {
            self.isSendJobInvitation = false;
            self.isAskUpdateCv = false;
            removeHoverElement('.sprite-invitation');
            removeHoverElement('.sprite-add-user');
            removeHoverElement('.sprite-chat');
            if (self.isCreateNewCandidate) {
                self.isCreateNewCandidate = false;
                $rootScope.$broadcast(constants.broadCastTile.createNewCandidate, { createNewCandidateStatus: self.isCreateNewCandidate });
            }
            showDialog(caMessage.deleteCandidateConfirm, caConstants.actionDelete);
        }

        function onClickRestore() {
            self.isSendJobInvitation = false;
            self.isAskUpdateCv = false;
            removeHoverElement('.sprite-invitation');
            removeHoverElement('.sprite-add-user');
            removeHoverElement('.sprite-chat');
            if (self.isCreateNewCandidate) {
                self.isCreateNewCandidate = false;
                $rootScope.$broadcast(constants.broadCastTile.createNewCandidate, { createNewCandidateStatus: self.isCreateNewCandidate });
            }
            showDialog(caMessage.restoreDeletedItemConfirm, caConstants.actionRestore);
        }

        function onClickMakeUserResponse(toggle) {
            self.isSendJobInvitation = false;
            self.isAskUpdateCv = false;
            removeHoverElement('.sprite-invitation');
            removeHoverElement('.sprite-add-user');
            removeHoverElement('.sprite-chat');
            if (self.isCreateNewCandidate) {
                self.isCreateNewCandidate = false;
                $rootScope.$broadcast(constants.broadCastTile.createNewCandidate, { createNewCandidateStatus: self.isCreateNewCandidate });
            }
            var stringDo = "do";
            self.action = toggle == stringDo ? caConstants.actionMakeResponsible : caConstants.actionUndoResponsible;
            var messageConfirm = toggle == stringDo ? caMessage.setUsersResponseItemConfirm : caMessage.removeUsersResponseItemConfirm;
            self.dialogConfirm.dialogMessage = messageConfirm;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function handleSelectedItems() {
            self.isDisabledIcon = true;
            self.isDisabledRestoreIcon = true;
            var selected = self.gridOptions.selectedItems;
            if (selected.length > 0) {

                var gridHeaderScope = angular.element($("#candidate-list .ngSelectionHeader")).scope();
                if (gridHeaderScope)
                    gridHeaderScope.allSelected = selected.length == self.gridOptions.$gridScope.renderedRows.length;

                $.each(selected, function (i, candidate) {
                    var itemInArray = $.grep(self.jobApplicationIdList, function (e) {
                        return e.JobApplicationId == candidate.JobApplicationId;
                    });
                    if (itemInArray.length === 0) {
                        if (typeof (candidate.candidateInfo) !== 'object') return;
                        var itemToList = {
                            JobApplicationId: candidate.JobApplicationId,
                            CandidateId: candidate.CandidateId,
                            FirstName: candidate.candidateInfo.FirstName,
                            Email: candidate.candidateInfo.Email,
                            Title: candidate.Gender,
                            Username: candidate.candidateInfo.Email,
                            Position: candidate.PositionName
                        };
                        self.jobApplicationIdList.push(itemToList);
                    }

                    if (candidate.IsDeleted.toLowerCase() === "true") {
                        self.isDisabledRestoreIcon = false;
                        if ($.inArray(candidate.CandidateId, self.candidateIdRestoreList) == -1) {
                            self.candidateIdRestoreList.push(candidate.CandidateId);
                        }
                    } else {
                        self.isDisabledIcon = false;
                        if ($.inArray(candidate.CandidateId, self.candidateIdList) == -1) {
                            self.candidateIdList.push(candidate.CandidateId);
                        }
                    }
                });

                $.each(self.jobApplicationIdList, function (i, jobApplicationId) {
                    var filterJobApplicationId = $.grep(selected, function (e) {
                        return e.JobApplicationId == jobApplicationId.JobApplicationId;
                    });
                    if (filterJobApplicationId.length === 0) {
                        self.jobApplicationIdList = $.grep(self.jobApplicationIdList, function (value) { return value.JobApplicationId != jobApplicationId.JobApplicationId; });
                    }
                });

                $.each(self.candidateIdList, function (i, candidateId) {
                    var filterCandidateId = $.grep(selected, function (e) { return e.CandidateId == candidateId; });
                    if (filterCandidateId.length === 0) {
                        self.candidateIdList = $.grep(self.candidateIdList, function (value) { return value != candidateId; });
                    }
                });
            }
            else if (selected.length === 0) {
                self.isDisabledIcon = true;
            }
        }

        function activeApi(method, query) {
            expandList = [];
            self.isLoadingInfor = true;
            $(constants.loadingIcon.overlay).show();
            $(constants.loadingIcon.indicator).show();
            historyPageSvc.setPreviousQuery(window.location.href, (query && query.value) ? query.value : "");
            $.jStorage.set(constants.localStorageKey.candidateSearch, query);
            var gridHeaderScope = angular.element($("#candidate-list .ngSelectionHeader")).scope();
            if (gridHeaderScope)
                gridHeaderScope.allSelected = false;
            //if (clearGridItemSelected) {
            //    self.gridOptions.selectedItems.length = 0;
            //    self.handleSelectedItems();
            //}
            self.isSearching = (method == constants.callSearchApi.search) ? constants.activeSearch : !constants.activeSearch;
            self.query = (self.isSearching == constants.activeSearch) ? query.value : "";
            self.pagingOptions.currentPage = 1;
            self.pageIndex = constants.paging.firstPage;
            if (!$scope.$$phase) $scope.$apply();
            $window.localStorage.setItem(constants.localStorageKey.currentCandidateListPage, self.pagingOptions.currentPage);
            self.getPagedDataAsync(self.pagingOptions.currentPage, self.query, self.isSearching);
        }

        function getPagedDataAsync() {
            self = caGridSvc.getPagedDataAsync(self, $scope);
            if (self.gridOptions) {
                self.gridOptions.selectedItems.length = 0;
                self.isDisabledIcon = true;
            }
            return self;
        }

        function setHistory(candidateId) {
            var dataFilter = switchCandidateSvc.getFilterData();
            var index = dataFilter.listId.indexOf(parseInt(candidateId, 10));
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + candidateId, window.location.href);
            historyPageSvc.setCurrentCandidateIdIndex(index);
        }

        function selectExpand(candidateId, event) {
            self.isSendJobInvitation = false;
            self.isCreateNewCandidate = false;
            self.isAskUpdateCv = false;
            removeHoverElement('.sprite-invitation');
            removeHoverElement('.sprite-add-user');
            removeHoverElement('.sprite-chat');
            if (!expandList || expandList.length === 0) {
                expandList = [candidateId];
                event.stopPropagation();
                return;
            }
            var candidateIndexInList = expandList.indexOf(candidateId);
            if (candidateIndexInList == -1) expandList.push(candidateId);
            else expandList.splice(candidateIndexInList, 1);
            event.stopPropagation();
        }

        function checkExpand(candidateId) {
            if (!expandList || expandList.length === 0) return "hide";
            var candidateIndexInList = expandList.indexOf(candidateId);
            if (candidateIndexInList == -1) return "hide";
            return "expand-sub-grid-row";
        }

        function getExpandIcon(candidateId) {
            if (!expandList || expandList.length === 0) return "fa expand-icon fa-2x fa-caret-right";
            var candidateIndexInList = expandList.indexOf(candidateId);
            if (candidateIndexInList == -1) return "fa expand-icon fa-2x fa-caret-right";
            return "fa expand-icon fa-2x fa-caret-down";
        }

        function goToDashboardJobDetail(id) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/jobs/" + id + "/dashboard", window.location.href);
            historyPageSvc.setPreviousTag(constants.baseUrl + "#/jobs/" + id + "/dashboard", constants.invitationMenuIndex.all);
        }

        function getEventTranferFromDashboard() {
            self.isComeFromDashboard = false;
            var previousUrl = historyPageSvc.getPreviousUrl(constants.baseUrl + "#/candidates");
            if (previousUrl && previousUrl.indexOf("dashboard") > -1) {
                historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates", "");
                self.isComeFromDashboard = true;
                $timeout(function () {
                    self.isComeFromDashboard = false;
                    loadingSvc.close();
                }, 4000);
            }
        }

        function getGridCss(isEmpty) {
            if (isEmpty) return "";
            return "grid-height";
        }

        function createNewCandidate() {
            self.isSendJobInvitation = false;
            self.isAskUpdateCv = false;
            self.isCreateNewCandidate = true;
            $rootScope.$broadcast(constants.broadCastTile.createNewCandidate, { createNewCandidateStatus: self.isCreateNewCandidate });
            self.jobApplicationIdList = [];
            self.gridOptions.selectAll(false);
            removeHoverElement('.sprite-invitation');
            removeHoverElement('.sprite-chat');
            addHoverElement('.sprite-add-user');
        }

        function onClickSendJobInvitation() {
            self.isAskUpdateCv = false;
            if (self.isCreateNewCandidate) {
                self.isCreateNewCandidate = false;
                $rootScope.$broadcast(constants.broadCastTile.createNewCandidate, { createNewCandidateStatus: self.isCreateNewCandidate });
            }
            $rootScope.$broadcast(constants.broadCastTile.sendJobInvitation, { jobApplicationIdList: self.jobApplicationIdList });
            $rootScope.$broadcast(constants.broadCastTile.clearSearch, {});
            self.isSendJobInvitation = true;
            addHoverElement('.sprite-invitation');
            removeHoverElement('.sprite-add-user');
            removeHoverElement('.sprite-chat');
        }
    }
})();
