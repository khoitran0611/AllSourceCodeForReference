﻿(function () {
    'use strict';
    angular.module('app').controller('caNewCtrl', CaNewCtrl);
    CaNewCtrl.$inject = ['uploadFilesSvc', 'caAppliedPositionSvc', 'candidateSvc', 'messageHandleSvc', 'datetimeSvc', 'caDetailSvc',
        'objectSvc', 'switchCandidateSvc', 'message', 'caMessage', 'constants', 'caConstants',
        '$scope', '$state', '$filter', '$location', '$cookieStore', '$rootScope', '$window', 'uploadFileSvc',
        'comparisonUtilSvc', 'loadingSvc'];
    function CaNewCtrl(uploadFilesSvc, caAppliedPositionSvc, candidateSvc, messageHandleSvc, datetimeSvc, caDetailSvc,
            objectSvc, switchCandidateSvc, message, caMessage, constants, caConstants,
            $scope, $state, $filter, $location, $cookieStore, $rootScope, $window, uploadFileSvc,
            comparisonUtilSvc, loadingSvc) {
        var male = 'Male';
        var female = 'Female';
        var appliedPositionEdited = {};
        var cvSourceData = {};
        var param = {};
        var hasImageUploadedOnTemp = false;
        var candidateImage = null;
        var self = this;

        self.cropImageModal = {
            source: ""
        };

        self.genders = [{ name: "" }, { name: male }, { name: female }];
        //self.addOnOpitionPosition = constants.defaultPosition;

        self.candidateInforData = {};
        self.generalInputForm = "$generalInputForm";
        self.fileType = 'CandidateFile';
        self.tempPath = '/FolderImage/Images/noavatar.jpg';
        self.pageMessage = caMessage.generalInformation;
        self.selectedCurrentPostion = {};
        self.tempDuplicateEmail = constants.stringEmpty;
        self.isRequiredUpdatePosition = false;
        self.isShowMessageIE = false;
        self.hasImageCropped = false;
        self.linkToCandidate = {};
        self.duplicateInfo = {};
        self.serverUrl = "";
        self.candidateFullName = '';

        self.isValidBirthday = isValidBirthday;
        self.onClickSaveCandidate = onClickSaveCandidate;
        self.canUploadFile = canUploadFile;
        self.isDisableSave = isDisableSave;
        self.accept = accept;
        self.checkDuplicateEmail = checkDuplicateEmail;
        self.gotoCandidate = gotoCandidate;
        self.selectCvSource = selectCvSource;
        self.imageUploadCrop = imageUploadCrop;
        self.checkPhoneCharacter = objectSvc.checkPhoneNumber;
        self.cancelCreateNewCandidate = cancelCreateNewCandidate;

        $scope.uploadCandidateImage = uploadCandidateImage;

        init();

        function init() {
            angular.copy(candidateSvc.candidateInforData, self.candidateInforData);
            self.candidateInforData.candidateBasicInfo = {};

            $('#daternage').daterangepicker({
                singleDatePicker: true,
                locale: {
                    format: 'DD-MM-YYYY'
                },
                showDropdowns: true
            },
            function (start, end, label) {
            });
            $('.date').datepicker({
                changeMonth: true, changeYear: true,
                autoclose: true, todayHighlight: true

            });
            self.currentPositions = candidateSvc.getCurrentOpenPositions().query(
            function () {
                initiliazeCandidateInformation();
                self.updateImage = candidateSvc.getUpdateImage();
                candidateSvc.disableUpdateImage();
                clearOverlay();
            });

            candidateSvc.getCvSources().query(function (data) {
                self.CvSource = data;
                cvSourceData = data;
                var defaultCvSource = {
                    Code: undefined,
                    Id: data.length + 1,
                    Text: "",
                    Name: ""
                };
                self.CvSource.splice(0, 0, defaultCvSource);
                self.cvSourceSelected = self.CvSource[0].Id;
            });

            self.initCurrentPosition = {
                service: candidateSvc.getCurrentOpenPositions(), id: 'CategoryId', optionsValue: 'JobId', text: 'JobTitle', option: {
                    placerholder: '',
                    multiple: false
                }
            };

            self.candidateInforData.candidateBasicInfo.ImagePath = constants.noAvatar;

            $scope.$watch('caNewController.candidateInforData.candidateBasicInfo', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                if (!comparisonUtilSvc.isNullOrUndefinedValue(self.candidateInforData.candidateBasicInfo) &&
                    !comparisonUtilSvc.isNullOrUndefinedValue(self.candidateInforData.candidateBasicInfo.FirstName) &&
                    !comparisonUtilSvc.isNullOrUndefinedValue(self.candidateInforData.candidateBasicInfo.LastName)) {
                    self.generalInputForm.$pristine = false;
                }
            }, true);

            $scope.$on(constants.broadCastTile.createNewCandidate, function (event, rootScopeParams) {
                if (!rootScopeParams.createNewCandidateStatus)
                    cancelCreateNewCandidate();
            });
        }

        function clearOverlay() {
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
            $('.modal-backdrop').remove();
        }

        function initiliazeCandidateInformation() {
            self.gender = self.genders[0].name;
            if (self.currentPositions && self.currentPositions.length > 0) {
                self.positionId = self.currentPositions[0].PstId;
                self.JobCodeId = self.currentPositions[0].RcmPstId;
            }
            self.cvFiles = [];
            self.generalInputForm.firstName.$setPristine(true);
            self.generalInputForm.lastName.$setPristine(true);
            self.generalInputForm.email.$setPristine(true);
            self.isShowMessageIE = true;
        }

        function isValidBirthday(birthday) {
            if (!birthday) return true;
            birthday = moment(birthday, ['MM-DD-YYYY', constants.formatDateDDMMYYYY]);
            var minAge = 20;
            var currentDate = new Date();
            currentDate.setFullYear(currentDate.getFullYear() - minAge);
            return currentDate > birthday;
        }

        function onClickSaveCandidate() {
            if (!isValidForm()) {
                return;
            }
            if (!self.hasImageCropped) {
                saveGeneralInformation();
                return;
            }
            uploadFile();
        }

        function isValidForm() {
            var result = true;
            if ((self.candidateInforData.candidateBasicInfo.StatusId != caConstants.candidateDetails.validForm.StatusId &&
                self.candidateInforData.candidateBasicInfo.PositionId == caConstants.candidateDetails.validForm.PositionId) || comparisonUtilSvc.isNullOrUndefinedValue(self.selectedCurrentPostion.id)) {
                if (self.candidateInforData.candidateBasicInfo.StatusId != caConstants.candidateDetails.validForm.ValidForm_StatusId) {
                    self.isRequiredUpdatePosition = true;
                    result = false;
                } else {
                    self.isRequiredUpdatePosition = false;
                }
            }
            return result;
        }

        function uploadFile() {
            self.candidateInforData.candidateBasicInfo.FullName = (isValidEmailAddress(self.candidateInforData.candidateBasicInfo.FirstName) && isValidEmailAddress(self.candidateInforData.candidateBasicInfo.LastName) && self.candidateInforData.candidateBasicInfo.FirstName == self.candidateInforData.candidateBasicInfo.Last) ? self.candidateInforData.candidateBasicInfo.FirstName : self.candidateInforData.candidateBasicInfo.FirstName + " " + self.candidateInforData.candidateBasicInfo.LastName;
            loadingSvc.show();
            uploadFileSvc.uploadFile(candidateImage, caConstants.candidateImage, self.candidateInforData.candidateBasicInfo.FullName).$promise.then(function (data) {
                $window.localStorage.setItem('CandidateFullName', self.candidateInforData.candidateBasicInfo.FullName, { expires: 1 });
                if (data.value.length < 0) return;
                self.candidateInforData.candidateBasicInfo.ImagePath = data.value;
                self.serverUrl = constants.serverUrl;
                saveGeneralInformation();
            });
        }

        function saveGeneralInformation() {
            loadingSvc.show();
            var dataToCheckDuplicate = {
                "PhoneNumber": !self.candidateInforData.candidateBasicInfo.Mobile ? "" : self.candidateInforData.candidateBasicInfo.Mobile,
                "FullName": self.candidateInforData.candidateBasicInfo.FullName = (isValidEmailAddress(self.candidateInforData.candidateBasicInfo.FirstName) && isValidEmailAddress(self.candidateInforData.candidateBasicInfo.LastName) && self.candidateInforData.candidateBasicInfo.FirstName == self.candidateInforData.candidateBasicInfo.Last) ? self.candidateInforData.candidateBasicInfo.FirstName : self.candidateInforData.candidateBasicInfo.FirstName + " " + self.candidateInforData.candidateBasicInfo.LastName,
                "Birthday": !self.candidateInforData.candidateBasicInfo.Birthday ? "" : datetimeSvc.convertDateForServerSide(self.candidateInforData.candidateBasicInfo.Birthday, false),
                "Email": self.candidateInforData.candidateBasicInfo.Email
            };
            candidateSvc.checkDuplicateInfo(_.random(-999999, 0), JSON.stringify(dataToCheckDuplicate)).get(
                function (response) {
                    loadingSvc.show();
                    var isDuplicate = false;
                    self.duplicateInfo = response;
                    if (self.duplicateInfo.isDuplicateEmail == "True") {
                        loadingSvc.close();
                        return;
                    }

                    $.each(response, function (index, value) {
                        isDuplicate = value == "True";
                        if (isDuplicate) {
                            $("#cawarning").modal('show');
                            createLinkToCandidate();
                            loadingSvc.close();
                            return false;
                        }
                    });

                    if (!isDuplicate)
                        updateCandidateInformation();
                    else
                        loadingSvc.close();
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.checkEmailError));
                });
        }

        function createLinkToCandidate() {
            var candidateNotFoundId = -1;
            var resultMatchedIsList = -2;
            if (self.duplicateInfo.candidateIdByName != candidateNotFoundId && self.duplicateInfo.candidateIdByName != resultMatchedIsList)
                self.linkToCandidate.byFullName = "../#candidates/" + self.duplicateInfo.candidateIdByName;
            else
                self.linkToCandidate.byFullName = "../#candidates#";

            if (self.duplicateInfo.candidateIdByPhoneNumber != candidateNotFoundId && self.duplicateInfo.candidateIdByPhoneNumber != resultMatchedIsList)
                self.linkToCandidate.byPhoneNumber = "../#candidates/" + self.duplicateInfo.candidateIdByPhoneNumber;
            else
                self.linkToCandidate.byPhoneNumber = "../#candidates#";

            if (self.duplicateInfo.candidateIdByBirthday != candidateNotFoundId && self.duplicateInfo.candidateIdByBirthday != resultMatchedIsList)
                self.linkToCandidate.byBirthday = "../#candidates/" + self.duplicateInfo.candidateIdByBirthday;
            else
                self.linkToCandidate.byBirthday = "../#candidates#";

        }

        function updateCandidateInformation() {
            var candidate = JSON.parse(JSON.stringify(self.candidateInforData.candidateBasicInfo));
            candidate.Birthday = datetimeSvc.convertDateForServerSide(self.candidateInforData.candidateBasicInfo.Birthday, false);
            candidate.Gender = self.gender;
            candidate.PositionId = self.positionId;
            if (candidate.ImagePath.toLowerCase().indexOf("image-placeholder") >= 0) candidate.ImagePath = "";
            loadingSvc.show();
            if (!hasImageUploadedOnTemp) {
                candidateSvc.addNewCandidateResource().save(candidate,
                    function (candidateId) {
                        loadingSvc.close();
                        self.isEditCandidateBasicInfo = false;
                        candidateId = arrayResourceToInt(candidateId);
                        addNewJobApplication(candidateId);
                        self.hasImageCropped = false;
                        toastr.success($filter(constants.translate)(caMessage.generalInformation.addCandidateInformationSuccessfully));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        self.isEditCandidateBasicInfo = true;
                        self.hasImageCropped = false;
                        hasImageUploadedOnTemp = false;
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.addCandidateInformationError));
                    });
            } else {
                caDetailSvc.moveCandidateImageToOriginal(candidate.ImagePath).get(function (result) {
                    var imagePath = arrayResourceToString(result);
                    imagePath = imagePath.substring(1, imagePath.lastIndexOf('\"'));
                    candidate.ImagePath = imagePath;
                    candidate.ImagePathTemp = imagePath;
                    candidateSvc.addNewCandidateResource().save(candidate,
                   function (candidateId) {
                       loadingSvc.close();
                       self.isEditCandidateBasicInfo = false;
                       candidateId = arrayResourceToInt(candidateId);
                       addNewJobApplication(candidateId);
                       self.hasImageCropped = false;
                       toastr.success($filter(constants.translate)(caMessage.generalInformation.addCandidateInformationSuccessfully));
                   },
                   function (xhr) {
                       loadingSvc.close();
                       self.isEditCandidateBasicInfo = true;
                       self.hasImageCropped = false;
                       hasImageUploadedOnTemp = false;
                       messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.addCandidateInformationError));
                   });
                }, function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.updateCandidateImageError));
                });
            }

        }

        function addNewJobApplication(candidateId) {
            setAppliedPositionEdited();
            caAppliedPositionSvc.addCandidateAppliedPosition(candidateId, appliedPositionEdited).$promise.then(function (data) {
                var jobApplicationId = 0;
                if (typeof (data.result) === "number") {
                    jobApplicationId = data.result;
                } else {
                    jobApplicationId = arrayResourceToInt(data);
                }
                if (self.candidateInforData.candidateBasicInfo.CvFiles) {
                    uploadCvFile(candidateId, jobApplicationId);
                }
                addNewScreeningCvHistory(candidateId, jobApplicationId);
                refreshCandidateList(candidateId);

            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.applicationPosition.addNewAppliedPositionFail));
            });
        }

        function setAppliedPositionEdited() {
            appliedPositionEdited.CategoryId = self.selectedCurrentPostion.id;
            appliedPositionEdited.JobCodeId = self.selectedCurrentPostion.optionsValue;
            appliedPositionEdited.RecruitmentId = self.selectedCurrentPostion.optionsValue;
            appliedPositionEdited.ScreenCvId = constants.applicationStatus.ScreeningCv.New;
            appliedPositionEdited.ScreenCv = 'New';
            var cvSources = $filter('filter')(self.CvSource, { Id: self.cvSourceSelected }, true);
            appliedPositionEdited.CvSourceId = cvSources[0].Name === "" ? null : self.cvSourceSelected;
        }

        function addNewScreeningCvHistory(candidateId, jobApplicationId) {
            var currentUserLogin = JSON.parse($window.localStorage.getItem("currentuserlogin"));
            var defaultStatus = constants.applicationStatus.ScreeningCv.New;
            var screeningCvHistory = {
                JobApplicationId: jobApplicationId,
                ModifiedDate: datetimeSvc.convertDateForServerSide(new Date(), true),
                ModifiedByUserId: currentUserLogin.UserId,
                Status: defaultStatus
            };
            candidateSvc.addNewScreeningCVHistory(candidateId, jobApplicationId).save(screeningCvHistory, function () {
                //todo code here
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.applicationPosition.addNewAppliedPositionFail));
            });
        }

        function refreshCandidateList(candidateId) {
            candidateSvc.getCandidates('1', '', false, '').get(function (candidateList) {
                var result = {
                    listId: []
                };

                if (!comparisonUtilSvc.isNullOrUndefinedValue(candidateList.Data) && candidateList.Data.length > 0) {
                    candidateList.Data.forEach(function (candidate) {
                        result.listId.push(candidate.CandidateId);
                    });
                }

                var dataFilter = {
                    listId: result.listId,
                    pageIndex: 1,
                    totalPages: 1
                };

                if (dataFilter.listId[0] != candidateId) {
                    dataFilter.listId.unshift(candidateId);
                }

                switchCandidateSvc.setFilterData(constants.filterData.addNewCandidate, dataFilter);
                switchCandidateSvc.setCurrentList(constants.filterData.addNewCandidate);
                $state.go('candidateDetail', { id: candidateId });
            });
        }

        function uploadCvFile(candidateId, jobApplicationId) {
            self.candidateBasicInfor = candidateSvc.getCandidateDataMainPage();
            param = { candidateId: candidateId, jobApplicationId: jobApplicationId, cvFiles: self.candidateInforData.candidateBasicInfo.CvFiles };
            uploadFilesSvc.updateCvFile(param);
        }

        function canUploadFile() {
            if (!(self.generalInputForm.firstName.$invalid || self.generalInputForm.lastName.$invalid))
                self.candidateFullName = self.candidateInforData.candidateBasicInfo.FirstName + self.candidateInforData.candidateBasicInfo.LastName;
            return !(self.generalInputForm.firstName.$invalid || self.generalInputForm.lastName.$invalid);
        }

        function isDisableSave() {
            return self.generalInputForm.$pristine ||
                self.generalInputForm.$invalid ||
                comparisonUtilSvc.isNullOrUndefinedValue(self.selectedCurrentPostion.id) ||
                (self.duplicateInfo.isDuplicateEmail == 'True' && self.tempDuplicateEmail == JSON.stringify(self.candidateInforData.candidateBasicInfo.Email));
        }

        function uploadCandidateImage() {
            var $input = document.getElementById('imageCandidate');
            if (!$input.files || !$input.files[0]) return;
            var fileSize = $input.files[0].size;

            if (fileSize >= caConstants.maxFileSizeUploaded) {
                toastr.warning($filter(caConstants.translate)(caMessage.uploadFileLessThan) + ' ' + $filter(caConstants.translate)(caMessage.sizeOfImage));
                cloneUploadInput();
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
                return;
            }

            candidateImage = $input.files[0];
            if (typeof (FileReader) == 'undefined') {
                self.candidateInforData.candidateBasicInfo.FullName = self.candidateInforData.candidateBasicInfo.FullName = (isValidEmailAddress(self.candidateInforData.candidateBasicInfo.FirstName) && isValidEmailAddress(self.candidateInforData.candidateBasicInfo.LastName) && self.candidateInforData.candidateBasicInfo.FirstName == self.candidateInforData.candidateBasicInfo.Last) ? self.candidateInforData.candidateBasicInfo.FirstName : self.candidateInforData.candidateBasicInfo.FirstName + " " + self.candidateInforData.candidateBasicInfo.LastName;

                uploadFileSvc.uploadCandidateImage(candidateImage, caConstants.candidateImageTemp, self.candidateInforData.candidateBasicInfo.FullName).$promise.then(function (data) {
                    $window.localStorage.setItem('CandidateFullName', self.candidateInforData.candidateBasicInfo.FullName, { expires: 1 });
                    if (data.value.length > 0) {
                        self.candidateInforData.candidateBasicInfo.ImagePath = data.value;
                        hasImageUploadedOnTemp = true;
                        if (!$scope.$$phase && !$scope.$root.$$phase) {
                            $scope.$apply();
                        }
                    }
                });

            } else {
                var reader = new FileReader();
                reader.onload = function (element) {
                    if (/^image\/\w+$/.test($input.files[0].type)) {
                        $rootScope.$broadcast(caConstants.events.updateCropImageSource, element.target.result);
                        angular.element(document.querySelector('#upload-image-modal')).modal('show');
                        if (!$scope.$$phase && !$scope.$root.$$phase) {
                            $scope.$apply();
                        }
                    } else {
                        cloneUploadInput();
                        toastr.warning($filter(constants.translate)(caMessage.generalInformation.importImage));
                    }
                };
                reader.readAsDataURL($input.files[0]);
            }
        }

        function cloneUploadInput() {
            var control = $('input#imageCandidate');
            control.replaceWith(control = control.clone(true));
        }

        function accept() {
            updateCandidateInformation();
        }

        function checkDuplicateEmail(error) {
            if (error.email || error.required)
                return;
            var dataToCheckDuplicate = {
                "PhoneNumber": "",
                "FullName": "",
                "Birthday": "",
                "Email": self.candidateInforData.candidateBasicInfo.Email
            };
            candidateSvc.checkDuplicateInfo(_.random(-999999, 0), JSON.stringify(dataToCheckDuplicate)).get(
                function (response) {
                    self.duplicateInfo = response;
                    if (!$scope.$$phase) $scope.$apply();
                    if (self.duplicateInfo.isDuplicateEmail != "True")
                        return;
                    self.tempDuplicateEmail = JSON.stringify(self.candidateInforData.candidateBasicInfo.Email);
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.checkEmailError));
                });
        }

        function gotoCandidate(pageParam, id) {
            var fullName = self.candidateInforData.candidateBasicInfo.FirstName + " " + self.candidateInforData.candidateBasicInfo.LastName;
            var resultMatchedIsList = -2;
            if (id != resultMatchedIsList)
                return;
            switch (pageParam) {
                case "byPhoneNumber":
                    var queryByPhoneNumber = "phone:({0})";
                    queryByPhoneNumber = String.format(queryByPhoneNumber, self.candidateInforData.candidateBasicInfo.Mobile);
                    $.jStorage.set(constants.localStorageKey.candidateSearch, { value: queryByPhoneNumber });
                    break;
                case "byFullName":
                    var queryByFullName = "fullName:({0}) isDeleted:(Yes) OR (No) ";
                    queryByFullName = String.format(queryByFullName, fullName);
                    $.jStorage.set(constants.localStorageKey.candidateSearch, { value: queryByFullName });
                    break;
                case "byBirthday":
                    var queryByBirthday = "fullName:({0}) dateOfBirth:({1}) isDeleted:(Yes) OR (No) ";
                    queryByBirthday = String.format(queryByBirthday, fullName, self.candidateInforData.candidateBasicInfo.Birthday);
                    $.jStorage.set(constants.localStorageKey.candidateSearch, { value: queryByBirthday });
                    break;
                default:
                    break;
            }
        }

        function selectCvSource() {
            setCvSourceSelected(self.cvSourceSelected);
        }

        function setCvSourceSelected(cvSourceId) {
            var cvSources = $filter('filter')(self.CvSource, { Id: cvSourceId }, true);
            if (cvSourceId && cvSources.length > 0) {
                self.cvSourceSelected = cvSourceId;
            } else {
                self.cvSourceSelected = self.CvSource[0].Id;
            }
        }

        function imageUploadCrop() {
            self.formImageData = new FormData();
            var imageUploaded = $('.img-container > img');
            var imageCropped = imageUploaded.cropper("getCroppedCanvas", { width: 240, height: 280 });
            self.candidateInforData.candidateBasicInfo.ImagePath = imageCropped.toDataURL("image/png");
            imageCropped.toBlob(function (blob) {
                self.formImageData.append('croppedImage', blob, 'cropped.png');
            });
            self.hasImageCropped = true;
        }

        function cancelCreateNewCandidate() {
            removeHoverElement('.sprite-add-user');
            $scope.$parent.$parent.caCtrl.isCreateNewCandidate = false;
            self.candidateInforData = {};
            angular.copy(candidateSvc.candidateInforData, self.candidateInforData);
            self.candidateInforData.candidateBasicInfo = {};
            self.candidateInforData.candidateBasicInfo.ImagePath = constants.noAvatar;
            var defaultCvSource = {
                Code: undefined,
                Id: cvSourceData.length + 1,
                Text: "",
                Name: ""
            };
            if (self.CvSource && self.CvSource.length > 0)
                self.CvSource.splice(0, 0, defaultCvSource);
            if (self.CvSource && self.CvSource.length > 0)
                self.cvSourceSelected = self.CvSource[0].Id;
            initiliazeCandidateInformation();
            self.selectedCurrentPostion = {};
        }
    }
})();