﻿(function () {
    'use strict';
    angular.module('app').factory('caSearchBoxInitialSvc', caSearchBoxInitialSvc);
    caSearchBoxInitialSvc.$inject = ['positionSvc', 'candidateSvc', '$filter'];

    function caSearchBoxInitialSvc(positionSvc, candidateSvc, $filter) {
        function initialSearchBox() {
            //TODO: will decide that we will keep search position or not
            //var listPosition = [];
            //var positions = positionSvc.getWholeCompanyPositions().query(function() {
            //        for (var i = 0; i < positions.length; i++) {
            //            var item = { id: positions[i].PstId, text: positions[i].PstName, isHide: positions[i].IsHide };
            //            listPosition.push(item);
            //        }
            //    },
            //    function() {
            //    });

            var tags = [];
            candidateSvc.tags().query(function(data) {
                for (var i = 0; i < data.length; i++) {
                    var item = { id: data[i].TagId, text: data[i].TagName };
                    tags.push(item);
                }
            }, function() {

            });

            var ratings = [{ value: 0, name: 0 }, { value: 1, name: 1 }, { value: 2, name: 2 }, { value: 3, name: 3 }, { value: 4, name: 4 }, { value: 5, name: 5 }];
            var interview =
            {
                candidateStatus: [
                    //Screen CV
                    { key: 'screenCvNew', value: 'New', displayValue: $filter('translate')('New'), isActive: false },
                    { key: 'screenCvInterested', value: 'Interested', displayValue: $filter('translate')('Interested'), isActive: false },
                    { key: 'screenCvReject', value: 'Rejected', displayValue: $filter('translate')('Rejected'), isActive: false },
                    { key: 'screenCvPass', value: 'Passed Screening', displayValue: $filter('translate')('Passed_Screening'), isActive: false },
                    { key: 'screenCvOnHold', value: 'On Hold', displayValue: $filter('translate')('On_Hold'), isActive: false },
                    { key: 'screenCvBlackList', value: 'Black List', displayValue: $filter('translate')('Black_List'), isActive: false },
                    //Interviewing
                    { key: 'Interviewing', value: 'Interviewing', displayValue: $filter('translate')('Interviewing'), isActive: false },
                    //Shortlisted
                    { key: 'Shortlisted', value: 'Shortlisted', displayValue: $filter('translate')('Shortlisted'), isActive: false },
                    //Offer
                    { key: 'Offered', value: 'Offered', displayValue: $filter('translate')('Offered'), isActive: false },
                    { key: 'OfferRejected', value: 'Offer Rejected', displayValue: $filter('translate')('Offer_Rejected'), isActive: false },
                    { key: 'Hired', value: 'Hired', displayValue: $filter('translate')('Hired'), isActive: false }
                ],
                screenCV: [
                    { key: 'screenCvNew', value: 'New', displayValue: $filter('translate')('New'), isActive: false },
                    { key: 'screenCvInterested', value: 'Interested', displayValue: $filter('translate')('Interested'), isActive: false },
                    { key: 'screenCvReject', value: 'Rejected', displayValue: $filter('translate')('Rejected'), isActive: false },
                    { key: 'screenCvPass', value: 'Passed', displayValue: $filter('translate')('Passed'), isActive: false },
                    { key: 'screenCvOnHold', value: 'On Hold', displayValue: $filter('translate')('On_Hold'), isActive: false },
                    { key: 'screenCvBlackList', value: 'Black List', displayValue: $filter('translate')('Black_List'), isActive: false }
                ],
                firstInterview: [
                    { key: 'firstInterviewPass', value: 'Passed', displayValue: $filter('translate')('Passed'), isActive: false },
                    { key: 'firstInterviewReject', value: 'Rejected', displayValue: $filter('translate')('Rejected'), isActive: false },
                    { key: 'firstInterviewStandBy', value: 'Not Updated', displayValue: $filter('translate')('Not Updated'), isActive: false }
                ],
                secondInterview: [
                    { key: 'secondInterviewPass', value: 'Passed', displayValue: $filter('translate')('Passed'), isActive: false },
                    { key: 'secondInterviewReject', value: 'Rejected', displayValue: $filter('translate')('Rejected'), isActive: false },
                    { key: 'secondInterviewStandBy', value: 'Not Updated', displayValue: $filter('translate')('Not Updated'), isActive: false }
                ],
                thirdInterview: [
                    { key: 'thirdInterviewPass', value: 'Passed', displayValue: $filter('translate')('Passed'), isActive: false },
                    { key: 'thirdInterviewReject', value: 'Rejected', displayValue: $filter('translate')('Rejected'), isActive: false },
                    { key: 'thirdInterviewStandBy', value: 'Not Updated', displayValue: $filter('translate')('Not Updated'), isActive: false }
                ]
            };


            var deletedValues = [
                { key: 'isDeletedYes', value: 'Yes', displayValue: $filter('translate')('Yes'), isActive: false },
                { key: 'isDeletedNo', value: 'No', displayValue: $filter('translate')('No'), isActive: false }
            ];

            var fieldSearch =
            [
                { field: 'general', value: 'general', displayName: $filter('translate')('Search_Label.General'), type: 'none', optionStyle: 'parent', parent: 'none' },
                /*******************************************************************************/
                { field: 'fullName', value: 'FullName', displayName: $filter('translate')('Search_Label.Full_Name'), type: 'textfield', optionStyle: '', parent: 'general' },
                { field: 'email', value: 'Email', displayName: $filter('translate')('Search_Label.Email'), type: 'textfield', optionStyle: '' },
                { field: 'phone', value: 'Phone', displayName: $filter('translate')('Search_Label.Phone'), type: 'textfield', optionStyle: '', parent: 'general' },
                { field: 'dateOfBirth', value: 'DateOfBirth', displayName: $filter('translate')('Search_Label.Date_Of_Birth'), type: 'daterangepickerLimit', optionStyle: '', parent: 'general' },
                { field: 'skill', value: 'Skill', displayName: $filter('translate')('Search_Label.Skill'), type: 'textfield', optionStyle: '', parent: 'general' },
                { field: 'languageSkill', value: 'LanguageSkill', displayName: $filter('translate')('Search_Label.Language_Skill'), type: 'textfield', optionStyle: '', parent: 'general' },

                /*******************************************************************************/
                { field: 'applications', value: 'applications', displayName: $filter('translate')('Search_Label.Applications'), type: 'none', optionStyle: 'parent', parent: 'none' },
                /*******************************************************************************/
                { field: 'cvStatus', value: 'CvStatus', displayName: $filter('translate')('Search_Label.CV_Status'), type: 'dropdowncheckbox', optionStyle: '', parent: 'applications', initData: interview.screenCV },
                { field: 'appliedDate', value: 'ApplyDate', displayName: $filter('translate')('Search_Label.Applied_Date'), type: 'daterangepicker', optionStyle: '', parent: 'applications' },
                //{ field: 'appliedPosition', value: 'PositionId', displayName: $filter('translate')('Search_Label.Applied_Positions'), type: 'select2', optionStyle: 'applied position', parent: 'applications', initData: listPosition },
                { field: 'candidateStatus', value: 'CandidateStatus', displayName: $filter('translate')('Search_Label.Candidate_Status'), type: 'dropdowncheckbox', optionStyle: '', parent: 'applications', initData: interview.candidateStatus },
                { field: 'tags', value: 'TagId', displayName: $filter('translate')('Search_Label.Tags'), type: 'select2', optionStyle: 'tags', parent: 'applications', initData: tags },
                { field: 'jobCode', value: 'JobCode', displayName: $filter('translate')('Search_Label.Job_Code'), type: 'textfield', optionStyle: '', parent: 'applications' },
                { field: 'cvContent', value: 'SearchCvContent', displayName: $filter('translate')('Search_Label.CV_Content'), type: 'textfield', optionStyle: '', parent: 'applications' },
                { field: 'completeScore', value: 'CompleteScore', displayName: $filter('translate')('Search_Label.CV_Completeness_Percent'), type: 'numberfield', optionStyle: '', parent: 'applications' },
                /*******************************************************************************/
                { field: 'suitabilityRatingField', value: 'suitabilityRatingField', displayName: $filter('translate')('Search_Label.Suitability_Rating'), type: 'none', optionStyle: 'parent', parent: 'none' },
                /*******************************************************************************/
                { field: 'suitabilityRating', value: 'SuitabilityRating', displayName: $filter('translate')('Search_Label.Star_Rating'), type: 'selectnumber', optionStyle: '', parent: 'suitabilityRating', initData: ratings },
                { field: 'suitabilityRatingUpdated', value: 'SuitabilityRatingUpdated', displayName: $filter('translate')('Search_Label.Rating_Last_Updated'), type: 'daterangepicker', optionStyle: '', parent: 'suitabilityRating' },
                /*******************************************************************************/
                { field: 'interview', value: 'Interview', displayName: $filter('translate')('Search_Label.Interview'), type: 'none', optionStyle: 'parent', parent: 'none' },
                /*******************************************************************************/
                { field: 'firstInterview', value: 'FirstInterview', displayName: $filter('translate')('Search_Label.1st_Interview'), type: 'dropdowncheckbox', optionStyle: '', parent: 'Interview', initData: interview.firstInterview },
                { field: 'secondInterview', value: 'SecondInterview', displayName: $filter('translate')('Search_Label.2nd_Interview'), type: 'dropdowncheckbox', optionStyle: '', parent: 'Interview', initData: interview.secondInterview },
                { field: 'thirdInterview', value: 'ThirdInterview', displayName: $filter('translate')('Search_Label.3rd_Interview'), type: 'dropdowncheckbox', optionStyle: '', parent: 'Interview', initData: interview.thirdInterview },

                /*******************************************************************************/
                { field: 'employment', value: 'Employment', displayName: $filter('translate')('Search_Label.Employment'), type: 'none', optionStyle: 'parent', parent: 'none' },
                /*******************************************************************************/
                { field: 'startDateSuggestion', value: 'StartDateSuggestion', displayName: $filter('translate')('Search_Label.Start_Date_Suggestion'), type: 'daterangepickerLimit', optionStyle: '', parent: 'employment' },
                { field: 'offerSendDate', value: 'OfferSendDate', displayName: $filter('translate')('Search_Label.Offer_Sent_Date'), type: 'daterangepicker', optionStyle: '', parent: 'employment' },
                { field: 'acceptLetterDate', value: 'AcceptLetterDate', displayName: $filter('translate')('Search_Label.Accept_Letter_Date'), type: 'daterangepicker', optionStyle: '', parent: 'employment' },
                /*******************************************************************************/
                { field: 'Advanced', value: 'Advanced', displayName: $filter('translate')('Search_Label.Advanced'), type: 'none', optionStyle: 'parent', parent: 'none' },
                /*******************************************************************************/
                { field: 'isDeleted', value: 'IsDeleted', displayName: $filter('translate')('Search_Label.Deleted_Candidates'), type: 'dropdowncheckbox', optionStyle: '', parent: 'Advanced', initData: deletedValues },
                { field: 'passedInterviews', value: 'PassedInterviews', displayName: $filter('translate')('Search_Label.Passed_Interviews_Key'), type: 'numberfield', optionStyle: '', parent: 'Advanced' },
                { field: 'failedInterviews', value: 'FailedInterviews', displayName: $filter('translate')('Search_Label.Failed_Interviews_Key'), type: 'numberfield', optionStyle: '', parent: 'Advanced' }
            ];
            var fieldName = {
                general: 'general',
                fullName: 'fullName',
                applyPosition: 'applyPosition',
                email: 'email',
                otherEmail: 'otherEmail',
                dateOfBirth: 'dateOfBirth',
                profession: 'profession',
                domain: 'domain',
                experience: 'experience',
                jobCode: 'jobCode',
                skill: 'skill',
                phone: 'phone',
                otherPhone: 'otherPhone',
                isDeleted: 'isDeleted',
                isMyResponsible: 'isMyResponsible',
                interview: 'interview',
                screenCv: 'screenCv',
                firstInterview: 'firstInterview',
                secondInterview: 'secondInterview',
                thirdInterview: 'thirdInterview',
                cv: 'cv',
                cvContent: 'cvContent',
                applyDate: 'applyDate',
                cvStatus: 'cvStatus',
                employment: 'employment',
                startDateSuggestion: 'startDateSuggestion',
                offerSendDate: 'offerSendDate',
                acceptLetterDate: 'acceptLetterDate'
            };
            var listType = "candidate-query-list-condition";
            var vm = {
                fieldSearch: fieldSearch,
                fieldName: fieldName,
                interview: interview,
                listType: listType
            };
            return vm;
        }

        return initialSearchBox;
    }
})();
