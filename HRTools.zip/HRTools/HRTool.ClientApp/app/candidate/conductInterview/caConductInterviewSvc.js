﻿(function () {
    'use strict';
    angular.module('app').factory('caConductInterviewSvc', caConductInterviewSvc);
    caConductInterviewSvc.$inject = ['$resource', '$filter', 'messageHandleSvc', 'message', 'caMessage', 'constants'];
    function caConductInterviewSvc($resource, $filter, messageHandleSvc, message, caMessage, constants) {
        var conductInterviewData = {
            candidateInterviewInfo: null,
            interviewDto: null,
            interviewCommentDtos: null
        };

        var service = {
            conductInterviewData: conductInterviewData,
            getConductInterview: getConductInterview,
            addConductInterview: addConductInterview,
            updateConductInterview: updateConductInterview,
            updateInterviewComment: updateInterviewComment,
            conductInterview: conductInterview
        };

        var url = constants.apiUrl + 'interviews/:interviewId/conduct-interview';
        var urlComment = constants.apiUrl + 'interviews/:interviewId/conduct-interview/comment';

        var resourceSvc = $resource(url, {}, {
            'getConductInterview': { method: 'GET', interviewId: '@interviewId' },
            'addConductInterview': { method: 'POST', interviewId: '@interviewId' },
            'updateConductInterview': { method: 'PUT', interviewId: '@interviewId' },
            'updateRating': { method: 'PUT', interviewId: '@interviewId', headers: { action: 'rating' } }
        });

        var commentSvc = $resource(urlComment, {}, {
            'updateInterviewComment': { method: 'PUT', interviewId: '@interviewId' }
        });

        return service;

        function getConductInterview(interviewId, callback) {
            resourceSvc.getConductInterview({ interviewId: interviewId }).$promise.then(
                function (responseData) {
                    conductInterviewData.candidateInterviewInfo = responseData.CandidateInterviewInfo;
                    conductInterviewData.interviewDto = responseData.InterviewDto;
                    conductInterviewData.interviewCommentDtos = responseData.InterviewCommentDtos;
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, caMessage.interview.loadInterViewFail);
                }).then(callback);
        }

        function addConductInterview(interviewId, conductInterviewDto, callback) {
            resourceSvc.addConductInterview({ interviewId: interviewId }, conductInterviewDto).$promise.then(
                function (response) {
                    messageHandleSvc.handleResponse(response, caMessage.interview.interviewFinish);
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, caMessage.interview.addConductInterviewFail);
                }).then(callback);
        }

        function conductInterview(interviewId) {
            return $resource(url, { interviewId: interviewId }, {});
        }

        function updateConductInterview(interviewId, action, updatedConductInterviewDto, successAction, failAction) {
            var defaultActionValue = 'rating';
            if (action == defaultActionValue) {
                resourceSvc.updateRating({ interviewId: interviewId }, updatedConductInterviewDto).$promise.then(
                function (response) {
                    messageHandleSvc.handleResponse(response, caMessage.interview.updateInterViewRatingSuccessful);
                    successAction();
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, caMessage.interview.updateInterViewRatingFail);
                });
                return;
            }
            resourceSvc.updateConductInterview({ interviewId: interviewId }, updatedConductInterviewDto).$promise.then(
                function (response) {
                    successAction(response);
                }, function (xhr) {
                    failAction(xhr);
                });
        }

        function updateInterviewComment(interviewId, interviewCommentDto, callback) {
            commentSvc.updateInterviewComment({ interviewId: interviewId }, interviewCommentDto).$promise.then(
                function (response) {
                    messageHandleSvc.handleResponse(response, caMessage.interview.updateInterViewCommentSuccessful);
                }, function (xhr) {
                    messageHandleSvc.handleResponse(xhr, caMessage.interview.updateInterViewCommentFail);
                }).then(callback);
        }
    }

})();
