﻿(function () {
    'use strict';
    angular.module('app').controller('caConductInterviewCtrl', CaConductInterviewCtrl);
    CaConductInterviewCtrl.$inject = ['$rootScope', '$scope', '$filter', '$state', '$stateParams', '$compile', '$timeout', '$window',
        'constants', 'caConstants', 'message', 'caMessage', 'messageHandleSvc', 'datetimeSvc', 'caConductInterviewSvc', 'emailSvc',
        'permissionSvc', 'authenticationSvc', 'moneySvc', 'historyPageSvc', 'objectSvc', 'uploadFileSvc', 'comparisonUtilSvc'];
    function CaConductInterviewCtrl($rootScope, $scope, $filter, $state, $stateParams, $compile, $timeout, $window,
            constants, caConstants, message, caMessage, messageHandleSvc, datetimeSvc, caConductInterviewSvc, emailSvc,
            permissionSvc, authenticationSvc, moneySvc, historyPageSvc, objectSvc, uploadFileSvc, comparisonUtilSvc) {
        //Global virables
        var self = this;
        self.permissionOfCurrentUser = {
            canAddInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_AddInterview),
            canEditInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_EditInterview),
            canViewInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview)
        };
        if (!self.permissionOfCurrentUser.canViewInterview) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }

        var isFirefox = typeof InstallTrigger !== 'undefined';   // Firefox 1.0+
        var interviewId = $state.params.interviewId;
        var audio_context;
        var recorder;
        var BAR_WIDTH = 4;
        var recordIntervalId;
        var playBackIntervalId;
        var analyserContext;
        var canvasWidth, canvasHeight;
        var coordinateX = 0;
        var waveCanvas = null;
        var indexPlayback = 0;
        var rects = [];
        var intervalCoordinate = 0;
        var conductInterviewDto = {
            interviewDto: {},
            interviewCommentDtos: []
        };
        var isRecordingAudioLoaded = false;
        var isBackToInterviewTab = false;
        var iconNames = ['default', 'smile', 'like', 'dontUnderstand', 'edit', 'success', 'fun'];
        var urlCommentIcon = '/Content/app/images/comments/';
        var extCommentIcon = ".png";
        var defaultTime = "00:00";
        var commentBtnPrefix = 'commentBtn';
        var filled = 'filled';
        var unfilled = 'unfilled';
        var ordinate = 0;
        var currentTime = 0;
        var movePositionX = 25;
        var audioElement;
        var recordingPath;
        var objHub;
        var durationTime = 0;
        var user;
        var commentIconDefault = urlCommentIcon + iconNames[0] + extCommentIcon;
        var updatedConductInterviewDto = null;
        var isMute = false;
        var requestFinish = 4;
        var okStatus = 200;
        var uploadTimeOut = 408;
        var uploadFileFail = false;
        var totalFileUpload = 0;
        var increaseTimeRecord;

        var _commentPrefix = "comment";
        var _startInterviewButtonText = 'Interviews.Start_Interview';
        var _isRecording = false;
        var _salaryObject = {};
        var _mp3Duration = 0;
        var _oldSummary = "";
        var _isSaveSalary = false;
        var _isStartRecording = false;
        var _audioStream = null;
        var _uploadTime;
        var _isPaused = false;
        var _uploadPercent = 9900;
        var _progressBarIndex = 0;
        var _drawProgressBar;
        var _fileIndex = 0;
        var _interviewTime = moment.utc().valueOf();
        var _isFirstShow = false;
        var _isShowToogleHeader = true;
        var _isShowButtonAddSummary = true;
        var _isNotRecording = true;
        var _isStartedInterview = false;
        var _backGround = [];

        self.pauseInterviewButtonText = 'Interviews.Pause_Interview';
        self.matchTitle = 'Interviews.Match_Title';
        self.ratingTitle = 'Interviews.Rating_Title';
        self.playAudioTitle = 'Interviews.Play_Audio_Title';
        self.pauseAudioTitle = 'Interviews.Pause_Audio_Title';
        self.startInterviewButton = "";
        self.currentComment = "";
        self.summary = "";
        self.percent = 0;
        self.isStartedRecord = false;
        self.isPlaying = false;


        self.stars = [{ id: 0, fill: unfilled }, { id: 1, fill: unfilled }, { id: 2, fill: unfilled }, { id: 3, fill: unfilled }, { id: 4, fill: unfilled }];
        self.isSkipButtonDisplay = true;
        self.isPassInterview = true;
        self.isFailInterview = true;
        self.summaryForm = "summaryForm";
        self.isShowSalaryButton = true;
        self.isSupportAudio = true;
        self.commentId = 0;
        self.icon = {
            playBack: '/Content/app/images/play_back.png',
            pauseInterview: '/Content/app/images/recom-icon-pauseinterview.png'
        };
        self.isInvalidSuggestedWorkingDate = false;
        self.interviewStatus = { startInterview: "start interview", choiceInterview: "choice interview", finishInterview: "finish" };
        self.commentList = [];
        self.isViewSummary = true;

        self.conductInterviewData = caConductInterviewSvc.conductInterviewData;
        self.recordTime = defaultTime;
        self.interviewDuration = defaultTime;
        self.startTime = defaultTime;
        self.processRecording = processRecording;
        self.playbackRecording = playbackRecording;
        self.pausePlayback = pausePlayback;
        self.finishConfirmed = finishConfirmed;
        self.dismiss = dismiss;
        self.buildComment = buildComment;
        self.cancelAddingSummary = cancelAddingSummary;
        self.saveAddingSummary = saveAddingSummary;
        self.showComment = showComment;
        self.toggleCommentsButton = toggleCommentsButton;
        self.cancelComment = cancelComment;
        self.saveComment = saveComment;
        self.rating = rating;
        self.saveRating = saveRating;
        self.showRating = showRating;
        self.cancelRating = cancelRating;
        self.skipInterview = skipInterview;
        self.addSalary = addSalary;
        self.sendEmail = sendEmail;
        self.onKeyUpComment = onKeyUpComment;
        self.currentInterviewStatus = self.interviewStatus.startInterview;
        self.goToCandidateInterviewsTab = goToCandidateInterviewsTab;
        self.getImagePath = getImagePath;
        self.checkSalarySaveCondition = checkSalarySaveCondition;
        self.finishInterview = finishInterview;
        self.interviewWithRecording = interviewWithRecording;
        self.onStartInterview = onStartInterview;
        self.onInterviewWithoutRecording = onInterviewWithoutRecording;
        self.updateInterviewResult = updateInterviewResult;
        self.cancelAddSalary = cancelAddSalary;
        self.saveAddingSalary = saveAddingSalary;
        self.mouseLeave = mouseLeave;
        self.mouseHover = mouseHover;
        self.clearRating = clearRating;
        self.toogleHeader = toogleHeader;
        self.getCssHeaderClass = getCssHeaderClass;
        self.checkSalaryCharater = objectSvc.checkNumber;
        self.showFormAddSummary = showFormAddSummary;
        self.checkVisibleAddSummaryForm = checkVisibleAddSummaryForm;
        self.startEditSummary = startEditSummary;
        self.convertText = objectSvc.convertHtmlTextView;
        self.getButtonImageLink = getButtonImageLink;


        init();

        function init() {
            caConductInterviewSvc.getConductInterview($state.params.interviewId);
            $('#comment-view-row').hide();
            $('.interview-information').mouseleave(function () {
                if (!_isStartRecording)
                    $('#temp-arrow').remove();
                $('#comment-view-row').hide();
            });

            clearOverlay();
            setDialogSkipConfirmInfo();

            caConductInterviewSvc.getConductInterview(interviewId, function () {
                if (comparisonUtilSvc.isNullOrUndefinedValue(caConductInterviewSvc.conductInterviewData.interviewDto)) return;
                if (caConductInterviewSvc.conductInterviewData.interviewDto.IsCanceled) {
                    goToCandidateInterviewsTab();
                    return;
                }
                self.match = angular.isNumber(caConductInterviewSvc.conductInterviewData.interviewDto.Match) ? angular.copy(caConductInterviewSvc.conductInterviewData.interviewDto.Match) : 0;
                self.ratingValue = angular.isNumber(caConductInterviewSvc.conductInterviewData.interviewDto.Rating) ? angular.copy(caConductInterviewSvc.conductInterviewData.interviewDto.Rating) : 0;
                self.currentResult = angular.copy(caConductInterviewSvc.conductInterviewData.interviewDto.Result);
                if (caConductInterviewSvc.conductInterviewData.interviewDto.RecordingPath &&
                    caConductInterviewSvc.conductInterviewData.interviewDto.RecordingPath !== '') {
                    //create audio
                    audioElement = createAudioElement(constants.serverUrl + caConductInterviewSvc.conductInterviewData.interviewDto.RecordingPath);
                    isMute = false;
                    //draw canvas
                    audioElement.addEventListener('canplaythrough', function () {
                        if (!isRecordingAudioLoaded) {
                            // compare mp3 duration is longer than Interview duration or not
                            _mp3Duration = (this.duration > caConductInterviewSvc.conductInterviewData.interviewDto.DurationTime) ?
                                angular.copy(caConductInterviewSvc.conductInterviewData.interviewDto.DurationTime) : angular.copy(this.duration);
                            drawRecordingPlaybackCanvas(_mp3Duration);
                        }
                    }, false);

                    audioElement.addEventListener('ended', function () {
                        resetAudioCanvas();
                    }, false);

                    visualizeComments(caConductInterviewSvc.conductInterviewData.interviewCommentDtos);

                    //display comments
                    self.commentList = caConductInterviewSvc.conductInterviewData.interviewCommentDtos;
                    for (var index = 0; index < caConductInterviewSvc.conductInterviewData.interviewCommentDtos.length; index++) {
                        createCommentElement(caConductInterviewSvc.conductInterviewData.interviewCommentDtos[index]);
                    }
                } else if (!caConductInterviewSvc.conductInterviewData.interviewDto.IsFinished) {

                    $.connection.hub.url = constants.serverUrl + 'signalr';
                    objHub = $.connection.conductInterviewHub;
                    if (objHub) {
                        initCommentIcons();
                        loadClientMethods();
                        objHub.client.onConnected = function (conductInterviewUser) {
                            if (conductInterviewUser.IsHost) {
                                self.isHost = true;
                                self.commentIcon = urlCommentIcon + iconNames[0] + extCommentIcon;
                                if (!$scope.$$phase && !$scope.$root.$$phase) {
                                    $scope.$apply();
                                }
                            } else {
                                objHub.server.sendCurrentConductInterviewToGroup(conductInterviewDto.interviewCommentDtos, intervalCoordinate);
                            }
                        };
                        $.connection.hub.start().done(function () {
                            objHub.server.connect(interviewId, user.UserId);
                        });
                    }
                    $("#position-note").show();
                } else if (caConductInterviewSvc.conductInterviewData.interviewDto.DurationTime > 0) {
                    isMute = true;
                    drawRecordingPlaybackCanvas(caConductInterviewSvc.conductInterviewData.interviewDto.DurationTime);
                    visualizeComments(caConductInterviewSvc.conductInterviewData.interviewCommentDtos);
                    self.commentList = caConductInterviewSvc.conductInterviewData.interviewCommentDtos;
                    for (var k = 0; k < caConductInterviewSvc.conductInterviewData.interviewCommentDtos.length; k++) {
                        createCommentElement(caConductInterviewSvc.conductInterviewData.interviewCommentDtos[k]);
                    }
                }

                self.isPassInterview = caConductInterviewSvc.conductInterviewData.interviewDto.Result === 1;
                self.isFailInterview = caConductInterviewSvc.conductInterviewData.interviewDto.Result === 0;

                self.positionNote = caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.PositionNote;
                self.positionNote = self.positionNote == 'null' ? "" : self.positionNote;
                copyConductInterviewData(caConductInterviewSvc.conductInterviewData);

                var currentUser = JSON.parse($window.localStorage.getItem("currentuserlogin"));
                if (!comparisonUtilSvc.isNullOrUndefinedValue(currentUser) || !comparisonUtilSvc.isNullOrUndefinedValue(currentUser)) {
                    user = window.angular.fromJson(currentUser);
                }

                $('#startDateSuggest').datepicker({ autoclose: true, todayHighlight: true });
            }, function () {
            });

            $rootScope.$on('$locationChangeStart', function (event) {
                if (window.location.href.indexOf('/conduct-interview') < 0 || !_isStartedInterview) {
                    closeHubCommentConnection();
                    return;
                }
                pauseRecording();
                $("#" + self.dialogConfirm.dialogId).modal('show');
                _isNotRecording = true;
                event.preventDefault();
            });

            $state.reload = function () {
                $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
            };
            window.onunload = stopHub();
            window.onbeforeunload = stopHub();
            $('#comment-row').hide();
        }

        function resetAudioCanvas() {
            self.isPlaying = false;
            if (!$scope.$$phase && !$scope.$root.$$phase) {
                $scope.$apply();
            }
            analyserContext.clearRect(0, 0, waveCanvas.width, waveCanvas.height);
            coordinateX = 0;
            isRecordingAudioLoaded = true;
            rects = [];
            //drawRecordingPlaybackCanvas(this.duration);
            drawRecordingPlaybackCanvas(_mp3Duration);
            //var mp3Duration
            indexPlayback = 0;
        }

        function copyConductInterviewData(conductInterviewData, isNotChangeSummary) {
            self.startDateSuggest = datetimeSvc.convertDateHour(conductInterviewData.candidateInterviewInfo.StartDateSuggest, false);
            $timeout(function () {
                $('#startDateSuggest').datepicker('setDate', self.startDateSuggest);
            }, 0);
            if (!isNotChangeSummary) {
                self.summary = angular.copy(conductInterviewData.interviewDto.Summary);
                _oldSummary = angular.copy(conductInterviewData.interviewDto.Summary);
            }
            self.currentSalary = angular.copy(conductInterviewData.candidateInterviewInfo.CurrentSalary);
            self.expectedSalary = angular.copy(conductInterviewData.candidateInterviewInfo.ExpectedSalary);
            self.suggestedSalary = angular.copy(conductInterviewData.candidateInterviewInfo.SuggestedSalary);
            _salaryObject = {
                currentSalary: angular.copy(self.currentSalary) ? parseInt(angular.copy(self.currentSalary)) : null,
                expectedSalary: angular.copy(self.expectedSalary) ? parseInt(angular.copy(self.expectedSalary)) : null,
                suggestedSalary: angular.copy(self.suggestedSalary) ? parseInt(angular.copy(self.suggestedSalary)) : null,
                workingDate: angular.copy(self.startDateSuggest) ? angular.copy(self.startDateSuggest) : ""
            };
        }

        function addSalary() {
            if (_isSaveSalary) return;
            var isSummaryChange = checkSummaryChange();
            copyConductInterviewData(caConductInterviewSvc.conductInterviewData, isSummaryChange);
            self.isShowSalaryButton = false;
            self.isInvalidSuggestedWorkingDate = false;
            $("#salary-form").modal('show');
        }

        function checkSalarySaveCondition() {
            var current = {
                currentSalary: angular.copy(self.currentSalary) ? parseInt(angular.copy(self.currentSalary)) : null,
                expectedSalary: angular.copy(self.expectedSalary) ? parseInt(angular.copy(self.expectedSalary)) : null,
                suggestedSalary: angular.copy(self.suggestedSalary) ? parseInt(angular.copy(self.suggestedSalary)) : null,
                workingDate: angular.copy(self.startDateSuggest) ? angular.copy(self.startDateSuggest) : ""
            };
            return JSON.stringify(_salaryObject) == JSON.stringify(current);
        }

        function createAudioElement(url) {
            var audio = document.createElement('audio');
            audio.style.visibility = 'hidden';

            audio.controls = true;
            audio.src = url;


            if (window.addEventListener) {
                (function () {
                    function playfunc() {
                        playBackIntervalId = setInterval(playAudio, 1000);
                    }
                    function pausefunc() {
                        clearInterval(playBackIntervalId);
                    }
                    function resumefunc() {
                        playfunc();
                    }
                    audio.addEventListener('play', playfunc, false);
                    audio.addEventListener('pause', pausefunc, false);
                    audio.addEventListener('resume', resumefunc, false);
                })();
            }

            return audio;
        }

        function loadClientMethods() {
            self.isHost = false;
            var isLoadedClient = false;
            var clientIntervalId;

            objHub.client.getComment = function (newInterviewCommentDto, userId) {
                // Add comment if it's sent from others
                if (user && userId != user.UserId) {
                    if (newInterviewCommentDto.Comment && newInterviewCommentDto.Comment !== "" && newInterviewCommentDto.Icon != commentIconDefault) {
                        conductInterviewDto.interviewCommentDtos[conductInterviewDto.interviewCommentDtos.length - 1].Comment = newInterviewCommentDto.Comment;
                    } else {
                        var newComments = [];
                        newComments.push(newInterviewCommentDto);
                        conductInterviewDto.interviewCommentDtos.push(newInterviewCommentDto);
                        visualizeComments(newComments);
                    }
                }
            };

            objHub.client.getCurrentConductInterviewOfGroup = function (commentDtos, currentInterviewTime) {
                if (self.isHost || isLoadedClient) return;
                intervalCoordinate = currentInterviewTime;
                durationTime = currentInterviewTime;
                isLoadedClient = true;
                _isStartRecording = true;
                drawRecordingPlaybackCanvas(currentInterviewTime);
                visualizeComments(commentDtos);

                self.commentIcon = urlCommentIcon + iconNames[0] + extCommentIcon;
                increaseTimeRecord = setInterval(increaseTime, 1000);
                clientIntervalId = setInterval(update, 1000);

                _isNotRecording = false;
            };

            objHub.client.getFinishedNotification = function () {
                clearInterval(increaseTimeRecord);
                clearInterval(clientIntervalId);
                $.connection.hub.stop();
                goToCandidateInterviewsTab();
            };

            objHub.client.getPauseRecordingNotification = function () {
                clearInterval(clientIntervalId);
                clearInterval(increaseTimeRecord);
            };

            objHub.client.getResumeRecordingNotification = function () {
                increaseTimeRecord = setInterval(increaseTime, 1000);
                clientIntervalId = setInterval(update, 1000);
            };

            objHub.client.notifyMultipleTabsOpened = function () {
                goToCandidateInterviewsTab();
            };
        }

        function initCommentIcons() {
            for (var i = 1; i < iconNames.length; i++) {
                var iconName = "'" + iconNames[i] + "'";
                var ele = $compile('<i class="img-border ' + getCommentIconCss(iconName) + '-hover" ng-click="ctrl.buildComment(' + iconName + ')" />')($scope);
                $('#conduct-interview-add-live-icon').append(ele);
                var element = $compile('<i class="img-border ' + getCommentIconCss(iconName) + '" ng-click="ctrl.buildComment(' + iconName + ')" />')($scope);
                $('#conduct-interview-add-live-interview').append(element);
            }

        }

        function drawRecordingPlaybackCanvas(audioDuration) {
            intervalCoordinate = 0;
            for (var i = 0; i < parseInt(audioDuration) ; i++) {
                update();
                self.startTime = defaultTime;
                self.interviewDuration = getTime(audioDuration);
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
                intervalCoordinate++;
            }
            registerRectEvent();
        }

        // increase time
        function increaseTime() {
            intervalCoordinate++;
            durationTime++;
        }
        // draw canvas
        function update() {
            if (!analyserContext) {
                waveCanvas = document.getElementById("wavedisplay");
                canvasWidth = waveCanvas.width;
                canvasHeight = waveCanvas.height;
                analyserContext = waveCanvas.getContext('2d');

            }

            var magnitude = getRandomInt(30, canvasHeight);
            var drawHeight = (isMute) ? -5 : -magnitude;
            var rectCoordinate = { x: coordinateX, y: canvasHeight, w: BAR_WIDTH - 1, h: drawHeight, interval: intervalCoordinate };

            var grd = analyserContext.createLinearGradient(0, canvasHeight, 0, 0);
            if (self.isStartedRecord || (self.isHost && !self.isHost)) {
                grd.addColorStop(0, caConstants.conductInterview.lightGreen);
                grd.addColorStop(1, caConstants.conductInterview.green);
            } else {
                grd.addColorStop(0, caConstants.conductInterview.black);
                grd.addColorStop(1, caConstants.conductInterview.black);
            }

            analyserContext.fillStyle = grd;
            analyserContext.fillRect(rectCoordinate.x, rectCoordinate.y / 2, rectCoordinate.w, rectCoordinate.h / 2);
            analyserContext.fillRect(rectCoordinate.x, (rectCoordinate.y) / 2, rectCoordinate.w, -rectCoordinate.h / 2);
            coordinateX += BAR_WIDTH;

            self.recordTime = getTime(intervalCoordinate);
            if (!$scope.$$phase && !$scope.$root.$$phase) {
                $scope.$apply();
            }
            rects.push(rectCoordinate);
            // the canvas will be clear when it was extended. So we have to re-draw the canvas from the magnitudes array.
            if (coordinateX > waveCanvas.width) {
                var widthExpanded = 100;
                var animateInterval = 800;

                waveCanvas.width += widthExpanded;
                if (waveCanvas.width > $('.interview-information').width()) {
                    var currentWidth = $("#shadowPlace").width();
                    $("#shadowPlace").css('width', currentWidth + widthExpanded + 'px');
                }
                // hack
                var leftPos = $('#audio-visualizer').scrollLeft();
                $("#audio-visualizer").animate({ scrollLeft: leftPos + widthExpanded }, animateInterval);

                for (var i = 0; i < rects.length; i++) {
                    analyserContext.fillStyle = grd;
                    analyserContext.fillRect(rects[i].x, rects[i].y / 2, rects[i].w, rects[i].h / 2);
                    analyserContext.fillRect(rects[i].x, rects[i].y / 2, rects[i].w, -rects[i].h / 2);
                }
            }
        }

        function getRandomInt(min, max) {
            return Math.floor(Math.random() * (max - min + 1)) + min;
        }

        function registerRectEvent() {
            if (waveCanvas && waveCanvas.getContext) {
                // listener, using W3C style for example
                if (!isMute) {
                    waveCanvas.addEventListener('click', function (e) {
                        var xpos, ypos;

                        if (comparisonUtilSvc.isNullOrUndefinedValue(e.offsetX)) {
                            xpos = e.pageX - $('#wavedisplay').offset().left;
                            ypos = e.pageY - $('#wavedisplay').offset().top;
                        } else {
                            xpos = e.offsetX;
                            ypos = e.offsetY;
                        }

                        var rect = collides(rects, xpos, ypos);
                        if (rect) {
                            audioElement.currentTime = rect.interval;
                            self.startTime = getTime(indexPlayback);
                            if (!$scope.$$phase) $scope.$apply();
                            isRecordingAudioLoaded = true;
                        }
                    }, false);
                }
            }
        }

        //set event for each rectangle
        function collides(rects, x, y) {
            var isCollision = false;
            for (var i = 0, len = rects.length; i < len; i++) {

                var left = rects[i].x, right = rects[i].x + rects[i].w;
                var bottom = 0, top = rects[i].y - rects[i].h;

                var grd = analyserContext.createLinearGradient(0, canvasHeight, 0, 0);

                if (rects[i].x <= x) {
                    grd.addColorStop(0, caConstants.conductInterview.green);
                    grd.addColorStop(1, caConstants.conductInterview.green);
                    analyserContext.fillStyle = grd;
                } else {
                    grd.addColorStop(0, caConstants.conductInterview.black);
                    grd.addColorStop(1, caConstants.conductInterview.black);
                    analyserContext.fillStyle = grd;
                }
                analyserContext.fillRect(rects[i].x, rects[i].y / 2, rects[i].w, rects[i].h / 2);
                analyserContext.fillRect(rects[i].x, rects[i].y / 2, rects[i].w, -rects[i].h / 2);
                if (right >= x &&
                    left <= x &&
                    bottom <= y &&
                    top >= y) {
                    indexPlayback = i;
                    isCollision = rects[i];
                }
            }
            return isCollision;
        }

        function setStartRecordingButtonText() {
            _startInterviewButtonText = 'Interviews.With_Recording';
            self.pauseInterviewButtonText = 'Interviews.No_Recording';
            self.startInterviewButton = "";
            self.currentInterviewStatus = self.interviewStatus.choiceInterview;
        }

        function initRecording() {
            try {
                // webkit shim
                window.AudioContext = window.AudioContext || window.webkitAudioContext;
                navigator.getUserMedia = (navigator.getUserMedia ||
                    navigator.webkitGetUserMedia ||
                    navigator.mozGetUserMedia ||
                    navigator.msGetUserMedia);

                window.URL = window.URL || window.webkitURL;

                audio_context = new AudioContext();

                navigator.getUserMedia({
                    audio: true
                }, startUserMedia, function () {

                });
                _isStartedInterview = true;
            } catch (e) {
                alert('No web audio support in this browser!');
                self.isSupportAudio = false;
            }
        }

        function startUserMedia(stream) {
            _audioStream = stream;
            var fftSize = 2048;
            //Create virtual input from empty amplification factor object
            var virtualInput = audio_context.createGain();
            //Assign stream source to html5 audio context object
            var microphone = audio_context.createMediaStreamSource(stream);
            window.source = microphone;
            //window.source.connect(audio_context.destination);

            //Connect media source output to virtualInput input
            //So, virtualInput now equals microphone input
            microphone.connect(virtualInput);

            //Set audio quality and assign it to virtualInput
            var analyserNode = audio_context.createAnalyser();
            analyserNode.fftSize = fftSize;
            virtualInput.connect(analyserNode);

            //Set the stream to RecorderJs from Matt Diamond
            recorder = new Recorder(virtualInput);

            //Set volume to zero
            var amplificationFactor = audio_context.createGain();
            amplificationFactor.gain.value = 0.0;

            //We set volume to zero to output, so we cancel echo
            amplificationFactor.connect(audio_context.destination);

            setFinishRecordingButtonText();
            self.currentInterviewStatus = self.interviewStatus.finishInterview;
            closeConductInterview();
            self.isStartedRecord = true;
            startRecording();
            _isNotRecording = false;
        }

        function startRecording() {
            if (!isMute) {
                if (recorder) recorder.record();
                _isRecording = true;
            }
            increaseTimeRecord = setInterval(increaseTime, 1000);
            recordIntervalId = setInterval(update, 1000);
            // start to upload chunk file
            if (!isMute && !isFirefox)
                _uploadTime = setInterval(uploadFile, 10000);
        }

        // upload chunk file function
        function uploadFile() {
            if (recorder) {
                recorder.getCurrentMp3(function (blob) {
                    uploadRecording(blob).$promise.then(function (responseText) {
                        recordingPath = responseText.value
                            .replace("\"", "")
                            .replace("\"", "")
                            .replace("<string xmlns=http://schemas.microsoft.com/2003/10/Serialization/>", "")
                            .replace("</string>", "");
                        totalFileUpload++;
                    });
                });
            }
        }

        function closeConductInterview() {
            $rootScope.$on('$locationChangeStart', function (event) {
                if (window.location.href.indexOf('/conduct-interview') < 0 || !_isStartedInterview) return;
                pauseRecording();
                $("#" + self.dialogConfirm.dialogId).modal('show');
                _isNotRecording = true;
                event.preventDefault();
            });
        }

        function setFinishRecordingButtonText() {
            _startInterviewButtonText = 'Interviews.Finish_Interview';
            self.startInterviewButton = "";
            self.pauseInterviewButtonText = 'Interviews.Pause_Interview';
        }

        function processRecording() {
            self.isSupportAudio = true;
            if (self.pauseInterviewButtonText == 'Interviews.Resume_Interview') {
                _isPaused = false;
                resumeRecording();
                _isNotRecording = false;
                if (objHub && self.isHost) {
                    objHub.server.sendResumeRecordingNotification();
                }
            } else if (self.pauseInterviewButtonText == 'Interviews.Pause_Interview') {
                _isPaused = true;
                pauseRecording();
                if (objHub && self.isHost) {
                    objHub.server.sendPauseRecordingNotification();
                }
            } else if (self.pauseInterviewButtonText == 'Interviews.No_Recording') {
                self.currentInterviewStatus = self.interviewStatus.finishInterview;
                setFinishRecordingButtonText();
                isMute = true;
                setDialogConfirmInfo();
                self.isStartedRecord = false;
                _isStartRecording = true;
                increaseTimeRecord = setInterval(increaseTime, 1000);
                recordIntervalId = setInterval(update, 1000);
                _uploadTime = undefined;
            }
        }

        function finishInterview() {
            pauseRecording();
            objHub.server.sendPauseRecordingNotification();
            $("#" + self.dialogConfirm.dialogId).modal('show');
            _isNotRecording = true;
        }

        function interviewWithRecording() {
            initRecording();
            isMute = false;
            self.isSkipButtonDisplay = false;
            setDialogConfirmInfo();
        }

        function onStartInterview() {
            setStartRecordingButtonText();
            self.isStartedRecord = true;
            _isNotRecording = true;
            _isStartRecording = true;
        }

        function onInterviewWithoutRecording() {
            self.currentInterviewStatus = self.interviewStatus.finishInterview;
            _isStartedInterview = true;
            setFinishRecordingButtonText();
            isMute = true;
            setDialogConfirmInfo();
            self.isStartedRecord = false;
            _isStartRecording = true;
            self.isSkipButtonDisplay = false;
            increaseTimeRecord = setInterval(increaseTime, 1000);
            recordIntervalId = setInterval(update, 1000);
            _uploadTime = undefined;
        }

        function resumeRecording() {
            if (_isPaused) return;
            self.pauseInterviewButtonText = 'Interviews.Pause_Interview';
            _isNotRecording = false;
            startRecording();
        }

        function playbackRecording() {
            if (!audioElement)
                return;
            audioElement.play();
            self.isPlaying = true;
        }

        function pausePlayback() {
            if (!audioElement)
                return;
            audioElement.pause();
            self.isPlaying = false;
        }

        function finishConfirmed() {
            finishRecording();
            closeHubCommentConnection();
            _isStartedInterview = false;
        }

        function closeHubCommentConnection() {
            if (_audioStream) _audioStream = null;
            if (!objHub) return;
            var location = window.location.href;
            objHub.server.disconnect(user.UserId);
            $.connection.hub.stop();
            objHub = null;
        }

        function finishRecording() {
            self.isUpFullFile = true;
            if (self.isStartedRecord) {
                $('#upload-video-file-progress').modal('show');
                createDownloadLink();
            } else {
                conductInterviewDto.interviewDto.Id = interviewId;
                conductInterviewDto.interviewDto.IsFinished = true;
                conductInterviewDto.interviewDto.DurationTime = durationTime;
                conductInterviewDto.interviewDto.RecordingPath = "";
                caConductInterviewSvc.addConductInterview(interviewId, conductInterviewDto, function () {
                    finishedConductInterview();
                });
            }
        }

        function finishedConductInterview() {
            $.connection.hub.stop();
            location.reload();
        }

        function createDownloadLink() {
            clearInterval(_uploadTime);
            // check current browser is firefox
            if (isFirefox) {
                _fileIndex = -1;
                uploadTotalFile();
                return;
            }
            if (recorder) {
                recorder.getCurrentMp3(function (blob) {
                    uploadRecording(blob).$promise.then(function (responseText) {
                        recordingPath = responseText.value
                            .replace("\"", "")
                            .replace("\"", "")
                            .replace("<string xmlns=http://schemas.microsoft.com/2003/10/Serialization/>", "")
                            .replace("</string>", "");
                        totalFileUpload++;
                        runProgressBar();
                    });
                });
            }

            checkConditionBeforeFinish();
            if (recorder) recorder.stop();
        }

        // check condition before upload file
        function checkConditionBeforeFinish() {
            var checkCondition = setInterval(function () {
                if (uploadFileFail) {
                    clearInterval(checkCondition);
                    uploadTotalFile();
                    return;
                }
                if (totalFileUpload > _fileIndex) {
                    clearInterval(checkCondition);
                    updateConductInterViewInformation(_fileIndex);
                    if (recorder) {
                        recorder.clear();
                        recorder.close();
                    }
                    return;
                }
                if (totalFileUpload <= _fileIndex) {
                    clearInterval(checkCondition);
                    uploadTotalFile();
                    return;
                }
            }, 1000);
        }

        // update conduct-interiew's information to database
        function updateConductInterViewInformation(lastIndex) {
            //insert db
            setInterviewDto();
            var conflictFile = 300;
            conductInterviewDto.interviewDto.DurationTime = durationTime;
            conductInterviewDto.interviewDto.RecordingPath = lastIndex + '_' + _interviewTime + "_" + interviewId + ".mp3";
            // callback to reload page after insert db
            caConductInterviewSvc.conductInterview(interviewId).save(conductInterviewDto, function () {
                _uploadPercent = 10000;
                if (recorder) {
                    recorder.clear();
                    recorder.close();
                }
                finishedConductInterview();
            }, function (error) {
                //If server're lost some mp3 file
                if (error.status == conflictFile) {
                    self.isUpFullFile = true;
                    var progressBar = document.getElementById('progress-bar-upfile');
                    self.percentValue = "Loading";
                    progressBar.style.width = self.percent + '%';
                    progressBar.textContent = self.percentValue;
                    progressBar.value = (self.percentValue);
                    uploadTotalFile();
                } else {
                    messageHandleSvc.handleResponse(error, caMessage.interview.loadInterViewFail);
                    finishedConductInterview();
                }
            });
        }

        // Upload full record mp3 file
        function uploadTotalFile() {
            _drawProgressBar = undefined;
            _fileIndex = "-1";
            //if (isFirefox) {
            _drawProgressBar = setInterval(runProgressBar(), 1);
            //}
            if (recorder) {
                recorder.exportMP3(function (blob) {
                    uploadRecording(blob).$promise.then(function (responseText) {
                        recordingPath = responseText.value
                            .replace("\"", "")
                            .replace("\"", "")
                            .replace("<string xmlns=http://schemas.microsoft.com/2003/10/Serialization/>", "")
                            .replace("</string>", "");

                        saveInterviewInformation();
                    });
                });
            }
        }

        function saveInterviewInformation() {
            //insert db
            setInterviewDto();
            conductInterviewDto.interviewDto.DurationTime = durationTime;
            conductInterviewDto.interviewDto.RecordingPath = '-1_' + (_interviewTime) + "_" + interviewId + ".mp3";
            // callback to reload page after insert db
            caConductInterviewSvc.addConductInterview(interviewId, conductInterviewDto, function () {
                _uploadPercent = 10000;
                if (recorder) {
                    recorder.clear();
                    recorder.close();
                }
                if (_drawProgressBar)
                    clearInterval(_drawProgressBar);
                finishedConductInterview();
            }, function (error) {
                if (_drawProgressBar)
                    clearInterval(_drawProgressBar);
                messageHandleSvc.handleResponse(error, caMessage.interview.loadInterViewFail);
            });
        }

        function runProgressBar() {
            var progressBar = document.getElementById('progress-bar-upfile');
            var timer = setInterval(function () {
                self.percent = (_uploadPercent / 100);
                for (; _progressBarIndex <= _uploadPercent; _progressBarIndex++) {
                    self.percentValue = (_progressBarIndex / 100) + '% ' + $filter(constants.translate)("Completed");
                    progressBar.style.width = (_progressBarIndex / 100) + '%';
                    progressBar.textContent = self.percentValue;
                    progressBar.value = self.percentValue;

                    if ((_uploadPercent / 100) >= 100) {
                        self.percent = 100;
                        self.percentValue = 100 + '% ' + $filter(constants.translate)("Completed");
                        progressBar.style.width = self.percent + '%';
                        progressBar.textContent = self.percentValue;
                        progressBar.value = self.percentValue;
                        clearInterval(timer);
                        break;
                    }
                }
            }, 1);
        }

        function uploadRecording(mp3Data) {

            var fileName = _fileIndex + '_' + _interviewTime + "_" + interviewId + ".mp3";
            var fileNameHeader = _interviewTime + "_" + interviewId;
            _fileIndex++;
            return uploadFileSvc.uploadFileMp3(mp3Data, fileName, fileNameHeader);
        }

        // upload file and draw progressbar
        function uploadAllRecording(mp3Data) {

            var fileName = _fileIndex + '_' + _interviewTime + "_" + interviewId + ".mp3";
            var fileNameHeader = _interviewTime + "_" + interviewId;
            _fileIndex++;
            return uploadFileSvc.uploadFileMp3(mp3Data, fileName, fileNameHeader);
        }

        function setInterviewDto() {
            conductInterviewDto.interviewDto.Id = interviewId;
            conductInterviewDto.interviewDto.RecordingPath = recordingPath;
            conductInterviewDto.interviewDto.IsFinished = true;
        }

        function dismiss() {
            isBackToInterviewTab = false;
            objHub.server.sendResumeRecordingNotification();
            resumeRecording();
        }

        function addComment() {
            if (self.commentIcon == commentIconDefault) {
                ordinate = coordinateX - movePositionX;
                currentTime = intervalCoordinate;
                self.commentIcon = urlCommentIcon + iconNames[0] + extCommentIcon;
                pushComment();
                return;
            }
            conductInterviewDto.interviewCommentDtos[conductInterviewDto.interviewCommentDtos.length - 1].Comment = self.currentComment;
            self.commentIcon = commentIconDefault;
            self.currentComment = "";

            if (objHub && user) {
                objHub.server.sendCommentToGroup(conductInterviewDto.interviewCommentDtos[conductInterviewDto.interviewCommentDtos.length - 1], user.UserId);
            }
        }

        function buildComment(icon) {
            if (!_isStartedInterview) return;
            $('#comment-row').show();
            $("#commentText").focus();
            $("#temp-arrow").remove();
            self.commentIcon = urlCommentIcon + icon + extCommentIcon;
            ordinate = coordinateX - movePositionX;
            try {
                currentTime = intervalCoordinate;
            } catch (exception) {
                currentTime = 0;
            }
            var arrow = '<div style="left:' + ordinate + 'px; top:33px;position:absolute; z-index:1074 " id="temp-arrow" class="glyphicon comment-arrow-up-icon"><div class="fa fa-sort-asc fa-3x"></div></div>';
            $('#audio-visualizer').append($compile(arrow)($scope));

            pushComment();
        }

        function addSummary() {
            $("#summaryInterview").focus();
        }

        function cancelAddingSummary() {
            $('#salary-form').modal('hide');
            self.summaryForm.$setPristine();
            _isShowButtonAddSummary = true;
            self.isViewSummary = true;
            self.isShowSalaryButton = true;
            copyConductInterviewData(caConductInterviewSvc.conductInterviewData);
        }

        function updateInterviewResult(result) {
            var interviewDto = {
                Id: interviewId,
                Summary: angular.copy(caConductInterviewSvc.conductInterviewData.interviewDto.Summary),
                Result: result
            };

            var candidateInterviewInfo = {
                JobApplicationId: caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.JobApplicationId,
                CurrentSalary: angular.copy(caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.CurrentSalary),
                ExpectedSalary: angular.copy(caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.ExpectedSalary),
                SuggestedSalary: angular.copy(caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.SuggestedSalary),
                StartDateSuggest: angular.copy(caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.StartDateSuggest)
            };

            updatedConductInterviewDto = {
                interviewDto: interviewDto,
                candidateInterviewInfo: candidateInterviewInfo
            };

            caConductInterviewSvc.updateConductInterview(interviewId, '', updatedConductInterviewDto, function (response) {
                self.currentResult = result;
                caConductInterviewSvc.conductInterviewData.interviewDto.Result = angular.copy(result);
                messageHandleSvc.handleResponse(response, caMessage.interview.updateInterViewResultSuccessful);
            }, function (error) {
                messageHandleSvc.handleResponse(error, caMessage.interview.updateInterViewResultFail);
            });
        }

        function saveAddingSummary(interviewResultStatus) {
            var interviewDto = {
                Id: interviewId,
                Summary: self.summary,
                Result: self.currentResult
            };

            self.isViewSummary = true;
            var candidateInterviewInfo = {
                JobApplicationId: caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.JobApplicationId,
                CurrentSalary: angular.copy(caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.CurrentSalary),
                ExpectedSalary: angular.copy(caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.ExpectedSalary),
                SuggestedSalary: angular.copy(caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.SuggestedSalary),
                StartDateSuggest: angular.copy(caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.StartDateSuggest)
            };

            updatedConductInterviewDto = {
                interviewDto: interviewDto,
                candidateInterviewInfo: candidateInterviewInfo
            };

            _isShowButtonAddSummary = true;
            caConductInterviewSvc.updateConductInterview(interviewId, '', updatedConductInterviewDto, function (response) {
                messageHandleSvc.handleResponse(response, caMessage.interview.updateInterViewSummarySuccessful);
                caConductInterviewSvc.conductInterviewData.interviewDto.Summary = angular.copy(self.summary);
                _oldSummary = self.summary ? angular.copy(self.summary) : null;
            }, function (error) {
                self.summary = _oldSummary ? angular.copy(_oldSummary) : null;
                messageHandleSvc.handleResponse(error, caMessage.interview.updateInterViewSummaryFail);
            });
        }

        function cancelAddSalary() {
            $('#salary-form').modal('hide');
            self.summaryForm.$setPristine();
            self.isShowSalaryButton = true;
            self.isInvalidSuggestedWorkingDate = false;
            copyConductInterviewData(caConductInterviewSvc.conductInterviewData, true);
        }

        function saveAddingSalary(interviewResultStatus) {
            _isSaveSalary = true;
            var interviewDto = {
                Id: interviewId,
                Summary: angular.copy(caConductInterviewSvc.conductInterviewData.interviewDto.Summary),
                Result: self.currentResult
            };

            var candidateInterviewInfo = {
                JobApplicationId: caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.JobApplicationId,
                CurrentSalary: self.currentSalary,
                ExpectedSalary: self.expectedSalary,
                SuggestedSalary: self.suggestedSalary,
                StartDateSuggest: datetimeSvc.convertDateForServerSide(self.startDateSuggest, false)
            };

            updatedConductInterviewDto = {
                interviewDto: interviewDto,
                candidateInterviewInfo: candidateInterviewInfo
            };

            if (moment(candidateInterviewInfo.StartDateSuggest).isValid() === false) {
                self.isInvalidSuggestedWorkingDate = true;
                _isSaveSalary = false;
                return;
            }
            if (moment().isAfter(candidateInterviewInfo.StartDateSuggest, 'day') === true) {
                self.isInvalidSuggestedWorkingDate = true;
                _isSaveSalary = false;
                return;
            }
            self.isInvalidSuggestedWorkingDate = false;

            $('#salary-form').modal('hide');
            caConductInterviewSvc.updateConductInterview(interviewId, '', updatedConductInterviewDto, function (response) {
                caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.StartDateSuggest = datetimeSvc.convertDateForServerSide(self.startDateSuggest, false);
                _isSaveSalary = false;
                caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.CurrentSalary = angular.copy(self.currentSalary);
                caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.ExpectedSalary = angular.copy(self.expectedSalary);
                caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.SuggestedSalary = angular.copy(self.suggestedSalary);
                _salaryObject = {
                    currentSalary: angular.copy(self.currentSalary) ? parseInt(angular.copy(self.currentSalary)) : null,
                    expectedSalary: angular.copy(self.expectedSalary) ? parseInt(angular.copy(self.expectedSalary)) : null,
                    suggestedSalary: angular.copy(self.suggestedSalary) ? parseInt(angular.copy(self.suggestedSalary)) : null,
                    workingDate: angular.copy(self.startDateSuggest) ? angular.copy(self.startDateSuggest) : ""
                };
                messageHandleSvc.handleResponse(response, caMessage.interview.updateSalaryInformationSuccessful);
            }, function (error) {
                _isSaveSalary = false;
                self.currentSalary = angular.copy(_salaryObject.currentSalary);
                self.expectedSalary = angular.copy(_salaryObject.expectedSalary);
                self.suggestedSalary = angular.copy(_salaryObject.suggestedSalary);
                self.startDateSuggest = angular.copy(_salaryObject.workingDate);
                messageHandleSvc.handleResponse(error, caMessage.interview.updateSalaryInformationFail);
            });
        }

        function showComment(index) {
            if (self.conductInterviewData.interviewDto.IsFinished) {
                $('#temp-arrow').remove();
                var positionLeft = $('#comment-' + index).position().left;
                var arrow = '<div style="left:' + (positionLeft - 10) + 'px; top:59px;position:absolute; z-index:1074 " id="temp-arrow" class="glyphicon comment-arrow-up-icon"><div class="fa fa-sort-asc fa-3x"></div></div>';
                $('#comment-view-row .comment-pre').css({
                    "max-width": ($('.interview-information').width() - 45) + "px"
                });
                $('#comment-view-row').show();
                $('#audio-visualizer').append($compile(arrow)($scope));
                var comment = self.conductInterviewData.interviewCommentDtos[index];
                for (var arrayIndex = 0; arrayIndex < self.conductInterviewData.interviewCommentDtos.length; arrayIndex++) {
                    _backGround[arrayIndex] = (arrayIndex == index) ? "background-red" : "background-transparent";
                }
                self.viewCommentText = comment.Comment;
                self.commentId = comment.Id;
                self.viewIcon = comment.Icon;
            }
        }

        function toggleCommentsButton(commentId) {
            var oldComment = getOldComment(commentId);
            var newComment = $('#' + commentId).val();
            var div = $('#' + commentId).parent();
            var commentButtonsContainer = $(div).next('#' + commentBtnPrefix + commentId);
            if (JSON.stringify(oldComment) != JSON.stringify(newComment)) {
                if (commentButtonsContainer.length === 0) {
                    $(createCommentButtons(commentId)).insertAfter(div);
                }
            } else {
                $('#' + commentId + '-row').removeClass('editing-row');
                commentButtonsContainer.remove();
            }
        }

        function cancelComment(commentId) {
            $('#' + commentId + '-row').removeClass('editing-row');
            var commentIndex = -1;
            var id = commentId.replace(_commentPrefix, "");
            for (var index = 0; index < self.conductInterviewData.interviewCommentDtos.length; index++) {
                if (self.conductInterviewData.interviewCommentDtos[index].Id == id) {
                    commentIndex = index;
                    break;
                }
            }
            var preElementId = "div#" + commentId;
            if (commentIndex > -1)
                $('#' + commentId).val(self.conductInterviewData.interviewCommentDtos[commentIndex].Comment);
            $('#' + commentBtnPrefix + commentId).remove();
            loadEditableCommentField(commentId);
        }

        function loadEditableCommentField(commentId) {
            var textareaElementId = "textarea#" + commentId;
            var preElementId = "div#" + commentId;

            if ($(textareaElementId)[0].value && $(textareaElementId)[0].value !== '') {
                $(textareaElementId).hide();
                $(preElementId).show();
            } else {
                $(preElementId).hide();
                $(textareaElementId).show();
            }

            $(preElementId).click(function () {
                $(this).hide();
                $(textareaElementId).show();
            });
        }

        function saveComment(commentId) {
            $('#' + commentId + '-row').removeClass('editing-row');
            var interviewerName = "";
            if (user) {
                interviewerName = user.FirstName + " " + user.LastName;
            }

            var id = commentId.replace(_commentPrefix, "");
            var newVal = $('#' + commentId).val();
            var commentDto = {
                Id: id,
                InterviewId: interviewId,
                Comment: newVal,
                InterviewerName: interviewerName
            };
            caConductInterviewSvc.updateInterviewComment(interviewId, commentDto, function () {
                updateInterviewComment(commentId, commentDto);
            });
        }

        function updateInterviewComment(commentId, commentDto) {
            cancelComment(commentId);
            var preElementId = "div#" + commentId;
            $(preElementId)[0].innerText = commentDto.Comment;
            $(preElementId)[0].innerHTML = commentDto.Comment;
            var textareaElementId = "textarea#" + commentId;
            $(textareaElementId)[0].value = commentDto.Comment;
            $(textareaElementId)[0].innerText = commentDto.Comment;
            self.conductInterviewData.interviewCommentDtos.forEach(function (comment, index) {
                if (comment.Id == commentDto.Id) {
                    if (self.commentId == commentDto.Id) self.viewCommentText = commentDto.Comment;
                    self.conductInterviewData.interviewCommentDtos[index].Comment = commentDto.Comment;
                }
            });
            loadEditableCommentField(commentId);
        }

        function rating(number) {
            self.ratingValueTemp = number + 1;
            for (var index = 0; index < self.stars.length; index++) {
                self.stars[index].fill = (self.stars[index].id <= number) ? filled : unfilled;
            }
        }

        function saveRating() {
            var interviewDto = {
                Id: interviewId,
                Comment: self.comment.toString(),
                Rating: self.ratingValueTemp,
                Match: self.matchTemp
            };

            updatedConductInterviewDto = {
                interviewDto: interviewDto
            };

            caConductInterviewSvc.updateConductInterview(interviewId, 'rating', updatedConductInterviewDto, function () {
                self.ratingValue = parseInt(self.ratingValueTemp);
                self.match = parseInt(self.matchTemp);
                caConductInterviewSvc.conductInterviewData.interviewDto.Comment = angular.copy(self.comment.toString());
                caConductInterviewSvc.conductInterviewData.interviewDto.Match = angular.copy(self.match);
                caConductInterviewSvc.conductInterviewData.interviewDto.Rating = angular.copy(self.ratingValue);
                self.comment = "";
                $('#interview-rating').modal('hide');
            });
        }

        function showRating() {
            rating(self.ratingValue - 1);
            self.matchTemp = parseInt(self.match);
            self.comment = (caConductInterviewSvc.conductInterviewData.interviewDto.Comment) ? caConductInterviewSvc.conductInterviewData.interviewDto.Comment.toString() : "";
            $('#interview-rating').modal('show');
            if (!_isFirstShow) {
                addNummber();
                _isFirstShow = true;
            }
        }

        function cancelRating() {
            $('#interview-rating').modal('hide');
        }

        function mouseLeave() {
            for (var index = 0; index < self.stars.length; index++) {
                self.stars[index].fill = (self.stars[index].id <= self.ratingValueTemp - 1) ? filled : unfilled;
            }
        }

        function mouseHover(number) {
            for (var index = 0; index < self.stars.length; index++) {
                self.stars[index].fill = (self.stars[index].id <= number) ? filled : unfilled;
            }
        }

        function clearRating() {
            rating(-1);
        }

        function goToCandidateInterviewsTab() {
            if (_isStartedInterview) {
                pauseRecording();
                $("#" + self.dialogConfirm.dialogId).modal('show');
                _isNotRecording = true;
                event.preventDefault();
                return;
            }
            var previousUrl = historyPageSvc.getPreviousUrl(window.location.href);
            historyPageSvc.setPreviousUrl(window.location.href, "");
            if (previousUrl && previousUrl.indexOf('candidates/') == -1) {
                window.location.href = previousUrl;
                return;
            }
            $state.go('candidateDetail', { id: caConductInterviewSvc.conductInterviewData.candidateInterviewInfo.CandidateId }).then(clearOverlay);
        }

        function clearOverlay() {
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
            $('.modal-backdrop').remove();
        }

        function pauseRecording() {
            if (!isMute) {
                if (recorder) recorder.stop();
                _isRecording = false;
            }
            //stop interval
            clearInterval(increaseTimeRecord);
            clearInterval(recordIntervalId);
            clearInterval(_uploadTime);
            self.pauseInterviewButtonText = 'Interviews.Resume_Interview';
        }

        function playAudio() {
            if (!analyserContext) {
                waveCanvas = document.getElementById("wavedisplay");
                canvasWidth = waveCanvas.width;
                canvasHeight = waveCanvas.height;
                analyserContext = waveCanvas.getContext('2d');
            }
            //stop interval
            if (indexPlayback > (rects.length - 1)) {
                audioElement.currentTime = 0;
                audioElement.pause();
                resetAudioCanvas();
                clearInterval(playBackIntervalId);
                self.startTime = defaultTime;
                indexPlayback = 0;
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
                return;
            }

            var grd = analyserContext.createLinearGradient(0, canvasHeight, 0, 0);
            grd.addColorStop(0, caConstants.conductInterview.green);
            grd.addColorStop(1, caConstants.conductInterview.green);

            analyserContext.fillStyle = grd;
            analyserContext.fillRect(rects[indexPlayback].x, rects[indexPlayback].y / 2, rects[indexPlayback].w, rects[indexPlayback].h / 2);
            analyserContext.fillRect(rects[indexPlayback].x, rects[indexPlayback].y / 2, rects[indexPlayback].w, -rects[indexPlayback].h / 2);
            indexPlayback++;
            self.startTime = getTime(indexPlayback);
            if (!$scope.$$phase) $scope.$apply();
        }

        function getTime(time) {
            var min = parseInt(parseInt(time) / 60);
            var sec = parseInt(parseInt(time) % 60);
            min = (min > 9) ? min : ('0' + min);
            sec = (sec > 9) ? sec : ('0' + sec);
            return min + " : " + sec;
        }

        function pushComment() {
            var interviewerName = "";
            if (user) {
                interviewerName = user.FirstName + " " + user.LastName;
            }

            var comment = {
                InterviewId: interviewId,
                Ordinate: ordinate,
                Comment: self.currentComment,
                Icon: self.commentIcon,
                CommentTime: currentTime,
                InterviewerName: interviewerName
            };
            conductInterviewDto.interviewCommentDtos.push(comment);
            self.currentComment = "";
            var newComments = [];
            var drawComment = angular.copy(comment);
            drawComment.Ordinate = ordinate + 5;
            newComments.push(drawComment);
            visualizeComments(newComments);

            if (objHub && user) {
                objHub.server.sendCommentToGroup(comment, user.UserId);
            }
        }

        function createCommentElement(comment) {
            var eleCommentId = _commentPrefix + comment.Id;
            eleCommentId = eleCommentId.trim();
            var commentForm = '<tr id="' + eleCommentId + '-row">' +
                                '<td>' +
                                    '<div class="input-group">' +
                                        '<div class="input-group-addon">' +
                                            '<label>' + getTime(comment.CommentTime) + '</label>' +
                                            '<span class="' + getCommentIconCss(comment.Icon) + '"></span>' +
                                        '</div>' +
                                        '<textarea rows="3" placeholder="{{ctrl.commentPlaceHolder}}"' +
                                                    'class="form-control" id="' + eleCommentId + '"' +
                                                    'ng-keyup="ctrl.toggleCommentsButton(\'' + eleCommentId + '\')" prist="{{comment.Comment}}">' + comment.Comment +
                                            '</textarea>' +
                                            '<div id="' + eleCommentId + '" class="col-xs-12 comment-pre editable-comment"  ng-bind-html="ctrl.convertText(\'' + comment.Comment + '\')"></div>' +
                                        '</div>' +
                                    '</td>' +
                                '</tr>';
            $('#commentShow').append($compile(commentForm)($scope));
            loadEditableCommentField(eleCommentId);
        }

        function createCommentButtons(commentId) {
            $('#' + commentId + '-row').addClass('editing-row');
            var divName = commentBtnPrefix + commentId;
            var cancelLink = '<button class="button-cancel" ng-click="ctrl.cancelComment(' + '\'' + commentId + '\'' + ')" translate="Cancel"></button>';
            var saveButton = '<button class="button-submit" ng-click="ctrl.saveComment(' + '\'' + commentId + '\'' + ')" translate="Save"></button>';
            var divContainer = '<div class="row text-right edit-comment-row-button" id="' + divName + '">' + "<br/>" + cancelLink + ' ' + saveButton + '</div>';
            return $compile(divContainer)($scope);
        }

        function getOldComment(commentId) {
            var preElementId = "div#" + commentId;
            return $(preElementId)[0].innerHTML;
        }

        function visualizeComments(comments) {
            for (var index = 0; index < comments.length; index++) {
                _backGround.push("background-transparent");
                var commentForm = '<div><div style="left:' + comments[index].Ordinate + 'px; top:43px" id="comment-' + index + '" class="tooltip bottom in"' +
                    ' ng-click="ctrl.showComment(' + index + ')">' +
                        '<div class="tooltip-arrow"></div>' +
                        '<img height="15" ng-class="ctrl.backGround[' + index + ']" src="' + comments[index].Icon + '" />' +
                        '</div></div>';
                $('#audio-visualizer').append($compile(commentForm)($scope));
            }
        }

        function addNummber() {
            var array = [-50, -40, -30, -20, -10, 0, 10, 20, 30, 40, 50];
            var maxPercent = 95;
            for (var index = 0; index < array.length; index++) {
                var positionLeft = (index * maxPercent / (array.length - 1));
                positionLeft = (array[index] === 0) ? positionLeft + 1.5 : positionLeft;
                $('#matchChoice').append($compile('<span style="position: absolute;left:' + positionLeft + '%;top:90%">' + array[index] + '</span>')($scope));
            }
        }

        function skipInterview() {
            setDialogSkipConfirmInfo();
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function setDialogConfirmInfo() {
            self.dialogConfirm = caMessage.interview.dialogConfirm;
            self.dialogConfirm.dialogTitle = $filter(constants.translate)(self.dialogConfirm.dialogTitle);
            self.dialogConfirm.dialogMessage = $filter(constants.translate)(self.dialogConfirm.dialogMessage);
        }

        function setDialogSkipConfirmInfo() {
            self.dialogConfirm = caMessage.interview.dialogSkipConfirm;
            self.dialogConfirm.dialogTitle = $filter(constants.translate)(self.dialogConfirm.dialogTitle);
            self.dialogConfirm.dialogMessage = $filter(constants.translate)(self.dialogConfirm.dialogMessage);
        }

        function sendEmail() {
            var failedEmailDto = {
                To: self.emailData.emailDto.To,
                Subject: self.emailData.emailDto.Subject,
                Content: self.emailData.emailDto.Content
            };
            updatedConductInterviewDto.failedEmailDto = failedEmailDto;

            caConductInterviewSvc.updateConductInterview(interviewId, '', updatedConductInterviewDto, function () {
                location.reload();
            });
        }

        function stopHub() {
            try {
                $.connection.hub.stop();
            } catch (error) { }
        }

        function onKeyUpComment(event) {
            var eventCode = event.charCode === 0 ? event.keyCode : event.charCode;
            if (eventCode != 13) return;
            $('#comment-row').hide();
            $('#temp-arrow').remove();
            addComment();
        }

        function toogleHeader() {
            _isShowToogleHeader = !_isShowToogleHeader;
            $("#conduct-interview-note").slideToggle("fast");
        }

        function getCssHeaderClass() {
            return _isShowToogleHeader && 'col-xs-1 fa fa-2x fa-caret-down' || 'col-xs-1 fa fa-2x fa-caret-right';
        }

        function getCommentIconCss(link) {
            if (link.indexOf("fun") > -1) return "glyphicon comment-2faces-icon";
            if (link.indexOf("smile") > -1) return "glyphicon comment-smile-icon";
            if (link.indexOf("like") > -1) return "glyphicon comment-like-icon";
            if (link.indexOf("dontUnderstand") > -1) return "glyphicon comment-question-icon";
            if (link.indexOf("success") > -1) return "glyphicon comment-graduate-icon";
            if (link.indexOf("edit") > -1) return "glyphicon comment-draw-icon";
            return "glyphicon comment-smile-icon";
        }

        function checkSummaryChange() {
            var currentSummary = self.summary ? self.summary : null;
            var latestSummary = _oldSummary ? _oldSummary : null;
            return (latestSummary != currentSummary);
        }

        function showFormAddSummary() {
            _isShowButtonAddSummary = false;
            self.isViewSummary = false;
        }

        function checkVisibleAddSummaryForm() {
            return ((!caConductInterviewSvc.conductInterviewData || !caConductInterviewSvc.conductInterviewData.interviewDto || !caConductInterviewSvc.conductInterviewData.interviewDto.Summary) ? true : false) && _isShowButtonAddSummary;
        }

        function startEditSummary() {
            self.isViewSummary = false;
        }

        function getButtonImageLink(image) {
            return (IS_PRODUCT_MODE) ? '../../../../' + image : image;
        }

        function getImagePath() {
            if (!self.conductInterviewData.candidateInterviewInfo || !self.conductInterviewData.candidateInterviewInfo.ImagePath)
                return constants.noAvatar;
            return constants.serverUrl + self.conductInterviewData.candidateInterviewInfo.ImagePath;
        }
    }
})();
