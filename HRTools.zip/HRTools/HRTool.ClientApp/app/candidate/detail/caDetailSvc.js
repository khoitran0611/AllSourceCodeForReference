﻿(function () {
    'use strict';
    angular.module('app').factory('caDetailSvc', caDetailSvc);
    caDetailSvc.$inject = ['$resource', '$q', 'caConstants', 'messageHandleSvc', '$rootScope', 'constants'];
    function caDetailSvc($resource, $q, caConstants, messageHandleSvc, $rootScope, constants) {
        var jobApplicationId = { value: null };
        var candidateId = '';
        var candidateInfo = null;
        var currentPosition = {
            id: 0, name: null, lastUpdateStatus: 0
        };
        var cvSources = [];
        var screeningStatus = { value: null, jobId: null };
        var lastUpdateStatus = { value: null, jobId: null };
        var isLoadingFail = false;

        var candidateJobApplicationList = [];

        var interviewData = { isShowLoading: true };
        var basicCandidateInfor = {};

        var service = {
            updateSelectedJobApplication: updateSelectedJobApplication,
            getSelectedJobApplicationId: getSelectedJobApplicationId,
            getCandidateDetailResource: getCandidateDetailResource,
            getNoteResource: getNoteResource,
            getCheckingEmailResource: getCheckingEmailResource,
            getAppliedInfoResource: getAppliedInfoResource,
            setCandidateId: setCandidateId,
            addNewScreeningCvHistory: addNewScreeningCvHistory,
            getJobApplicationInfoByCandidateId: getJobApplicationInfoByCandidateId,
            getCurrentPosition: getCurrentPosition,
            setCurrentPosition: setCurrentPosition,
            getJobApplicationInfo: getJobApplicationInfo,
            restoreDeleteCandidate: restoreDeleteCandidate,
            candidateNoteResource: candidateNoteResource,
            getCurrentCandidate: getCurrentCandidate,
            setCvSources: setCvSources,
            getCvSources: getCvSources,
            getScreeningStatus: getScreeningStatus,
            updateScreeningStatus: updateScreeningStatus,
            getCandidateDetailInfo: getCandidateDetailInfo,
            getLastUpdateStatus: getLastUpdateStatus,
            updateLastUpdateStatus: updateLastUpdateStatus,
            candidateJobApplicationList: candidateJobApplicationList,
            getCandidateJobApplicationList: getCandidateJobApplicationList,
            updateCandiateJobApplicationList: updateCandiateJobApplicationList,
            getCurrentLoading: getCurrentLoading,
            setCurrentLoading: setCurrentLoading,
            moveCandidateImageToOriginal: moveCandidateImageToOriginal,
            setInterviewData: setInterviewData,
            getInterviewData: getInterviewData,
            setCandidateBasicInfo: setCandidateBasicInfo,
            getCandidateBasicInfo: getCandidateBasicInfo
        };
        return service;

        function setCandidateBasicInfo(data) {
            basicCandidateInfor = data;
        }

        function getCandidateBasicInfo() {
            return basicCandidateInfor;
        }
        function updateSelectedJobApplication(id) {
            jobApplicationId.value = id;
        }

        function getSelectedJobApplicationId(callback) {
            return jobApplicationId;
        }

        function getCandidateDetailResource(param) {
            return $resource(
                constants.apiUrl + 'candidates/:id',
                     { id: param.candidateId }, { 'update': { method: 'PUT' } });
        }

        function getNoteResource(param) {
            return $resource(constants.apiUrl + 'candidates/:id/candidate-note', { id: param.candidateId });
        }

        function getCheckingEmailResource(id, emailToCheckDuplicate) {
            return $resource(constants.apiUrl + 'candidates/:id', { id: id, emailToCheckDuplicate: emailToCheckDuplicate, action: 'getGeneralInfo' });
        }

        function getAppliedInfoResource(param) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/appliedpositions/:jobApplicationId', { candidateId: param.candidateId, jobApplicationId: param.jobApplicationId }, { 'update': { method: 'PUT' } });
        }

        function setCandidateId(id) {
            candidateInfo = null;
            candidateId = id;
        }

        function addNewScreeningCvHistory(param) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/job-application/:jobApplicationId/cscreening-cv-history', { candidateId: param.candidateId, jobApplicationId: param.jobApplicationId });
        }

        function getJobApplicationInfoByCandidateId() {
            return $resource(constants.apiUrl + 'candidates/:candidateId/appliedpositions/:jobApplicationId', { candidateId: candidateId });
        }

        function getCurrentPosition() {
            return currentPosition;
        }

        function setCurrentPosition(position) {
            if (!position) {
                currentPosition = { name: null };
                return;
            }
            currentPosition.id = position.PositionId;
            currentPosition.name = position.PositionName;
            currentPosition.lastUpdateStatus = position.LastUpdateStatus;
            $rootScope.$broadcast(caConstants.updateCurrentPosition);
        }

        /* EXPERIENCE Section */
        function getJobApplicationInfo(param) {
            return $resource(constants.apiUrl + 'candidates/:id/job-application/:jobApplicationId', { id: param.candidateId, jobApplicationId: param.jobApplicationId });
        }

        /* ADMINISTRATION tab*/
        function getCandidateDetailInfo(param) {
            var deferred = $q.defer();
            $resource(constants.apiUrl + 'candidates/:id').get({ id: param.candidateId }).$promise.then(
                function (value) {
                    deferred.resolve(value);
                }, function (reason) {
                    deferred.reject(reason);
                });
            return deferred.promise;
        }

        function restoreDeleteCandidate(param) {
            var deferred = $q.defer();
            $resource(constants.apiUrl + 'candidates/:id', { id: '0' }, {
                RestoreDelete: { method: 'PATCH', headers: { ActionName: 'RestoreDeleteCandidate', DataJsonFormat: JSON.stringify(param) } }
            }).RestoreDelete().$promise.then(
                function (value) {
                    deferred.resolve(value);
                }, function (reason) {
                    deferred.reject(reason);
                });
            return deferred.promise;
        }

        /* NOTE Tab */
        function candidateNoteResource(param) {
            return $resource(constants.apiUrl + 'candidates/:id/candidate-note', { id: param.candidateId });
        }

        function getCurrentCandidate() {
            return candidateId;
        }
        function setCvSources(sources) {
            cvSources = sources;
        }
        function getCvSources() {
            return cvSources;
        }
        function getScreeningStatus() {
            return screeningStatus;
        }
        function updateScreeningStatus(status, jobId, isActionMenuUpdate) {
            screeningStatus.value = status;
            screeningStatus.jobId = jobId;
            screeningStatus.isActionMenuUpdate = isActionMenuUpdate;

        }
        function getLastUpdateStatus() {
            return lastUpdateStatus;
        }
        function updateLastUpdateStatus(status, jobId) {
            lastUpdateStatus.value = status;
            lastUpdateStatus.jobId = jobId;
        }

        function getCandidateJobApplicationList() {
            return candidateJobApplicationList;
        }

        function updateCandiateJobApplicationList(param) {
            getAppliedInfoResource(param).query().$promise.then(function (response) {
                candidateJobApplicationList = response;
            });
            return candidateJobApplicationList;
        }
        function getCurrentLoading() {
            return isLoadingFail;
        }
        function setCurrentLoading(value) {
            isLoadingFail = value;
        }
        function moveCandidateImageToOriginal(param) {
            return $resource(
                constants.apiUrl + 'files/move-candidate-image-to-origin', { imagePath: param }, { 'update': { method: 'PUT' } });
        }

        function setInterviewData(data) {
            interviewData = data;
        }

        function getInterviewData() {
            return interviewData;
        }
    }

})();
