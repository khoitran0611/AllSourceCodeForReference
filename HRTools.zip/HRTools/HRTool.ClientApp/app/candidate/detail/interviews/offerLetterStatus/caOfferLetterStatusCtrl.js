﻿(function () {
    'use strict';
    angular.module('app').controller('caOfferLetterStatusCtrl', CaOfferLetterStatusCtrl);
    CaOfferLetterStatusCtrl.$inject = ['datetimeSvc', 'validationSvc', 'caOfferLetterStatusSvc', 'messageHandleSvc', 'permissionSvc', 'historyPageSvc',
        'constants', 'caMessage',
        '$filter', '$state', '$location', '$timeout', 'comparisonUtilSvc'];
    function CaOfferLetterStatusCtrl(datetimeSvc, validationSvc, caOfferLetterStatusSvc, messageHandleSvc, permissionSvc, historyPageSvc,
            constants, caMessage,
            $filter, $state, $location, $timeout, comparisonUtilSvc) {
        var self = this;
        var statusDefault = 0;
        var statusSuccess = 1;
        var statusFail = 2;

        self.initOfferLetter = {};
        self.closeTitle = $filter(constants.translate)(caMessage.offerLetter.close);
        self.createOfferLetterTitle = $filter(constants.translate)(caMessage.offerLetter.createOfferLetter);
        self.Currency = "VND";
        self.acceptStatus = "";
        self.pageTitle = $filter(constants.translate)(caMessage.offerLetter.updateOfferLetterStatusPageTitle);
        self.offerLetter = null;
        self.linkToEditOfferLetter = linkToEditOfferLetter;
        self.listOfferStatus = translateStatus(constants.offerLetter.listOfferStatus);
        self.showUpdateButton = showUpdateButton;
        self.updateOfferStatus = updateOfferStatus;
        self.goBack = goBack;
        self.showValue = showValue;
        self.candidateUrl = "../#/candidates";
        var _offerLetterStatus = $.jStorage.get("offerLetterStatus");
        self.serverUrl = constants.serverUrl;

        self.permissionOnPage = {
            isViewUpdateOfferLetterPermission: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.UpdateOfferStatus_ViewStatusOfferLetter),
            isUpdateOfferStatusPermission: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.UpdateOfferStatus_UpdateOfferStatus),
            isResendOfferLetterPermission: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.UpdateOfferStatus_ResendOfferLetter)
        };
        if (!self.permissionOnPage.isViewUpdateOfferLetterPermission) {
            var interviewTabUrl = 'candidates/' + $state.params.candidateId;
            $location.path(interviewTabUrl);
            $location.replace();
            return;
        }

        init();

        function init() {
            self.offerLetter = caOfferLetterStatusSvc.getOfferLetterResource($state.params.candidateId, $state.params.jobApplicationId, undefined).get(
            function (data) {
                if (comparisonUtilSvc.isNullOrUndefinedValue(_offerLetterStatus)) {
                    if (comparisonUtilSvc.isNullOrUndefinedValue(data.IsAcceptSigning)) {
                        data.IsAcceptSigning = statusDefault;
                    } else {
                        data.IsAcceptSigning = (data.IsAcceptSigning) ? statusSuccess : (!data.IsAcceptSigning) ? statusFail : statusDefault;
                    }
                } else {
                    data.IsAcceptSigning = _offerLetterStatus == "Accepted" ? statusSuccess : statusFail;
                    $.jStorage.deleteKey("offerLetterStatus");
                }
                var isServerType = false;
                if (data.AcceptDate) {
                    data.AcceptDate = datetimeSvc.convertDate(data.AcceptDate, isServerType);
                }
                self.acceptStatus = getStatus(data.IsAcceptSigning);
                self.initOfferLetter = copyOfferLetter(data);
                setDelay(false);
            },
            function (xhr) {
                setDelay(false);
                messageHandleSvc.handleResponse(xhr, caMessage.error);

            });

            $('.date').datepicker({
                autoclose: true, todayHighlight: true
            });
        }

        function copyOfferLetter(offerLetter) {
            return { IsAcceptSigning: offerLetter.IsAcceptSigning, AcceptDate: offerLetter.AcceptDate, NoteAccept: offerLetter.NoteAccept, ContractCodeId: offerLetter.ContractCodeId };
        }

        function setDelay(isDelay) {
            if (isDelay) {
                $(constants.loadingIcon.overlay).show();
                $(constants.loadingIcon.indicator).show();
                return;
            }
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
            $('.modal-backdrop').remove();
        }

        function linkToEditOfferLetter(candidateId, jobApplicationId) {
            return "#/candidates/" + candidateId + "/job-application/" + jobApplicationId + "/offer-letter/create";
        }

        function translateStatus(statuses) {
            var results = [];
            for (var index = 0; index < statuses.length; index++) {
                var value = { id: statuses[index].id, name: $filter(constants.translate)(statuses[index].name) };
                results.push(value);
            }
            return results;
        }

        function showUpdateButton() {
            return !comparisonUtilSvc.isNullOrUndefinedValue(_offerLetterStatus) ? false : !self.offerLetter.AcceptDate || (JSON.stringify(self.initOfferLetter) == JSON.stringify(copyOfferLetter(self.offerLetter)));
        }

        function updateOfferStatus() {
            var postData = copyOfferLetter(self.offerLetter);
            var isServerType = true;
            postData.IsAcceptSigning = postData.IsAcceptSigning == statusDefault ? null : postData.IsAcceptSigning == statusSuccess ? true : false;
            postData.AcceptDate = comparisonUtilSvc.isNullOrUndefinedValue(postData.IsAcceptSigning) ? "" : datetimeSvc.convertDate(postData.AcceptDate, isServerType);
            caOfferLetterStatusSvc.getOfferLetterResource($state.params.candidateId, $state.params.jobApplicationId, postData.ContractCodeId).update(postData,
                function () {
                    self.initOfferLetter = copyOfferLetter(self.offerLetter);
                    self.acceptStatus = getStatus(self.offerLetter.IsAcceptSigning);
                    toastr.success($filter(constants.translate)(caMessage.offerLetter.updateSuccessful));
                    $timeout(function () {
                        goBack();
                    }, 1000);
                },
                function (xhr) {
                    var previousOffer = copyOfferLetter(self.initOfferLetter);
                    self.offerLetter.IsAcceptSigning = previousOffer.IsAcceptSigning;
                    self.offerLetter.AcceptDate = previousOffer.AcceptDate;
                    self.offerLetter.NoteAccept = previousOffer.NoteAccept;
                    messageHandleSvc.handleResponse(xhr, caMessage.offerLetter.updateFail);
                });
        }

        function getStatus(value) {
            var length = self.listOfferStatus.length;
            if (value >= length || value < 0) return "";
            for (var index = 0; index < length; index++) {
                if (self.listOfferStatus[index].id == value) return self.listOfferStatus[index].name;
            }
            return "";
        }

        var currentCandidateId = $state.params.candidateId;
        function goBack() {
            var url = window.location.href;
            var previousUrl = historyPageSvc.getPreviousUrl(url);
            if (previousUrl && previousUrl.indexOf("/#/candidates/") == -1) {
                historyPageSvc.setPreviousUrl(url, "");
                window.location.href = previousUrl;
                return;
            }
            historyPageSvc.setPreviousUrl(url, "");
            $state.go('candidateDetail', {
                id: currentCandidateId
            }).then(clearOverlay);
            return;
        }


        function clearOverlay() {
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
            $('.modal-backdrop').remove();
        }

        function showValue(value) {
            if (!value || value <= statusDefault || isNaN(value)) return false;
            return true;
        }
    }
})();
