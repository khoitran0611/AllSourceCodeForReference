﻿(function () {
    'use strict';
    angular.module('app').factory('caOfferLetterStatusSvc', caOfferLetterStatusSvc);
    caOfferLetterStatusSvc.$inject = ['$resource', 'constants', ];
    function caOfferLetterStatusSvc($resource, constants) {
        return {
            getOfferLetterResource: getOfferLetterResource
        };
        function getOfferLetterResource(candidateId, jobApplicationId, contractId) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/job-application/:jobApplicationId/offer-letters/:id',
                { candidateId: candidateId, jobApplicationId: jobApplicationId, id: contractId, actionName: "GetOfferLetter" }, { 'update': { method: "PUT" } });
        }
    }
})();