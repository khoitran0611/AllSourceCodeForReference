﻿(function () {
    'use strict';
    angular.module('app').factory('caOfferLetterCreateSvc', caOfferLetterCreateSvc);
    caOfferLetterCreateSvc.$inject = ['$resource', 'caConstants', 'constants'];
    function caOfferLetterCreateSvc($resource, caConstants, constants) {
        return {
            getOfferLetterResource: getOfferLetterResource,
            createOfferLetterResource: createOfferLetterResource
        };

        function getOfferLetterResource(candidateId, jobApplicationId, contractId) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/job-application/:jobApplicationId/offer-letters/:id',
                { candidateId: candidateId, jobApplicationId: jobApplicationId, id: contractId, actionName: "CreateOfferLetter" }, { 'update': { method: "PUT" } });
        }

        function createOfferLetterResource(actionName) {
            return $resource(constants.apiUrl + 'offer-letters?actionName=:actionName',
                { actionName: actionName }, { 'update': { method: "PUT" } });
        }
    }
})();