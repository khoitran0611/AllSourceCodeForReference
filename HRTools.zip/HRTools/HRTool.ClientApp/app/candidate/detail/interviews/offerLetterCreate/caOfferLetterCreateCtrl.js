﻿(function () {
    'use strict';
    angular.module('app').controller('caOfferLetterCreateCtrl', CaOfferLetterCreateCtrl);
    CaOfferLetterCreateCtrl.$inject = ['datetimeSvc', 'validationSvc', 'caOfferLetterCreateSvc', 'emailSvc', 'authenticationSvc', 'historyPageSvc', 'positionSvc',
        'constants', 'permissionSvc', 'messageHandleSvc', '$filter', '$state', '$stateParams', "$scope", '$timeout', '$window', 'message', 'caMessage', 'uploadFileSvc', 'caConstants',
        'comparisonUtilSvc'
    ];
    function CaOfferLetterCreateCtrl(datetimeSvc, validationSvc, caOfferLetterCreateSvc, emailSvc, authenticationSvc, historyPageSvc, positionSvc,
            constants, permissionSvc, messageHandleSvc, $filter, $state, $stateParams, $scope, $timeout, $window, message, caMessage, uploadFileSvc, caConstants,
            comparisonUtilSvc) {
        var self = this;
        self.hasFile = false;
        self.salaryChanged = false;
        self.startWorkindDateChanged = false;
        self.basicSalaryChanged = false;
        self.percentageOfSalaryChanged = false;
        self.probationMonthChanged = false;
        self.allowanceChanged = false;
        self.true = true;
        self.false = false;
        self.isOpenOfferLetter = false;
        self.pageTitle = "";
        self.showSendButton = false;
        self.useThisPositionName = false;
        self.allowanMessage = undefined;
        self.percentageSalaryOfferMessage = undefined;
        self.probationMonthMessage = undefined;
        self.basicSalaryOfferMessage = undefined;
        self.workingStartDateMessage = undefined;
        self.salaryOfferMessage = undefined;
        self.file = "";
        self.Currency = "VND";
        self.fileType = "UploadFileAttachment";
        self.candidateUrl = "../#/candidates";
        self.serverUrl = constants.serverUrl;
        self.isHidePosition = false;
        self.permissionOnPage = {
            isViewOfferLetterPermission: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CreateOfferLetter_ViewOfferLetterPage),
            isSendOfferLetterPermission: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CreateOfferLetter_SendOfferLetter),
            isResendOfferLetterPermission: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.UpdateOfferStatus_ResendOfferLetter)
        };
        self.initPosition = { id: "text", text: "text" };
        self.isChooseAnotherReport = false;
        self.ReportTo = _defaultValue;

        self.goBack = goBack;
        self.previewEmail = previewEmail;
        self.sendEmail = sendEmail;
        self.finishSendMail = finishSendMail;
        self.uploadFile = uploadFile;
        self.removeFile = removeFile;
        $scope.uploadFile = uploadFile;
        self.changeSalaryOffer = changeSalaryOffer;
        self.changeStartWorkingDate = changeStartWorkingDate;
        self.changeBasicSalaryOffer = changeBasicSalaryOffer;
        self.changeProbationMonth = changeProbationMonth;
        self.changePercentageSalaryOffer = changePercentageSalaryOffer;
        self.changeAllowance = changeAllowance;
        self.canSendMail = canSendMail;
        self.approveOfferWithoutSendMail = approveOfferWithoutSendMail;
        self.viewOfferLetter = viewOfferLetter;
        self.approveOffer = approveOffer;
        self.getWarningPositionNameMessage = getWarningPositionNameMessage;
        self.selectReportTo = selectReportTo;

        var candidateId = $state.params.candidateId;
        var _defaultValue = -1;
        var reportList = [
        { text: $filter(constants.translate)("Report_List.CEO_Office_Manager") },
        { text: $filter(constants.translate)("Report_List.CTO_Project_Manager") },
        { text: $filter(constants.translate)("Report_List.Team_Leader_Project_Manager") },
        { text: $filter(constants.translate)("Report_List.Office_Manager") },
        { text: $filter(constants.translate)("Report_List.IT_Manager") }];

        init();

        function init() {
            getOfferLetterData();
            $('.date').datepicker({
                autoclose: true, todayHighlight: true
            });

            self.init = { text: "PstName", id: "PstId" };
            self.listPosition = [];
            $('#choose-report').select2();
        }

        if (!self.permissionOnPage.isViewOfferLetterPermission && !self.permissionOnPage.isResendOfferLetterPermission) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }

        function getOfferLetterData() {
            self.offerLetter = caOfferLetterCreateSvc.getOfferLetterResource($state.params.candidateId, $state.params.jobApplicationId, undefined).get(
            function (data) {
                self.listPosition = positionSvc.getAllPositions().query(function () { }, function () { });
                self.reportList = reportList;
                data.WorkingStartDate = datetimeSvc.convertDate(data.WorkingStartDate, false);
                var minSalary = 4200000;
                var minValue = 0;
                data.SalaryOffer = data.SalaryOffer >= minSalary ? data.SalaryOffer : minSalary;
                data.BasicSalaryOffer = data.BasicSalaryOffer >= minSalary ? data.BasicSalaryOffer : minSalary;
                data.PercentageSalaryOffer = data.PercentageSalaryOffer > minValue ? data.PercentageSalaryOffer : minValue + 1;
                data.MonthProbation = data.MonthProbation > minValue ? data.MonthProbation : minValue + 1;
                self.useThisPositionName = data.OfferPositionName === data.CandidatePosistion ? false : true;
                self.offerLetter.OfferPositionName = data.OfferPositionName === "" ? data.CandidatePosistion : data.OfferPositionName;
                self.isHidePosition = data.IsHide;
                setDelay(false);
                self.isOpenOfferLetter = false;
                createOfferLetter();
                getMail();
            },
            function (xhr) {
                setDelay(false);
                messageHandleSvc.handleResponse(xhr, caMessage.error);
            });
        }

        function goBack() {
            var url = window.location.href;
            var previousUrl = historyPageSvc.getPreviousUrl(url);
            if (previousUrl && previousUrl.indexOf("/#/candidates/") == -1) {
                historyPageSvc.setPreviousUrl(url, "");
                window.location.href = previousUrl;
                return;
            }
            historyPageSvc.setPreviousUrl(url, "");
            $state.go('candidateDetail', {
                id: candidateId
            }).then(clearOverlay);
            return;
        }

        function clearOverlay() {
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
            $('.modal-backdrop').remove();
        }

        function setDelay(isDelay) {
            if (isDelay) {
                $(constants.loadingIcon.overlay).show();
                $(constants.loadingIcon.indicator).show();
                return;
            }
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
            $('.modal-backdrop').remove();
        }

        function previewEmail() {
            if (!self.permissionOnPage.isSendOfferLetterPermission && !self.permissionOnPage.isResendOfferLetterPermission) {
                goBack();
            }
            self.isOpenOfferLetter = false;
            self.showSendButton = false;
            if (!self.canSendMail()) return;
            if (self.hasFile) getMail();
            else createOfferLetter();
        }

        function getMail() {
            self.isShowLoading = true;
            var actionId = constants.emailCode.offerLetter;
            var mail = new copyOfferLetter(self.offerLetter);
            mail.WorkingStartDate = datetimeSvc.convertDate(mail.WorkingStartDate, true);
            emailSvc.getLetter(actionId, mail).get(function (data) {
                self.emailData = data.ExportOfferLetter.EmailToSent;
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
                if (self.isOpenOfferLetter) {
                    self.isOpenOfferLetter = false;
                    var openOfferLetter = $window.open(constants.serverUrl + self.emailData.FilePathToViewOnBrowser);
                    if (comparisonUtilSvc.isNullOrUndefinedValue(openOfferLetter) || typeof (openOfferLetter) == 'undefined')
                        toastr.warning($filter(constants.translate)("Pop_Up_Block"));
                }
                self.isShowLoading = false;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, caMessage.error);
                self.isShowLoading = false;
            });
        }

        function copyOfferLetter(letter) {
            var copyobject = {
                IsCreate: letter.IsCreate,
                ContractCodeId: letter.ContractCodeId,
                JobApplicationId: letter.JobApplicationId,
                ContractCodeRcmPstId: letter.ContractCodeRcmPstId,
                ContractCodeNo: letter.ContractCodeNo,
                ContractCodeCode1: letter.ContractCodeCode1,
                ContractCodeCode2: letter.ContractCodeCode2,
                ContractCodeType: letter.ContractCodeType,
                ContractCodeEmplId: letter.ContractCodeEmplId,
                SendingDate: letter.SendingDate,
                NoteSending: letter.NoteSending,
                WorkingStartDate: letter.WorkingStartDate,
                NoteWorkingStartDate: letter.NoteWorkingStartDate,
                ViewScreenCandidate: letter.ViewScreenCandidate,
                SalaryOffer: letter.SalaryOffer,
                BasicSalaryOffer: letter.BasicSalaryOffer,
                PercentageSalaryOffer: letter.PercentageSalaryOffer,
                NoteOffer: letter.NoteOffer,
                AnotherAgree: letter.AnotherAgree,
                ReportTo: letter.ReportTo,
                IsAcceptSigning: letter.IsAcceptSigning,
                NoteSigning: letter.NoteSigning,
                ValidTo: letter.ValidTo,
                IsFreshGraduated: letter.IsFreshGraduated,
                MonthTrial: letter.MonthTrial,
                SalaryIncrease: letter.SalaryIncrease,
                Allowance: letter.Allowance,
                MonthProbation: letter.MonthProbation,
                AcceptDate: letter.AcceptDate,
                NoteAccept: letter.NoteAccept,
                CompanyShortName: letter.CompanyShortName,
                RefNoExport: letter.RefNoExport,
                CandidateId: letter.CandidateId,
                CandidateFullName: letter.CandidateFullName,
                CandidateFirstName: letter.CandidateFirstName,
                CandidateLastName: letter.CandidateLastName,
                CandidatePosistion: letter.CandidatePosistion,
                CandidateJobCode: letter.CandidateJobCode,
                IsValid: letter.IsValid,
                ExportOfferLetter: letter.ExportOfferLetter,
                OfferPositionName: (self.useThisPositionName ? letter.OfferPositionName : "")
            };
            return copyobject;
        }

        function sendEmail() {
            if (!self.canSendMail()) return;
            if (self.hasFile) getMail();
            else createOfferLetter();
        }

        function finishSendMail() {
            self.isShowLoading = true;
            var action = "SendEmail";
            if (!self.useThisPositionName) {
                self.offerLetter.OfferPositionName = "";
            }

            var mail = new copyOfferLetter(self.offerLetter);
            mail.WorkingStartDate = datetimeSvc.convertDate(mail.WorkingStartDate, true);
            mail.ExportOfferLetter.EmailToSent = self.emailData;
            caOfferLetterCreateSvc.createOfferLetterResource(action).save(mail,
                function () {
                    toastr.success($filter(constants.translate)("Send_Email_Success"));
                    $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
                    self.isShowLoading = false;
                    $timeout(function () {
                        goBack();
                    }, 1000);
                },
                function (xhr) {
                    self.isShowLoading = false;
                    messageHandleSvc.handleResponse(xhr, "Send_Email_Error");
                });
        }

        function createOfferLetter() {
            var action = "OfferLetterPdf";
            self.isShowLoading = true;
            var mail = new copyOfferLetter(self.offerLetter);
            mail.WorkingStartDate = datetimeSvc.convertDate(mail.WorkingStartDate, true);
            caOfferLetterCreateSvc.createOfferLetterResource(action).save(mail, function (data) {
                self.offerLetter.ExportOfferLetter = data;
                getMail();
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            });
        }

        function uploadFile() {
            var fileUpload = document.getElementById("offerLetterAttachment").value;
            if (fileUpload !== '') {

                var offerLetterAttachment = $('#offerLetterAttachment')[0].files[0];
                uploadFileSvc.uploadFile(offerLetterAttachment, caConstants.offerLetterEmployee, $stateParams.candidateId).$promise.then(function (data) {
                    $window.localStorage.setItem('CandidateID', $stateParams.candidateId, { expires: 1 });
                    if (data.value.length > 0) {
                        data.value = data.value.replace('"', '');
                        var array = sliceString(data.value, ',');
                        self.offerLetter.ExportOfferLetter.FilePathToViewOnBrowser = array[0];
                        self.offerLetter.ExportOfferLetter.FileName = array[1];
                        self.offerLetter.ExportOfferLetter.FilePath = array[2];
                        self.file = array[2];
                        self.hasFile = true;
                        getMail();
                        if (!$scope.$$phase && !$scope.$root.$$phase) {
                            $scope.$apply();
                        }
                    }
                });
            }
        }

        function sliceString(string, character) {
            var array = [];
            var lastIndex = 0;
            var value;
            for (lastIndex = 0; string.length > 0; lastIndex++) {
                if (string.indexOf(character) < 0) {
                    value = string;
                    if (value.indexOf('"') >= 0) value = value.replace('"', '');
                    array.push(value);
                    string = "";
                } else {
                    value = string.substr(0, string.indexOf(character));
                    if (value.indexOf('"') >= 0) value = value.replace('"', '');
                    array.push(value);
                    string = string.substr(string.indexOf(character) + 1, string.length);
                }
            }
            return array;
        }

        function removeFile() {
            self.offerLetter.ExportOfferLetter.FilePathToViewOnBrowser = "";
            self.offerLetter.ExportOfferLetter.FileName = "";
            self.offerLetter.ExportOfferLetter.FilePath = "";
            self.file = "";
            self.hasFile = false;
        }

        function changeSalaryOffer() {
            var maxValue = 1000000000, minValue = 100000;
            self.salaryOfferMessage = checkValue(self.offerLetter.SalaryOffer, maxValue, minValue);
            self.salaryChanged = true;
        }

        function changeStartWorkingDate() {
            self.workingStartDateMessage = (self.offerLetter.WorkingStartDate) ? undefined : $filter(constants.translate)("This_Field_Is_Required");
            if (self.offerLetter.WorkingStartDate) {
                var today = moment(new Date());
                var workingDate = moment(self.offerLetter.WorkingStartDate, constants.formatDateDDMMYYYY);
                var diff = workingDate.diff(today, 'days');
                self.workingStartDateMessage = (diff > -1) ? "" : $filter(constants.translate)("Commencement_Date_Must_Greater_Than_Or_Equal_Today");
            }

            self.startWorkindDateChanged = true;
        }

        function changeBasicSalaryOffer() {
            var maxValue = 1000000000, minValue = 100000;
            self.basicSalaryOfferMessage = checkValue(self.offerLetter.BasicSalaryOffer, maxValue, minValue);
            self.basicSalaryChanged = true;
        }

        function changeProbationMonth() {
            var maxValue = 5, minValue = 1;
            self.probationMonthMessage = checkValue(self.offerLetter.MonthProbation, maxValue, minValue);
            self.probationMonthChanged = true;
        }

        function changePercentageSalaryOffer() {
            var maxValue = 100, minValue = 1;
            self.percentageSalaryOfferMessage = checkValue(self.offerLetter.PercentageSalaryOffer, maxValue, minValue);
            self.percentageOfSalaryChanged = true;
        }

        function changeAllowance() {
            var maxValue = 1000000000, minValue = 1;
            self.allowanMessage = checkValue(self.offerLetter.Allowance, maxValue, minValue);
            self.allowanMessage = (!self.offerLetter.Allowance) ? undefined : self.allowanMessage;
            self.allowanceChanged = true;
        }

        function checkValue(value, maxValue, minValue) {
            if (!value) return $filter(constants.translate)("This_Field_Is_Required");
            if (value < minValue) return $filter(constants.translate)("Min_Value_Massage") + minValue;
            if (value > maxValue) return $filter(constants.translate)("Max_Value_Massage") + maxValue;
            if ((minValue > 1 && value % minValue !== 0)) return $filter(constants.translate)("Not_increment") + minValue;
            if ((minValue = 1 && value % minValue !== 0)) return $filter(constants.translate)("Not_integer");
            return undefined;
        }

        function canSendMail() {
            var value;
            value = (!self.offerLetter ||
                self.allowanMessage || self.percentageSalaryOfferMessage ||
                self.probationMonthMessage || self.basicSalaryOfferMessage || self.workingStartDateMessage || self.salaryOfferMessage);
            return comparisonUtilSvc.isNullOrUndefinedValue(value);
        }

        function approveOfferWithoutSendMail() {
            approveOfferLetter();
        }

        function updateToServer(data) {
            var action = "ApproveOfferLetterWithoutSendEmail";
            caOfferLetterCreateSvc.createOfferLetterResource(action).save(data,
                        function () {
                            toastr.success($filter(constants.translate)("Approve_Offer_Letter_Success"));
                            $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
                            self.isShowLoading = false;
                            $timeout(function () {
                                goBack();
                            }, 1000);
                        },
                        function (xhr) {
                            self.isShowLoading = false;
                            messageHandleSvc.handleResponse(xhr, "Approve_Offer_Letter_Error");
                        });
        }
        function approveOfferLetter() {
            self.isShowLoading = true;
            var actionCreateOffer = "OfferLetterPdf";
            if (!self.useThisPositionName) {
                self.offerLetter.OfferPositionName = "";
            }
            var mail = new copyOfferLetter(self.offerLetter);
            mail.WorkingStartDate = datetimeSvc.convertDate(mail.WorkingStartDate, true);
            mail.ExportOfferLetter.EmailToSent = self.emailData;
            if (!self.hasFile) {
                caOfferLetterCreateSvc.createOfferLetterResource(actionCreateOffer).save(mail, function (data) {
                    self.offerLetter.ExportOfferLetter = data;
                    mail.ExportOfferLetter = data;
                    updateToServer(mail);
                });
            } else {
                updateToServer(mail);
            }
        }

        function viewOfferLetter() {
            if (!self.canSendMail()) return;
            self.isOpenOfferLetter = true;
            if (self.hasFile) getMail();
            else createOfferLetter();
        }

        function approveOffer() {
            if (!self.permissionOnPage.isSendOfferLetterPermission && !self.permissionOnPage.isResendOfferLetterPermission) {
                goBack();
            }
            self.isOpenOfferLetter = false;
            self.showSendButton = true;
            if (!self.canSendMail()) return;
            if (self.hasFile) getMail();
            else createOfferLetter();
        }

        function selectReportTo() {
            if (self.ReportTo == _defaultValue) {
                self.isChooseAnotherReport = true;
                return;
            }
            self.isChooseAnotherReport = true;
            self.offerLetter.ReportTo = angular.copy(self.ReportTo);
        }

        function getWarningPositionNameMessage() {
            if (self.isHidePosition) {
                if (!self.useThisPositionName) return "(" + $filter(constants.translate)("Change_The_Position_Offered_To_A_Rea_Massage") + ")";
                if (self.offerLetter.OfferPositionName == self.offerLetter.CandidatePosistion) return "(" + $filter(constants.translate)("Change_The_Position_Offered_To_A_Rea_Massage") + ")";
                if (!self.offerLetter.OfferPositionName) return "(" + $filter(constants.translate)("Change_The_Position_Offered_To_A_Rea_Massage") + ")";
            }
            return "";
        }

    }
})();
