﻿(function () {
    'use strict';
    angular.module('app').controller('caInterviewsCtrl', CaInterviewsCtrl);
    CaInterviewsCtrl.$inject = ['$location', '$state', '$filter', '$scope', '$timeout', '$stateParams', '$window',
        'candidateSvc', 'datetimeSvc', 'moneySvc', 'emailSvc', 'messageHandleSvc', 'permissionSvc', 'caDetailSvc', 'caApplicationsSvc', 'historyPageSvc', 'styleSvc', 'objectSvc',
        'message', 'caMessage', 'constants', 'caConstants', 'caDetailModel', 'interviewSummaryModel', '$rootScope', 'comparisonUtilSvc'];
    function CaInterviewsCtrl($location, $state, $filter, $scope, $timeout, $stateParams, $window,
            candidateSvc, datetimeSvc, moneySvc, emailSvc, messageHandleSvc, permissionSvc, caDetailSvc, caApplicationsSvc, historyPageSvc, styleSvc, objectSvc,
            message, caMessage, constants, caConstants, caDetailModel, interviewSummaryModel, $rootScope, comparisonUtilSvc) {
        var statusDefault = 0;
        var statusSuccess = 1;
        var statusFail = 2;
        var self = this;

        self.isEditMode = false;
        self.isModifiedData = false;
        self.LastUpdateStatus = "";
        self.LastUpdateStatusId = "";
        self.convertDateToShortDate12HourFormat = datetimeSvc.convertDateToShortDate12HourFormat;

        var initialInterviewSummaryDto = {};
        self.interviewSummary = {};
        self.isInvalidSuggestedWorkingDate = false;
        self.answerOfferLetter = "";
        self.isShowLoading = true;
        self.isDisableBecomeEmployee = true;
        self.jobApplicationId = 0;
        self.isDisableOfferLetter = true;
        self.isDisableScheduleInterview = true;
        self.isDisableStartInterview = true;
        self.showCreateOffer = false;
        self.showThankYouLetterIcon = false;
        self.showOfferAttachmentIcon = false;
        self.candidateRejected = false;
        self.newStatusId = constants.applicationStatus.ScreeningCv.New;
        self.offerStatus = "";
        self.rejectCandidate = constants.applicationStatus.Other.RejectAll;
        self.candidateId = $stateParams.id;
        self.listAction = constants.listAction;
        self.screeningStatus = caDetailSvc.getScreeningStatus();
        self.LastestCVUpdateStatus = caDetailSvc.getLastUpdateStatus();

        self.listOfferStatus = translateStatus(constants.offerLetter.listOfferStatus);
        self.candidateBasicInfor = candidateSvc.getCandidateDataMainPage();
        self.formatMoney = formatMoney;
        self.convertDate = convertDate;
        self.addScheduleInterview = addScheduleInterview;
        self.sendOfferLetter = sendOfferLetter;
        self.becomeEmployee = becomeEmployee;
        self.startInterview = startInterview;
        self.editInterview = editInterview;
        self.cancelInterview = cancelInterview;
        self.sendMail = sendMail;
        self.isNewScreeningCv = isNewScreeningCv;
        self.canShowOfferLetterButton = canShowOfferLetterButton;
        self.jobApplicationId = caDetailSvc.getSelectedJobApplicationId();
        self.getOverallStatus = getOverallStatus;
        self.onClickEdit = onClickEdit;
        self.onClickCancel = onClickCancel;
        self.onClickSave = onClickSave;
        self.jobApplications = caApplicationsSvc.getCurrentApplications();
        self.getLastUpdateStatus = getLastUpdateStatus;
        self.getTitle = getTitle;
        self.getCssTitle = getCssTitle;
        self.createNewOffer = createNewOffer;
        self.goToReSchedulePage = goToReSchedulePage;
        self.checkNumber = objectSvc.checkNumber;
        self.getInterviewState = getInterviewState;

        self.permissionOfCurrentUser = {
            addInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_AddInterview),
            editInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_EditInterview),
            viewInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview),
            addSchedule: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_AddSchedule),
            editSchedule: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_EditSchedule),
            viewSchedule: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_ViewScheduleInterview),
            viewOfferLetterPage: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CreateOfferLetter_ViewOfferLetterPage),
            viewOfferLetterStatus: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.UpdateOfferStatus_ViewStatusOfferLetter),
            becomeEmployee: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_BecomeEmployee),
            sendMailRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SendMailUpdateCV),
            canViewEditInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_EditInterview) && permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview),
            canViewReschedules: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_EditSchedule) && permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_ViewScheduleInterview),
            canViewInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_AddInterview) && permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview)
        };

        var jobApplicationId = 0;
        self.createNewOfferfferSendingDate = "";
        self.acceptOfferDate = "";
        self.isHide = false;
        self.interviewIconInfor = [];
        self.currentPositionName = "";
        self.isChangedName = false;
        self.acceptSigningValue = 0;
        init();

        function init() {
            $scope.$on('loadInterviewDataFinish', function (event, rootScopeParams) {
                var data = rootScopeParams.data;
                self.isShowLoading = data.isShowLoading;
                self.isHide = false;
                if (!data.candidateInterview) return;
                self.hasDealSalary = false;
                self.positionStatus = { css: "", text: "" };
                var candidateInterviews = data.candidateInterview;
                self.isHide = candidateInterviews.IsHide;
                self.showThankYouLetterIcon = false;
                self.candidateInterview = candidateInterviews;
                createInterview(self.candidateInterview.Interviews, self.candidateInterview.LastUpdateStatus);
                self.positionStatus = styleSvc.setPositionStatus(self.candidateInterview.JobApplicationStatus);
                candidateInterviews.OverallStatus = formatOverallStatus(candidateInterviews.OverallStatus);
                self.LastUpdateStatus = getLastUpdateStatus(self.candidateInterview.LastUpdateStatus);
                self.LastUpdateStatusId = angular.copy(self.candidateInterview.LastUpdateStatus);
                if (self.LastUpdateStatusId == constants.applicationStatus.Other.RejectAll) {
                    self.candidateRejected = true;
                }
                if (self.LastUpdateStatusId == constants.applicationStatus.Other.RejectAll && !self.candidateInterview.IsSendMail) {
                    self.showThankYouLetterIcon = true;
                }
                self.showOfferAttachmentIcon = self.candidateInterview.HasOfferLetter;
                initialInterviewSummaryDto = new interviewSummaryModel(candidateInterviews, self.candidateId, jobApplicationId);
                self.interviewSummary = new interviewSummaryModel(candidateInterviews, self.candidateId, jobApplicationId);
                checkSalaryInformation();
                if (!self.candidateInterview) return;
                var isServerType = false;
                if (self.candidateInterview.OfferSendingDate) {
                    self.offerSendingDate = datetimeSvc.convertDate(self.candidateInterview.OfferSendingDate, isServerType);
                }
                if (self.candidateInterview.AcceptOfferDate) {
                    self.acceptOfferDate = datetimeSvc.convertDate(self.candidateInterview.AcceptOfferDate, isServerType);
                }
                if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateInterview.IsAcceptSigning)) {
                    self.acceptSigningValue = statusDefault;
                } else {
                    self.acceptSigningValue = (self.candidateInterview.IsAcceptSigning) ? statusSuccess : (self.candidateInterview.IsAcceptSigning === false) ? statusFail : statusDefault;
                    if (self.acceptSigningValue == 2) {
                        self.offerStatus = constants.applicationStatus.OfferStatus.RejectOffer;
                    }
                }
                self.answerOfferLetter = getStatus(self.acceptSigningValue);
                changeSentOfferLetterText();
                setEnableOfferLetter();
                setEnableScheduleInterview();
                setEnableBecomeEmployee();
                candidateSvc.setCandidateDataMainPagePositionName(candidateInterviews.JobApplicationName);
                setPositionName();
                $timeout(function () {
                    self.isShowLoading = false;
                }, 300);
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }

            }, true);

            $scope.$watch('ciCtrl.isActionProcessing', function (value) {
                self.isShowLoading = value;
            }, true);

            $scope.$watch('ciCtrl.jobApplicationId', function (newValue, oldValue) {
                var defaultValue = 0;
                if (!newValue || !newValue.value)
                    return;
                if (newValue.value == defaultValue) return;
                self.isShowLoading = true;
                caDetailSvc.setCandidateId(self.candidateId);
                if (self.jobApplicationId.value > defaultValue) {
                    jobApplicationId = parseInt(self.jobApplicationId.value);
                }
            }, true);

            $scope.$watch('ciCtrl.screeningStatus', function (newValue, oldValue) {
                if (newValue == oldValue || !self.candidateInterview || self.candidateInterview.LastUpdateStatus == newValue.value)
                    return;
                var getUserLoginFromCookie = JSON.parse($window.localStorage.getItem("currentuserlogin"));
                var screeningCvModel = {
                    "JobApplicationId": self.jobApplicationId,
                    "ModifiedDate": datetimeSvc.convertDateForServerSide(new Date(), true),
                    "ModifiedUser": getUserLoginFromCookie.UserId,
                    "ModifiedUserName": getUserLoginFromCookie.FullName,
                    "Note": null,
                    "Status": newValue.value
                };
                self.candidateInterview.LastUpdateStatus = newValue.value;
                self.LastUpdateStatus = getLastUpdateStatus(newValue.value);
                self.candidateInterview.ScreeningCVHistories.push(screeningCvModel);

                if (newValue.value == constants.applicationStatus.Other.RejectAll || newValue.value == constants.applicationStatus.ScreeningCv.Rejected || newValue.value == constants.applicationStatus.ScreeningCv.BlackList) {
                    self.isDisableOfferLetter = true;
                    self.isDisableScheduleInterview = true;
                    self.isDisableStartInterview = true;
                }
            }, true);

            $scope.$watch('ciCtrl.candidateInterview.ScreeningCVHistories', function (newValue, oldValue) {
                setEnableScheduleInterview();
                setEnableOfferLetter();
                if (newValue === oldValue || comparisonUtilSvc.isNullOrUndefinedValue(newValue) || newValue.length === 0)
                    return;
            }, true);

            $scope.$watch('ciCtrl.jobApplications', function (newValue, oldValue) {
                var jobApplicationList = self.jobApplications.appliedPositions;
                self.isEdit = false;
                if (jobApplicationList && jobApplicationList.length > 0) {
                    jobApplicationList.forEach(function (jobApp) {
                        if (jobApp.JobApplicationId == self.jobApplicationId.value) {
                            if (self.candidateInterview && self.candidateInterview.JobApplicationName != jobApp.PositionName) {
                                self.candidateInterview.JobApplicationName = jobApp.PositionName;
                            }
                        }
                    });
                }
                setPositionName();
            }, true);

            $scope.$watch('ciCtrl.interviewSummary', function (newValue, oldValue) {
                if (newValue == oldValue)
                    return;
                else {
                    self.isModifiedData = JSON.stringify(initialInterviewSummaryDto) != JSON.stringify(self.interviewSummary);
                }
            }, true);

            $scope.$watch('ciCtrl.LastestCVUpdateStatus', function (newValue, oldValue) {
                if (newValue == oldValue)
                    return;
                else {
                    self.LastUpdateStatusId = newValue.value;
                    self.LastUpdateStatus = getLastUpdateStatus(newValue.value);
                    if (newValue.value == constants.applicationStatus.ScreeningCv.Rejected && newValue.jobId == self.jobApplicationId.value) {
                        self.candidateInterview.LastUpdateStatus = newValue.value;
                        caDetailSvc.setCurrentPosition(self.candidateInterview);
                    }
                    if (newValue.value == constants.applicationStatus.Other.RejectAll && newValue.jobId == self.jobApplicationId.value) {
                        self.isDisableScheduleInterview = true;
                        self.candidateInterview.LastUpdateStatus = newValue.value;
                        self.isDisableOfferLetter = true;
                        self.isDisableStartInterview = true;
                        if (self.LastUpdateStatusId == constants.applicationStatus.Other.RejectAll && !self.candidateInterview.IsSendMail) {
                            self.showThankYouLetterIcon = true;
                        }
                        caDetailSvc.setCurrentPosition(self.candidateInterview, self.LastestCVUpdateStatus);
                        createInterview(self.candidateInterview.Interviews);
                        if (!self.candidateInterview.Interviews || self.candidateInterview.Interviews.length === 0) return;
                        for (var index = 0; index < self.candidateInterview.Interviews.length; index++) {
                            if (!self.candidateInterview.Interviews[index].InterviewRound.IsFinished)
                                self.candidateInterview.Interviews[index].InterviewRound.IsCanceled = true;
                        }
                    }
                }

            }, true);

            $scope.$on(constants.broadCastTile.emailSent, function () {
                self.showThankYouLetterIcon = false;
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            });

            $(".modal-backdrop").remove();
        }

        function createInterview(interviewList, currentStatus) {
            self.interviewIconInfor = [];
            if (!interviewList || interviewList.length === 0) return;
            for (var index = 0; index < interviewList.length; index++) {
                var infor = interviewList[index].InterviewRound;
                var inteviewResult = convertInterviewResult(infor.Result);
                var item = {
                    result: inteviewResult,
                    bookRoomDate: infor.FromBookRoomDate,
                    currentStatus: currentStatus,
                    isFinish: infor.IsFinished,
                    isCanceled: infor.IsCanceled,
                    scheduleId: infor.ScheduleInterviewId,
                    interviewId: infor.InterviewId,
                    title: getInterviewName(index, inteviewResult)
                };
                self.interviewIconInfor.push(interviewRoundDisplay(item));
            }
        }

        function getInterviewName(index, result) {
            switch ((index)) {
                case 0:
                    return $filter(constants.translate)("1st_Interview") + $filter(constants.translate)(result);
                case 1:
                    return $filter(constants.translate)("2nd_Interview") + $filter(constants.translate)(result);
                case 2:
                    return $filter(constants.translate)("3rd_Interview") + $filter(constants.translate)(result);
                default:
                    return "";
            }
        }

        function convertInterviewResult(result) {

            if (result == constants.applicationStatus.FirstInterview.Passed ||
                result == constants.applicationStatus.SecondInterview.Passed ||
                result == constants.applicationStatus.ThirdInterview.Passed) {
                return constants.interviewResult.passText;
            }

            if (result == constants.applicationStatus.FirstInterview.Rejected ||
                result == constants.applicationStatus.SecondInterview.Rejected ||
                result == constants.applicationStatus.ThirdInterview.Rejected) {
                return constants.interviewResult.rejectText;
            }
            return "";
        }

        function interviewRoundDisplay(interview) {
            var item = {};
            var interviewTime = interview.bookRoomDate ? (" " + moment(interview.bookRoomDate).format(constants.formatDateDDMMYYYY)) : "";
            item.result = interview.result;
            if (interview.result == constants.stringEmpty && interview.bookRoomDate != constants.stringEmpty) {
                if (interview.overallStatus == constants.applicationStatus.Other.RejectAll)
                    item.result = constants.applicationStatus.Other.RejectAll;
                else item.result = constants.interviewResult.scheduledDate;
                interview.title = interview.title + interviewTime;
            }
            item.id = interview.interviewId;
            item.ScheduleId = interview.scheduleId;
            item.currentStatus = interview.currentStatus;
            item.isFinish = interview.isFinish;
            item.isCanceled = interview.isCanceled;
            item.bookRoomDate = interview.bookRoomDate;
            item.title = interview.isCanceled ? $filter(constants.translate)("Canceled") + ": " + interview.title : interview.title;
            item.visible = interview.result || interview.bookRoomDate != constants.stringEmpty ? true : false;
            return item;
        }

        function loadData(candidateId, currentJobApplicationId) {
            self.hasDealSalary = false;
            self.positionStatus = { css: "", text: "" };
            //candidateSvc.getCandidateInforData(candidateId, function () {
            var candidateInterviews = candidateSvc.interviewResource(candidateId, currentJobApplicationId).get(
                function () {
                    var currentJobApplication = caDetailSvc.getSelectedJobApplicationId();
                    if (currentJobApplication.value != currentJobApplicationId) return;
                    self.showThankYouLetterIcon = false;
                    self.candidateInterview = candidateInterviews;
                    self.positionStatus = styleSvc.setPositionStatus(self.candidateInterview.JobApplicationStatus);
                    candidateInterviews.OverallStatus = formatOverallStatus(candidateInterviews.OverallStatus);
                    self.LastUpdateStatus = getLastUpdateStatus(self.candidateInterview.LastUpdateStatus);
                    self.LastUpdateStatusId = angular.copy(self.candidateInterview.LastUpdateStatus);
                    caDetailSvc.updateSelectedJobApplication(currentJobApplicationId);
                    if (self.LastUpdateStatusId == constants.applicationStatus.Other.RejectAll) {
                        self.candidateRejected = true;
                    }
                    if (self.LastUpdateStatusId == constants.applicationStatus.Other.RejectAll && !self.candidateInterview.IsSendMail) {
                        self.showThankYouLetterIcon = true;
                    }
                    self.showOfferAttachmentIcon = self.candidateInterview.HasOfferLetter;
                    initialInterviewSummaryDto = new interviewSummaryModel(candidateInterviews, self.candidateId, jobApplicationId);
                    self.interviewSummary = new interviewSummaryModel(candidateInterviews, self.candidateId, jobApplicationId);
                    checkSalaryInformation();
                    if (!self.candidateInterview) return;
                    var isServerType = false;
                    if (self.candidateInterview.OfferSendingDate) {
                        self.candidateInterview.OfferSendingDate = datetimeSvc.convertDate(self.candidateInterview.OfferSendingDate, isServerType);
                    }
                    if (self.candidateInterview.AcceptOfferDate) {
                        self.candidateInterview.AcceptOfferDate = datetimeSvc.convertDate(self.candidateInterview.AcceptOfferDate, isServerType);
                    }
                    if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateInterview.IsAcceptSigning)) {
                        self.acceptSigningValue = statusDefault;
                    } else {
                        self.acceptSigningValue = (self.candidateInterview.IsAcceptSigning) ? statusSuccess : (self.candidateInterview.IsAcceptSigning === false) ? statusFail : statusDefault;
                        if (self.acceptSigningValue == 2) {
                            self.offerStatus = constants.applicationStatus.OfferStatus.RejectOffer;
                        }
                    }
                    self.answerOfferLetter = getStatus(self.acceptSigningValue);
                    changeSentOfferLetterText();
                    setEnableOfferLetter();
                    setEnableScheduleInterview();
                    setEnableBecomeEmployee();
                    candidateSvc.setCandidateDataMainPagePositionName(candidateInterviews.JobApplicationName);
                    setPositionName();
                    $timeout(function () {
                        self.isShowLoading = false;
                    }, 300);
                    if (!$scope.$$phase && !$scope.$root.$$phase) {
                        $scope.$apply();
                    }
                },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    checkSalaryInformation();
                    messageHandleSvc.handleResponse(xhr, caMessage.interview.getCandidateInterviewError, doesNotShow);
                });
            //});
        }

        function checkSalaryInformation() {
            if (!self.candidateInterview) {
                self.hasDealSalary = false;
                return false;
            }
            self.hasDealSalary = self.candidateInterview.SuggestedWorkingDate || self.candidateInterview.SuggestedSalary ||
                self.candidateInterview.ExpectedSalary || self.candidateInterview.CurrentSalary;
            return self.hasDealSalary;
        }

        function getStatus(value) {
            var length = self.listOfferStatus.length;
            if (value >= length || value < 0) return "";
            for (var index = 0; index < length; index++) {
                if (self.listOfferStatus[index].id == value) return self.listOfferStatus[index].name;
            }
            return "";
        }

        function translateStatus(statuses) {
            var results = [];
            for (var index = 0; index < statuses.length; index++) {
                var value = { id: statuses[index].id, name: $filter(constants.translate)(statuses[index].name) };
                results.push(value);
            }
            return results;
        }

        function formatOverallStatus(overallStatus) {
            var overallStatusString = ' ';
            switch (overallStatus) {
                case caConstants.candidateInterview.FormatOverallStatus.rejectStatus:
                    overallStatusString = constants.interviewResult.rejectText;
                    break;
                case caConstants.candidateInterview.FormatOverallStatus.passStatus:
                    overallStatusString = constants.interviewResult.inProgressText;
                    break;
                case caConstants.candidateInterview.FormatOverallStatus.onholdStatus:
                    overallStatusString = constants.interviewResult.onHoldText;
                    break;
                case caConstants.candidateInterview.FormatOverallStatus.blacklistStatus:
                    overallStatusString = constants.interviewResult.blackListText;
                    break;
                case caConstants.candidateInterview.FormatOverallStatus.newStatus:
                    overallStatusString = constants.interviewResult.newText;
                    break;
                case caConstants.candidateInterview.FormatOverallStatus.openStatus:
                    overallStatusString = constants.interviewResult.openText;
                    break;
                case caConstants.candidateInterview.FormatOverallStatus.successStatus:
                    overallStatusString = constants.interviewResult.successfulText;
                    break;
                case caConstants.candidateInterview.FormatOverallStatus.shortlist:
                    overallStatusString = constants.interviewResult.newText;
                    break;
                default:
            }
            return overallStatusString;
        }

        function changeSentOfferLetterText() {
            var sentOfferLetterString = $filter(constants.translate)(caConstants.sentOfferLetter);
            self.changeUpdateOfferLetterText = function () {
                self.isUpdateOfferLetter = self.candidateInterview.HasOfferLetter;
                sentOfferLetterString = self.isUpdateOfferLetter ? $filter(constants.translate)(caConstants.updateOfferLetter) : $filter(constants.translate)(caConstants.offerJob);
                self.showCreateOffer = self.isUpdateOfferLetter ? true : false;
                return sentOfferLetterString;
            };
        }

        function setEnableOfferLetter() {
            self.isDisableOfferLetter = true;
            if (self.candidateInterview && (self.candidateInterview.JobApplicationName) && (self.candidateInterview.ScreeningCVHistories) && (self.candidateInterview.ScreeningCVHistories).length > 0) {
                $.each(self.candidateInterview.ScreeningCVHistories, function (index, screeningCv) {
                    self.isDisableOfferLetter = (screeningCv.Status == caConstants.scheduleInterview.passStatus || screeningCv.Status == caConstants.scheduleInterview.openStatus) ? false : true;
                });
            }
            if (self.candidateInterview && self.candidateInterview.LastUpdateStatus == constants.applicationStatus.Other.RejectAll) {
                self.isDisableOfferLetter = true;
            }
        }

        function setEnableScheduleInterview() {
            if (self.candidateInterview && (self.candidateInterview.ScreeningCVHistories) && (self.candidateInterview.ScreeningCVHistories).length > 0) {
                $.each(self.candidateInterview.ScreeningCVHistories, function (index, screeningCv) {
                    self.isDisableScheduleInterview = (screeningCv.Status == constants.applicationStatus.ScreeningCv.Interested || screeningCv.Status == constants.applicationStatus.ScreeningCv.Passed) ? false : true;
                    self.isDisableStartInterview = self.isDisableScheduleInterview;
                });
            } else {
                self.isDisableScheduleInterview = true;
            }

            //createInterview(self.candidateInterview.Interviews);
            if (!!self.candidateInterview && !!self.candidateInterview.Interviews && self.candidateInterview.Interviews.length > 0) {
                var lastInterview = self.candidateInterview.Interviews[self.candidateInterview.Interviews.length - 1];
                if (lastInterview.InterviewRound.LevelRound == caConstants.levelRound.thirdRound) {
                    self.isDisableScheduleInterview = true;
                    self.isDisableStartInterview = false;
                }
            }

            if (self.candidateInterview && self.candidateInterview.HasOfferLetter) {
                self.isDisableScheduleInterview = true;
            }

            if (self.candidateInterview && self.candidateInterview.LastUpdateStatus == constants.applicationStatus.Other.RejectAll) {
                self.isDisableScheduleInterview = true;
                self.isDisableStartInterview = true;
            }
        }

        function setEnableBecomeEmployee() {
            self.hasPermission = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_BecomeEmployee);
            self.isCandidateAcceptOfferLetter = candidateSvc.candidateInforData.IsBecomeEmployee;
            var isAcceptSigning =false;
            if (!comparisonUtilSvc.isNullOrUndefinedValue(self.acceptSigningValue)) {
                isAcceptSigning = (self.acceptSigningValue === 1) ? true : false;
            } else {
                isAcceptSigning = false;
            }
            self.isDisableBecomeEmployee = (self.candidateInterview.HasOfferLetter && self.hasPermission && isAcceptSigning) ? false : true;
        }

        function formatMoney(number, places, symbol, thousand) {
            var minValue = 0;
            if (!number || isNaN(number) || number <= minValue) return "";
            return moneySvc.formatMoney(number, places, symbol, thousand);
        }

        function convertDate(date, isDateTime) {
            return datetimeSvc.convertDateHour(date, isDateTime);
        }

        function addScheduleInterview() {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + $state.params.id + "/job-application/" + jobApplicationId + "/schedule-interview/" + 0, window.location.href);
            $state.go('scheduleInterview', {
                id: $state.params.id, jobApplicationId: jobApplicationId, interviewId: 0
            });
        }

        function sendOfferLetter() {
            if (self.candidateInterview.HasOfferLetter) {
                $state.go('offerLetterStatus', { candidateId: self.candidateId, jobApplicationId: self.jobApplicationId.value });
            } else {
                $state.go('offerLetterCreate', { candidateId: self.candidateId, jobApplicationId: self.jobApplicationId.value });
            }
        }

        function becomeEmployee() {
            $state.go("become-employee", { candidateId: self.candidateId, jobApplicationId: jobApplicationId });
        }

        function startInterview(interviewId) {
            if (!self.permissionOfCurrentUser.addInterview) return;
            var interviewTabUrl = 'candidates/' + self.candidateId + '/interviews';
            $location.path(interviewTabUrl);
            $location.replace();
            history.pushState(null, "conduct-interview", $location.absUrl());
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/interviews/" + interviewId + "/conduct-interview", window.location.href);
            $state.go('conductInterview', {
                interviewId: interviewId
            });
        }

        function editInterview(interviewId) {
            if (!self.permissionOfCurrentUser.editInterview) return;
            var interviewTabUrl = 'candidates/' + self.candidateId + '/interviews';
            $location.path(interviewTabUrl);
            $location.replace();
            history.pushState(null, "conduct-interview", $location.absUrl());
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/interviews/" + interviewId + "/conduct-interview", window.location.href);
            $state.go('conductInterview', {
                interviewId: interviewId
            });
        }

        function cancelInterview(interviewId) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/interviews/" + interviewId + "/cancel-interview", window.location.href);
            $state.go('cancelInterview', {
                interviewId: interviewId
            });
        }

        function sendMail() {
            emailSvc.data.emailDto.IsCreate = !self.candidateInterview.HasOfferLetter;
            emailSvc.data.emailDto.CandidateFirstName = self.candidateInterview.FirstName;
            emailSvc.data.emailDto.CandidateFullName = self.candidateInterview.FullName;
            emailSvc.data.emailDto.LastName = self.candidateInterview.LastName;
            if (self.candidateInterview.HasOfferLetter) {
                candidateSvc.offerLetter(emailSvc.data.emailDto).update(function () {
                }, function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, caMessage.error, doesNotShow);

                });
            } else {
                candidateSvc.addNewOfferLetter(emailSvc.data.emailDto, 'SendEmail').save(emailSvc.data.emailDto, function () {
                    self.candidateInterview.HasOfferLetter = true;
                }, function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, caMessage.error, doesNotShow);
                });
            }
        }

        function isNewScreeningCv() {
            if (self.candidateInterview) {
                var newStatus = 'New';
                if ((!!self.candidateInterview.ScreeningCVHistories && self.candidateInterview.ScreeningCVHistories.length > 0) || jobApplicationId === 0 || self.candidateInterview.OverallStatus != newStatus)
                    return true;
                return false;
            }
            return true;
        }

        function canShowOfferLetterButton() {
            if (!self.candidateInterview) return false;
            return self.candidateInterview.HasOfferLetter ? self.permissionOfCurrentUser.viewOfferLetterStatus : self.permissionOfCurrentUser.viewOfferLetterPage;
        }

        function getOverallStatus() {
            var result = 'New';
            if (!self.candidateInterview) return result;
            if (self.candidateInterview.HasOfferLetter) return 'Successful';
            if (!!self.candidateInterview.ScreeningCVHistories && self.candidateInterview.ScreeningCVHistories.length > 0) {
                $.each(self.candidateInterview.ScreeningCVHistories, function (index, screeningCv) {
                    result = formatOverallStatus(parseInt(screeningCv.Status));
                });
                if (!self.candidateInterview.Interviews || self.candidateInterview.Interviews.length === 0) {
                    return result;
                } else {
                    result = "In Progress";
                    return result;
                }
            }
            return result;
        }

        function onClickEdit() {
            self.isEditMode = !self.isEditMode;
            $timeout(function () {
                $('.date').datepicker({ autoclose: true, todayHighlight: true });
            }, 200);
        }

        function onClickCancel() {
            self.interviewSummary = new interviewSummaryModel(initialInterviewSummaryDto, self.candidateId, jobApplicationId);
            self.isInvalidSuggestedWorkingDate = false;
            $timeout(function () {
                self.isEditMode = !self.isEditMode;
                self.isModifiedData = false;
                checkSalaryInformation();
            });
        }

        function onClickSave() {
            self.interviewSummary.StartDateSuggest = datetimeSvc.convertDateForServerSide(self.interviewSummary.SuggestedWorkingDateOnView, false);

            if (moment(self.interviewSummary.StartDateSuggest).isValid() === false) {
                self.isInvalidSuggestedWorkingDate = true;
                return;
            }
            if (moment().isAfter(self.interviewSummary.StartDateSuggest, 'day') === true) {
                self.isInvalidSuggestedWorkingDate = true;
                return;
            }

            self.isInvalidSuggestedWorkingDate = false;
            candidateSvc.interviewResource(self.candidateId, jobApplicationId, "UpdateSummaryForInterview").update(self.interviewSummary,
                    function (result) {
                        messageHandleSvc.handleResponse(result, caMessage.interview.updateSalaryInformationSuccessful);
                        self.candidateInterview.CurrentSalary = self.interviewSummary.CurrentSalary;
                        self.candidateInterview.ExpectedSalary = self.interviewSummary.ExpectedSalary;
                        self.candidateInterview.SuggestedSalary = self.interviewSummary.SuggestedSalary;
                        self.candidateInterview.SuggestedWorkingDate = (self.interviewSummary.SuggestedWorkingDateOnView) ? new Date(moment(self.interviewSummary.SuggestedWorkingDateOnView, constants.formatDateDDMMYYYY)) : "";
                        initialInterviewSummaryDto = new interviewSummaryModel(self.candidateInterview, self.candidateId, jobApplicationId);
                        self.isModifiedData = false;
                        self.isEditMode = false;
                        checkSalaryInformation();
                    },
                    function (xhr) {
                        checkSalaryInformation();
                        messageHandleSvc.handleResponse(xhr, caMessage.interview.updateSalaryInformationFail);
                    });
        }

        function getLastUpdateStatus(statusId) {
            var resultTitle = "";
            statusId = safeToString(statusId);
            switch (statusId) {
                case constants.applicationStatus.ScreeningCv.Interested:
                case constants.applicationStatus.ScreeningCv.Rejected:
                case constants.applicationStatus.ScreeningCv.OnHold:
                case constants.applicationStatus.ScreeningCv.BlackList:
                case constants.applicationStatus.ScreeningCv.New:
                    return getTitle(statusId).toUpperCase();
                case constants.applicationStatus.ScreeningCv.Passed:
                    return (getTitle(statusId) + " " + $filter(constants.translate)("Interviews.Screening")).toUpperCase();
                case constants.applicationStatus.OfferStatus.AlreadySent:
                    return (getOfferStatus(statusId)).toUpperCase();
                case constants.applicationStatus.OfferStatus.AcceptOffer:
                case constants.applicationStatus.OfferStatus.RejectOffer:
                    return ($filter(constants.translate)("Offer_Letter.Offer_Title") + " " + getOfferStatus(statusId)).toUpperCase();
                case constants.applicationStatus.Other.RejectAll:
                    return $filter(constants.translate)("Rejected");
                case constants.applicationStatus.Other.Shortlist:
                    return $filter(constants.translate)("Shortlisted");
                case constants.applicationStatus.FirstInterview.New:
                case constants.applicationStatus.FirstInterview.Passed:
                case constants.applicationStatus.FirstInterview.Rejected:
                    resultTitle = getInterviewStatus(statusId);
                    return ($filter(constants.translate)("Interviews.First_Interview") + " " + resultTitle).toUpperCase();
                case constants.applicationStatus.SecondInterview.New:
                case constants.applicationStatus.SecondInterview.Passed:
                case constants.applicationStatus.SecondInterview.Rejected:
                    resultTitle = getInterviewStatus(statusId);
                    return ($filter(constants.translate)("Interviews.Second_Interview") + " " + resultTitle).toUpperCase();
                case constants.applicationStatus.ThirdInterview.New:
                case constants.applicationStatus.ThirdInterview.Passed:
                case constants.applicationStatus.ThirdInterview.Rejected:
                    resultTitle = getInterviewStatus(statusId);
                    return ($filter(constants.translate)("Interviews.Third_Interview") + " " + resultTitle).toUpperCase();
            }
            return "";
        }

        function getOfferStatus(statusId) {
            switch (statusId) {
                case constants.applicationStatus.OfferStatus.AlreadySent:
                    return $filter(constants.translate)("Offer_Letter.Offered");
                case constants.applicationStatus.OfferStatus.AcceptOffer:
                    return $filter(constants.translate)("Offer_Letter.Accepted");
                case constants.applicationStatus.OfferStatus.RejectOffer:
                    return $filter(constants.translate)("Offer_Letter.Rejected");
                default: return "";
            }
        }

        function getInterviewStatus(statusId) {
            if (statusId == constants.applicationStatus.FirstInterview.Passed ||
                statusId == constants.applicationStatus.SecondInterview.Passed ||
                statusId == constants.applicationStatus.ThirdInterview.Passed)
                return $filter(constants.translate)("Passed");
            if (statusId == constants.applicationStatus.FirstInterview.New ||
                statusId == constants.applicationStatus.SecondInterview.New ||
                statusId == constants.applicationStatus.ThirdInterview.New)
                return $filter(constants.translate)("Interviews.In_Progress");
            if (statusId == constants.applicationStatus.FirstInterview.Rejected ||
                statusId == constants.applicationStatus.SecondInterview.Rejected ||
                statusId == constants.applicationStatus.ThirdInterview.Rejected)
                return $filter(constants.translate)("Rejected");
            return "";
        }

        function getTitle(statusId) {
            return styleSvc.setTitle(statusId);
        }

        function getCssTitle(statusId) {
            return styleSvc.setStatusCss(statusId);
        }

        function goToReSchedulePage(candidateId, jobAppId, interviewId) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + candidateId + "/job-application/" + jobAppId + "/schedule-interview/" + interviewId, window.location.href);
            $state.go('scheduleInterview', { id: candidateId, jobApplicationId: jobApplicationId, interviewId: interviewId });
        }

        function getInterviewState(interview) {
            if (!interview || !interview.InterviewRound) return "";
            if (interview.InterviewRound.IsCanceled) {
                return interview.InterviewRound.IntRndName + " - Canceled";
            }
            return interview.InterviewRound.IntRndName;
        }

        function createNewOffer() {
            $state.go('offerLetterCreate', { candidateId: self.candidateId, jobApplicationId: self.jobApplicationId.value });
        }

        function setPositionName() {
            if (!self.candidateInterview || !self.candidateInterview.JobApplicationName) {
                self.isChangedName = false;
                self.currentPositionName = "";
                return "";
            }
            if (!self.candidateInterview.OfferPositionName || (self.candidateInterview.JobApplicationName == self.candidateInterview.OfferPositionName)) {
                self.isChangedName = false;
                self.currentPositionName = angular.copy(self.candidateInterview.JobApplicationName);
                return self.candidateInterview.JobApplicationName;
            }
            self.isChangedName = true;
            self.currentPositionName = angular.copy(self.candidateInterview.OfferPositionName);
            return self.candidateInterview.OfferPositionName;
        }
    }
})();
