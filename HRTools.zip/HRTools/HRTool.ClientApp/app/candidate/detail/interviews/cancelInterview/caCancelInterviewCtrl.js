﻿(function () {
    'use strict';
    angular.module('app').controller('caCancelInterviewCtrl', CaCancelInterviewCtrl);
    CaCancelInterviewCtrl.$inject = ['$state', '$filter', '$timeout', 'constants', 'caConstants', 'message', 'styleSvc', 'emailSvc', 'caScheduleInterviewSvc', 'permissionSvc', 'objectSvc', 'authenticationSvc', 'messageHandleSvc', 'historyPageSvc', 'caMessage', '$resource'];
    function CaCancelInterviewCtrl($state, $filter, $timeout, constants, caConstants, message, styleSvc, emailSvc, caScheduleInterviewSvc, permissionSvc, objectSvc, authenticationSvc, messageHandleSvc, historyPageSvc, caMessage, $resource) {
        var emailInterviewType = 2;
        var interviewId = $state.params.interviewId;
        var data = null;
        var previewEmailType = { Candidate: 1, Interviewer: 2 };
        var candidateActionType = "Preview cancel email (Candidate)";
        var interviewerActionType = "Preview cancel email (Interviewer)";
        var self = this;
        var candidateTemMail = {}, employeeTemMail = {};
        var candidateToogle = true;
        var interviewerToogle = true;
        self.currentUserPermission = permissionSvc.getCurrentUserPermission();
        if (!self.currentUserPermission.canViewSchedule) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }
        self.emailDisabled = true;
        self.isSendMailToCandidateChecked = true;
        self.isSendMailToInterviewerChecked = true;
        self.candidateName = "";
        self.interviewerName = "";
        self.interviewerEmailContent = {};
        self.candidateEmailContent = {};
        self.classForCandidateHeader = "";
        self.classForInterviewerHeader = "";

        self.getHeaderStyle = getHeaderStyle;
        self.finish = finish;
        self.openPreviewEmailModal = openPreviewEmailModal;
        self.onClickHeader = onClickHeader;
        self.onClickCollapseButton = onClickCollapseButton;
        self.openConfirmModal = openConfirmModal;
        self.finish = finish;
        self.cancel = cancel;

        init();
        function init() {
            clearOverlay(true);
            self.canShowFinish = self.currentUserPermission.canEditSchedule || self.currentUserPermission.canAddSchedule;
            caScheduleInterviewSvc.interviewInfoForCanceling(interviewId).get(function (result) {
                data = result;
                self.candidateName = data.FullNameCandidate;
                self.interviewerName = data.InterviewerName;
                var dataForGetMail = convertDataForGetMail(data);
                getEmail(dataForGetMail, candidateActionType);
                getEmail(dataForGetMail, interviewerActionType);
                self.emailData = emailSvc.data;
            });


            self.previewEmail = {};
            self.classForCandidateHeader = getCssHeaderClass(candidateToogle);
            self.classForInterviewerHeader = getCssHeaderClass(interviewerToogle);
        }

        function getEmail(scheduleInterview, emailType) {
            scheduleInterview.ActionType = emailType;
            emailSvc.getEmailTempateByIdType(emailInterviewType, scheduleInterview, function () {
                if (emailType == candidateActionType) {
                    candidateTemMail = {};
                    if (emailSvc.data.emailDto)
                        angular.copy(emailSvc.data.emailDto, candidateTemMail);
                    self.candidateEmail = {};
                    if (emailSvc.data.emailDto)
                        angular.copy(emailSvc.data.emailDto, self.candidateEmail);
                    $timeout(function () {
                        angular.copy(candidateTemMail, self.candidateEmail);
                    }, 200);
                }
                if (emailType == interviewerActionType) {
                    employeeTemMail = {};
                    if (emailSvc.data.emailDto)
                        angular.copy(emailSvc.data.emailDto, employeeTemMail);
                    self.interviewerEmail = {};
                    if (emailSvc.data.emailDto)
                        angular.copy(emailSvc.data.emailDto, self.interviewerEmail);
                    $timeout(function () {
                        angular.copy(employeeTemMail, self.interviewerEmail);
                        clearOverlay();
                    }, 200);
                }
            }, function (error) {
                messageHandleSvc.handleResponse(error, message.errorLoadingData);
            });
        }

        function getHeaderStyle() {
            return styleSvc.getHeaderStyle(self.isSkillEditing);
        }

        function copyEmail(source, target) {
            target.subject = source.Subject;
            target.emailTo = source.To;
            target.content = source.Content;
        }

        function openPreviewEmailModal() {
            $('#preview-email-modal').modal('show');
        }

        function onClickCollapseButton(event) {
            var target = $(event.target);
            self.isCandidate = !self.isCandidate;
            candidateActionType = "Preview email (Candidate)";
            interviewerActionType = "Preview email (Interviewer)";
            data.ActionType = candidateActionType;

            if (!self.isCandidate) {
                data.ActionType = interviewerActionType;
            }
            if (target.attr('id') == "candidate-email-part-collapse") {
                candidateToogle = !candidateToogle;
                $("#candidate-email-tab").slideToggle("slow");
                $('#cke_CandidateEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                self.classForCandidateHeader = getCssHeaderClass(candidateToogle);
            } else {
                interviewerToogle = !interviewerToogle;
                $("#interviewer-email-tab").slideToggle("slow");
                $('#cke_InterviewerEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                self.classForInterviewerHeader = getCssHeaderClass(interviewerToogle);
            }
        }

        function onClickHeader(event) {
            var target = $(event.target);
            self.isCandidate = !self.isCandidate;
            candidateActionType = "Preview email (Candidate)";
            interviewerActionType = "Preview email (Interviewer)";
            data.ActionType = candidateActionType;

            if (!self.isCandidate) {
                data.ActionType = interviewerActionType;
            }
            if (target.attr('id') == "candidate-email-part-header" || target.attr('id') == "candidate-mail-checkbox") {
                if ($("#candidate-email-tab").css('display') == 'none' && $('#candidate-mail-checkbox').is(':checked')) {
                    candidateToogle = true;
                    $("#candidate-email-tab").slideToggle("slow");
                    $('#cke_CandidateEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                    self.classForCandidateHeader = getCssHeaderClass(candidateToogle);
                }
                if ($("#candidate-email-tab").css('display') == 'block' && !$('#candidate-mail-checkbox').is(':checked')) {
                    candidateToogle = false;
                    $("#candidate-email-tab").slideToggle("slow");
                    $('#cke_CandidateEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                    self.classForCandidateHeader = getCssHeaderClass(candidateToogle);
                }
            } else {
                if ($("#interviewer-email-tab").css('display') == 'none' && $('#interviewer-mail-checkbox').is(':checked')) {
                    interviewerToogle = true;
                    $("#interviewer-email-tab").slideToggle("slow");
                    $('#cke_InterviewerEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                    self.classForInterviewerHeader = getCssHeaderClass(interviewerToogle);
                }
                if ($("#interviewer-email-tab").css('display') == 'block' && !$('#interviewer-mail-checkbox').is(':checked')) {
                    interviewerToogle = false;
                    $("#interviewer-email-tab").slideToggle("slow");
                    $('#cke_InterviewerEmailMessage .cke_inner .cke_contents .cke_reset').contents().find('.cke_editable').css("overflow-y", "auto !important");
                    self.classForInterviewerHeader = getCssHeaderClass(interviewerToogle);
                }
            }
            event.stopPropagation();
        }

        function getCssHeaderClass(state) {
            return state && 'col-xs-1 fa fa-2x fa-caret-down' || 'col-xs-1 fa fa-2x fa-caret-right';
        }

        function openConfirmModal() {
            backToInterviewsTab();
        }

        function clearOverlay(isShow) {
            if (isShow) {
                $(constants.loadingIcon.overlay).show();
                $(constants.loadingIcon.indicator).show();
            } else {
                $(constants.loadingIcon.overlay).hide();
                $(constants.loadingIcon.indicator).hide();
                $('.modal-backdrop').remove();
            }
        }

        function backToInterviewsTab() {
            $timeout(function () {
                var url = constants.baseUrl + "#/interviews/" + interviewId + "/cancel-interview";
                var previousUrl = historyPageSvc.getPreviousUrl(url);
                if (previousUrl && previousUrl.indexOf("/#/candidates/") == -1) {
                    historyPageSvc.getPreviousUrl(url, "");
                    window.location.href = previousUrl;
                    return;
                }
                historyPageSvc.setPreviousUrl(url, "");
                $state.go('candidateDetail', {
                    id: data.CandidateId
                }).then(function() {
                    clearOverlay(false);
                });
                return;
            }, 1500);
        }

        function cancel() {
            backToInterviewsTab();
        }

        function finish() {
            caScheduleInterviewSvc.interviewInfoForCanceling(interviewId).update(function () {
                if (self.isSendMailToCandidateChecked) {
                    self.candidateEmail.IsCandidate = true;
                    scheduleEmail().sendScheduleEmail(self.candidateEmail,
                        function () {

                        }, function (xhr) {
                            messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                        }
                     );
                }
                // Send email to interview
                if (self.isSendMailToInterviewerChecked) {
                    self.interviewerEmail.IsCandidate = false;
                    scheduleEmail().sendScheduleEmail(self.interviewerEmail,
                        function () {

                        }, function (xhr) {
                            messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                        }
                     );
                }
                toastr.success($filter(constants.translate)(caMessage.interview.cancelInterviewSuccessful));
                cancel();
            }, function (error) {
                messageHandleSvc.handleResponse(error, caMessage.interview.cancelInterviewFail);
            });
        }

        function scheduleEmail() {
            return $resource(constants.apiUrl + 'emails/', {},
                { "sendScheduleEmail": { method: "POST", headers: { ActionName: "cancelScheduleEmail" } } });
        }

        function convertDataForGetMail(data) {
            var dataForGetMail = {
                CanDtlId: data.JobApplicationId,
                CandidateId: data.CandidateId,
                InterviewId: data.InterviewId,
                SchId: data.ScheduleInterviewId
            };

            return dataForGetMail;
        }

    }
})();
