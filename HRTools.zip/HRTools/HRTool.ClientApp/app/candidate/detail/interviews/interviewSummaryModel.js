﻿(function () {
    "use strict";
    angular.module('app').factory('interviewSummaryModel', interviewSummaryModel);
    interviewSummaryModel.$inject = ['constants'];

    function interviewSummaryModel(constants) {
        return interviewSummaryModel;

        function interviewSummaryModel(interview, candidateId, jobApplicationId) {
            /* jshint -W040 */
            var self = this;
            self.Id = jobApplicationId;
            self.CandidateId = candidateId;
            self.CurrentSalary = interview.CurrentSalary || '';
            self.ExpectedSalary = interview.ExpectedSalary || '';
            self.SuggestedSalary = interview.SuggestedSalary || '';
            self.SuggestedWorkingDate = interview.SuggestedWorkingDate;
            self.StartDateSuggest = null;
            self.SuggestedWorkingDateOnView = (interview.SuggestedWorkingDate) ? moment(interview.SuggestedWorkingDate).format(constants.formatDateDDMMYYYY) : "";
            return self;
        }
    }
})();