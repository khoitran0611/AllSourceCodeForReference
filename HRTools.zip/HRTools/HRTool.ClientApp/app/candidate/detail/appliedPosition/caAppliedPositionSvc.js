﻿(function () {
    'use strict';
    angular.module('app').factory('caAppliedPositionSvc', caAppliedPositionSvc);
    caAppliedPositionSvc.$inject = [
        "$resource", "$filter", "caDetailSvc", "messageHandleSvc", "constants", "message", "comparisonUtilSvc"];
    function caAppliedPositionSvc(
        $resource, $filter, caDetailSvc, messageHandleSvc, constants, message, comparisonUtilSvc) {
        var url = constants.apiUrl + "candidates/:candidateId/appliedpositions/:jobApplicationId";

        var appliedPositionsData = {
            appliedPositions: null,
            appliedPosition: null
        };

        var candidateResource = $resource(url, {}, {
            "getCandidateAppliedPositions": { method: "GET", isArray: true, params: { candidateId: "@candidateId" } },
            "addCandidateAppliedPosition": { method: "POST", params: { candidateId: "@candidateId" } },
            "updateCandidateAppliedPosition": { method: "PUT", params: { candidateId: "@candidateId", jobApplicationId: "@jobApplicationId" } },
            "deleteCandidateAppliedPosition": { method: "DELETE", params: { candidateId: "@candidateId", jobApplicationId: "@jobApplicationId" } }
        });

        function getAppliedPositions(candidateId, jobApplicationId) {
            candidateResource.getCandidateAppliedPositions({ candidateId: candidateId }).$promise.then(function (result) {
                appliedPositionsData.appliedPositions = result;
                if (jobApplicationId) {
                    window.angular.forEach(appliedPositionsData.appliedPositions, function (appliedPosition) {
                        if (appliedPosition.JobApplicationId == parseInt(jobApplicationId, 10)) {
                            appliedPositionsData.appliedPosition = appliedPosition;
                            setCurrentInterviewStatus(appliedPosition);
                        }
                    });
                }
            }, function (xhr) {
                var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                caDetailSvc.setCurrentLoading(false);
                messageHandleSvc.handleResponse(xhr, message.errorLoadingData, doesNotShow);
            });
            return appliedPositionsData;
        }

        function setCurrentInterviewStatus(appliedPosition) {
            if (!comparisonUtilSvc.isNullOrUndefinedValue(appliedPosition.ThirdInterview) && appliedPosition.ThirdInterview !== "") {
                appliedPositionsData.appliedPosition.CurrentInterviewStatusDisplay = "Third Interview";
                appliedPositionsData.appliedPosition.CurrentInterviewStatusId = appliedPosition.ThirdInterviewId;
                appliedPositionsData.appliedPosition.CurrentInterviewStatus = appliedPosition.ThirdInterview;
                return;
            }
            if (!comparisonUtilSvc.isNullOrUndefinedValue(appliedPosition.SecondInterview) && appliedPosition.SecondInterview !== "") {
                appliedPositionsData.appliedPosition.CurrentInterviewStatusDisplay = "Second Interview";
                appliedPositionsData.appliedPosition.CurrentInterviewStatusId = appliedPosition.SecondInterviewId;
                appliedPositionsData.appliedPosition.CurrentInterviewStatus = appliedPosition.SecondInterview;
                return;
            }
            if (!comparisonUtilSvc.isNullOrUndefinedValue(appliedPosition.FirstInterview) && appliedPosition.FirstInterview !== "") {
                appliedPositionsData.appliedPosition.CurrentInterviewStatusDisplay = "First Interview";
                appliedPositionsData.appliedPosition.CurrentInterviewStatusId = appliedPosition.FirstInterviewId;
                appliedPositionsData.appliedPosition.CurrentInterviewStatus = appliedPosition.FirstInterview;
                return;
            }
            if (appliedPosition.ScreenCv !== "") {
                appliedPositionsData.appliedPosition.CurrentInterviewStatusDisplay = "Cv Status";
                appliedPositionsData.appliedPosition.IsScreenCv = true;
                appliedPositionsData.appliedPosition.CurrentInterviewStatusId = appliedPosition.ScreenCvId;
                appliedPositionsData.appliedPosition.CurrentInterviewStatus = appliedPosition.ScreenCv;
            }
        }

        function getCandidateAppliedPositions(candidateId) {
            return candidateResource.getCandidateAppliedPositions({ candidateId: candidateId });
        }

        function addCandidateAppliedPosition(candidateId, appliedPosition) {
            return candidateResource.addCandidateAppliedPosition({ candidateId: candidateId }, appliedPosition);
        }

        function updateCandidateAppliedPosition(candidateId, jobApplicationId, appliedPosition) {
            return candidateResource.updateCandidateAppliedPosition({ candidateId: candidateId, jobApplicationId: jobApplicationId }, appliedPosition);
        }

        function deleteCandidateAppliedPosition(candidateId, jobApplicationId) {
            return candidateResource.deleteCandidateAppliedPosition({ candidateId: candidateId, jobApplicationId: jobApplicationId });
        }

        return {
            appliedPositionsData: appliedPositionsData,
            getAppliedPositions: getAppliedPositions,
            getCandidateAppliedPositions: getCandidateAppliedPositions,
            addCandidateAppliedPosition: addCandidateAppliedPosition,
            updateCandidateAppliedPosition: updateCandidateAppliedPosition,
            deleteCandidateAppliedPosition: deleteCandidateAppliedPosition
        };
    }
})();
