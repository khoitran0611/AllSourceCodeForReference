﻿(function () {
    "use strict";
    angular.module('app').factory('caDetailModel',
        function () {
            var data =
            {
                jobApplicationId: '',
                isDeleted: false,
                newNote: { value: '' },
                newCvStatus: { value: '' }
            };

            return {
                getJobApplicationId: function() {
                    return data.jobApplicationId;
                },
                setJobApplicationId: function(jobApplicationId) {
                    data.jobApplicationId = jobApplicationId;
                },
                getCandidateStatus: function() {
                    return data.isDeleted;
                },
                setCandidateStatus: function(isDeleted) {
                    data.isDeleted = isDeleted;
                },
                getNewNote: function() {
                    return data.newNote;
                },
                setNewNote: function(note) {
                    data.newNote.value = note;
                },
                getNewCvStatus: function() {
                    return data.newCvStatus;
                },
                setNewCvStatus: function(status) {
                    data.newCvStatus.value = status;
                }
            };
        });
})();
