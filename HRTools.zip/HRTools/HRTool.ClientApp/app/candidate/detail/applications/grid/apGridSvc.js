﻿(function () {
    'use strict';
    angular.module('app').factory('apGridSvc', apGridSvc);
    apGridSvc.$inject = ['gridSvc', 'messageHandleSvc', 'caApplicationsSvc', 'caDetailSvc',
        'gridHeader', 'constants', 'apGridModel', 'enumGlyphicon',
        '$filter', 'caMessage'];
    function apGridSvc(gridSvc, messageHandleSvc, caApplicationsSvc, caDetailSvc,
            gridHeader, constants, apGridModel, enumGlyphicon,
            $filter, caMessage) {
                var revealed = {
                    getPagedDataAsync: getPagedDataAsync,
                    gridInit: gridInit
                };
                return revealed;

                function getPagedDataAsync(self, $scope, data) {
                    var result = self;
                    result.data = [];
                    var totalItems = 0;
                    if (data && data.length > 0) {
                        totalItems = data.length;
                        data.forEach(function (appliedPosition) {
                            result.data.push(new apGridModel(appliedPosition));
                        }, function (xhr) {
                            caDetailSvc.setCurrentLoading(false);
                            messageHandleSvc.handleResponse(xhr, caMessage.applicationPosition.getAppliedPositionFailed);
                        });
                    }
                    result.totalPages = Math.ceil(totalItems / self.itemsPerPage);
                    result = gridSvc.setPagingData(result, $scope);
                    return result;
                }

                function gridInit(self, $scope) {
                    var result = self;
                    result.columnDefs = [
                        new gridHeader('AppliedDate', "Applied_Date", constants.formatDateTimeFilter, true),
                        new gridHeader("PositionName", "Application_Records.Position_Name", '', true),
                        new gridHeader("CoverLetterUrl", "Application_Records.Cover_Letter", '', true),
                        new gridHeader("ScreenCv", "Screen_CV", '', true),
                        new gridHeader("IqMark", "Application_Records.Iq_Mark", '', true),
                        new gridHeader("TechnicalMark", "Application_Records.Technical_Mark", '', true),
                        new gridHeader("FirstInterview", "Application_Records.First_Interview", '', false),
                        new gridHeader("SecondInterview", "Application_Records.Second_Interview", '', false),
                        new gridHeader("ThirdInterview", "Application_Records.Third_Interview", '', false),
                        new gridHeader("EditRow", '', '', true)
                    ];
                    result.customCss.showButtonEditRow = enumGlyphicon.glyphiconEditButton;
                    result = gridSvc.init(result, $scope);
                    return result;
                }
    }

})();