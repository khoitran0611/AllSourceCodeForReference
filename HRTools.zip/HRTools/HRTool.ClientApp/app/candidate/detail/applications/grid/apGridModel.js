﻿(function () {
    'use strict';

    angular.module('app').factory('apGridModel', apGridModel);

    function apGridModel() {
        var model = function (appliedPosition) {
            /* jshint -W040 */
            var self = this;
            self.JobApplicationId = appliedPosition.JobApplicationId || '';
            self.JobCode = appliedPosition.JobCode || '';
            self.CategoryId = appliedPosition.CategoryId || '';
            self.PositionId = appliedPosition.PositionId || '';
            self.AppliedDate = appliedPosition.AppliedDate || '';
            self.PositionName = appliedPosition.PositionName || '';
            self.ScreenCv = appliedPosition.ScreenCv || '';
            self.IqMark = appliedPosition.IqMark || '';
            self.TechnicalMark = appliedPosition.TechnicalMark || '';
            self.CoverLetterUrl = appliedPosition.CoverLetterUrl || '';
            self.FirstInterview = appliedPosition.FirstInterview || '';
            self.SecondInterview = appliedPosition.SecondInterview || '';
            self.ThirdInterview = appliedPosition.ThirdInterview || '';
            self.CvSource = appliedPosition.CvSource || '';
            self.CvSourceId = appliedPosition.CvSourceId || '';
            self.HasScheduleInterview = appliedPosition.HasScheduleInterview || '';
            self.RecruitmentId = appliedPosition.RecruitmentId;
            self.CandidateId = appliedPosition.CandidateId || '';
            self.CompanyName = appliedPosition.CompanyName || '';
            self.CvSourceName = appliedPosition.CvSourceName || '';
            self.ScreenCvId = appliedPosition.ScreenCvId || '';
            self.EditRow = '';
            self.IsHide = appliedPosition.IsHide;
            self.LastedStatus = appliedPosition.LastedStatus;
        };
        return model;
    }
})();