﻿(function () {
    'use strict';
    angular.module('app').controller('caColumnsSettingCtrl', CaColumnsSettingCtrl);
    CaColumnsSettingCtrl.$inject = ["$modalInstance", "columns"];
    function CaColumnsSettingCtrl($modalInstance, columns) {
        var self = this;
        window.angular.forEach(columns, function (col) {
            if (col.name === "AppliedDate") {
                col.text = "Applied Date";
            }
        });

        self.columns = columns;
        self.ok = function () {
            $modalInstance.close(self.columns);
        };

        self.cancel = function () {
            $modalInstance.dismiss('cancel');
        };
    }
})();