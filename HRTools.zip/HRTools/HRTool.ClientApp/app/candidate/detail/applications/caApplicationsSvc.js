﻿(function () {
    'use strict';
    angular.module('app').factory('caApplicationsSvc', caApplicationsSvc);
    caApplicationsSvc.$inject = ["$resource", "$filter", "styleSvc", "caDetailSvc", "messageHandleSvc", "constants"];
    function caApplicationsSvc($resource, $filter, styleSvc, caDetailSvc, messageHandleSvc, constants) {
        var url = constants.apiUrl + "candidates/:candidateId/appliedpositions/:jobApplicationId";

        var applicationsData = {
            appliedPositions: null,
            appliedPosition: null
        };

        var candidateResource = $resource(url, {}, {
            "getCandidateAppliedPositions": { method: "GET", isArray: true, params: { candidateId: "@candidateId" } },
            "addCandidateAppliedPosition": { method: "POST", params: { candidateId: "@candidateId" } },
            "updateCandidateAppliedPosition": { method: "PUT", params: { candidateId: "@candidateId", jobApplicationId: "@jobApplicationId" } },
            "deleteCandidateAppliedPosition": { method: "DELETE", params: { candidateId: "@candidateId", jobApplicationId: "@jobApplicationId" } }
        });

        return {
            applicationsData: applicationsData,
            getCandidateApplications: getCandidateApplications,
            addCandidateApplication: addCandidateApplication,
            updateCandidateApplication: updateCandidateApplication,
            deleteCandidateApplication: deleteCandidateApplication,
            getApplications: getApplications,
            getCurrentApplications: getCurrentApplications,
            setJobApplicationScreenCVStatus: setJobApplicationScreenCVStatus,
            updateCurrentApplications: updateCurrentApplications,
            deleteCurrentApplication: deleteCurrentApplication,
            updateJobApplicationNote: updateJobApplicationNote,
            updateJobApplicationRating: updateJobApplicationRating,
            resetDefaultApplication: resetDefaultApplication
        };

        function getCandidateApplications(candidateId) {
            return candidateResource.getCandidateAppliedPositions({ candidateId: candidateId });
        }

        function addCandidateApplication(candidateId, appliedPosition) {
            return candidateResource.addCandidateAppliedPosition({ candidateId: candidateId }, appliedPosition);
        }

        function updateCandidateApplication(candidateId, jobApplicationId, appliedPosition) {
            return candidateResource.updateCandidateAppliedPosition({ candidateId: candidateId, jobApplicationId: jobApplicationId }, appliedPosition);
        }

        function deleteCandidateApplication(candidateId, jobApplicationId) {
            return candidateResource.deleteCandidateAppliedPosition({ candidateId: candidateId, jobApplicationId: jobApplicationId });
        }

        function getApplications(candidateId, jobApplicationId) {
            candidateResource.getCandidateAppliedPositions({ candidateId: candidateId }).$promise.then(function (result) {
                applicationsData.appliedPositions = result;
                if (jobApplicationId) {
                    window.angular.forEach(applicationsData.appliedPositions, function (appliedPosition) {
                        if (appliedPosition.JobApplicationId == parseInt(jobApplicationId, 10)) {
                            applicationsData.appliedPosition = appliedPosition;
                            setCurrentInterviewStatus(appliedPosition);
                        }
                    });
                }
            }, function (xhr) {
                var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                caDetailSvc.setCurrentLoading(false);
                messageHandleSvc.handleResponse(xhr, "Load_Application_Postion_Fail", doesNotShow);
            });
            return applicationsData;
        }

        function getCurrentApplications() {
            return applicationsData;
        }

        function setJobApplicationScreenCVStatus(jobApplicationId, screenCvId) {
            if (!applicationsData.appliedPositions) return;
            for (var index = 0; index < applicationsData.appliedPositions.length; index++) {
                if (applicationsData.appliedPositions[index].JobApplicationId == jobApplicationId) {
                    applicationsData.appliedPositions[index].ScreenCv = styleSvc.setTitle(screenCvId + '');
                    applicationsData.appliedPositions[index].ScreenCvId = screenCvId;
                    return;
                }
            }
        }

        function updateCurrentApplications(application, isAddedNew) {
            if (isAddedNew) {
                application.Rating = 0;
                applicationsData.appliedPositions.unshift(application);
            }
            else {
                for (var index = 0; index < applicationsData.appliedPositions.length; index++) {
                    if (applicationsData.appliedPositions[index].JobApplicationId == application.JobApplicationId) {
                        applicationsData.appliedPositions[index] = application;
                        return;
                    }
                }
            }
        }

        function deleteCurrentApplication(application) {
            for (var index = 0; index < applicationsData.appliedPositions.length; index++) {
                if (applicationsData.appliedPositions[index].JobApplicationId == application.JobApplicationId) {
                    applicationsData.appliedPositions.splice(index, 1);
                    return;
                }
            }
        }

        function updateJobApplicationNote(jobApplicationId, note) {
            var jobLength = applicationsData.appliedPositions.length;
            for (var index = 0; index < jobLength; index++) {
                if (applicationsData.appliedPositions[index].JobApplicationId == jobApplicationId) applicationsData.appliedPositions[index].Note = note;
            }
        }

        function updateJobApplicationRating(jobApplicationId, rating) {
            var jobLength = applicationsData.appliedPositions.length;
            for (var index = 0; index < jobLength; index++) {
                if (applicationsData.appliedPositions[index].JobApplicationId == jobApplicationId) applicationsData.appliedPositions[index].Rating = rating;
            }
        }
        function resetDefaultApplication() {
            applicationsData = {
                appliedPositions: null,
                appliedPosition: null
            };
            return applicationsData;
        }
    }

})();