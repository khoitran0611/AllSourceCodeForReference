﻿(function () {
    'use strict';
    angular.module('app').controller('caApplicationsCtrl', CaApplicationsCtrl);
    CaApplicationsCtrl.$inject = ["constants", "caConstants", "message", "caMessage",
        "$state", "$filter", "$scope", "$compile", "$modal", 'styleSvc',
        "permissionSvc", "caDetailSvc", "caApplicationsSvc", "apGridSvc", "candidateSvc", "messageHandleSvc", '$timeout', "$rootScope",
        'comparisonUtilSvc'];
    function CaApplicationsCtrl(constants, caConstants, message, caMessage,
            $state, $filter, $scope, $compile, $modal, styleSvc,
            permissionSvc, caDetailSvc, caApplicationsSvc, apGridSvc, candidateSvc, messageHandleSvc, $timeout, $rootScope,
            comparisonUtilSvc) {
        var candidateId = $state.params.id;
        var appliedPositionEdited = {};
        var isLoadingEdit = false;
        var resetCommand = "resetSeleted";
        var self = this;
        var param = {
            candidateId: candidateId
        };
        self.permissionOfCurrentUser = {
            editApplication: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            viewApplication: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewCandidateInfo),
            canCustomizeColumns: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.OpenPositions_CustomizeColumnsOnJobsListing),
        };
        if (!self.permissionOfCurrentUser.viewApplication) $state.go('candidates');
        self.pageIndex = 1;
        self.totalPages = 0;
        self.pagingOptions = {};
        self.showFooter = false;
        self.enablePaging = false;
        self.showSelectionCheckbox = false;
        self.dataGrid = "ctrl.data";
        self.pagingEvent = "ctrl.pagingOptions";
        self.rowTemplate = "candidate/detail/applications/grid/apRowGridTemplate.html";
        self.gridTemplate = "candidate/detail/applications/grid/apGridTemplate.html";
        self.headerRowTemplate = "candidate/detail/applications/grid/apHeaderRowTemplate.html";
        self.gridId = "apGrid";
        self.columnDefs = [];
        self.customCss = {};
        self.candidateId = $state.params.id;
        self.showColumnMenu = true;
        self.disableSpinner = true;
        self.doDisplayPositionForm = false;
        self.jobApplicationId = null;
        self.isAddNew = true;
        self.candidateHasPositionAlready = false;
        self.itemsPerPage = 10;
        self.initCurrentPosition = {
            service: candidateSvc.getCurrentOpenPositions(),
            id: "CategoryId",
            text: "JobTitle",
            optionsValue: "JobId",
            option: {
                placerholder: "",
                multiple: false
            }
        };
        self.appliedPositionsData = caApplicationsSvc.getCurrentApplications();
        self.screeningStatus = caDetailSvc.getScreeningStatus();

        self.togglePosition = togglePosition;
        self.cancel = cancel;
        self.save = save;
        self.deleteAppliedPosition = deleteAppliedPosition;
        self.editing = editing;
        self.handleSelectedItems = handleSelectedItems;
        self.getPagedDataAsync = getPagedDataAsync;
        self.selectJobCode = selectJobCode;
        self.selectCVSource = selectCVSource;
        self.translateJobTitle = translateJobTitle;

        var isAddNewPosition = false;
        var isEditing = false;

        init();

        function init() {
            $scope.lockColumnsCustomization = !self.permissionOfCurrentUser.canCustomizeColumns;

            self = apGridSvc.gridInit(self, $scope);
            self = self.getPagedDataAsync();

            self.candateInforData = candidateSvc.candidateInforData;
            self.appliedPositionsData = caApplicationsSvc.getApplications(candidateId);

            $scope.$watch('ctrl.selectedJob', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                if (newValue) {
                    self.selectedCategoryId = newValue.id;
                    self.openPositionName = newValue.text;
                    selectOpenPosition(newValue.optionsValue);
                    self.recuitmentIdSelected = newValue.optionsValue;
                }
            }, true);

            $scope.$watch('ctrl.appliedPositionsData', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                self.data = self.appliedPositionsData.appliedPositions;
                self.getPagedDataAsync();
            }, true);

            $scope.$watch('ctrl.screeningStatus', function (newValue, oldValue) {
                if (newValue == oldValue || self.appliedPositionsData.appliedPositions.length === 0)
                    return;
                var index = findWithAttr(self.appliedPositionsData.appliedPositions, "JobApplicationId", newValue.jobId);
                if (index >= 0)
                    self.appliedPositionsData.appliedPositions[index].ScreenCvId = newValue.value;

            }, true);
        }

        function togglePosition(appliedPosition) {
            isLoadingEdit = true;
            self.doDisplayPositionForm = !self.doDisplayPositionForm;
            if (appliedPosition) {
                self.isAddNew = false;
                self.jobApplicationId = appliedPosition.JobApplicationId;
                appliedPositionEdited = appliedPosition;
                self.HasScheduleInterview = appliedPosition.HasScheduleInterview;
            } else {
                self.HasScheduleInterview = false;
                if (self.candateInforData.openPositions && self.candateInforData.openPositions.length > 0) {
                    self.selectedJob = { id: self.candateInforData.openPositions[0].CategoryId, text: self.candateInforData.openPositions[0].JobTitle, optionsValue: self.candateInforData.openPositions[0].JobId, optionsText: undefined };
                }
            }

            if (self.doDisplayPositionForm) {
                setSelectedOpenPosition(appliedPositionEdited.CategoryId, appliedPositionEdited.RecruitmentId, appliedPositionEdited.PositionName);
                setSelectedJobCode(appliedPositionEdited.CategoryId, appliedPositionEdited.JobCode, appliedPosition ? appliedPosition.RecruitmentId : undefined);
                setSelectedCvSource(appliedPositionEdited.CvSourceId);
            }
            $timeout(function () {
                $('html, body').animate({ scrollTop: $(document).height() }, 'slow');
            }, 500);

        }

        function setSelectedOpenPosition(categoryId, recruitmentId, positionName) {
            if (isAddNewPosition) {
                isAddNewPosition = false;
            }
            if (categoryId) {
                var openPositions = $filter('filter')(self.candateInforData.openPositions, { JobId: recruitmentId }, true);
                var indexPosition = $.map(self.candateInforData.openPositions, function (obj, index) {
                    if (obj.CategoryId == categoryId) {
                        return index;
                    }
                });
                if (openPositions.length > 0) {
                    self.selectedCategoryId = categoryId;
                    self.selectedJob = { id: categoryId, text: openPositions[0].JobTitle, optionsValue: openPositions[0].JobId, optionsText: undefined };
                    return;
                } else {
                    if (openPositions.length === 0) {
                        self.selectedJob = { id: categoryId, text: positionName, optionsValue: "resetSeleted", optionsText: undefined };
                        var oldPosition = {};
                        oldPosition.CategoryId = categoryId;
                        oldPosition.JobTitle = positionName;
                        self.selectedCategoryId = categoryId;
                        isAddNewPosition = true;
                        return;
                    }
                }
            }
            if (self.candateInforData.openPositions && self.candateInforData.openPositions.length > 0) {
                self.selectedJob = { id: self.candateInforData.openPositions[0].CategoryId, text: self.candateInforData.openPositions[0].JobTitle, optionsValue: self.candateInforData.openPositions[0].JobId, optionsText: undefined };
                self.selectedCategoryId = self.candateInforData.openPositions[0].CategoryId;
            }
        }

        function setSelectedJobCode(positionId, jobCodeName, recruimentId) {
            self.jobCodesOfPosition = [];
            window.angular.forEach(self.candateInforData.jobCodes, function (jobCode) {
                if (jobCode.Code == self.selectedCategoryId && jobCode.Text == caConstants.recruitmentStatus.Published.id) {
                    self.jobCodesOfPosition.push(jobCode);
                }
            });

            if (self.jobCodesOfPosition.length === 0) {
                self.jobCodeSelected = false;
                return;
            }

            angular.forEach(self.jobCodesOfPosition, function (jobCode, index) {
                if (jobCode.Id == recruimentId) {
                    self.jobCodeSelected = self.jobCodesOfPosition[index].Id;
                    self.jobCodeName = self.jobCodesOfPosition[index].Name;
                    return;
                }
            });

            if (comparisonUtilSvc.isNullOrUndefinedValue(recruimentId) || !positionId) {
                self.jobCodeSelected = self.jobCodesOfPosition[0].Id;
                self.jobCodeName = self.jobCodesOfPosition[0].Name;
            }
        }

        function setSelectedCvSource(cvSourceId) {
            var cvSources = $filter('filter')(self.candateInforData.cvSources, { Id: cvSourceId }, true);
            if (cvSourceId && cvSources.length > 0) {
                self.cvSourceSelected = cvSourceId;
                self.cvSourceName = cvSources[0].Name;
            } else {
                self.cvSourceSelected = self.candateInforData.cvSources[0].Id;
                self.cvSourceName = self.candateInforData.cvSources[0].Name;
            }
        }

        function selectOpenPosition(recruimentId) {
            self.jobCodesOfPosition = $filter('filter')(self.candateInforData.jobCodes, { Code: self.selectedCategoryId + '' }, true);
            if (self.jobCodesOfPosition && self.jobCodesOfPosition.length > 0) {
                setSelectedJobCode(self.selectedCategoryId, self.jobCodesOfPosition[0].Name, recruimentId);
            }
        }

        function cancel() {
            self.doDisplayPositionForm = false;
            appliedPositionEdited = {};
            self.jobApplicationId = '';
            isEditing = false;
            isLoadingEdit = false;
            self.isAddNew = true;
            self.selectedJob = {};
            self.selectedJob = { id: 0, text: "", optionsValue: resetCommand, optionsText: undefined };
        }

        function save() {
            self.isChangePosition = (appliedPositionEdited.RecruitmentId != self.recuitmentIdSelected);
            self.appliedPositionsData.appliedPositions.forEach(function (appliedPosition) {
                if (appliedPosition.RecruitmentId == self.recuitmentIdSelected) {
                    self.candidateHasPositionAlready = true;
                }
            });
            if (!self.jobApplicationId) {
                if (self.candidateHasPositionAlready) {
                    toastr.warning($filter(constants.translate)(caMessage.candidateHas) + ' ' + self.openPositionName + ' ' + $filter(constants.translate)(caMessage.already));
                    self.candidateHasPositionAlready = false;
                    return;
                } else {
                    self.candidateHasPositionAlready = false;
                    appliedPositionEdited.CategoryId = self.selectedCategoryId;
                    appliedPositionEdited.RecruitmentId = self.jobCodeSelected;
                    appliedPositionEdited.PositionName = self.isChangePosition ? self.openPositionName : appliedPositionEdited.PositionName;
                    appliedPositionEdited.ScreenCvId = constants.applicationStatus.ScreeningCv.New;
                    appliedPositionEdited.JobCode = self.jobCodeName;
                    appliedPositionEdited.ScreenCv = "New";
                    caApplicationsSvc.addCandidateApplication(candidateId, appliedPositionEdited).$promise.then(function (data) {
                        appliedPositionEdited.AppliedDate = new Date();
                        appliedPositionEdited.JobApplicationId = data.result;
                        appliedPositionEdited.IsHide = data.IsHide;
                        appliedPositionEdited.CandidateId = self.candidateId;
                        caApplicationsSvc.updateCurrentApplications(appliedPositionEdited, true);
                        addCandidateApplication(data);
                        caDetailSvc.updateCandiateJobApplicationList(param);
                        cancel();
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                    });
                }
            } else {
                if (self.isChangePosition && self.candidateHasPositionAlready) {
                    toastr.warning($filter(constants.translate)(caMessage.candidateHas) + ' ' + self.openPositionName + ' ' + $filter(constants.translate)(caMessage.already));
                    self.candidateHasPositionAlready = false;
                    return;
                } else {
                    if (self.isChangePosition) {
                        appliedPositionEdited.CategoryId = self.selectedCategoryId;
                        appliedPositionEdited.RecruitmentId = self.jobCodeSelected;
                        appliedPositionEdited.PositionName = self.isChangePosition ? self.openPositionName : appliedPositionEdited.PositionName;
                    }
                    var cvSources = $filter('filter')(self.candateInforData.cvSources, { Id: self.cvSourceSelected }, true);
                    appliedPositionEdited.CvSourceId = cvSources[0].Name === "" ? null : self.cvSourceSelected;
                    appliedPositionEdited.JobCode = self.jobCodeName;
                    caApplicationsSvc.updateCandidateApplication(candidateId, appliedPositionEdited.JobApplicationId, appliedPositionEdited)
                        .$promise.then(function (data) {
                            if (data.result) {
                                appliedPositionEdited.IsHide = data.IsHide;
                                caApplicationsSvc.updateCurrentApplications(appliedPositionEdited, false);
                                self.candidateHasPositionAlready = false;
                                var cvSources = $filter('filter')(self.candateInforData.cvSources, { Name: appliedPositionEdited.CvSource }, true);
                                $rootScope.$broadcast(caConstants.events.updateCVTab, {
                                    cvSourceId: comparisonUtilSvc.isNullOrUndefinedValue(appliedPositionEdited.CvSourceId) ? cvSources[0].Id : appliedPositionEdited.CvSourceId,
                                    positionName: appliedPositionEdited.PositionName,
                                    jobApplicationId: appliedPositionEdited.JobApplicationId
                                });
                            }
                            cancel();
                            messageHandleSvc.handleResponse(data, caMessage.applicationPosition.updateAppliedPositionSuccessful);
                        }, function (xhr) {
                            messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                        });
                }
            }
        }

        function addCandidateApplication(data) {
            if (data.result === 0) {
                messageHandleSvc.handleResponse(null, caMessage.applicationPosition.addCurrentAppliedPositionFail);
            } else {
                messageHandleSvc.handleResponse(data, caMessage.applicationPosition.addNewAppliedPositionSuccessful);
            }
            updateLatestJobAppId();
        }

        function deleteAppliedPosition() {
            $modal.open({
                templateUrl: 'candidate/detail/applications/confirmDialog/caConfirm.html',
                controller: ['$scope', '$modalInstance', function ($scope, $modalInstance) {
                    $scope.header = $filter(constants.translate)("Confirm_Delete");
                    $scope.message = $filter(constants.translate)("Application_Records.Do_You_Want_To_Delete_Applied_Position");
                    $scope.ok = function () {
                        if (self.jobApplicationId) {
                            caApplicationsSvc.deleteCandidateApplication(candidateId, self.jobApplicationId).$promise.then(function (data) {
                                if (data) {
                                    caApplicationsSvc.deleteCurrentApplication({ JobApplicationId: self.jobApplicationId });
                                    messageHandleSvc.handleResponse(data, caMessage.applicationPosition.deleteAppliedPositionSuccessful);
                                    updateLatestJobAppId();
                                    var index = findWithAttr(self.data, "JobApplicationId", self.jobApplicationId);
                                    if (index > -1) self.data.splice(index, 1);
                                    if (!$scope.$$phase && !$scope.$root.$$phase) {
                                        $scope.$apply();
                                    }
                                    cancel();
                                } else {
                                    messageHandleSvc.handleResponse(data, caMessage.applicationPosition.deleteAppliedPositionFail);
                                }
                            }, function (xhr) {
                                messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                            });
                        }
                        $modalInstance.dismiss('cancel');
                    };
                    $scope.cancel = function () {
                        $modalInstance.dismiss('cancel');
                    };
                }]
            });
        }

        function updateLatestJobAppId() {
            candidateSvc.getCandidateInformation(candidateId).get().$promise.then(
                function (data) {
                    candidateSvc.updateSeletedJobApplication(data.CandidateBasicInfo.JobApplicationId);
                    candidateSvc.candidateInforData.candidateBasicInfo.JobApplicationId = data.CandidateBasicInfo.JobApplicationId;
                    candidateSvc.candidateInforData.candidateBasicInfo.PositionName = data.CandidateBasicInfo.PositionName;
                });

        }

        function setStatus(status) {
            return styleSvc.setStatus(status);
        }

        function editing(application) {
            isEditing = true;
            togglePosition(application);
        }

        function handleSelectedItems(data) {
            if (isEditing) {
                if (isLoadingEdit) return;
                self.togglePosition(data.entity);
            }
        }

        function getPagedDataAsync() {
            self = apGridSvc.getPagedDataAsync(self, $scope, self.appliedPositionsData.appliedPositions);
            return self;
        }

        function selectJobCode() {
            if (!self.jobCodesOfPosition || self.jobCodesOfPosition.length <= 0) return;
            for (var index = 0; index < self.jobCodesOfPosition.length; index++) {
                if (self.jobCodesOfPosition[index].Id == self.jobCodeSelected) self.jobCodeName = self.jobCodesOfPosition[index].Name;
            }
        }

        function selectCVSource() {
            setSelectedCvSource(self.cvSourceSelected);
        }

        function translateJobTitle(status) {
            switch (status) {
                case "Ended":
                    return " - " + $filter(constants.translate)("Job_Status.Ended");
                case "Closed":
                    return " - " + $filter(constants.translate)("Job_Status.Closed");
                default:
                    return "";
            }
        }
    }
})();

