﻿(function () {
    'use strict';
    angular.module('app').controller('caDetailCtrl', CaDetailCtrl);
    CaDetailCtrl.$inject = ['caDetailSvc', 'emailSvc', 'messageHandleSvc', 'permissionSvc', 'historyPageSvc',
        'candidateSvc', 'datetimeSvc', 'caApplicationsSvc', 'switchCandidateSvc', 'comparisonUtilSvc',
        'caDetailModel', 'message', 'constants', 'caConstants', "caMessage",
        '$state', '$scope', '$location', '$rootScope', '$filter', '$document', '$stateParams'];
    function CaDetailCtrl(caDetailSvc, emailSvc, messageHandleSvc, permissionSvc, historyPageSvc,
        candidateSvc, datetimeSvc, caApplicationsSvc, switchCandidateSvc, comparisonUtilSvc,
        caDetailModel, message, constants, caConstants, caMessage,
        $state, $scope, $location, $rootScope, $filter, $document, $stateParams) {
        var self = this;
        self.permissionOfCurrentUser = {
            resetPasswordRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_Resetpassword),
            updateInterviewRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview),
            updateRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            sendMailRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SendMailUpdateCV),
            scheduleInterviewRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_ViewScheduleInterview),
            becomEmployeeRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_BecomeEmployee),
            offerLetterRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.UpdateOfferStatus_ViewStatusOfferLetter),
            viewCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewCandidateInfo),
            viewEmailCorrespondence: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewEmailCorrespondence),
            viewInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview),
            sendJobInvitation: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SendJobInvitation),
            viewSelectionProcess: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewSelectionProcessSection),
            viewEmailsSection: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewEmailsSection),
            viewDiscussionSection: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewDiscussionSection),
            viewAdministrationSection: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewAdministrationSection)
        };
        if (!self.permissionOfCurrentUser.viewCandidateInfor) {
            //authenticationSvc.logout();
            messageHandleSvc.handlePermission();
            return;
        }

        var candidateId = $state.params.id;
        var dataFilter = switchCandidateSvc.getFilterData();
        if (!dataFilter) dataFilter = { listId: [$state.params.id], pageIndex: 1, totalPages: 1 };
        var tempIndex = historyPageSvc.getCurrentCandidateIdIndex();
        var currentCandidateIndex = (tempIndex >= 0) ? tempIndex : 0;
        var firstIndex = 0;
        var firstPage = 1;
        var atBottom = (currentCandidateIndex == dataFilter.listId.length - 1);
        var atTop = (currentCandidateIndex == firstIndex);

        self.jobApplicationId = caDetailSvc.getSelectedJobApplicationId();
        self.isDeleted = false;
        self.isSendJobInvitation = false;
        self.isAskUpdateCv = false;
        self.canChangeCandidate = dataFilter.listId.length > 1;
        self.isDisableNext = atBottom && dataFilter.pageIndex == dataFilter.totalPages;
        self.isDisablePrevious = atTop && dataFilter.pageIndex == firstPage;

        self.getCssClass = getCssClass;
        self.backToCandidateList = backToCandidateList;
        self.getMail = getMail;
        self.goBackToCandidatePage = goBackToCandidatePage;
        self.onClickSendJobInvitation = onClickSendJobInvitation;
        self.nextCandidate = nextCandidate;
        self.previousCandidate = previousCandidate;


        init();

        function init() {
            self.isInitializing = true;
            setTimeout(function () { self.isInitializing = false }, 1500);

            caApplicationsSvc.resetDefaultApplication();
            candidateSvc.getCandidateInforData(candidateId);

            $rootScope.$on('$stateChangeStart',
                function (event, toState, toParams, fromState, fromParams) {
                    caDetailSvc.setCurrentLoading(true);
                    $rootScope.isComeBackInterviewTab =
                        ((fromState.name.indexOf('scheduleInterview') > -1 ||
                            fromState.name.indexOf('become-employee') > -1 ||
                            fromState.name.indexOf('cancelInterview') > -1 ||
                            fromState.name.indexOf('offerLetterStatus') > -1 ||
                            fromState.name.indexOf('conductInterview') > -1 ||
                            fromState.name.indexOf('offerLetterCreate') > -1) && toState.name.indexOf('candidateDetail') > -1) ? true : false;
                    if ($rootScope.isComeBackInterviewTab) $rootScope.currentJobApplicationIdOfCandidate = fromParams.jobApplicationId ? fromParams.jobApplicationId : self.jobApplicationId.value;
                });
            setMenu($rootScope.isComeBackInterviewTab);

            $scope.$on(caConstants.updateCurrentPosition, function () {
                self.currentPosition = caDetailSvc.getCurrentPosition();
                self.showRemindUpdateCvIcon =
                    (self.currentPosition.lastUpdateStatus == constants.applicationStatus.Other.RejectAll ||
                        self.currentPosition.lastUpdateStatus == constants.applicationStatus.ScreeningCv.Rejected ||
                        self.currentPosition.lastUpdateStatus == constants.applicationStatus.Other.BecomeEmployee ||
                        self.currentPosition.lastUpdateStatus == constants.applicationStatus.OfferStatus.HasOffer ||
                        self.currentPosition.lastUpdateStatus == constants.applicationStatus.OfferStatus.AlreadySent ||
                        self.currentPosition.lastUpdateStatus == constants.applicationStatus.OfferStatus.AcceptOffer ||
                        self.currentPosition.lastUpdateStatus == constants.applicationStatus.OfferStatus.RejectOffer) ? false : true;

                self.showJobInvitationIcon =
                    (self.currentPosition.lastUpdateStatus == constants.applicationStatus.Other.BecomeEmployee) ? false : true;

                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            });

            $scope.$watch(function () { return caDetailModel.getCandidateStatus(); }, function (newValue) {
                self.isDeleted = newValue;
            });
        }

        function setMenu(isBackToInterview) {
            var menus = [
                { id: "cvTab", name: "CV", url: "/cv", enable: true, isActive: isBackToInterview ? false : true },
                { id: "applicationTab", name: "Applications", url: "/applications", enable: true, isActive: false }
            ];
            if (self.permissionOfCurrentUser.viewSelectionProcess) {
                menus.push({ id: "interviewTab", name: "Selection Process", url: "/interviews", enable: true, isActive: isBackToInterview ? true : false });
            }
            if (self.permissionOfCurrentUser.viewEmailCorrespondence) {
                menus.push({ id: "emailTab", name: "Emails", url: "/emails", enable: true, isActive: false });
            }
            if (self.permissionOfCurrentUser.viewDiscussionSection) {
                menus.push({ id: "noteTab", name: "Discussion", url: "/note", enable: true, isActive: false });
            }
            if (self.permissionOfCurrentUser.viewAdministrationSection) {
                menus.push({ id: "adminTab", name: "Administration", url: "/administration", enable: true, isActive: false });
            }
            if (isBackToInterview) {
                caDetailSvc.updateSelectedJobApplication($rootScope.currentJobApplicationIdOfCandidate);
            }
            if (!$scope.$$phase && !$scope.$root.$$phase) {
                $scope.$apply();
            }
            self.menus = menus;
            return self.menus;
        }

        function backToCandidateList() {
            if ($rootScope.doesCandidateComeFromDashboard) window.history.back();
            if (!$rootScope.interviewHistory || $rootScope.interviewHistory.indexOf(parseInt($state.params.id)) == -1) {
                $state.go(caConstants.mainPage);
            } else {
                $rootScope.interviewHistory.splice($rootScope.interviewHistory.indexOf(parseInt($state.params.id)), 1);
                $state.go("interviewSchedule");
            }
        }

        function getMail() {
            var jobApplicationId = caDetailSvc.getSelectedJobApplicationId();
            var jobApplicationIdList = [];
            self.emailData = {};
            var itemToList = {
                JobApplicationId: jobApplicationId.value
            };
            jobApplicationIdList.push(itemToList);
            emailSvc.jobApplicationUpdateCvEmail(jobApplicationId.value).get(function (data) {
                self.emailData = data;
                self.originContent = angular.copy(self.emailData.Content);
                self.emailData.originContent = self.originContent;
                self.originSubject = angular.copy(self.emailData.Subject);
                self.emailData.originSubject = self.originSubject;
                self.emailData.listOfJobApplication = jobApplicationIdList;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
            });
            self.isAskUpdateCv = true;
            self.isSendJobInvitation = false;
            removeHoverElement('.sprite-invitation');
            addHoverElement('.sprite-chat');
        }

        function goBackToCandidatePage() {
            var previousUrl = historyPageSvc.getPreviousUrl(window.location.href);
            if (previousUrl) {
                historyPageSvc.setPreviousUrl(window.location.href, "");
                window.location.href = previousUrl;
                return;
            }
            $state.go('candidates');
        }

        function getCssClass(divId) {
            var menu = getMenuItemById(divId);
            if (menu === null) return 'hide';
            switch (divId) {
                case 'applicationTab':
                    return menu.isActive ? 'show row' : 'hide row';
                case 'cvTab':
                case 'interviewTab':
                case 'emailTab':
                case 'noteTab':
                case 'adminTab':
                    return menu.isActive ? 'show' : 'hide';
                default: return 'hide';
            }
        }

        function getMenuItemById(id) {
            if (!self.menus) return null;
            for (var index = 0; index < self.menus.length; index++) {
                if (self.menus[index].id === id) return self.menus[index];
            }
            return null;
        }

        function onClickSendJobInvitation() {
            var jobApplicationId = caDetailSvc.getSelectedJobApplicationId();
            var itemToList = {
                JobApplicationId: jobApplicationId.value
            };
            var jobApplicationList = [];
            jobApplicationList.push(itemToList);
            $rootScope.$broadcast(constants.broadCastTile.sendJobInvitation, { jobApplicationIdList: jobApplicationList });
            self.isSendJobInvitation = true;
            self.isAskUpdateCv = false;
            removeHoverElement('.sprite-chat');
            addHoverElement('.sprite-invitation');
        }

        function nextCandidate() {
            if (self.isShowLoading) return;
            if (self.isDisableNext) return;
            if (self.isInitializing) return;

            caDetailSvc.updateSelectedJobApplication(0);
            caApplicationsSvc.resetDefaultApplication();
            $rootScope.$broadcast(caConstants.events.showLoadingEvent, {});
            if (atBottom) {
                historyPageSvc.setCurrentCandidateIdIndex(0);
                goNewDataFilter(++dataFilter.pageIndex);
                return;
            }
            self.isShowLoading = true;
            var nextIndex = currentCandidateIndex + 1;
            if (dataFilter.listId[nextIndex] != candidateId)
                $state.go($state.current, { id: dataFilter.listId[nextIndex] });
            else $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
            historyPageSvc.setCurrentCandidateIdIndex(nextIndex);
        }

        function previousCandidate() {
            if (self.isShowLoading) return;
            if (self.isDisablePrevious) return;
            if (self.isInitializing) return;

            caDetailSvc.updateSelectedJobApplication(0);
            caApplicationsSvc.resetDefaultApplication();
            $rootScope.$broadcast(caConstants.events.showLoadingEvent, {});
            if (atTop) {
                goNewDataFilter(--dataFilter.pageIndex);
                historyPageSvc.setCurrentCandidateIdIndex(9);
                return;
            }
            self.isShowLoading = true;
            var nextIndex = currentCandidateIndex - 1;
            if (dataFilter.listId[nextIndex] != candidateId)
                $state.go($state.current, { id: dataFilter.listId[nextIndex] });
            else $state.transitionTo($state.current, $stateParams, { reload: true, inherit: true, notify: true });
            historyPageSvc.setCurrentCandidateIdIndex(nextIndex);
        }

        function goNewDataFilter(pageIndex) {
            caDetailSvc.setCurrentLoading(true);
            var result = {
                listId: [],
                pageIndex: pageIndex
            };
            var action = '';
            var currentList = $.jStorage.get('currentList');
            if (currentList == constants.filterData.latestCvUpdateViewAll || currentList == constants.filterData.latestApplicationViewAll) {
                action = 'getallbysortcolumnmodifieddate';
            }

            candidateSvc.getCandidates(pageIndex, dataFilter.query, dataFilter.isSearching, action).get(function (candidateList) {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(candidateList.Data) && candidateList.Data.length > 0) {
                    for (var i = 0; i < candidateList.Data.length; i++) {
                        result.listId.push(candidateList.Data[i].CandidateId);
                    }
                }

                dataFilter = {
                    isSearching: dataFilter.isSearching,
                    listId: result.listId,
                    pageIndex: result.pageIndex,
                    totalPages: candidateList.TotalPages,
                    query: dataFilter.query
                };
                switchCandidateSvc.setFilterData(currentList, dataFilter);

                if (atBottom) {
                    $state.go($state.current, { id: dataFilter.listId[firstIndex] });
                }
                if (atTop) {
                    $state.go($state.current, { id: dataFilter.listId[dataFilter.listId.length - 1] });
                }
            },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData, doesNotShow);
                });
        }
    }
})();

