﻿(function () {
    'use strict';
    angular.module('app').controller('caAppliedInfoCtrl', CaAppliedInfoCtrl);
    CaAppliedInfoCtrl.$inject = ['caDetailSvc', 'messageHandleSvc', 'caApplicationsSvc', 'candidateSvc', 'emailSvc', 'historyPageSvc',
        'permissionSvc', '$stateParams', '$rootScope', '$scope', '$timeout',
        'message', 'caConstants', 'constants', "caMessage", "caMessage", "$filter"];
    function CaAppliedInfoCtrl(caDetailSvc, messageHandleSvc, caApplicationsSvc, candidateSvc, emailSvc, historyPageSvc,
        permissionSvc, $stateParams, $rootScope, $scope, $timeout,
        message, caConstants, constants, caMessage, $filter) {
        var self = this;
        self.isShowLoading = true;
        self.isEmptyData = false;
        self.appliedPositions = {};
        self.seletedPositionIndex = 0;
        self.serverUrl = constants.serverUrl;
        self.currentInterview = undefined;
        self.applicationRating = 0;
        self.candidateId = $stateParams.id;
        self.isHide = false;
        self.canEditCandidateInfo = true;

        self.getButtonStyle = getButtonStyle;
        self.updateSelectedJobApplication = updateSelectedJobApplication;
        self.getLastedInterview = getLastedInterview;
        self.getThankYouMail = getThankYouMail;
        self.goToJobDetail = goToJobDetail;
        self.goToDashboardJobDetail = goToDashboardJobDetail;

        self.permissionOfCurrentUser = {
            canViewOpenPositionDetail: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.OpenPositions_ViewOpenPositionDetail),
            canViewDashboard: permissionSvc.checkGroupOfPermissionCondition([permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewLatestApplications),
                                                            permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewLatestCvUpdates),
                                                            permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewJobsSnapshot),
                                                            permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewJobActivity)])};

        var param = {};

        init();

        function init() {
            param.candidateId = $stateParams.id;
            var currentJobId = 0;
            self.currentApplications = caApplicationsSvc.getCurrentApplications();
            $scope.$watch('caApCtrl.currentApplications', function (newValue) {
                var currentPosition = caDetailSvc.getSelectedJobApplicationId();
                currentJobId = $rootScope.currentJobApplicationIdOfCandidate ? $rootScope.currentJobApplicationIdOfCandidate : currentPosition.value;
                if (newValue) {
                    self.appliedPositions = caApplicationsSvc.getCurrentApplications().appliedPositions;
                    if (!self.appliedPositions || self.appliedPositions.length === 0) {
                        caDetailSvc.updateSelectedJobApplication(0);
                        loadInterviewInfor(0);
                        self.applicationRating = 0;
                        $timeout(function () {
                            self.isShowLoading = false;
                        }, 2000);
                        return;
                    }
                    if (self.appliedPositions && self.appliedPositions.length === 0) {
                        self.isEmptyData = true;
                    } else {
                        self.isEmptyData = false;
                    }
                    var currentJobIndex = self.appliedPositions ? findWithAttr(self.appliedPositions, "JobApplicationId", currentJobId) : -1;
                    self.seletedPositionIndex = currentJobIndex > -1 ? currentJobIndex : 0;
                    var currentJobApplicationId = self.appliedPositions[self.seletedPositionIndex].JobApplicationId;
                    caDetailSvc.updateSelectedJobApplication(currentJobApplicationId);
                    loadInterviewInfor(currentJobApplicationId);
                    self.applicationRating = parseInt(self.appliedPositions[self.seletedPositionIndex].Rating);
                    caDetailSvc.setCurrentPosition(self.appliedPositions[self.seletedPositionIndex]);
                    $rootScope.currentJobApplicationIdOfCandidate = '';
                    $timeout(function () {
                        self.isShowLoading = false;
                    }, 1500);
                }
            }, true);

            $scope.$on(caConstants.events.showLoadingEvent, function () {
                self.isShowLoading = true;
            });

            $scope.$on(constants.broadCastTile.updateCandidateRating, function (event, rootScopeParams) {
                caApplicationsSvc.updateJobApplicationRating(rootScopeParams.Id, rootScopeParams.Rating);
            });

            $scope.$on(constants.broadCastTile.rejectCandidate, function (event, rootScopeParams) {
                getThankYouMail();
            });

            self.canEditCandidateInfo = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo);
        }

        function loadInterviewInfor(jobApplicationId) {
            if (!jobApplicationId) {
                var data = {};
                data.isShowLoading = false;
                caDetailSvc.setInterviewData(data);
                broadcastInterview(data);
                return;
            }

            self.isShowLoading = true;
            caDetailSvc.setCandidateId(self.candidateId);
            jobApplicationId = parseInt(jobApplicationId);
            loadInterviewData(self.candidateId, jobApplicationId);
            caDetailSvc.updateSelectedJobApplication(jobApplicationId);
        }

        function goToJobDetail(id) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/jobs/" + id, window.location.href);
            historyPageSvc.setPreviousTag(constants.baseUrl + "#/jobs/" + id, constants.invitationMenuIndex.all);
            $rootScope.$broadcast(constants.broadCastTile.storeJobFilter, {});
            $.jStorage.set(constants.localStorageKey.jobSearch, self.filter);
        }

        function goToDashboardJobDetail(id) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/jobs/" + id + "/dashboard", window.location.href);
            historyPageSvc.setPreviousTag(constants.baseUrl + "#/jobs/" + id + "/dashboard", constants.invitationMenuIndex.all);
            $rootScope.$broadcast(constants.broadCastTile.storeJobFilter, {});
            $.jStorage.set(constants.localStorageKey.jobSearch, self.filter);
        }

        function broadcastInterview(data) {
            $rootScope.$broadcast("loadInterviewDataFinish", { data: data });
        }

        function loadInterviewData(candidateId, jobApplicationId) {
            var data = {};
            data.isShowLoading = true;
            self.isHide = false;
            caDetailSvc.setInterviewData(data);
            broadcastInterview(data);
            var candidateInterviews = candidateSvc.interviewResource(candidateId, jobApplicationId).get(
                function () {
                    var currentJobApplication = caDetailSvc.getSelectedJobApplicationId();
                    if (!currentJobApplication.value || jobApplicationId != currentJobApplication.value) return;
                    self.isHide = candidateInterviews.IsHide;
                    data.candidateInterview = candidateInterviews;
                    caDetailSvc.setInterviewData(data);
                    broadcastInterview(data);
                },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    data.isShowLoading = false;
                    caDetailSvc.setInterviewData(data);
                    broadcastInterview(data);
                    messageHandleSvc.handleResponse(xhr, caMessage.interview.getCandidateInterviewError, doesNotShow);
                });
        }

        function getButtonStyle(index) {
            return self.seletedPositionIndex == index ? constants.buttonCircleActiveClass : constants.buttonCircleClass;
        }

        function updateSelectedJobApplication(index) {
            if (index < 0 || index > self.appliedPositions.length - 1) return;
            self.seletedPositionIndex = index;
            var jobApplicationId = self.appliedPositions[index].JobApplicationId;
            caDetailSvc.setCurrentPosition(self.appliedPositions[index]);
            self.applicationRating = parseInt(self.appliedPositions[self.seletedPositionIndex].Rating);
            loadInterviewInfor(jobApplicationId);
            caDetailSvc.updateSelectedJobApplication(jobApplicationId);
        }

        function getLastedInterview(list) {
            if (!list || list.length === 0) {
                self.currentInterview = undefined;
                return "";
            }
            for (var index = list.length - 1; index >= 0; index--) {
                if (!list[index].InterviewRound.IsCanceled) {
                    self.currentInterview = list[index];
                    return self.currentInterview.InterviewRound.DateInterview;
                }
            }
            self.currentInterview = undefined;
            return "";
        }

        function getThankYouMail() {
            var jobApplicationId = caDetailSvc.getSelectedJobApplicationId();
            self.emailData.listOfJobApplication = [jobApplicationId.value];
            emailSvc.getLetter(constants.emailCode.thankYouLetter, { CanRndCanDtllId: jobApplicationId.value }).get(function (data) {
                self.emailData.dataForPreview = data;
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            }, function (error) {
                messageHandleSvc.handleResponse(error, $filter(constants.translate)(message.errorLoadingData));
            });
            $("#reviewThankYouMailModal").modal('show');
        }
    }
})();
