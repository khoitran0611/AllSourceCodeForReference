﻿(function () {
    'use strict';
    angular.module('app').controller('caGeneralInfoCtrl', CaGeneralInfoCtrl);
    CaGeneralInfoCtrl.$inject = ['caDetailModel', 'caGeneralInfoModel', 'constants', 'caConstants', 'message', 'caMessage',
        '$state', '$stateParams', '$scope', '$filter', '$timeout', '$compile', '$rootScope', '$window',
        'candidateSvc', 'switchCandidateSvc', 'caDetailSvc', 'datetimeSvc', 'messageHandleSvc', 'permissionSvc', "caApplicationsSvc",
        "historyPageSvc", "objectSvc", "uploadFileSvc", 'comparisonUtilSvc', 'loadingSvc'];
    function CaGeneralInfoCtrl(caDetailModel, caGeneralInfoModel, constants, caConstants, message, caMessage,
            $state, $stateParams, $scope, $filter, $timeout, $compile, $rootScope, $window,
            candidateSvc, switchCandidateSvc, caDetailSvc, datetimeSvc, messageHandleSvc, permissionSvc, caApplicationsSvc,
            historyPageSvc, objectSvc, uploadFileSvc, comparisonUtilSvc, loadingSvc) {
        var self = this;
        self.imageUploaded = $('.img-container img');
        self.cropImageModal = {
            source: ""
        };
        self.isShowLoading = true;
        self.candidateBasicInfo = { Gender: "" };
        self.isModifiedData = false;
        self.isEditMode = false;
        self.isValidBirthday = true;
        self.isShowMoreDetail = false;
        self.canChangeCandidate = true;
        self.isDisableNext = true;
        self.isDisablePrevious = true;
        self.isDisplayLastName = true;
        self.genders = [{ name: "" }, { name: "Male" }, { name: "Female" }];
        self.initTagInfo = {};
        self.formImageData = null;

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };

        self.editGeneralInformation = editGeneralInformation;
        self.onChangeBirthday = onChangeBirthday;
        $scope.uploadCandidateImage = uploadCandidateImage;
        self.saveGeneralInformation = saveGeneralInformation;
        self.cancelEditGeneralInformation = cancelEditGeneralInformation;
        self.changeName = changeName;
        self.getCssClass = getCssClass;
        self.imageUploadCrop = imageUploadCrop;
        self.avatarPath = constants.noAvatar;
        self.checkPhoneCharacter = objectSvc.checkPhoneNumber;
        self.getFullName = getFullName;

        var param = {};
        var initialCandidateBasicInfo = {};
        var hasImageCropped = false;
        var hasImageUploadedOnTemp = false;
        var candidateImage = null;

        init();

        function init() {
            self.candidateBasicInfo = {};
            initialCandidateBasicInfo = {};
            param.candidateId = $stateParams.id;

            $scope.$on("loadcandidateBasicInfo", function (event, response) {
                var data = response.data;
                if (!data.CandidateBasicInfo) return;
                caDetailSvc.setCandidateBasicInfo(data);
                initialCandidateBasicInfo = new caGeneralInfoModel(data.CandidateBasicInfo);
                self.candidateBasicInfo = new caGeneralInfoModel(data.CandidateBasicInfo);
                self.avatarPath = getImageLink(data.CandidateBasicInfo.ImagePath);

                if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateBasicInfo.City) || self.candidateBasicInfo.City === "") {
                    self.candidateBasicInfo.CityDisplay = "";
                } else if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateBasicInfo.Address) || self.candidateBasicInfo.Address === "") {
                    self.candidateBasicInfo.CityDisplay = self.candidateBasicInfo.City;
                } else {
                    self.candidateBasicInfo.CityDisplay = ", " + self.candidateBasicInfo.City;
                }
                self.isDisplayLastName = !isValidEmailAddress(self.candidateBasicInfo.FirstName) || !isValidEmailAddress(self.candidateBasicInfo.LastName) || (self.candidateBasicInfo.FirstName != self.candidateBasicInfo.LastName);
                caDetailModel.setCandidateStatus(self.candidateBasicInfo.IsDelete);
                $timeout(function () {
                    self.isShowLoading = false;
                    var templateTagInfoDirective = "<div tag-info inittaginfo=\"caGeInCtrl.initTagInfo\" candidateid=\"{{caGeInCtrl.candidateBasicInfo.CandidateId}}\"><\/div>";
                    self.initTagInfo.listTag = $.map(data.ListTagInfo, function (item) {
                        return {
                            id: item.TagId,
                            text: item.TagName
                        };
                    });
                    self.initTagInfo.initSelection = $.map(self.candidateBasicInfo.Tags, function (item) {
                        return item.TagId;
                    });
                    angular.element(document.getElementById('candidatetag')).append($compile(templateTagInfoDirective)($scope));
                }, 500);
            });

            $scope.$watch('caGeInCtrl.candidateBasicInfo', function (newValue, oldValue) {
                if (newValue == oldValue) return;
                self.isModifiedData = angular.toJson(self.candidateBasicInfo) != angular.toJson(initialCandidateBasicInfo);
            }, true);

            $scope.$watch(function () {
                return window.innerWidth;
            }, function (value) {
                self.screenWidth = value;
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            });

            $scope.$on(caConstants.events.updateCandidateName, function (event, rootScopeParams) {
                self.candidateBasicInfo.IsDelete = rootScopeParams.IsDelete;
            });
        }

        function getImageLink(link) {
            if (!link || link.toLowerCase().indexOf("image-placeholder") >= 0) return angular.copy(constants.noAvatar);
            var linkInLowerCase = link.toLowerCase();
            if (linkInLowerCase.indexOf("http://") === 0 || linkInLowerCase.indexOf("https://") === 0 || linkInLowerCase.indexOf("www.") >= 0) return link;
            return (constants.serverUrl + link);
        }

        function editGeneralInformation() {
            resetDirtyForm();
            self.isEditMode = !self.isEditMode;
            $timeout(function () {
                $('#dob.date').datepicker({ autoclose: true, todayHighlight: true, orientation: "top left" });
            }, 500);
        }

        function onChangeBirthday() {
            var now = new Date();
            var currentYear = moment(now);
            var minAge = 20, maxAge = 100;
            var yearOld = moment(self.candidateBasicInfo.BirthdayOnView, constants.formatDateDDMMYYYY);
            self.isValidBirthday = currentYear.diff(yearOld, 'years') >= minAge && currentYear.diff(yearOld, 'years') < maxAge;
        }

        function uploadCandidateImage() {
            var $input = document.getElementById('imageCandidate');
            if (!$input.files || !$input.files[0]) return;
            var fileSize = $input.files[0].size;
            if (fileSize >= caConstants.maxFileSizeUploaded) {
                toastr.warning($filter(caConstants.translate)(caMessage.uploadFileLessThan) + ' ' + $filter(caConstants.translate)(caMessage.sizeOfImage));
                cloneUploadInput();
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
                return;
            }

            candidateImage = $input.files[0];
            if (typeof (FileReader) == constants.undefined) {
                uploadCandidateImageToTemp(candidateImage);
            } else {
                var reader = new FileReader();
                reader.onload = function (element) {
                    if (/^image\/\w+$/.test($input.files[0].type)) {
                        $rootScope.$broadcast(caConstants.events.updateCropImageSource, element.target.result);
                        angular.element(document.querySelector('#upload-image-modal')).modal('show');
                        if (!$scope.$$phase && !$scope.$root.$$phase) {
                            $scope.$apply();
                        }
                    } else {
                        cloneUploadInput();
                        toastr.warning($filter(constants.translate)(caMessage.generalInformation.importImage));
                    }
                };
                reader.readAsDataURL($input.files[0]);
            }
        }

        function uploadCandidateImageToTemp(file) {
            self.candidateBasicInfo.FullName = (isValidEmailAddress(self.candidateBasicInfo.FirstName) && isValidEmailAddress(self.candidateBasicInfo.LastName) && self.candidateBasicInfo.FirstName == self.candidateBasicInfo.Last) ? self.candidateBasicInfo.FirstName : self.candidateBasicInfo.FirstName + " " + self.candidateBasicInfo.LastName;
            uploadFileSvc.uploadFile(file, caConstants.candidateImageTemp, getProfilePictureNameByFullName(self.candidateBasicInfo.FullName)).$promise.then(function (data) {
                //TODO remove below line
                $window.localStorage.setItem(caConstants.candidateFullName, self.candidateBasicInfo.FullName, { expires: 1 });
                if (data.value.length < 0) return;
                self.candidateBasicInfo.ImagePath = data.value;
                self.avatarPath = constants.serverUrl + data.value;
                hasImageUploadedOnTemp = true;
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            }, function (error) {
                messageHandleSvc.handleResponse(error, $filter(constants.translate)("General_Information.Error_In_Updating_Candidate_Image"));
            });
            return;

            function getProfilePictureNameByFullName(fullName) {
                var fileName = fullName.replace(/[\\/:*?"<>|]/g, '').trim();
                return fileName !== '' ? fileName : moment().format('YYYY-MM-DD');
            }
        }

        function cloneUploadInput() {
            var control = $('input#imageCandidate');
            control.replaceWith(control = control.clone(true));
            self.candidateBasicInfo.ImagePath = angular.copy(self.avatarPath);
        }

        function saveGeneralInformation() {
            loadingSvc.show();
            caDetailSvc.getCheckingEmailResource($stateParams.id, self.candidateBasicInfo.Email).get(
                function (data) {
                    loadingSvc.close();
                    var duplicate = 't';
                    if (data[0] == duplicate && initialCandidateBasicInfo.Email != self.candidateBasicInfo.Email) {
                        toastr.error($filter(constants.translate)(caMessage.generalInformation.duplicateEmailError));
                        return;
                    }
                    saveAllDataToDatabase();
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, caMessage.generalInformation.checkEmailError);
                });
        }

        function saveAllDataToDatabase() {
            self.candidateBasicInfo.Birthday = datetimeSvc.convertDateForServerSide(self.candidateBasicInfo.BirthdayOnView, false);
            if (self.candidateBasicInfo.Mobile.length) {
                self.candidateBasicInfo.Mobile = formatPhoneNumber(self.candidateBasicInfo.Mobile);
            }
            if (self.candidateBasicInfo.Phone.length) {
                self.candidateBasicInfo.Phone = formatPhoneNumber(self.candidateBasicInfo.Phone);
            }
            self.candidateBasicInfo.ImagePath = self.candidateBasicInfo.ImagePath.toLowerCase().indexOf("image-placeholder") >= 0 ? "" : self.candidateBasicInfo.ImagePath;
            self.avatarPath = getImageLink(self.candidateBasicInfo.ImagePath);
            loadingSvc.show();
            if (!hasImageUploadedOnTemp) {
                caDetailSvc.getCandidateDetailResource(param).update(self.candidateBasicInfo,
                    function (data) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(data, caMessage.generalInformation.updateCandidateInformationSuccess);
                        self.candidateBasicInfo.FullName = self.candidateBasicInfo.FullName = (isValidEmailAddress(self.candidateBasicInfo.FirstName) && isValidEmailAddress(self.candidateBasicInfo.LastName) && self.candidateBasicInfo.FirstName == self.candidateBasicInfo.Last) ? self.candidateBasicInfo.FirstName : self.candidateBasicInfo.FirstName + " " + self.candidateBasicInfo.LastName;
                        initialCandidateBasicInfo = new caGeneralInfoModel(self.candidateBasicInfo);
                        self.isDisplayLastName = !isValidEmailAddress(self.candidateBasicInfo.FirstName) || !isValidEmailAddress(self.candidateBasicInfo.LastName) || (self.candidateBasicInfo.FirstName != self.candidateBasicInfo.LastName);
                        angular.copy(initialCandidateBasicInfo, self.candidateBasicInfo);
                        candidateSvc.candidateInforData.candidateBasicInfo = angular.copy(initialCandidateBasicInfo);
                        $rootScope.$broadcast(caConstants.events.updateCandidateGeneralInformation, self.candidateBasicInfo);
                        $timeout(function () {
                            resetDirtyForm();
                        }, 500);
                        if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateBasicInfo.City) || self.candidateBasicInfo.City === "") {
                            self.candidateBasicInfo.CityDisplay = "";
                        } else if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateBasicInfo.Address) || self.candidateBasicInfo.Address === "") {
                            self.candidateBasicInfo.CityDisplay = self.candidateBasicInfo.City;
                        } else {
                            self.candidateBasicInfo.CityDisplay = ", " + self.candidateBasicInfo.City;
                        }
                        if (!$scope.$$phase && !$scope.$root.$$phase) {
                            $scope.$apply();
                        }
                    },
                    function (xhr) {
                        loadingSvc.close();
                        hasImageUploadedOnTemp = false;
                        messageHandleSvc.handleResponse(xhr, caMessage.generalInformation.updateCandidateInformationError);
                    });
            } else {
                caDetailSvc.moveCandidateImageToOriginal(self.candidateBasicInfo.ImagePath).get(function (result) {
                    var imagePath = arrayResourceToString(result);
                    self.candidateBasicInfo.ImagePathTemp = imagePath;
                    self.candidateBasicInfo.ImagePath = imagePath;
                    self.avatarPath = getImageLink(self.candidateBasicInfo.ImagePath);
                    caDetailSvc.getCandidateDetailResource(param).update(self.candidateBasicInfo,
                        function (data) {
                            loadingSvc.close();
                            messageHandleSvc.handleResponse(data, caMessage.generalInformation.updateCandidateInformationSuccess);
                            self.candidateBasicInfo.FullName = self.candidateBasicInfo.FullName = (isValidEmailAddress(self.candidateBasicInfo.FirstName) && isValidEmailAddress(self.candidateBasicInfo.LastName) && self.candidateBasicInfo.FirstName == self.candidateBasicInfo.Last) ? self.candidateBasicInfo.FirstName : self.candidateBasicInfo.FirstName + " " + self.candidateBasicInfo.LastName;
                            initialCandidateBasicInfo = new caGeneralInfoModel(self.candidateBasicInfo);
                            self.isDisplayLastName = !isValidEmailAddress(self.candidateBasicInfo.FirstName) || !isValidEmailAddress(self.candidateBasicInfo.LastName) || (self.candidateBasicInfo.FirstName != self.candidateBasicInfo.LastName);
                            angular.copy(initialCandidateBasicInfo, self.candidateBasicInfo);
                            candidateSvc.candidateInforData.candidateBasicInfo = angular.copy(initialCandidateBasicInfo);
                            $rootScope.$broadcast(caConstants.events.updateCandidateGeneralInformation, self.candidateBasicInfo);
                            hasImageCropped = false;
                            $timeout(function () {
                                resetDirtyForm();
                            }, 500);
                            if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateBasicInfo.City) || self.candidateBasicInfo.City === "") {
                                self.candidateBasicInfo.CityDisplay = "";
                            } else if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateBasicInfo.Address) || self.candidateBasicInfo.Address === "") {
                                self.candidateBasicInfo.CityDisplay = self.candidateBasicInfo.City;
                            } else {
                                self.candidateBasicInfo.CityDisplay = ", " + self.candidateBasicInfo.City;
                            }
                            if (!$scope.$$phase && !$scope.$root.$$phase) {
                                $scope.$apply();
                            }
                        },
                        function (xhr) {
                            loadingSvc.close();
                            messageHandleSvc.handleResponse(xhr, caMessage.generalInformation.updateCandidateInformationError);
                        });
                }, function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, caMessage.generalInformation.updateCandidateImageError);
                });
            }
        }

        function resetDirtyForm() {
            hasImageCropped = false;
            hasImageUploadedOnTemp = false;
            self.isEditMode = false;
            self.isModifiedData = false;
            self.isValidBirthday = true;
            return;
        }

        function cancelEditGeneralInformation() {
            self.candidateBasicInfo = new caGeneralInfoModel(initialCandidateBasicInfo);
            self.avatarPath = getImageLink(self.candidateBasicInfo.ImagePath);
            if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateBasicInfo.City) || self.candidateBasicInfo.City === "") {
                self.candidateBasicInfo.CityDisplay = "";
            } else if (comparisonUtilSvc.isNullOrUndefinedValue(self.candidateBasicInfo.Address) || self.candidateBasicInfo.Address === "") {
                self.candidateBasicInfo.CityDisplay = self.candidateBasicInfo.City;
            } else {
                self.candidateBasicInfo.CityDisplay = ", " + self.candidateBasicInfo.City;
            }
            resetDirtyForm();
        }

        function changeName(name) {
            if (!name) return "";
            var maxLength = 23;
            if (self.screenWidth < 1600 && self.screenWidth >= 1028) maxLength = 21;
            if (self.screenWidth < 1028 && self.screenWidth >= 1024) maxLength = 14;
            if (self.screenWidth < 1024 && self.screenWidth >= 768) maxLength = 10;
            if (self.screenWidth < 768 && self.screenWidth >= 600) maxLength = 7;
            if (self.screenWidth < 600 && self.screenWidth >= 568) maxLength = 6;
            if (self.screenWidth < 568) maxLength = 4;
            if (name.length <= maxLength) return name;
            return name.substr(0, maxLength) + '...';
        }


        function getCssClass(isViewMode) {
            return isViewMode ? !self.isEditMode && 'show panel-body' || 'hide panel-body bg-default' : !self.isEditMode && 'hide panel-body bg-info' || 'show panel-body bg-default';
        }

        function imageUploadCrop() {
            self.formImageData = new FormData();
            var imageUploaded = $('.img-container > img');
            var imageCropped = imageUploaded.cropper("getCroppedCanvas", { width: 240, height: 280 });
            self.candidateBasicInfo.ImagePath = imageCropped.toDataURL("image/png");
            self.avatarPath = angular.copy(self.candidateBasicInfo.ImagePath);
            imageCropped.toBlob(function (blob) {
                self.formImageData.append('croppedImage', blob, 'cropped.png');
                var fileAfterCrop = self.formImageData.get('croppedImage');
                uploadCandidateImageToTemp(fileAfterCrop);
            });
            hasImageCropped = true;
        }

        function getFullName() {
            if (!self.candidateBasicInfo || !self.candidateBasicInfo.FirstName) return '';
            if (!self.isDisplayLastName) return self.candidateBasicInfo.FirstName;
            return self.candidateBasicInfo.FirstName + ' ' + self.candidateBasicInfo.LastName;
        }
    }
})();