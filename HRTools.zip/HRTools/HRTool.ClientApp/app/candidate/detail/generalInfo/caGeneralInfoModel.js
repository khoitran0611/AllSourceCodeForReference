﻿(function () {
    "use strict";
    angular.module('app').factory('caGeneralInfoModel', caGeneralInfoModel);
    caGeneralInfoModel.$inject = ['constants', 'datetimeSvc', 'comparisonUtilSvc'];

    function caGeneralInfoModel(constants, datetimeSvc, comparisonUtilSvc) {
        var model = function (candidateGeneralInfo) {
            /* jshint -W040 */
            var self = this;

            self.CandidateId = candidateGeneralInfo.CandidateId;
            self.FirstName = candidateGeneralInfo.FirstName || "";
            self.LastName = candidateGeneralInfo.LastName || "";
            self.FullName = candidateGeneralInfo.FullName || "";
            self.Email = candidateGeneralInfo.Email || "";
            self.OtherEmail = candidateGeneralInfo.OtherEmail || "";
            self.BirthdayOnView = candidateGeneralInfo.Birthday ? moment(candidateGeneralInfo.Birthday).format(constants.formatDateDDMMYYYY) : null;
            self.Birthday = candidateGeneralInfo.Birthday ? datetimeSvc.convertDateForServerSide(self.BirthdayOnView, false) : null;
            self.IdNo = candidateGeneralInfo.IdNo || "";
            self.Address = candidateGeneralInfo.Address || "";
            self.City = candidateGeneralInfo.City || "";
            self.Gender = candidateGeneralInfo.Gender || "";
            self.ImagePath = (
                    candidateGeneralInfo.ImagePath == constants.stringContainNull ||
                        candidateGeneralInfo.ImagePath == constants.stringEmpty ||
                        comparisonUtilSvc.isNullOrUndefinedValue(candidateGeneralInfo.ImagePath)
                ) ? constants.noAvatar : candidateGeneralInfo.ImagePath;
            self.ImagePathTemp = self.ImagePath;

            self.Mobile = candidateGeneralInfo.Mobile || "";
            self.Phone = candidateGeneralInfo.Phone || "";
            self.Note = candidateGeneralInfo.Note || "";
            self.StatusId = candidateGeneralInfo.StatusId;
            self.IsDelete = candidateGeneralInfo.IsDelete;
            self.IsAccepted = candidateGeneralInfo.IsAccepted;

            self.Tags = candidateGeneralInfo.Tags;
        };
        return model;
    }
})();
