﻿(function () {
    'use strict';

    angular.module('app').controller('caUploadedDocumentCtrl', UploadedDocumentCtrl);
    UploadedDocumentCtrl.$inject = ['uploadFilesSvc', '$state', 'caDetailSvc', 'loadingSvc'];

    function UploadedDocumentCtrl(uploadFilesSvc, $state, caDetailSvc, loadingSvc) {
        var candidateId = $state.params.id;
        var originFiles = [];
        var params = {
            candidateId: candidateId,
            jobApplicationId: ''
        };
        var self = this;
        self.fileType = 'CandidateFile';
        self.cvFiles = [];
        self.candidateName = '';
        self.isEdit = false;

        self.edit = edit;
        self.save = save;
        self.cancel = cancel;
        self.isDisableSave = isDisableSave;

        init();
        function init() {
            caDetailSvc.setCandidateId(candidateId);
            params.jobApplicationId = caDetailSvc.getSelectedJobApplicationId(init).value;
            if (params.jobApplicationId) {
                uploadFilesSvc.getCvAttachments(params).query(
                function (response) {
                    self.cvFiles = response;
                    angular.copy(self.cvFiles, originFiles);
                    loadingSvc.close();
                });
            } else {
                loadingSvc.close();
            }
            self.candidateName = caDetailSvc.getCandidateName();
        }

        function edit() {
            self.isEdit = true;
        }

        function save() {
            params.cvFiles = self.cvFiles;
            uploadFilesSvc.updateCvFile(params);
            self.isEdit = false;
            angular.copy(self.cvFiles, originFiles);
        }

        function cancel() {
            self.isEdit = false;
            uploadFilesSvc.clearInputForm();
            angular.copy(originFiles, self.cvFiles);
        }

        function isDisableSave() {
            return angular.equals(self.cvFiles, originFiles);
        }
    }
})();