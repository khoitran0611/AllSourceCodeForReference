﻿(function () {
    'use strict';
    angular.module('app').controller('caNoteCtrl', CaNoteCtrl);
    CaNoteCtrl.$inject = ['caDetailSvc', 'datetimeSvc', 'messageHandleSvc', 'permissionSvc',
        'constants', 'caConstants', 'caMessage', 'message', 'caDetailModel',
        '$scope', '$filter', '$state', '$window'];
    function CaNoteCtrl(caDetailSvc, datetimeSvc, messageHandleSvc, permissionSvc,
        constants, caConstants, caMessage, message, caDetailModel,
        $scope, $filter, $state, $window) {
        var self = this;
        self.newNote = '';
        self.notes = [];

        self.convertDate = convertDate;
        self.addNew = addNew;
        self.noteStatus = caDetailModel.getNewNote();

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo)
        };

        var candidateId = $state.params.id;
        var currentUserLogin = JSON.parse($window.localStorage.getItem("currentuserlogin"));
        var param = {
            candidateId: candidateId
        };

        init();
        function init() {
            caDetailSvc.candidateNoteResource(param).query().$promise.then(function (response) {
                self.notes = response;
            }, function (xhr) {
                var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                caDetailSvc.setCurrentLoading(false);
                messageHandleSvc.handleResponse(xhr, message.errorLoadingData, doesNotShow);
            });

            $scope.$watch('self.noteStatus', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                if (newValue.value) {
                    self.notes.push(newValue.value);
                }
            }, true);
        }

        function convertDate(date, isDateTime) {
            return datetimeSvc.convertDateHour(date, isDateTime);
        }

        function addNew() {
            var note = {
                CreatedByUserId: currentUserLogin.UserId,
                CreatedUser: currentUserLogin.FullName,
                CandidateId: param.candidateId,
                Source: $filter(constants.translate)(caConstants.administrationSource.administration),
                CreatedDate: new Date(),
                Note: self.newNote
            };
            caDetailSvc.candidateNoteResource(param).save(note, function (response) {
                if (angular.isString(response[0])) {
                    formatAfterAdd(note);
                    toastr.success($filter(constants.translate)(caMessage.notes.addNewNoteSuccessfully));
                }
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, caMessage.notes.addNewNoteError);
            });
        }

        function formatAfterAdd(note) {
            self.notes.push(note);
            self.newNote = '';
        }
    }
})();