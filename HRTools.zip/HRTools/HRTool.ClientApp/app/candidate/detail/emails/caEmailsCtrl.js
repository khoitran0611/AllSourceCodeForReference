﻿(function () {
    'use strict';
    angular.module('app').controller('caEmailsCtrl', CaEmailsCtrl);
    CaEmailsCtrl.$inject = ['caDetailSvc', 'datetimeSvc', 'messageHandleSvc', 'permissionSvc',
        'constants', 'caConstants', 'caMessage', 'message', 'caDetailModel',
        '$scope', '$filter', '$state', 'candidateSvc', '$stateParams', '$timeout', '$compile', '$sce'];
    function CaEmailsCtrl(caDetailSvc, datetimeSvc, messageHandleSvc, permissionSvc,
        constants, caConstants, caMessage, message, caDetailModel,
        $scope, $filter, $state, candidateSvc, $stateParams, $timeout, $compile, $sce) {
        var self = this;
        var jobApplicationId = 0;

        var _jobApplicationId = caDetailSvc.getSelectedJobApplicationId();
        var _candidateId = $stateParams.id;
        self.isShowLoading = true;
        self.emailTrackingList = {};
        self.serverUrl = constants.serverUrl;

        self.showMoreLess = showMoreLess;

        init();

        function init() {
            $scope.$watch('ceCtrl.jobApplicationId', function (newValue) {
                var defaultValue = 0;
                if (!newValue)
                    return;
                if (newValue.value == defaultValue) return;
                self.isShowLoading = true;
                caDetailSvc.setCandidateId(_candidateId);
                if (_jobApplicationId.value > defaultValue) {
                    self.emailTrackingList = [];
                    jobApplicationId = parseInt(_jobApplicationId.value);
                    loadEmailTracking(_candidateId, jobApplicationId);
                }
            }, true);
        }

        function loadEmailTracking(candidateId, jobApplicationId) {
            candidateSvc.emailTrackingResource(candidateId, jobApplicationId).query(function (data) {
                self.emailTrackingList = [];
                self.emailTrackingList = data;
                for (var i = 0; i < self.emailTrackingList.length; i++) {
                    self.emailTrackingList[i].Body = $sce.trustAsHtml(self.emailTrackingList[i].Body);
                }
                $timeout(function () {
                    $('.email-body').each(function () {
                        if ($(this).children().length > 0) {
                            $(this).find('a').removeAttr("href");
                            $(this).children('meta').remove();
                            $(this).children('style').remove();
                            $(this).children('script').remove();
                            $(this).children('div').each(function () {
                                var temp = $(this).html();
                                $(this).parent('.email-body').append(temp);
                                $(this).remove();
                            });
                            if ($(this).children('i.fa-ellipsis-h').length === 0) {
                                $(this).append($compile('<i class="fa fa-ellipsis-h show-default" ng-click="ceCtrl.showMoreLess($event)"></i>')($scope));
                            }
                            $(this).children().slice(0, 2).addClass('show-default');
                        }
                    });
                }, 800);
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, caMessage.emailTrackingLoadingError);
            });
        }

        function showMoreLess(event) {
            var target = $(event.target);
            target.parent().children().toggleClass('show');
            return false;
        }
    }
})();