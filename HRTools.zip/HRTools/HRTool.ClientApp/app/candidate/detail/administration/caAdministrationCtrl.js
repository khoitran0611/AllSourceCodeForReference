﻿(function () {
    'use strict';
    angular.module('app').controller('caAdministrationCtrl', CaAdministrationCtrl);
    CaAdministrationCtrl.$inject = ['messageHandleSvc', 'permissionSvc', 'authenticationSvc', 'constants', 'caConstants', 'message', 'caMessage', '$state', '$filter', 'caDetailSvc', '$rootScope', '$scope'];
    function CaAdministrationCtrl(messageHandleSvc, permissionSvc, authenticationSvc, constants, caConstants, message, caMessage, $state, $filter, caDetailSvc, $rootScope, $scope) {
        var self = this;
        self.canShowDeleteButton = false;
        self.isShowLoading = false;
        self.currentUserPermission = permissionSvc.getCurrentUserPermission();
        self.candidateEmail = '';

        self.showConfirmDialog = showConfirmDialog;
        self.onYesConfirm = onYesConfirm;
        self.changeDeleteLabel = changeDeleteLabel;
        self.dialogConfirm = angular.copy(caMessage.administration.dialogConfirmDelete);
        var _candidateBasicInfoBackup = caDetailSvc.getCandidateBasicInfo();

        var candidateId = $state.params.id;
        var isCandidateDeleted = null;
        var candidateBasicInfo = {};
        var dialogConfirmRestore = {
            dialogTitle: $filter(constants.translate)('Confirm_Restore'),
            dialogMessage: $filter(constants.translate)('Administration.Are_You_Sure_To_Restore_This_Candidate')
        };
        var dialogCornfirmDelete = {
            dialogTitle: $filter(constants.translate)(caMessage.administration.dialogConfirmDelete.dialogTitle),
            dialogMessage: $filter(constants.translate)(caMessage.administration.dialogConfirmDelete.dialogMessage)
        };

        init();

        function init() {
            $scope.$on("loadcandidateBasicInfo", function (event, response) {
                candidateBasicInfo = response.data.CandidateBasicInfo;
                _candidateBasicInfoBackup = response.data.CandidateBasicInfo;
                if (!candidateBasicInfo) return;
                isCandidateDeleted = candidateBasicInfo.IsDelete;
                if (isCandidateDeleted) {
                    self.canShowDeleteButton = self.currentUserPermission.canRestoreCandidate;
                } else {
                    self.canShowDeleteButton = self.currentUserPermission.canDeleteCandidate;
                }
            }, true);

            $scope.$on(caConstants.events.updateCandidateGeneralInformation, function (event, rootScopeParams) {
                candidateBasicInfo.Email = angular.copy(rootScopeParams.Email);
                if (!$scope.$$phase) $scope.$apply();
            });
        }

        function showConfirmDialog() {
            if (isCandidateDeleted) {
                self.dialogConfirm.dialogTitle = angular.copy(dialogConfirmRestore.dialogTitle);
                self.dialogConfirm.dialogMessage = angular.copy(dialogConfirmRestore.dialogMessage);
            } else {
                self.dialogConfirm.dialogTitle = angular.copy(dialogCornfirmDelete.dialogTitle);
                self.dialogConfirm.dialogMessage = angular.copy(dialogCornfirmDelete.dialogMessage);
            }
            angular.element('#' + self.dialogConfirm.dialogId).modal('show');
        }

        function onYesConfirm() {
            if (!self.canShowDeleteButton) {
                messageHandleSvc.handlePermission(true);
                return;
            }
            var paramAction = {
                id: '0',
                listCandidateId: [candidateId]
            };
            var successMessage = '';
            var errorMessage = '';
            if (isCandidateDeleted) {
                paramAction.action = 'restoreCandidate';
                successMessage = caMessage.administration.restoreCandidateSuccess;
                errorMessage = caMessage.administration.restoreCandidateError;
            } else {
                paramAction.action = 'deleteCandidate';
                successMessage = caMessage.administration.deleteCandidateSuccess;
                errorMessage = caMessage.administration.deleteCandidateError;
            }

            caDetailSvc.restoreDeleteCandidate(paramAction).then(
                function (response) {
                    var updateSuccessfully = 'UpdateSuccessfully';
                    if (response[candidateId] == updateSuccessfully) {
                        toastr.success($filter(constants.translate)(successMessage));
                        isCandidateDeleted = !isCandidateDeleted;
                        $rootScope.$broadcast(caConstants.events.updateCandidateName, { IsDelete: isCandidateDeleted });
                    }
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, errorMessage);
                });
        }

        function changeDeleteLabel() {
            return isCandidateDeleted ? caConstants.administrationSource.Restore : caConstants.administrationSource.Delete;
        }
    }
})();
