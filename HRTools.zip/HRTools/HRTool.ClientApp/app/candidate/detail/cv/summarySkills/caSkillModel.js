﻿(function () {
    'use strict';
    angular.module('app').factory('caSkillModel', caSkillModel);

    function caSkillModel() {
        var resource = function (candidateSkill, isEmployee) {
            /* jshint -W040 */
            var self = this;
            self.Id = candidateSkill ? candidateSkill.Id : undefined;
            self.CandidateId = candidateSkill ? candidateSkill.CandidateId : undefined;
            self.EmployeeId = candidateSkill ? candidateSkill.EmployeeId : undefined;
            self.SkillName = candidateSkill ? candidateSkill.SkillName : '';
            self.LevelId = candidateSkill ? candidateSkill.LevelId : 0;
            self.LevelName = candidateSkill ? candidateSkill.LevelName : '';
            self.Year = candidateSkill ? candidateSkill.Year : 0;
            self.LastUsed = candidateSkill ? candidateSkill.LastUsed : (new Date()).getFullYear();
            self.IsEmployee = isEmployee;
            self.elementId = "Summary-Skill-" + String.randomNumber();
            self.isError = false;

            return self;
        };
        return resource;
    }
})();