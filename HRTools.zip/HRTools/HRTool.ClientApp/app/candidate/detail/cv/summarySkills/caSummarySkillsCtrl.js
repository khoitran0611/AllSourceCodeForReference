﻿(function () {
    'use strict';
    angular.module('app').controller('caSummarySkillsCtrl', CaSummarySkillsCtrl);
    CaSummarySkillsCtrl.$inject = ['caCvSvc', 'validationSvc', 'styleSvc', 'messageHandleSvc', 'permissionSvc', 'caDetailSvc', "objectSvc",
        'constants', 'caConstants', 'message', 'caMessage', 'caSkillModel',
        '$stateParams', '$scope', '$filter', '$timeout', 'comparisonUtilSvc', 'loadingSvc'];
    function CaSummarySkillsCtrl(caCvSvc, validationSvc, styleSvc, messageHandleSvc, permissionSvc, caDetailSvc, objectSvc,
            constants, caConstants, message, caMessage, caSkillModel,
            $stateParams, $scope, $filter, $timeout, comparisonUtilSvc, loadingSvc) {
        var self = this;
        var param = {};
        var oldCandidateSkill = [];
        var rowIndexEditing;
        var isModifiedSkill = false;
        var invalidRowIndex = constants.newRowIndex;
        var candidateId = $stateParams.id;

        self.candidateSkills = [];
        self.isSkillEditing = false;
        self.levels = constants.levels;
        self.isAddingSkill = false;
        self.isShowToogleHeader = true;
        self.isUpdatedByAddMore = false;
        self.dialogConfirm = caMessage.summarySkill.dialogConfirm;
        self.checkNumber = objectSvc.checkNumber;

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };

        self.getHeaderStyle = getHeaderStyle;
        self.years = getYears();
        self.isSkillRowEditing = isSkillRowEditing;
        self.onClickEdit = onClickEdit;
        self.onClickHeader = onClickHeader;
        self.onClickCancelEditRow = onClickCancelEditRow;
        self.onClickEditRow = onClickEditRow;
        self.onClickSaveSkill = onClickSaveSkill;
        self.onClickAddSkill = onClickAddSkill;
        self.isModifiedData = isModifiedData;
        self.onKeyDownYear = onKeyDownYear;
        self.onClickDeleteRow = onClickDeleteRow;
        self.onYes = onYes;
        self.getCssHeaderClass = getCssHeaderClass;
        self.toggleDisplayButton = toggleDisplayButton;

        var skillIdDeleting;
        var rowIndexDeleting;

        init();

        function init() {
            param.candidateId = $stateParams.id;
            caCvSvc.getSummarySkillResource(param).query(
                function (data) {
                    $.each(data, function (index, candidateSkill) {
                        formatLevelName(candidateSkill);
                        formatLastUsed(candidateSkill);
                        candidateSkill.elementId = "Summary-Skill-" + index;
                        var skillItem = new caSkillModel(candidateSkill, false);
                        self.candidateSkills.push(skillItem);
                        oldCandidateSkill.push(skillItem);
                    });
                    $.each(self.candidateSkills, function (index, candidateSkill) {
                        formatLevelName(candidateSkill);
                        formatLastUsed(candidateSkill);
                    });
                    $.each(oldCandidateSkill, function (index, candidateSkill) {
                        formatLevelName(candidateSkill);
                        formatLastUsed(candidateSkill);
                    });
                },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, caMessage.summarySkill.getCandidateSkillError, doesNotShow);
                });

            $scope.$watch('cvCtrl.isEditForm', function (value) {
                self.isSkillEditing = value;
                resetEdit();
            }, true);

            $scope.$watch('caSSCtrl.candidateSkills', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                if (!comparisonUtilSvc.isNullOrUndefinedValue(oldCandidateSkill) && self.candidateSkills.length > 0 && !self.isAddingSkill) {
                    var candidateSkillsFormat = copySkill(self.candidateSkills);
                    isModifiedSkill = JSON.stringify(candidateSkillsFormat) != JSON.stringify(oldCandidateSkill);
                } else {
                    if (self.isAddingSkill) {
                        isModifiedSkill = true;
                    }
                }
            }, true);
        }

        function getHeaderStyle() {
            return styleSvc.getHeaderStyle(self.isSkillEditing);
        }

        function getYears() {
            var duration = 10;
            var list = [];
            var date = new Date();
            var year = date.getFullYear();
            for (var i = year; i >= year - duration; i--) {
                list.push({ value: i });
            }
            return list;
        }

        function isSkillRowEditing(rowIndex) {
            if (rowIndex == rowIndexEditing)
                return true;
            return false;
        }

        function resetEdit() {
            if (!self.isSkillEditing && isModifiedSkill)
                self.candidateSkills = copySkill(oldCandidateSkill);
            rowIndexEditing = constants.newRowIndex;
            isModifiedSkill = false;
            self.isAddingSkill = false;
            if (angular.element('#summary-skills-detail').css('display') == 'none')
                self.onClickHeader();
        }

        function onClickEdit() {
            self.isSkillEditing = !self.isSkillEditing;
            resetEdit();
        }

        function onClickHeader() {
            self.isShowToogleHeader = !self.isShowToogleHeader;
            $('#summary-skills-detail').slideToggle('slow');
        }

        function onClickCancelEditRow() {
            if (self.isAddingSkill) {
                self.candidateSkills.pop();
            }
            self.candidateSkills = copySkill(oldCandidateSkill);
            rowIndexEditing = constants.newRowIndex;
            isModifiedSkill = false;
            self.isAddingSkill = false;
        }

        function onClickEditRow(rowIndex) {
            if (self.isAddingSkill && rowIndexEditing != invalidRowIndex)
                return;
            rowIndexEditing = rowIndex;
        }

        function updateSkill(skillEditing, param) {
            caCvSvc.getSummarySkillResource(param).update(skillEditing,
                    function () {
                        loadingSvc.close();
                        onSuccessSaveSkill();
                        toastr.success($filter(constants.translate)(caMessage.summarySkill.updateCandidateSkillSuccess));
                    },
                    function () {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.summarySkill.updateCandidateSkillError);
                    });
        }

        function addNewSkill(skillEditing, param) {
            caCvSvc.getSummarySkillResource(param).save(skillEditing,
                   function (newSkillId) {
                       loadingSvc.close();
                       skillEditing.Id = arrayResourceToInt(newSkillId);
                       onSuccessSaveSkill();
                       toastr.success($filter(constants.translate)(caMessage.summarySkill.addCandidateSkillSuccess));
                   },
                   function () {
                       loadingSvc.close();
                       messageHandleSvc.handleResponse(xhr, caMessage.summarySkill.insertCandidateSkillError);
                   });
        }

        function onClickSaveSkill(skillId, rowIndex) {
            var skillEditing = getRowEditing(rowIndex);
            skillEditing.LastUsed = skillEditing.LastUsed ? skillEditing.LastUsed.value : null;
            param.skillId = skillId;

            loadingSvc.show();
            if (!self.isAddingSkill) {
                updateSkill(skillEditing, param);
            } else {
                addNewSkill(skillEditing, param);
            }
        }

        function getRowEditing(rowIndex) {
            var skill = new caSkillModel(null, false);
            skill = self.candidateSkills[rowIndex];
            return skill;
        }

        function onSuccessSaveSkill() {
            if (!self.isUpdatedByAddMore) {
                rowIndexEditing = constants.newRowIndex;
                self.isAddingSkill = false;
            }

            self.isUpdatedByAddMore = false;
            isModifiedSkill = false;
            oldCandidateSkill = copySkill(_.filter(self.candidateSkills, function (item) { return !comparisonUtilSvc.isNullOrUndefinedValue(item.Id); }));
        }

        function onClickAddSkill(formName) {
            var isError = false;
            var skill = createSkill();
            if (rowIndexEditing != constants.newRowIndex)
                isError = validateAddMoreAction(self.candidateSkills);
            if (isError) return;
            self.candidateSkills.push(skill);
            focusInput(self.candidateSkills);
            rowIndexEditing = self.candidateSkills.length + constants.newRowIndex;
            self.isAddingSkill = true;
        }

        function focusInput(skills) {
            $timeout(function () {
                var newIndex = findWithAttr(skills, "Id", undefined);
                var inputName = "form#{0} input[type='text']";
                inputName = String.format(inputName, skills[newIndex].elementId);
                var input = angular.element($(inputName));
                input.focus();
            }, 500);
        }

        function validateAddMoreAction(list) {
            for (var i = 0; i < list.length; i++) {
                var inputHiddenError = "form#{0} input[name='inputerror']";
                inputHiddenError = String.format(inputHiddenError, list[i].elementId);
                var isError = angular.element(document.querySelector(inputHiddenError)).attr('value');
                if (isError == "true") {
                    toastr.warning($filter(caConstants.translate)(caMessage.checkInputField));
                    self.skillForm.skillName.$dirty = true;
                    return true;
                }
            }

            for (i = 0; i < list.length; i++) {
                var inputHiddenModified = "form#{0} input[name='inputmodified']";
                inputHiddenModified = String.format(inputHiddenModified, list[i].elementId);
                var isModifiedFiled = angular.element(document.querySelector(inputHiddenModified)).attr('value');
                if (!list[i].Id) {
                    param.skillId = list[i].Id;
                    list[i].LastUsed = list[i].LastUsed.value;
                    self.isUpdatedByAddMore = true;
                    addNewSkill(list[i], param);
                }
                else if (isModifiedFiled == "true") {
                    param.skillId = list[i].Id;
                    list[i].LastUsed = list[i].LastUsed.value;
                    self.isUpdatedByAddMore = true;
                    updateSkill(list[i], param);
                } else
                    continue;
            }
            return false;
        }

        function createSkill() {
            var skill = new caSkillModel(null, false);
            skill.CandidateId = candidateId;
            formatLevelName(skill);
            formatLastUsed(skill);
            return skill;
        }

        function formatLevelName(skill) {
            $.each(self.levels, function (index, level) {
                if (skill.LevelId == level.Id)
                    skill.LevelName = self.levels[index].Name;
            });
        }

        function formatLastUsed(skill) {
            $.each(self.years, function (index, year) {
                if (skill.LastUsed == year.value)
                    skill.LastUsed = self.years[index];
            });
        }

        function isModifiedData(rowIndex) {
            return rowIndex == rowIndexEditing && isModifiedSkill;
        }

        function onKeyDownYear(event) {
            validationSvc.onKeyDownTextBox(event);
        }

        function onClickDeleteRow(skillId, rowIndex) {
            if (self.isAddingSkill) {
                $('.deleteIcon').attr('data-target', '');
                return;
            }
            $('.deleteIcon').attr('data-target', '#confirmDialog');
            skillIdDeleting = skillId;
            rowIndexDeleting = rowIndex;
            $('#' + self.dialogConfirm.dialogId).modal('show');
        }

        function onYes() {
            param.skillId = skillIdDeleting;

            loadingSvc.show();
            caCvSvc.getSummarySkillResource(param).delete(
                function () {
                    loadingSvc.close();
                    removeSkill();
                    toastr.success($filter(constants.translate)(caMessage.summarySkill.deleteCandidateSkillSuccess));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, caMessage.summarySkill.deleteCandidateSkillError);
                });
        }

        function removeSkill() {
            self.candidateSkills.splice(rowIndexDeleting, 1);
            oldCandidateSkill = copySkill(self.candidateSkills);
            rowIndexEditing = constants.newRowIndex;
        }

        function copySkill(fromSkill) {
            var skillsFormat = [];
            $.each(fromSkill, function (item, skill) {
                formatLevelName(skill);
                formatLastUsed(skill);
                skillsFormat.push(new caSkillModel(skill, false));
            });
            return skillsFormat;
        }

        function getCssHeaderClass() {
            return self.isShowToogleHeader && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function toggleDisplayButton() {
            return self.isSkillEditing ? 'show' : 'hide';
        }
    }
})();
