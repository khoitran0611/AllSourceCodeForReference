﻿(function () {
    'use strict';
    angular.module('app').controller('caExperienceCtrl', CaExperienceCtrl);
    CaExperienceCtrl.$inject = [
        '$state', '$scope', '$rootScope', '$q', '$filter',
        '$timeout', '$window', 'caDetailSvc', 'caApplicationsSvc',
        'uploadFilesSvc', 'messageHandleSvc', 'permissionSvc', 'datetimeSvc',
        'styleSvc', 'candidateSvc', 'objectSvc', 'message',
        'caConstants', 'caDetailModel', 'constants', 'caMessage',
        'comparisonUtilSvc', 'loadingSvc', 'caCvSvc'
    ];
    function CaExperienceCtrl(
        $state, $scope, $rootScope, $q, $filter,
        $timeout, $window, caDetailSvc, caApplicationsSvc,
        uploadFilesSvc, messageHandleSvc, permissionSvc, datetimeSvc,
        styleSvc, candidateSvc, objectSvc, message,
        caConstants, caDetailModel, constants, caMessage,
        comparisonUtilSvc, loadingSvc, caCvSvc) {
        var self = this;

        var candidateId = $state.params.id;
        var originBasicInfo = {};
        var originCvfiles = {};
        var originStatusId = null;

        var currentUserLogin = JSON.parse($window.localStorage.getItem("currentuserlogin"));
        var params = {
            candidateId: candidateId
        };
        var cvSources = [];
        var jobApplicationList = [];
        var resetCommand = constants.resetCommand;
        var _updatedScreenCv = false;
        var _modifiedCvfiles = false;
        var _modifiedBasicInfo = false;
        var _isChangePosition = false;
        var _candidateHasPositionAlready = false;
        var _rejectCandidateStatus = constants.applicationStatus.Other.RejectAll;
        var _LastestCVUpdateStatus = caDetailSvc.getLastUpdateStatus();
        var _jobApplications = caApplicationsSvc.getCurrentApplications();
        var _candidateApplicationList = [];

        self.serverUrl = constants.serverUrl;
        self.permissionOfCurrentUser = {
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            canDownloadCandidateDocuments: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DownloadDocuments),
        };
        self.isShowLoading = true;
        self.isEdit = false;
        self.jobApplicationId = null;
        self.candidateBasicInfo = null;
        self.statusDisplay = '';
        self.hasInterview = false;
        self.rejectCandidate = false;
        self.fileType = constants.fileType.candidateFile;
        self.cvFiles = [];
        self.candidateName = '';
        self.screeningStatus = caDetailSvc.getScreeningStatus();
        self.edit = edit;
        self.save = save;
        self.cancel = cancel;
        self.isDisableSave = isDisableSave;
        self.setInterviewStatusCss = setInterviewStatusCss;
        self.getCssClass = getCssClass;
        self.checkRejectStatus = checkRejectStatus;
        self.updateNote = updateNote;
        self.checkNumber = objectSvc.checkNumber;
        self.getCvAttachment = getCvAttachment;
        self.initCurrentPosition = {
            service: candidateSvc.getCurrentOpenPositions(), id: "CategoryId", text: "JobTitle", optionsValue: "JobId", option: {
                placerholder: "",
                multiple: false
            }
        };
        self.selectedPosition = {};

        init();

        function init() {

            getAllData();

            $scope.$watch('expCtrl.jobApplicationId', function (newValue, oldValue) {
                if ((!!newValue && newValue.value === 0) || newValue === oldValue || !newValue) {
                    $timeout(function () {
                        self.isShowLoading = false;
                    }, 300);
                    return;
                }

                self.isShowLoading = true;
                jobApplicationList = _jobApplications.appliedPositions;
                if (!jobApplicationList || jobApplicationList.length === 0) {
                    self.currentJobApplication = {};
                    if (!$scope.$$phase) $scope.$apply();
                    return;
                }

                self.isEdit = false;
                self.candidateBasicInfo = JSON.parse(JSON.stringify(originBasicInfo));
                params.jobApplicationId = newValue.value;

                var index = findWithAttr(jobApplicationList, "JobApplicationId", newValue.value);
                if (index < 0)
                    return;
                self.rejectCandidate = jobApplicationList[index].LastUpdateStatus == _rejectCandidateStatus ? true : false;
                self.hasInterview = (jobApplicationList[index].FirstInterViewScheduleId > 0 || jobApplicationList[index].SecondInterviewId > 0 || jobApplicationList[index].ThirdInterViewScheduleId > 0);
                self.currentJobApplication.JobCodeId = jobApplicationList[index].RecruitmentId;
                self.currentJobApplication.SentOfferLetter = jobApplicationList[index].SentOfferLetter;
                self.currentJobApplication.PositionName = jobApplicationList[index].PositionName;
                self.currentJobApplication.AppliedDate = jobApplicationList[index].AppliedDate;
                self.currentJobApplication.CvSourceName = jobApplicationList[index].CvSourceName;
                self.currentJobApplication.PositionId = jobApplicationList[index].PositionId;
                self.currentJobApplication.JobApplicationId = jobApplicationList[index].JobApplicationId;
                self.currentJobApplication.RecruitmentId = jobApplicationList[index].RecruitmentId;
                self.currentJobApplication.ScreenCvId = jobApplicationList[index].ScreenCvId;
                self.currentJobApplication.CvSourceId = jobApplicationList[index].CvSourceId;
                self.currentJobApplication.ScreenCv = jobApplicationList[index].ScreenCv;
                self.currentJobApplication.Summary = jobApplicationList[index].Summary;
                self.currentJobApplication.CoverLetterText = jobApplicationList[index].CoverLetterText;

                if (typeof (jobApplicationList[index]) == "object") {
                    self.currentJobApplication.FirstInterViewScheduleId = angular.copy(jobApplicationList[index].FirstInterViewScheduleId);
                    self.currentJobApplication.FirstInterview = angular.copy(jobApplicationList[index].FirstInterview);
                    self.currentJobApplication.SecondInterViewScheduleId = angular.copy(jobApplicationList[index].SecondInterViewScheduleId);

                    self.currentJobApplication.SecondInterview = angular.copy(jobApplicationList[index].SecondInterview);
                    self.currentJobApplication.ThirdInterViewScheduleId = angular.copy(jobApplicationList[index].ThirdInterViewScheduleId);
                    self.currentJobApplication.ThirdInterview = angular.copy(jobApplicationList[index].ThirdInterview);
                    self.currentJobApplication.Summary = angular.copy(jobApplicationList[index].Summary);
                    self.currentJobApplication.CoverLetterText = angular.copy(jobApplicationList[index].CoverLetterText);
                }
                if (jobApplicationList.length > 0)
                    displayStatus(jobApplicationList[index]);

                getCvFiles(params);

                getCurrentSource();

                $timeout(function () {
                    self.isShowLoading = false;
                }, 300);

                if (!$scope.$$phase) $scope.$apply();


            }, true);

            $scope.$watch('expCtrl.currentJobApplication.StatusId', function (newValue, oldValue) {
                if (newValue != oldValue && !comparisonUtilSvc.isNullOrUndefinedValue(oldValue) && (newValue != self.currentJobApplication.ScreenCvId)) {
                    _updatedScreenCv = true;
                } else if (!comparisonUtilSvc.isNullOrUndefinedValue(oldValue) && (newValue == self.currentJobApplication.ScreenCvId)) {
                    _updatedScreenCv = false;
                }
            }, true);

            $scope.$watch('expCtrl.cvFiles', function (newValue, oldValue) {
                if (newValue !== oldValue && !comparisonUtilSvc.isNullOrUndefinedValue(oldValue)) {
                    if (angular.equals(self.cvFiles, originCvfiles)) {
                        _modifiedCvfiles = false;
                    } else {
                        _modifiedCvfiles = true;
                    }
                }
            }, true);

            $scope.$watch('expCtrl.candidateBasicInfo', function (newValue, oldValue) {
                if (newValue !== oldValue && !comparisonUtilSvc.isNullOrUndefinedValue(oldValue)) {
                    if (angular.equals(self.candidateBasicInfo, originBasicInfo)) {
                        _modifiedBasicInfo = false;
                    } else {
                        _modifiedBasicInfo = true;
                    }
                }
            }, true);

            $scope.$watch('expCtrl.screeningStatus', function (newValue, oldValue) {
                if (newValue == oldValue || !newValue.isActionMenuUpdate || !self.currentJobApplication)
                    return;
                self.currentJobApplication.StatusId = parseInt(newValue.value, 10);
                self.currentJobApplication.ScreenCvId = parseInt(newValue.value, 10);
                self.candidateBasicInfo.StatusResult = styleSvc.setTitle(newValue.value + '');
                self.candidateBasicInfo.IsScreenCv = true;
                originBasicInfo = JSON.parse(JSON.stringify(self.candidateBasicInfo));
            }, true);

            $scope.$watch('cvCtrl.isEditForm', function (value) {
                self.isEditing = value;
                if (self.currentJobApplication)
                    originStatusId = self.currentJobApplication.StatusId;
                if (!value) {
                    cancel();
                }
            }, true);

            $scope.$on(caConstants.events.showLoadingEvent, function () {
                self.isShowLoading = true;
            });

            $scope.$on(caConstants.events.updateCVTab, function (event, rootScopeParams) {
                if (self.jobApplicationId.value == rootScopeParams.jobApplicationId) {
                    self.currentJobApplication.PositionName = rootScopeParams.positionName;
                    var index = findWithAttr(cvSources, 'Id', rootScopeParams.cvSourceId);
                    self.currentJobApplication.CvSourceName = cvSources[index].Name;
                }
            });

            $scope.$on(constants.broadCastTile.updateCandidateNode, function (event, rootScopeParams) {
                if (self.candidateBasicInfo.CandidateId == rootScopeParams.CandidateId) {
                    originBasicInfo.JobApplicationNote = rootScopeParams.Note;
                    self.candidateBasicInfo = JSON.parse(JSON.stringify(originBasicInfo));
                    setCurrentInterviewStatus(self.currentJobApplication);
                    displayStatus(self.currentJobApplication);
                }
            });


            $scope.$on(caConstants.events.updateCandidateGeneralInformation, function (event, rootScopeParams) {
                self.candidateBasicInfo = copyCandidateInformation(JSON.parse(JSON.stringify(rootScopeParams)), self.candidateBasicInfo);
                originBasicInfo = copyCandidateInformation(JSON.parse(JSON.stringify(rootScopeParams)), originBasicInfo);
            });

            function copyCandidateInformation(source, destiny) {
                destiny.Mobile = source.Mobile;
                destiny.Address = source.Address;
                destiny.Birthday = source.Birthday;
                destiny.City = source.City;
                destiny.Email = source.Email;
                destiny.FirstName = source.FirstName;
                destiny.FullName = source.FullName;
                destiny.Gender = source.Gender;
                destiny.ImagePath = source.ImagePath;
                destiny.ImagePathTemp = source.ImagePathTemp;
                destiny.Phone = source.Phone;
                destiny.LastName = source.LastName;
                destiny.IdNo = source.IdNo;
                destiny.OtherEmail = source.OtherEmail;
                return destiny;
            }

            $scope.$watch("expCtrl.selectedPosition", function (newValue, oldValue) {
                if (self.currentJobApplication && newValue && newValue.text !== "" && (newValue.optionsValue != self.currentJobApplication.RecruitmentId)) {
                    self.isModifiedPosition = true;
                    return;
                } else {
                    self.isModifiedPosition = false;
                }
                if (newValue == oldValue)
                    return;
            }, true);
        }

        function displayStatus(jobApplication) {
            if (!jobApplication || !self.candidateBasicInfo) return;
            if (jobApplication.ThirdInterview || jobApplication.SecondInterview || jobApplication.FirstInterview)
                setCurrentInterviewStatus(jobApplication);
            else {
                self.candidateBasicInfo.statusDisplay = 'CV Status';
                self.candidateBasicInfo.StatusResult = styleSvc.setTitle(jobApplication.ScreenCvId + '');
                self.currentJobApplication.StatusId = parseInt(jobApplication.ScreenCvId, 10);
                self.candidateBasicInfo.IsScreenCv = true;
            }
        }

        function setCurrentInterviewStatus(jobApplication) {
            if (jobApplication.ThirdInterview) {
                self.candidateBasicInfo.statusDisplay = 'Third Interview';
                self.candidateBasicInfo.StatusResult = jobApplication.ThirdInterview;
                self.currentJobApplication.StatusId = jobApplication.ThirdInterviewId;
                self.candidateBasicInfo.IsScreenCv = false;
                return;
            }
            if (jobApplication.SecondInterview) {
                self.candidateBasicInfo.statusDisplay = 'Second Interview';
                self.candidateBasicInfo.StatusResult = jobApplication.SecondInterview;
                self.currentJobApplication.StatusId = jobApplication.SecondInterviewId;
                self.candidateBasicInfo.IsScreenCv = false;
                return;
            }
            if (jobApplication.FirstInterview) {
                self.candidateBasicInfo.statusDisplay = 'First Interview';
                self.candidateBasicInfo.StatusResult = jobApplication.FirstInterview;
                self.currentJobApplication.StatusId = jobApplication.FirstInterviewId;
                self.candidateBasicInfo.IsScreenCv = false;
                return;
            }

            self.currentJobApplication.StatusId = parseInt(jobApplication.StatusId, 10);
        }

        function getCvFiles(param) {
            self.cvFiles = [];
            uploadFilesSvc.getCvAttachments(param).query(
                function (response) {
                    response.forEach(function (cvFile) {
                        cvFile.NewItem = false;
                        self.cvFiles.push(cvFile);
                    });
                    originCvfiles = JSON.parse(JSON.stringify(self.cvFiles));
                });
        }

        function getCurrentSource() {
            if (!self.currentJobApplication) return;
            var cvSourcesTemp = $filter('filter')(cvSources, { Id: self.currentJobApplication.CvSourceId }, true);
            if (cvSourcesTemp && cvSourcesTemp.length > 0)
                self.currentJobApplication.CvSourceName = cvSourcesTemp[0].Name;
        }

        function getCandidateDetailData() {
            var deferred = $q.defer();
            caDetailSvc.getCandidateDetailResource(params).get().$promise.then(
                function (value) {
                    deferred.resolve(value);
                }, function (reason) {
                    deferred.reject(reason);
                });
            return deferred.promise;
        }

        function getAppliedInfoData() {
            var deferred = $q.defer();
            caDetailSvc.getAppliedInfoResource(params).query().$promise.then(
                function (value) {
                    deferred.resolve(value);
                }, function (reason) {
                    deferred.reject(reason);
                });
            return deferred.promise;
        }

        function broadcastCandidateBasicInfo(candidate) {
            $rootScope.$broadcast("loadcandidateBasicInfo", { data: candidate });
        }

        function getAllData() {
            $q.all([
                getCandidateDetailData(),
                getAppliedInfoData()
            ]).then(function (response) {
                broadcastCandidateBasicInfo(response[0]);
                self.candidateName = response[0].CandidateBasicInfo.FullName;
                self.modifiedDate = datetimeSvc.convertDate(response[0].CandidateBasicInfo.ModifiedDate);
                self.candidateBasicInfo = response[0].CandidateBasicInfo;
                originBasicInfo = JSON.parse(JSON.stringify(self.candidateBasicInfo));
                self.jobApplicationId = caDetailSvc.getSelectedJobApplicationId();
                cvSources = response[0].CvSources;
                var defaultCvSource = {
                    Code: undefined,
                    Id: response[0].CvSources.length + 1,
                    Text: "",
                    Name: ""
                };
                cvSources.splice(0, 0, defaultCvSource);

                jobApplicationList = response[1];
                _candidateApplicationList = response[1];
                self.currentJobApplication = jobApplicationList[0];
                self.candateInforData = candidateSvc.candidateInforData;
                if (self.currentJobApplication && !comparisonUtilSvc.isNullOrUndefinedValue(self.currentJobApplication.LastUpdateStatus)) {
                    self.rejectCandidate = self.currentJobApplication.LastUpdateStatus == _rejectCandidateStatus ? true : false;
                }

                self.hasInterview = self.currentJobApplication ? (self.currentJobApplication.FirstInterViewScheduleId > 0 || self.currentJobApplication.SecondInterViewScheduleId > 0 || self.currentJobApplication.ThirdInterViewScheduleId > 0) : false;

                $timeout(function () {
                    self.isShowLoading = false;
                }, 500);
            }, function (xhr) {
                var doesNotShow = !JSON.parse(JSON.stringify(caDetailSvc.getCurrentLoading()));
                caDetailSvc.setCurrentLoading(false);
                messageHandleSvc.handleResponse(xhr, message.errorLoadingData, doesNotShow);
            });
        }

        function edit() {
            self.isEdit = true;
            self.hasSaved = false;
            originStatusId = self.currentJobApplication.StatusId;
            originBasicInfo = JSON.parse(JSON.stringify(self.candidateBasicInfo));
            originCvfiles = JSON.parse(JSON.stringify(self.cvFiles));
            _updatedScreenCv = false;
            _modifiedCvfiles = false;
            self.modifiedNote = false;
            _modifiedBasicInfo = false;
            self.isModifiedPosition = false;
            uploadFilesSvc.clearInputForm();
            checkRejectStatus();
            var openPosition = $filter('filter')(self.candateInforData.openPositions, { JobId: self.currentJobApplication.RecruitmentId }, true);
            if (openPosition && openPosition.length !== 0) {
                self.selectedPosition = { id: self.currentJobApplication.CategoryId, text: openPosition[0].JobTitle, optionsValue: openPosition[0].JobId, optionsText: undefined };
            } else {
                self.selectedPosition = { id: 0, text: "", optionsValue: resetCommand, optionsText: undefined };
            }
        }

        function checkRejectStatus() {
            if (_LastestCVUpdateStatus && _LastestCVUpdateStatus.value == constants.applicationStatus.Other.RejectAll && _LastestCVUpdateStatus.jobId == self.jobApplicationId.value) {
                self.rejectCandidate = true;
                return true;
            }
            if (self.currentJobApplication && self.currentJobApplication.StatusId == constants.applicationStatus.Other.RejectAll) {
                self.rejectCandidate = true;
                return true;
            }
            self.rejectCandidate = false;
            return false;
        }

        function updateNote(value) {
            self.candidateBasicInfo.JobApplicationNote = value;
            var note = {
                CreatedUserId: currentUserLogin.UserId,
                CreatedUser: currentUserLogin.FirstName + ' ' + currentUserLogin.LastName,
                CandidateId: candidateId,
                Source: $filter(constants.translate)(caConstants.administrationSource.Screening),
                CreatedDate: new Date(),
                Note: value
            };
            caDetailModel.setNewNote(note);
        }

        function save() {
            if (self.hasSaved) return;
            self.hasSaved = true;
            _candidateApplicationList = _jobApplications.appliedPositions;
            var updateSuccess = true;
            var applicationEdited = $filter('filter')(_candidateApplicationList, { JobApplicationId: params.jobApplicationId });
            _isChangePosition = applicationEdited[0].RecruitmentId != self.selectedPosition.optionsValue;

            _candidateApplicationList.forEach(function (appliedPosition) {
                if (appliedPosition.RecruitmentId == self.selectedPosition.optionsValue) {
                    _candidateHasPositionAlready = true;
                }
            });
            var newOpenPositionSelected = $filter('filter')(self.candateInforData.openPositions, {
                JobId: comparisonUtilSvc.isNullOrUndefinedValue(self.selectedPosition.optionsValue) ? applicationEdited : self.selectedPosition.optionsValue
            }, true);
            if (_candidateHasPositionAlready && _isChangePosition) {
                toastr.warning($filter(constants.translate)(caMessage.candidateHas) + ' ' + newOpenPositionSelected[0].JobTitle + ' ' + $filter(constants.translate)(caMessage.already));
                self.selectedPosition = { id: self.currentJobApplication.CategoryId, text: applicationEdited[0].PositionName, optionsValue: applicationEdited[0].RecruitmentId, optionsText: undefined };
                _candidateHasPositionAlready = false;
                self.hasSaved = false;
                self.isEdit = false;
                return;
            } else {
                if (newOpenPositionSelected.length === 0) {
                    newOpenPositionSelected = $filter('filter')(_candidateApplicationList, { PositionId: self.currentJobApplication.PositionId }, true);
                    self.candidateBasicInfo.PositionId = newOpenPositionSelected[0].PositionId;
                    self.candidateBasicInfo.PositionName = newOpenPositionSelected[0].PositionName;
                    self.currentJobApplication.PositionName = newOpenPositionSelected[0].PositionName;
                    self.currentJobApplication.PositionId = newOpenPositionSelected[0].PositionId;
                    self.currentJobApplication.RecruitmentId = newOpenPositionSelected[0].RecruitmentId;
                    self.candidateBasicInfo.JobCodeId = newOpenPositionSelected[0].RecruitmentId;
                } else {
                    self.candidateBasicInfo.PositionId = newOpenPositionSelected[0].PstId;
                    self.candidateBasicInfo.PositionName = newOpenPositionSelected[0].JobTitle;
                    self.currentJobApplication.PositionName = newOpenPositionSelected[0].JobTitle;
                    self.currentJobApplication.PositionId = newOpenPositionSelected[0].PstId;
                    self.currentJobApplication.RecruitmentId = newOpenPositionSelected[0].JobId;
                    self.candidateBasicInfo.JobCodeId = newOpenPositionSelected[0].JobId;

                    applicationEdited[0].PositionId = newOpenPositionSelected[0].PstId;
                    applicationEdited[0].PositionName = newOpenPositionSelected[0].JobTitle;
                    applicationEdited[0].RecruitmentId = newOpenPositionSelected[0].JobId;
                    applicationEdited[0].ScreenCv = self.currentJobApplication.ScreenCv;
                    applicationEdited[0].ScreenCvId = self.currentJobApplication.ScreenCvId;
                }
                _candidateHasPositionAlready = false;
                if (originBasicInfo.JobApplicationNote != self.candidateBasicInfo.JobApplicationNote) {
                    var note = {
                        CreatedByUserId: currentUserLogin.UserId,
                        CreatedUser: currentUserLogin.FirstName + ' ' + currentUserLogin.LastName,
                        CandidateId: candidateId,
                        Source: $filter(constants.translate)(caConstants.administrationSource.Screening),
                        CreatedDate: new Date(),
                        Note: self.candidateBasicInfo.JobApplicationNote
                    };

                    loadingSvc.show();
                    caDetailSvc.getNoteResource(params).save(note).$promise.then(
                        function () {
                            loadingSvc.close();
                            caApplicationsSvc.updateJobApplicationNote(params.jobApplicationId, note.Note);
                            caDetailModel.setNewNote(note);
                            self.hasSaved = false;
                        }, function () {
                            loadingSvc.close();
                            updateSuccess = false;
                            self.hasSaved = false;
                        });
                }
                self.candidateBasicInfo.JobApplicationId = params.jobApplicationId;
                self.candidateBasicInfo.StatusId = self.currentJobApplication.StatusId;
                self.candidateBasicInfo.JobCode = newOpenPositionSelected[0].JobCode;
                self.candidateBasicInfo.NewStatus = styleSvc.setTitle(self.currentJobApplication.StatusId + "");

                applicationEdited[0].JobCode = newOpenPositionSelected[0].JobCode;

                caApplicationsSvc.updateCurrentApplications(applicationEdited[0], false);
                var isChangeInformation = compareCandidates(self.candidateBasicInfo, originBasicInfo);

                loadingSvc.show();
                caDetailSvc.getCandidateDetailResource(params).update(self.candidateBasicInfo,
                    function () {
                        loadingSvc.close();
                        if (_updatedScreenCv) {
                            var newStatus = {
                                JobApplicationId: params.jobApplicationId,
                                ModifiedDate: datetimeSvc.convertDateForServerSide(new Date(), true),
                                ModifiedByUserId: currentUserLogin.UserId,
                                ModifiedUserName: currentUserLogin.FullName,
                                Note: self.candidateBasicInfo.JobApplicationNote,
                                Status: self.currentJobApplication.StatusId
                            };
                            var positionForUpdateStatus = {
                                PositionId: self.currentJobApplication.PositionId,
                                PositionName: self.currentJobApplication.PositionName,
                                LastUpdateStatus: newStatus.Status
                            };

                            caDetailSvc.addNewScreeningCvHistory(params).save(newStatus).$promise.then(
                                function () {
                                    caDetailModel.setNewCvStatus(newStatus);
                                    caDetailSvc.updateScreeningStatus(newStatus.Status, self.jobApplicationId);
                                    caDetailSvc.setCurrentPosition(positionForUpdateStatus);
                                    self.currentJobApplication.ScreenCvId = newStatus.Status;
                                    self.currentJobApplication.StatusId = newStatus.Status;
                                    displayStatus(self.currentJobApplication);
                                    caApplicationsSvc.setJobApplicationScreenCVStatus(self.jobApplicationId.value, self.currentJobApplication.StatusId);
                                    self.hasSaved = false;
                                }, function () {
                                    updateSuccess = false;
                                    self.hasSaved = false;
                                });
                        }
                        if (_modifiedCvfiles) {
                            params.cvFiles = self.cvFiles;
                            uploadFilesSvc.updateCvFile(params);
                        }

                        if (updateSuccess) {
                            displayStatus(self.currentJobApplication);
                            originBasicInfo = JSON.parse(JSON.stringify(self.candidateBasicInfo));
                            var cvSource = $filter('filter')(cvSources, {
                                Name: comparisonUtilSvc.isNullOrUndefinedValue(self.currentJobApplication.CvSource) ? "" : self.currentJobApplication.CvSource
                            }, true);
                            $rootScope.$broadcast(caConstants.events.updateCVTab, {
                                cvSourceId: comparisonUtilSvc.isNullOrUndefinedValue(self.currentJobApplication.CvSourceId) ? cvSource[0].Id : self.currentJobApplication.CvSourceId,
                                positionName: self.currentJobApplication.PositionName,
                                jobApplicationId: self.currentJobApplication.JobApplicationId
                            });
                            if (isChangeInformation)
                                toastr.success($filter(constants.translate)(caMessage.generalInformation.updateExperienceSuccess));
                            if (_updatedScreenCv)
                                toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                            self.isEdit = false;
                            _updatedScreenCv = false;
                            _modifiedCvfiles = false;
                            _modifiedBasicInfo = false;
                        }
                    },
                    function (xhr) {
                        loadingSvc.close();
                        self.isEdit = true;
                        self.hasSaved = false;
                        if (isChangeInformation) {
                            messageHandleSvc.handleResponse(xhr, caMessage.generalInformation.updateCvStatusError);
                            return;
                        }
                        if (_updatedScreenCv)
                            messageHandleSvc.handleResponse(xhr, caMessage.generalInformation.updateCvStatusError);
                    });
            }

        }

        function compareCandidates(source, destiny) {
            if (source.Domain != destiny.Domain) return true;
            if (source.Profession != destiny.Profession) return true;
            if (source.ExperienceYear != destiny.ExperienceYear) return true;
            return false;
        }

        function cancel() {
            self.isEdit = false;
            self.hasSaved = false;
            revert();
        }

        function revert() {
            uploadFilesSvc.clearInputForm();
            self.candidateBasicInfo = JSON.parse(JSON.stringify(originBasicInfo));
            displayStatus(self.currentJobApplication);
            self.cvFiles = JSON.parse(JSON.stringify(originCvfiles));
            if (!self.currentJobApplication) self.currentJobApplication = {};
            self.currentJobApplication.StatusId = originStatusId;
            _updatedScreenCv = false;
            _modifiedCvfiles = false;
            _modifiedBasicInfo = false;
        }

        function setInterviewStatusCss(status) {
            return styleSvc.setStatusCss(status);
        }

        function isDisableSave() {
            return !_modifiedBasicInfo && !_updatedScreenCv && !_modifiedCvfiles && !self.isModifiedPosition;
        }

        function getCssClass() {
            return self.isShowLoading ? 'hide' : 'show';
        }

        function getCvAttachment(jobAttachment) {

            if (!jobAttachment.Url) {
                return;
            }
            if (jobAttachment.Url.indexOf("http") > -1) {
                self.attachmentDownloadingUrl = true;
                var jobAttachmentUrl = '';
                return caCvSvc.getCvAttachmentFileFromCandidate(jobAttachment.Id)
                    .then(function (jobAttachmentUrl) {
                        self.attachmentDownloadingUrl = false;
                        var modifiedAttachmentUrl = jobAttachmentUrl.substring(1, jobAttachmentUrl.length - 1);
                        jobAttachment.Url = modifiedAttachmentUrl;
                    })
                    .then(function () {
                        $window.open(constants.serverUrl + jobAttachment.Url);
                    });
            } else {
                $window.open(constants.serverUrl + jobAttachment.Url);
            }
        }
    }
})();
