﻿(function () {
    'use strict';
    angular.module('app').factory('caCvSvc', caCvSvc);
    caCvSvc.$inject = ["$resource", "constants", "$http"];
    function caCvSvc($resource, constants, $http) {
        var service = {
            getSummarySkillResource: getSummarySkillResource,
            getEmploymentHistoryResource: getEmploymentHistoryResource,
            getOutstandingProjectResource: getOutstandingProjectResource,
            getEducationsResource: getEducationsResource,
            getCoursesResource: getCoursesResource,
            getLanguageSkillResource: getLanguageSkillResource,
            getCertificationsResource: getCertificationsResource,
            getReferencesResource: getReferencesResource,
            getCvAttachmentFileFromCandidate: getCvAttachmentFileFromCandidate,
            getAttachmentInfoFromCandidate: getAttachmentInfoFromCandidate
        };
        return service;


        function getSummarySkillResource(param) {
            return $resource(
                constants.apiUrl + 'candidates/:candidateId/skills/:skillId',
                { candidateId: param.candidateId, skillId: param.skillId }, { "update": { method: "PUT" } });
        }
        function getLanguageSkillResource(param) {
            return $resource(
                constants.apiUrl + 'candidates/:candidateId/languageSkill/:languageSkillId',
                { candidateId: param.candidateId, languageSkillId: param.skillId }, { "update": { method: "PUT" } });
        }
        function getEmploymentHistoryResource(param) {
            return $resource(
                constants.apiUrl + 'candidates/:candidateId/employment-histories/:employmentHistoryId',
                { candidateId: param.candidateId, employmentHistoryId: param.employmentHistoryId },
                { "update": { method: "PUT" } });
        }
        function getOutstandingProjectResource(param) {
            return $resource(
                constants.apiUrl + 'candidates/:candidateId/outstanding-projects/:outstandingProjectId',
                { candidateId: param.candidateId, outstandingProjectId: param.outstandingProjectId },
                { "update": { method: "PUT" } });
        }
        function getEducationsResource(param) {
            return $resource(
                constants.apiUrl + 'candidates/:candidateId/educations/:educationId',
                { candidateId: param.candidateId, educationId: param.educationId },
                { "update": { method: "PUT" } });
        }
        function getCoursesResource(param) {
            return $resource(
                constants.apiUrl + 'candidates/:candidateId/trainings/:trainingId',
                { candidateId: param.candidateId, trainingId: param.courseId },
                { "update": { method: "PUT" } });
        }
        function getCertificationsResource(param) {
            return $resource(
                constants.apiUrl + 'candidates/:candidateId/certification/:certificationId',
                { candidateId: param.candidateId, certificationId: param.certificationId },
                { "update": { method: "PUT" } });
        }
        function getReferencesResource(param) {
            return $resource(
                constants.apiUrl + 'candidates/:candidateId/reference/:referenceId',
                { candidateId: param.candidateId, referenceId: param.referenceId },
                { "update": { method: "PUT" } });
        }
        function getCvAttachmentFileFromCandidate(param) {
            return $http.get(constants.apiUrl + 'attachmentfile/getCvAttachmentFile/' + param)
                .then(function (response) {
                    return response.data;
                });
        }

        function getAttachmentInfoFromCandidate(param) {
            return $http.get(constants.apiUrl + 'attachmentfile/getCvAttachmentFile/' + param)
                .then(function (response) {
                    return response.data;
                });
        }
    }

})();
