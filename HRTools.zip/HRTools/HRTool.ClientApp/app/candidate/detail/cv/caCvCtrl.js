﻿(function () {
    'use strict';
    angular.module('app').controller('caCvCtrl', CaCvCtrl);
    CaCvCtrl.$inject = ['permissionSvc'];
    function CaCvCtrl(permissionSvc) {
        var self = this;
        self.isEditForm = false;
        self.button = { icon: 'sprite-white-pencil', text: 'Edit', buttonCss: 'button-submit' };

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };

        self.onFinishLoading = onFinishLoading;
        self.edit = edit;

        function onFinishLoading(sectionId) {
            document.getElementById(sectionId).className = "";
        }

        function edit() {
            self.isEditForm = !self.isEditForm;
        }
    }
})();
