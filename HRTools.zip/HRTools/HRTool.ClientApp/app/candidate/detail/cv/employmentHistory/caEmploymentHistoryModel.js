﻿(function () {
    'use strict';

    angular.module('app').factory('caEmploymentHistoryModel', caEmploymentHistoryModel);

    function caEmploymentHistoryModel() {
        var model = function (employeeEmploymentHistory, isEmployee, allowNull) {
            /* jshint -W040 */
            var self = this;
            self.Id = employeeEmploymentHistory ? employeeEmploymentHistory.Id : undefined;
            self.CandidateId = employeeEmploymentHistory ? employeeEmploymentHistory.CandidateId : undefined;
            self.EmployeeId = employeeEmploymentHistory ? employeeEmploymentHistory.EmployeeId : undefined;
            self.Position = employeeEmploymentHistory ? employeeEmploymentHistory.Position : '';
            self.Company = employeeEmploymentHistory ? employeeEmploymentHistory.Company : '';
            self.StartTime = employeeEmploymentHistory && employeeEmploymentHistory.StartTime ? employeeEmploymentHistory.StartTime : allowNull ? "" : new Date();
            self.EndTime = employeeEmploymentHistory && employeeEmploymentHistory.EndTime ? employeeEmploymentHistory.EndTime : allowNull ? "" : new Date();
            self.Supervisor = employeeEmploymentHistory && employeeEmploymentHistory.Supervisor ? employeeEmploymentHistory.Supervisor : "";
            self.SupervisorEmail = employeeEmploymentHistory && employeeEmploymentHistory.SupervisorEmail ? employeeEmploymentHistory.SupervisorEmail : '';
            self.SupervisorPhoneNumber = employeeEmploymentHistory && employeeEmploymentHistory.SupervisorPhoneNumber ? employeeEmploymentHistory.SupervisorPhoneNumber : "";
            self.Salary = employeeEmploymentHistory && employeeEmploymentHistory.Salary ? employeeEmploymentHistory.Salary : undefined;
            self.ReasonForLeaving = employeeEmploymentHistory && employeeEmploymentHistory.ReasonForLeaving ? employeeEmploymentHistory.ReasonForLeaving : "";
            self.Responsibilities = employeeEmploymentHistory && employeeEmploymentHistory.Responsibilities ? employeeEmploymentHistory.Responsibilities : "";
            self.Description = employeeEmploymentHistory && employeeEmploymentHistory.Description ? employeeEmploymentHistory.Description : "";
            self.IsEmployee = isEmployee;
            self.Address = employeeEmploymentHistory && employeeEmploymentHistory.Address ? employeeEmploymentHistory.Address : '';
            self.Duration = employeeEmploymentHistory ? employeeEmploymentHistory.Duration : '';
            self.Website = employeeEmploymentHistory && employeeEmploymentHistory.Website ? employeeEmploymentHistory.Website : '';
            self.Attachments = employeeEmploymentHistory && employeeEmploymentHistory.Attachments ? employeeEmploymentHistory.Attachments : [];
            self.isShowMore = false;
        };
        return model;
    }
})();