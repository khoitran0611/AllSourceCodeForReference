﻿(function () {
    'use strict';
    angular.module('app').controller('caEmploymentHistoryCtrl', CaEmploymentHistoryCtrl);
    CaEmploymentHistoryCtrl.$inject = ['caCvSvc', 'handleRequestSvc', 'messageHandleSvc', 'datetimeSvc', 'styleSvc', 'validationSvc', 'permissionSvc', 'caDetailSvc',
        'constants', 'message', 'caMessage', "objectSvc", 'caEmploymentHistoryModel',
        '$stateParams', '$scope', '$timeout', '$filter','loadingSvc'];
    function CaEmploymentHistoryCtrl(caCvSvc, handleRequestSvc, messageHandleSvc, datetimeSvc, styleSvc, validationSvc, permissionSvc, caDetailSvc,
            constants, message, caMessage, objectSvc, caEmploymentHistoryModel,
            $stateParams, $scope, $timeout, $filter, loadingSvc) {
        var self = this;
        var _isRowEditing = false;
        self.isEditMode = false;
        var _isAddingEmploymentHistory = false;

        self.isModifiedData = false;
        self.isValidDate = true;
        self.dialogConfirm = caMessage.candidateEmploymentHistory.dialogConfirm;
        self.candidateEmploymentHistories = [];
        var _isShowToogleHeader = true;

        self.checkPhoneNumber = objectSvc.checkPhoneNumber;
        self.checkNumber = objectSvc.checkNumber;
        self.toggleMoreDetail = toggleMoreDetail;

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };

        self.addCandidateEmploymentHistory = addCandidateEmploymentHistory;
        self.toogleHeader = toogleHeader;
        self.saveCandidateEmploymentHistory = saveCandidateEmploymentHistory;
        self.editEmploymentHistory = editEmploymentHistory;
        self.cancelEditEmploymentHistory = cancelEditEmploymentHistory;
        self.removeEmploymentHistory = removeEmploymentHistory;
        self.acceptDeleteCaEmploymentHistory = acceptDeleteCaEmploymentHistory;
        self.onChangeDate = onChangeDate;
        self.getCssHeaderClass = getCssHeaderClass;
        self.getDetailContentClass = getDetailContentClass;
        self.getButtonAddMoreClass = getButtonAddMoreClass;

        var param = {};
        var initialCaEmploymentHistories = [];
        var rowEditing;
        var rowIndexDeleting;

        init();

        function init() {
            param.candidateId = $stateParams.id;
            var employmentHistories = caCvSvc.getEmploymentHistoryResource(param).query(
                function () {
                    $.each(employmentHistories, function (item, empHis) {
                        self.candidateEmploymentHistories.push(new caEmploymentHistoryModel(empHis, false, true));
                        initialCaEmploymentHistories.push(new caEmploymentHistoryModel(empHis, false, true));
                    });
                    formatDate(self.candidateEmploymentHistories);
                    formatDate(initialCaEmploymentHistories);
                },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData, doesNotShow);
                });

            $scope.$watch("caEmpHisCtrl.candidateEmploymentHistories", function (newVal, oldVal) {
                if (newVal == oldVal)
                    return;
                else if (_isAddingEmploymentHistory)
                    self.isModifiedData = true;
                else {
                    var candidateEmploymentHistoriesFormat = copyEmploymentHistory(self.candidateEmploymentHistories);
                    self.isModifiedData = JSON.stringify(candidateEmploymentHistoriesFormat) != JSON.stringify(initialCaEmploymentHistories);
                }
            }, true);

            $scope.$watch('cvCtrl.isEditForm', function (value) {
                self.isEditMode = value;
                resetEdit();
            }, true);
        }

        function resetEdit() {
            rowEditing = constants.newRowIndex;

            if (_isAddingEmploymentHistory) {
                self.isEditMode = false;
            }
            if (self.isModifiedData) {
                self.candidateEmploymentHistories = copyEmploymentHistory(initialCaEmploymentHistories);
            }
            if (angular.element("#candidate-employment-history-detail").css('display') == "none") {
                self.toogleHeader();
            }

            if (!self.isEditMode) {
                resetRowIndex();
            }
        }

        function resetRowIndex() {
            _isAddingEmploymentHistory = false;
            rowEditing = constants.newRowIndex;
            self.isModifiedData = false;
            self.isValidDate = true;
            _isRowEditing = false;
        }

        function formatDate(employmentHistoriesFormat) {
            $.each(employmentHistoriesFormat, function (item, employmentHistoryFormat) {
                employmentHistoryFormat.StartTime = (employmentHistoryFormat.StartTime) ? moment(employmentHistoryFormat.StartTime).format(constants.formatDateDDMMYYYY) : "";
                employmentHistoryFormat.EndTime = (employmentHistoryFormat.EndTime) ? moment(employmentHistoryFormat.EndTime).format(constants.formatDateDDMMYYYY) : "";
            });
        }

        function addCandidateEmploymentHistory() {
            if (rowEditing == constants.newRowIndex) {
                _isAddingEmploymentHistory = true;
                var candidateEmploymentHistory = new caEmploymentHistoryModel(null, false, false);
                self.candidateEmploymentHistories.push(candidateEmploymentHistory);
                rowEditing = self.candidateEmploymentHistories.length - 1;
                self.candidateEmploymentHistories[rowEditing].StartTime = moment(self.candidateEmploymentHistories[rowEditing].StartTime).format(constants.formatDateDDMMYYYY);
                self.candidateEmploymentHistories[rowEditing].EndTime = moment(self.candidateEmploymentHistories[rowEditing].EndTime).format(constants.formatDateDDMMYYYY);
                $timeout(function () {
                    $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                    $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
                }, 100);

            } else {
                toastr.warning(message.editingData, message.titleWarning);
            }
        }

        function toogleHeader() {
            _isShowToogleHeader = !_isShowToogleHeader;
            $("#candidate-employment-history-detail").slideToggle("slow");
        }

        function saveCandidateEmploymentHistory(employmentHistoryId) {
            param.employmentHistoryId = employmentHistoryId;
            var employmentForSaving = angular.copy(self.candidateEmploymentHistories[rowEditing]);
            employmentForSaving.StartTime = datetimeSvc.convertDateForServerSide(employmentForSaving.StartTime, false);
            employmentForSaving.EndTime = datetimeSvc.convertDateForServerSide(employmentForSaving.EndTime, false);
            if (_isAddingEmploymentHistory) {
                loadingSvc.show();
                caCvSvc.getEmploymentHistoryResource(param).save(employmentForSaving,
                    function (response) {
                        loadingSvc.close();
                        saveEmploymentHistorySuccess(response);
                        toastr.success($filter(constants.translate)(caMessage.candidateEmploymentHistory.addCandidateEmploymentHistorySuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.candidateEmploymentHistory.addCandidateEmploymentHistoryError);
                    });
            } else {
                loadingSvc.show();
                caCvSvc.getEmploymentHistoryResource(param).update(employmentForSaving,
                    function (response) {
                        loadingSvc.close();
                        saveEmploymentHistorySuccess(response);
                        toastr.success($filter(constants.translate)(caMessage.candidateEmploymentHistory.updateCandidateEmploymentHistorySuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.candidateEmploymentHistory.updateCandidateEmploymentHistoryError);
                    });
            }
        }

        function saveEmploymentHistorySuccess(response) {
            self.candidateEmploymentHistories[rowEditing].Id = response.Id;
            self.candidateEmploymentHistories[0].SupervisorPhoneNumber = formatPhoneNumber(self.candidateEmploymentHistories[0].SupervisorPhoneNumber);
            initialCaEmploymentHistories = copyEmploymentHistory(self.candidateEmploymentHistories);
            resetRowIndex();
        }

        function checkIsEditingRow(rowIndex) {
            return rowIndex == rowEditing ? true : false;
        }

        function editEmploymentHistory(rowIndex) {
            self.isValidDate = true;
            self.isEditMode = true;
            _isRowEditing = true;
            if (!_isAddingEmploymentHistory) {
                rowEditing = rowIndex;
            }
            else {
                toastr.warning($filter(constants.translate)(message.addingData));
            }
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function cancelEditEmploymentHistory() {
            self.candidateEmploymentHistories = copyEmploymentHistory(initialCaEmploymentHistories);
            resetRowIndex();
        }

        function copyEmploymentHistory(fromEmploymentHistory) {
            var candidateEmploymentHistoriesFormat = [];
            $.each(fromEmploymentHistory, function (item, employmentHistory) {
                candidateEmploymentHistoriesFormat.push(new caEmploymentHistoryModel(employmentHistory, false, true));
            });
            return candidateEmploymentHistoriesFormat;
        }

        function removeEmploymentHistory(employmentHistoryId, rowIndex, currentEmploymentHistory) {
            if (_isAddingEmploymentHistory) {
                toastr.warning($filter(constants.translate)(message.addingData));
                return;
            }
            rowIndexDeleting = rowIndex;
            param.employmentHistoryId = employmentHistoryId;
            param.isEmployee = currentEmploymentHistory.IsEmployee;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function acceptDeleteCaEmploymentHistory() {
            loadingSvc.show();
            caCvSvc.getEmploymentHistoryResource(param).delete(false,
                function (response) {
                    loadingSvc.close();
                    var result = handleRequestSvc.result(response);
                    if (!result) {
                        toastr.error($filter(constants.translate)(caMessage.candidateEmploymentHistory.deleteCandidateEmploymentHistoryError));
                        return;
                    }
                    self.candidateEmploymentHistories.splice(rowIndexDeleting, 1);
                    initialCaEmploymentHistories = copyEmploymentHistory(self.candidateEmploymentHistories);
                    toastr.success($filter(constants.translate)(caMessage.candidateEmploymentHistory.deleteCandidateEmploymentHistorySuccess));
                    resetRowIndex();
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                });
        }

        function onChangeDate() {
            var startTime = moment(self.candidateEmploymentHistories[rowEditing].StartTime, constants.formatDateDDMMYYYY);
            var endTime = moment(self.candidateEmploymentHistories[rowEditing].EndTime, constants.formatDateDDMMYYYY);
            var diff = endTime.diff(startTime, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function getCssHeaderClass() {
            return _isShowToogleHeader && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function getDetailContentClass(index, isViewMode) {
            return isViewMode ? (checkIsEditingRow(index) ? 'hide' : 'show') : (checkIsEditingRow(index) ? 'show' : 'hide');
        }

        function getButtonAddMoreClass() {
            return self.isEditMode && !_isAddingEmploymentHistory && !_isRowEditing ? 'show' : 'hide';
        }

        function toggleMoreDetail(object) {
            object.isShowMore = !object.isShowMore;
        }
    }
})();