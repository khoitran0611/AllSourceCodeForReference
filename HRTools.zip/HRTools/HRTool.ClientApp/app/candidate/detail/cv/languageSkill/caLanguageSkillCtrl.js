﻿(function () {
    'use strict';
    angular.module('app').controller('caLanguageSkillCtrl', CaLanguageSkillCtrl);
    CaLanguageSkillCtrl.$inject = ['caCvSvc', 'validationSvc', 'styleSvc', 'messageHandleSvc', 'permissionSvc', 'caDetailSvc', "objectSvc",
        'constants', 'caConstants', 'message', 'caMessage', 'caLanguageSkillModel',
        '$stateParams', '$scope', '$filter', '$timeout', 'comparisonUtilSvc', 'loadingSvc'];
    function CaLanguageSkillCtrl(caCvSvc, validationSvc, styleSvc, messageHandleSvc, permissionSvc, caDetailSvc, objectSvc,
            constants, caConstants, message, caMessage, caLanguageSkillModel,
            $stateParams, $scope, $filter, $timeout, comparisonUtilSvc, loadingSvc) {
        var self = this;
        var param = {};
        var oldCandidateLanguageSkill = [];
        var rowIndexEditing;
        var isModifiedLanguageSkill = false;
        var invalidRowIndex = constants.newRowIndex;
        var candidateId = $stateParams.id;
        var _isAddingLanguageSkill = false;
        var _isShowToogleHeader = true;
        var _isUpdatedByAddMore = false;

        self.candidateLanguageSkills = [];
        self.isLanguageSkillEditing = false;
        self.languageLevels = constants.languageLevels;
        self.dialogConfirm = caMessage.languageSkill.dialogConfirm;
        self.checkNumber = objectSvc.checkNumber;

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };

        self.isLanguageSkillRowEditing = isLanguageSkillRowEditing;
        self.onClickEdit = onClickEdit;
        self.onClickHeader = onClickHeader;
        self.onClickCancelEditRow = onClickCancelEditRow;
        self.onClickEditRow = onClickEditRow;
        self.onClickSaveLanguageSkill = onClickSaveLanguageSkill;
        self.onClickAddLanguageSkill = onClickAddLanguageSkill;
        self.isModifiedData = isModifiedData;
        self.onClickDeleteRow = onClickDeleteRow;
        self.onYes = onYes;
        self.getCssHeaderClass = getCssHeaderClass;
        self.toggleDisplayButton = toggleDisplayButton;
        var languageSkillIdDeleting;
        var rowIndexDeleting;

        init();

        function init() {
            param.candidateId = $stateParams.id;
            caCvSvc.getLanguageSkillResource(param).query(
                function (data) {
                    $.each(data, function (index, candidateLanguageSkill) {
                        formatLevelName(candidateLanguageSkill);
                        candidateLanguageSkill.elementId = "Language-Skill-" + index;
                        var skillItem = new caLanguageSkillModel(candidateLanguageSkill, false);
                        self.candidateLanguageSkills.push(skillItem);
                        oldCandidateLanguageSkill.push(skillItem);
                    });
                    $.each(self.candidateLanguageSkills, function (index, candidateLanguageSkill) {
                        formatLevelName(candidateLanguageSkill);
                    });
                    $.each(oldCandidateLanguageSkill, function (index, candidateLanguageSkill) {
                        formatLevelName(candidateLanguageSkill);
                    });
                },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, caMessage.languageSkill.getCandidateSkillError, doesNotShow);
                });

            $scope.$watch('cvCtrl.isEditForm', function (value) {
                self.isLanguageSkillEditing = value;
                resetEdit();
            }, true);


            $scope.$watch('caLSCtrl.candidateLanguageSkills', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                if (!comparisonUtilSvc.isNullOrUndefinedValue(oldCandidateLanguageSkill) && self.candidateLanguageSkills.length > 0 && !_isAddingLanguageSkill) {
                    var candidateLanguageSkillsFormat = copyLanguageSkill(self.candidateLanguageSkills);
                    isModifiedLanguageSkill = JSON.stringify(candidateLanguageSkillsFormat) != JSON.stringify(oldCandidateLanguageSkill);
                } else {
                    if (_isAddingLanguageSkill) {
                        isModifiedLanguageSkill = true;
                    }
                }
            }, true);
        }

        function isLanguageSkillRowEditing(rowIndex) {
            return rowIndex == rowIndexEditing;
        }

        function resetEdit() {
            if (!self.isLanguageSkillEditing && isModifiedLanguageSkill)
                self.candidateLanguageSkills = copyLanguageSkill(oldCandidateLanguageSkill);
            rowIndexEditing = constants.newRowIndex;
            isModifiedLanguageSkill = false;
            _isAddingLanguageSkill = false;
            if (angular.element('#language-skill-detail').css('display') == 'none')
                self.onClickHeader();
        }

        function onClickEdit() {
            self.isLanguageSkillEditing = !self.isLanguageSkillEditing;
            resetEdit();
        }

        function onClickHeader() {
            _isShowToogleHeader = !_isShowToogleHeader;
            $('#language-skill-detail').slideToggle('slow');
        }

        function onClickCancelEditRow() {
            if (_isAddingLanguageSkill) {
                self.candidateLanguageSkills.pop();
            }
            self.candidateLanguageSkills = copyLanguageSkill(oldCandidateLanguageSkill);
            rowIndexEditing = constants.newRowIndex;
            isModifiedLanguageSkill = false;
            _isAddingLanguageSkill = false;
        }

        function onClickEditRow(rowIndex) {
            if (_isAddingLanguageSkill && rowIndexEditing != invalidRowIndex)
                return;
            rowIndexEditing = rowIndex;
        }

        function updateLanguageSkill(languageSkillEditing, param) {
            caCvSvc.getLanguageSkillResource(param).update(languageSkillEditing,
                    function () {
                        loadingSvc.close();
                        onSuccessSaveSkill();
                        toastr.success($filter(constants.translate)(caMessage.languageSkill.updateCandidateSkillSuccess));
                    },
                    function () {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.languageSkill.updateCandidateSkillError);
                    });
        }

        function addNewLanguageSkill(skillEditing, param) {
            caCvSvc.getLanguageSkillResource(param).save(skillEditing,
                   function (newSkillId) {
                       loadingSvc.close();
                       skillEditing.Id = arrayResourceToInt(newSkillId);
                       onSuccessSaveSkill();
                       toastr.success($filter(constants.translate)(caMessage.languageSkill.addCandidateSkillSuccess));
                   },
                   function () {
                       loadingSvc.close();
                       messageHandleSvc.handleResponse(xhr, caMessage.languageSkill.insertCandidateSkillError);
                   });
        }

        function onClickSaveLanguageSkill(skillId, rowIndex) {
            var skillEditing = getRowEditing(rowIndex);
            param.skillId = skillId;

            loadingSvc.show();
            if (!_isAddingLanguageSkill) {
                updateLanguageSkill(skillEditing, param);
            } else {
                addNewLanguageSkill(skillEditing, param);
            }
        }

        function getRowEditing(rowIndex) {
            var languageSkill = new caLanguageSkillModel(null, false);
            languageSkill = self.candidateLanguageSkills[rowIndex];
            return languageSkill;
        }

        function onSuccessSaveSkill() {
            if (!_isUpdatedByAddMore) {
                rowIndexEditing = constants.newRowIndex;
                _isAddingLanguageSkill = false;
            }

            _isUpdatedByAddMore = false;
            isModifiedLanguageSkill = false;
            oldCandidateLanguageSkill = copyLanguageSkill(_.filter(self.candidateLanguageSkills, function (item) { return !comparisonUtilSvc.isNullOrUndefinedValue(item.Id); }));
        }

        function onClickAddLanguageSkill(formName) {
            var isError = false;
            var languageSkill = createLanguageSkill();
            if (rowIndexEditing != constants.newRowIndex)
                isError = validateAddMoreAction(self.candidateLanguageSkills);
            if (isError) return;
            self.candidateLanguageSkills.push(languageSkill);
            focusInput(self.candidateLanguageSkills);
            rowIndexEditing = self.candidateLanguageSkills.length + constants.newRowIndex;
            _isAddingLanguageSkill = true;
        }

        function focusInput(skills) {
            $timeout(function () {
                var newIndex = findWithAttr(skills, "Id", undefined);
                var inputName = "form#{0} input[type='text']";
                inputName = String.format(inputName, skills[newIndex].elementId);
                var input = angular.element($(inputName));
                input.focus();
            }, 500);
        }

        function validateAddMoreAction(list) {
            for (var i = 0; i < list.length; i++) {
                var inputHiddenError = "form#{0} input[name='inputerror']";
                inputHiddenError = String.format(inputHiddenError, list[i].elementId);
                var isError = angular.element(document.querySelector(inputHiddenError)).attr('value');
                if (isError == "true") {
                    toastr.warning($filter(caConstants.translate)(caMessage.checkInputField));
                    self.skillForm.skillName.$dirty = true;
                    return true;
                }
            }

            for (i = 0; i < list.length; i++) {
                var inputHiddenModified = "form#{0} input[name='inputmodified']";
                inputHiddenModified = String.format(inputHiddenModified, list[i].elementId);
                var isModifiedFiled = angular.element(document.querySelector(inputHiddenModified)).attr('value');
                if (!list[i].Id) {
                    param.skillId = list[i].Id;
                    _isUpdatedByAddMore = true;
                    addNewLanguageSkill(list[i], param);
                }
                else if (isModifiedFiled == "true") {
                    param.skillId = list[i].Id;
                    _isUpdatedByAddMore = true;
                    updateLanguageSkill(list[i], param);
                } else
                    continue;
            }
            return false;
        }

        function createLanguageSkill() {
            var languageSkill = new caLanguageSkillModel(null, false);
            languageSkill.CandidateId = candidateId;
            formatLevelName(languageSkill);
            return languageSkill;
        }

        function formatLevelName(languageSkill) {
            $.each(self.languageLevels, function (index, level) {
                if (languageSkill.LevelId == level.Id)
                    languageSkill.LevelName = self.languageLevels[index].Name;
            });
        }

        function isModifiedData(rowIndex) {
            return rowIndex == rowIndexEditing && isModifiedLanguageSkill;
        }

        function onClickDeleteRow(languageSkillId, rowIndex) {
            if (_isAddingLanguageSkill) {
                $('.deleteIcon').attr('data-target', '');
                return;
            }
            $('.deleteIcon').attr('data-target', '#confirmDialog');
            languageSkillIdDeleting = languageSkillId;
            rowIndexDeleting = rowIndex;
            $('#' + self.dialogConfirm.dialogId).modal('show');
        }

        function onYes() {
            param.skillId = languageSkillIdDeleting;
            loadingSvc.show();
            caCvSvc.getLanguageSkillResource(param).delete(
                function () {
                    loadingSvc.close();
                    removeLanguageSkill();
                    toastr.success($filter(constants.translate)(caMessage.languageSkill.deleteCandidateSkillSuccess));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, caMessage.languageSkill.deleteCandidateSkillError);
                });
        }

        function removeLanguageSkill() {
            self.candidateLanguageSkills.splice(rowIndexDeleting, 1);
            oldCandidateLanguageSkill = copyLanguageSkill(self.candidateLanguageSkills);
            rowIndexEditing = constants.newRowIndex;
        }

        function copyLanguageSkill(fromLanguageSkill) {
            var languageSkillsFormat = [];
            $.each(fromLanguageSkill, function (item, languageSkill) {
                formatLevelName(languageSkill);
                languageSkillsFormat.push(new caLanguageSkillModel(languageSkill, false));
            });
            return languageSkillsFormat;
        }

        function getCssHeaderClass() {
            return _isShowToogleHeader && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function toggleDisplayButton() {
            return self.isLanguageSkillEditing ? 'show' : 'hide';
        }
    }
})();
