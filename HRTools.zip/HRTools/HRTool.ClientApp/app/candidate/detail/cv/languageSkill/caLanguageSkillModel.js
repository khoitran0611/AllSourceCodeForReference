﻿(function () {
    'use strict';
    angular.module('app').factory('caLanguageSkillModel', caLanguageSkillModel);

    function caLanguageSkillModel() {
        var resource = function (candidateLanguageSkill, isEmployee) {
            /* jshint -W040 */
            var self = this;
            self.Id = candidateLanguageSkill ? candidateLanguageSkill.Id : undefined;
            self.CandidateId = candidateLanguageSkill ? candidateLanguageSkill.CandidateId : undefined;
            self.EmployeeId = candidateLanguageSkill ? candidateLanguageSkill.EmployeeId : undefined;
            self.SkillName = candidateLanguageSkill ? candidateLanguageSkill.SkillName : '';
            self.LevelId = candidateLanguageSkill ? candidateLanguageSkill.LevelId : 0;
            self.LevelName = candidateLanguageSkill ? candidateLanguageSkill.LevelName : '';
            self.IsEmployee = isEmployee;
            self.elementId = "Language-Skill-" + String.randomNumber();
            self.isError = false;
            self.Attachments = candidateLanguageSkill && candidateLanguageSkill.Attachments ? candidateLanguageSkill.Attachments : [];
            return self;
        };
        return resource;
    }
})();