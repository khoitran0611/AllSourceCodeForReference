﻿(function () {
    'use strict';
    angular.module('app').controller('caCoursesCtrl', CaCoursesCtrl);
    CaCoursesCtrl.$inject = ['caCvSvc', 'datetimeSvc', 'validationSvc', 'styleSvc', 'messageHandleSvc', 'permissionSvc', 'caDetailSvc', "objectSvc",
        'constants', 'caConstants', 'message', 'caMessage', 'caCourseModel',
        '$stateParams', '$scope', '$filter', '$timeout', 'loadingSvc'];
    function CaCoursesCtrl(caCvSvc, datetimeSvc, validationSvc, styleSvc, messageHandleSvc, permissionSvc, caDetailSvc, objectSvc,
            constants, caConstants, message, caMessage, caCourseModel,
            $stateParams, $scope, $filter, $timeout, loadingSvc) {
        var self = this;
        var param = {};
        var oldCandidateCourses = [];
        var invalidRowIndex = constants.newRowIndex;
        var candidateId = $stateParams.id;
        var _isRowEditing = false;
        var _isAddingCourse = false;
        var _isShowToogleHeader = true;

        self.isModifiedData = false;
        self.candidateCourses = [];
        self.isCourseEditing = false;
        self.dialogConfirm = caMessage.course.dialogConfirm;

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };

        self.onClickEdit = onClickEdit;
        self.onClickHeader = onClickHeader;
        self.onClickAddCourse = onClickAddCourse;
        self.onYes = onYes;
        self.getCssHeaderClass = getCssHeaderClass;
        self.getButtonAddMoreClass = getButtonAddMoreClass;
        self.onClickEditRow = onClickEditRow;
        self.checkIsEditingRow = checkIsEditingRow;
        self.onClickSaveCourse = onClickSaveCourse;
        self.onClickCancelEdit = onClickCancelEdit;
        self.onClickDeleteRow = onClickDeleteRow;
        self.getDetailContentClass = getDetailContentClass;
        self.onChangeDate = onChangeDate;

        var rowEditing;
        var rowIndexDeleting;
        var courseIdDeleting;

        init();

        function init() {
            param.candidateId = $stateParams.id;
            caCvSvc.getCoursesResource(param).query(
                function (data) {
                    $.each(data, function (index, candidateCourse) {
                        var courseItem = new caCourseModel(candidateCourse, true);
                        self.candidateCourses.push(courseItem);
                    });
                    formatDate(self.candidateCourses);
                    oldCandidateCourses = angular.copy(self.candidateCourses);
                },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, caMessage.summarySkill.getCandidateSkillError, doesNotShow);
                });

            $scope.$watch('cvCtrl.isEditForm', function (value) {
                self.isCourseEditing = value;
                resetEdit();
            }, true);

            $scope.$watch('caCoCtrl.candidateCourses', function () {
                if (self.candidateCourses.length > 0 && !_isAddingCourse) {
                    var courseFormat = copyCourse(self.candidateCourses);
                    self.isModifiedData = JSON.stringify(courseFormat) != JSON.stringify(oldCandidateCourses);
                } else {
                    if (_isAddingCourse)
                        self.isModifiedData = true;
                }
            }, true);
        }

        function formatDate(coursesFormat) {
            $.each(coursesFormat, function (item, coursesFormat) {
                coursesFormat.FromDate = (coursesFormat.FromDate) ? moment(coursesFormat.FromDate).format(constants.formatDateDDMMYYYY) : "";
                coursesFormat.ToDate = (coursesFormat.ToDate) ? moment(coursesFormat.ToDate).format(constants.formatDateDDMMYYYY) : "";
            });
        }

        function resetEdit() {
            rowEditing = constants.newRowIndex;
            if (_isAddingCourse) {
                self.candidateCourses.pop();
                _isAddingCourse = false;
            }
            if (self.isModifiedData)
                self.candidateCourses = copyCourse(oldCandidateCourses);

            if (angular.element("#course-detail").css("display") == 'none')
                self.onClickHeader();

            if (!self.isCourseEditing) {
                _isRowEditing = false;
            }
        }

        function onClickEdit() {
            self.isCourseEditing = !self.isCourseEditing;
            resetEdit();
            $timeout(function () {
                $('html, body').animate({ scrollTop: $(document).height() }, 'slow');
            }, 200);
        }

        function onClickHeader() {
            _isShowToogleHeader = !_isShowToogleHeader;
            $('#candidate-course-detail').slideToggle('slow');
        }

        function onClickAddCourse() {
            if (rowEditing != invalidRowIndex) {
                toastr.warning($filter(constants.translate)(caMessage.editingData));
                return;
            }
            _isAddingCourse = true;
            self.isValidDate = true;
            var newCourse = new caCourseModel(null, false);
            self.candidateCourses.push(newCourse);
            rowEditing = self.candidateCourses.length - 1;
            self.candidateCourses[rowEditing].FromDate = moment(self.candidateCourses[rowEditing].FromDate).format(constants.formatDateDDMMYYYY);
            self.candidateCourses[rowEditing].ToDate = moment(self.candidateCourses[rowEditing].ToDate).format(constants.formatDateDDMMYYYY);
            $timeout(function () {
                $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
            });
        }

        function onClickSaveCourse(courseId) {
            var courseForSaving = angular.copy(self.candidateCourses[rowEditing]);
            courseForSaving.candidateId = param.candidateId;
            courseForSaving.FromDate = datetimeSvc.convertDateForServerSide(courseForSaving.FromDate, false);
            courseForSaving.ToDate = datetimeSvc.convertDateForServerSide(courseForSaving.ToDate, false);
            loadingSvc.show();
            if (_isAddingCourse) {
                param.courseId = '';
                caCvSvc.getCoursesResource(param).save(courseForSaving,
                    function (newCourseId) {
                        loadingSvc.close();
                        newCourseId = arrayResourceToInt(newCourseId);
                        onSuccessSaveCourse(newCourseId);
                        toastr.success($filter(constants.translate)(caMessage.course.addCandidateCourseSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.course.addCandidateCourseError);
                    });
            } else {
                param.courseId = courseId;
                caCvSvc.getCoursesResource(param).update(courseForSaving,
                    function () {
                        loadingSvc.close();
                        onSuccessSaveCourse();
                        toastr.success($filter(constants.translate)(caMessage.course.updateCandidateCourseSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.course.updateCandidateCourseError);
                    });
            }
        }

        function onSuccessSaveCourse(newCourseId) {
            self.candidateCourses[rowEditing].Id = newCourseId ? newCourseId : self.candidateCourses[rowEditing].Id;
            self.candidateCourses[rowEditing].Comment = (self.candidateCourses[rowEditing].Comment === null || self.candidateCourses[rowEditing].Comment === "") ? "" : self.candidateCourses[rowEditing].Comment;
            oldCandidateCourses = copyCourse(self.candidateCourses);
            rowEditing = constants.newRowIndex;
            _isAddingCourse = false;
            self.isModifiedData = false;
            _isRowEditing = false;
        }

        function checkIsEditingRow(rowIndex) {
            if (rowIndex == rowEditing) return true;
            return false;
        }

        function onClickEditRow(rowIndex) {
            if (_isAddingCourse) {
                toastr.warning($filter(constants.translate)(caMessage.addingData));
                return;
            }
            self.isValidDate = true;
            _isRowEditing = true;
            rowEditing = rowIndex;
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function onClickCancelEdit() {
            self.candidateCourses = copyCourse(oldCandidateCourses);
            rowEditing = constants.newRowIndex;
            if (_isAddingCourse)
                _isAddingCourse = false;
            _isRowEditing = false;
            self.isValidDate = true;
        }

        function copyCourse(fromCourse) {
            var coursesFormat = [];
            $.each(fromCourse, function (item, course) {
                coursesFormat.push(new caCourseModel(course, true));
            });

            return coursesFormat;
        }

        function onClickDeleteRow(courseId, rowIndex) {
            param.courseId = courseId;
            rowIndexDeleting = rowIndex;
            courseIdDeleting = courseId;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function onYes() {
            loadingSvc.show();
            caCvSvc.getCoursesResource(param).delete(
                function () {
                    loadingSvc.close();
                    self.candidateCourses.splice(rowIndexDeleting, 1);
                    oldCandidateCourses = copyCourse(self.candidateCourses);
                    toastr.success($filter(constants.translate)(caMessage.course.deleteCandidateCourseSuccess));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, caMessage.course.deleteCandidateCourseError);
                });
        }

        function onChangeDate() {
            var fromDate = (self.candidateCourses[rowEditing].FromDate) ? moment(self.candidateCourses[rowEditing].FromDate, constants.formatDateDDMMYYYY) : "";
            var toDate = (self.candidateCourses[rowEditing].ToDate) ? moment(self.candidateCourses[rowEditing].ToDate, constants.formatDateDDMMYYYY) : "";
            if (toDate === "") {
                self.isValidDate = true;
                return true;
            }
            var diff = toDate.diff(fromDate, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function getCssHeaderClass() {
            return _isShowToogleHeader && 'col-xs-1 fa sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function getButtonAddMoreClass() {
            return self.isCourseEditing && !_isAddingCourse && !_isRowEditing ? 'show' : 'hide';
        }

        function getDetailContentClass(index, isViewMode) {
            return isViewMode ? (checkIsEditingRow(index) ? 'hide' : 'show') : (checkIsEditingRow(index) ? 'show' : 'hide');
        }
    }
})();
