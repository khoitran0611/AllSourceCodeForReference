﻿(function () {
    'use strict';
    angular.module('app').factory('caCourseModel', caCourseModel);

    function caCourseModel() {
        var resource = function (candidateCourse, allowNull) {
            /* jshint -W040 */
            var self = this;
            self.Id = candidateCourse ? candidateCourse.Id : 0;
            self.CandidateId = candidateCourse ? candidateCourse.CandidateId : 0;
            self.Name = candidateCourse ? candidateCourse.Name : '';
            self.FromDate = candidateCourse && candidateCourse.FromDate ? candidateCourse.FromDate : allowNull ? '' : new Date();
            self.ToDate = candidateCourse && candidateCourse.ToDate ? candidateCourse.ToDate : allowNull ? '' : new Date();
            self.Comment = candidateCourse ? candidateCourse.Comment : '';
            self.Attachments = candidateCourse && candidateCourse.Attachments ? candidateCourse.Attachments : [];
            return self;
        };
        return resource;
    }
})();