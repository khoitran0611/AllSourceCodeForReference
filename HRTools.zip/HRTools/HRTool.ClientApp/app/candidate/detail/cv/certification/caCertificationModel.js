﻿(function () {
    'use strict';
    angular.module('app').factory('caCertificationModel', caCertificationModel);

    function caCertificationModel() {
        var resource = function (candidateCertification, allowNull) {
            /* jshint -W040 */
            var self = this;
            self.Id = candidateCertification ? candidateCertification.Id : 0;
            self.CandidateId = candidateCertification ? candidateCertification.CandidateId : 0;
            self.Name = candidateCertification ? candidateCertification.Name : '';
            self.Authority = candidateCertification ? candidateCertification.Authority : '';
            self.LicenseNumber = candidateCertification ? candidateCertification.LicenseNumber : '';
            self.Url = candidateCertification ? candidateCertification.Url : '';
            self.FromDate = candidateCertification && candidateCertification.FromDate ? candidateCertification.FromDate : allowNull ? '' : new Date();
            self.ToDate = candidateCertification && candidateCertification.ToDate ? candidateCertification.ToDate : allowNull ? '' : new Date();
            self.Attachments = candidateCertification && candidateCertification.Attachments ? candidateCertification.Attachments : [];
            return self;
        };
        return resource;
    }
})();