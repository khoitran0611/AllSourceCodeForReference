﻿(function () {
    'use strict';
    angular.module('app').controller('caCertificationsCtrl', CaCertificationsCtrl);
    CaCertificationsCtrl.$inject = ['caCvSvc', 'datetimeSvc', 'validationSvc', 'styleSvc', 'messageHandleSvc', 'permissionSvc', 'caDetailSvc', "objectSvc",
        'constants', 'caConstants', 'message', 'caMessage', 'caCertificationModel',
        '$stateParams', '$scope', '$filter', '$timeout', '$sce','loadingSvc'];
    function CaCertificationsCtrl(caCvSvc, datetimeSvc, validationSvc, styleSvc, messageHandleSvc, permissionSvc, caDetailSvc, objectSvc,
            constants, caConstants, message, caMessage, caCertificationModel,
            $stateParams, $scope, $filter, $timeout, $sce, loadingSvc) {
        var self = this;
        var param = {};
        var oldCandidateCertifications = [];
        var invalidRowIndex = constants.newRowIndex;
        var candidateId = $stateParams.id;

        var _isRowEditing = false;
        var _isAddingCertification = false;
        var _isShowToogleHeader = true;
        self.isModifiedData = false;
        self.candidateCertifications = [];
        self.isCertificationEditing = false;
        self.dialogConfirm = caMessage.certification.dialogConfirm;

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };

        self.onClickEdit = onClickEdit;
        self.onClickHeader = onClickHeader;
        self.onClickAddCertification = onClickAddCertification;
        self.onYes = onYes;
        self.getCssHeaderClass = getCssHeaderClass;
        self.getButtonAddMoreClass = getButtonAddMoreClass;
        self.onClickEditRow = onClickEditRow;
        self.onClickSaveCertification = onClickSaveCertification;
        self.onClickCancelEdit = onClickCancelEdit;
        self.onClickDeleteRow = onClickDeleteRow;
        self.getDetailContentClass = getDetailContentClass;
        self.onChangeDate = onChangeDate;

        var rowEditing;
        var rowIndexDeleting;
        var certificationIdDeleting;

        init();

        function init() {
            param.candidateId = $stateParams.id;
            caCvSvc.getCertificationsResource(param).query(
                function (data) {
                    $.each(data, function (index, candidateCertification) {
                        var certificationItem = new caCertificationModel(candidateCertification, true);
                        self.candidateCertifications.push(certificationItem);
                    });
                    formatDate(self.candidateCertifications);
                    oldCandidateCertifications = angular.copy(self.candidateCertifications);
                },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, caMessage.summarySkill.getCandidateSkillError, doesNotShow);
                });

            $scope.$watch('cvCtrl.isEditForm', function (value) {
                self.isCertificationEditing = value;
                resetEdit();
            }, true);

            $scope.$watch('caCertCtrl.candidateCertifications', function () {
                if (self.candidateCertifications.length > 0 && !_isAddingCertification) {
                    var certificationFormat = copyCertification(self.candidateCertifications);
                    self.isModifiedData = JSON.stringify(certificationFormat) != JSON.stringify(oldCandidateCertifications);
                } else {
                    if (_isAddingCertification)
                        self.isModifiedData = true;
                }
            }, true);
        }

        function formatDate(certificationsFormat) {
            $.each(certificationsFormat, function (item, certificationsFormat) {
                certificationsFormat.FromDate = (certificationsFormat.FromDate) ? moment(certificationsFormat.FromDate).format(constants.formatDateDDMMYYYY) : "";
                certificationsFormat.ToDate = (certificationsFormat.ToDate) ? moment(certificationsFormat.ToDate).format(constants.formatDateDDMMYYYY) : "";
                certificationsFormat.Duration = certificationsFormat.FromDate +  $sce.trustAsHtml(' &ndash; ') +  certificationsFormat.ToDate;
            });
        }

        function resetEdit() {
            rowEditing = constants.newRowIndex;
            if (_isAddingCertification) {
                self.candidateCertifications.pop();
                _isAddingCertification = false;
            }
            if (self.isModifiedData)
                self.candidateCertifications = copyCertification(oldCandidateCertifications);

            if (angular.element("#candidate-certification-detail").css("display") == 'none')
                self.onClickHeader();

            if (!self.isCertificationEditing) {
                _isRowEditing = false;
            }
        }

        function onClickEdit() {
            self.isCertificationEditing = !self.isCertificationEditing;
            resetEdit();
            $timeout(function () {
                $('html, body').animate({ scrollTop: $(document).height() }, 'slow');
            }, 200);
        }

        function onClickHeader() {
            _isShowToogleHeader = !_isShowToogleHeader;
            $('#candidate-certification-detail').slideToggle('slow');
        }

        function onClickAddCertification() {
            if (rowEditing != invalidRowIndex) {
                toastr.warning($filter(constants.translate)(caMessage.editingData));
                return;
            }
            _isAddingCertification = true;
            self.isValidDate = true;
            var newCertification = new caCertificationModel(null, false);
            self.candidateCertifications.push(newCertification);
            rowEditing = self.candidateCertifications.length - 1;
            self.candidateCertifications[rowEditing].FromDate = moment(self.candidateCertifications[rowEditing].FromDate).format(constants.formatDateDDMMYYYY);
            self.candidateCertifications[rowEditing].ToDate = moment(self.candidateCertifications[rowEditing].ToDate).format(constants.formatDateDDMMYYYY);
            $timeout(function () {
                $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
            });
        }

        function onClickSaveCertification(certificationId) {
            var certificationForSaving = angular.copy(self.candidateCertifications[rowEditing]);
            certificationForSaving.candidateId = param.candidateId;
            certificationForSaving.FromDate = datetimeSvc.convertDateForServerSide(certificationForSaving.FromDate, false);
            certificationForSaving.ToDate = datetimeSvc.convertDateForServerSide(certificationForSaving.ToDate, false);
            loadingSvc.show();
            if (_isAddingCertification) {
                param.certificationId = '';
                caCvSvc.getCertificationsResource(param).save(certificationForSaving,
                    function (newCertificationId) {
                        loadingSvc.close();
                        newCertificationId = arrayResourceToInt(newCertificationId);
                        onSuccessSaveCertification(newCertificationId);
                        toastr.success($filter(constants.translate)(caMessage.certification.addCandidateCertificationSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.certification.addCandidateCertificationError);
                    });
            } else {
                param.certificationId = certificationId;
                caCvSvc.getCertificationsResource(param).update(certificationForSaving,
                    function () {
                        loadingSvc.close();
                        onSuccessSaveCertification();
                        toastr.success($filter(constants.translate)(caMessage.certification.updateCandidateCertificationSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.certification.updateCandidateCertificationError);
                    });
            }
        }

        function onSuccessSaveCertification(newCertificationId) {
            self.candidateCertifications[rowEditing].Id = newCertificationId ? newCertificationId : self.candidateCertifications[rowEditing].Id;
            self.candidateCertifications[rowEditing].Comment = (self.candidateCertifications[rowEditing].Comment === null || self.candidateCertifications[rowEditing].Comment === "") ? "" : self.candidateCertifications[rowEditing].Comment;
            oldCandidateCertifications = copyCertification(self.candidateCertifications);
            rowEditing = constants.newRowIndex;
            _isAddingCertification = false;
            self.isModifiedData = false;
            _isRowEditing = false;
        }

        function checkIsEditingRow(rowIndex) {
            if (rowIndex == rowEditing) return true;
            return false;
        }

        function onClickEditRow(rowIndex) {
            if (_isAddingCertification) {
                toastr.warning($filter(constants.translate)(caMessage.addingData));
                return;
            }
            self.isValidDate = true;
            _isRowEditing = true;
            rowEditing = rowIndex;
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function onClickCancelEdit() {
            self.candidateCertifications = copyCertification(oldCandidateCertifications);
            rowEditing = constants.newRowIndex;
            if (_isAddingCertification)
                _isAddingCertification = false;
            _isRowEditing = false;
            self.isValidDate = true;
        }

        function copyCertification(fromCertification) {
            var certificationsFormat = [];
            $.each(fromCertification, function (item, certification) {
                certificationsFormat.push(new caCertificationModel(certification, true));
            });

            return certificationsFormat;
        }

        function onClickDeleteRow(certificationId, rowIndex) {
            param.certificationId = certificationId;
            rowIndexDeleting = rowIndex;
            certificationIdDeleting = certificationId;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function onYes() {
            loadingSvc.show();
            caCvSvc.getCertificationsResource(param).delete(
                function () {
                    loadingSvc.close();
                    self.candidateCertifications.splice(rowIndexDeleting, 1);
                    oldCandidateCertifications = copyCertification(self.candidateCertifications);
                    toastr.success($filter(constants.translate)(caMessage.certification.deleteCandidateCertificationSuccess));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, caMessage.certification.deleteCandidateCertificationError);
                });
        }

        function onChangeDate() {
            var fromDate = (self.candidateCertifications[rowEditing].FromDate) ? moment(self.candidateCertifications[rowEditing].FromDate, constants.formatDateDDMMYYYY) : "";
            var toDate = (self.candidateCertifications[rowEditing].ToDate) ? moment(self.candidateCertifications[rowEditing].ToDate, constants.formatDateDDMMYYYY) : "";
            if (toDate === "") {
                self.isValidDate = true;
                return true;
            }
            var diff = toDate.diff(fromDate, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function getCssHeaderClass() {
            return _isShowToogleHeader && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function getButtonAddMoreClass() {
            return self.isCertificationEditing && !_isAddingCertification && !_isRowEditing ? 'show' : 'hide';
        }

        function getDetailContentClass(index, isViewMode) {
            return isViewMode ? (checkIsEditingRow(index) ? 'hide' : 'show') : (checkIsEditingRow(index) ? 'show' : 'hide');
        }
    }
})();
