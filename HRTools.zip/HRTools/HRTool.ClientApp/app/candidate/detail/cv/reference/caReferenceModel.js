﻿(function () {
    'use strict';
    angular.module('app').factory('caReferenceModel', caReferenceModel);

    function caReferenceModel() {
        var resource = function (CandidateReference) {
            /* jshint -W040 */
            var self = this;
            self.Id = CandidateReference ? CandidateReference.Id : undefined;
            self.CandidateId = CandidateReference ? CandidateReference.CandidateId : undefined;
            self.Name = CandidateReference ? CandidateReference.Name : '';
            self.Email = CandidateReference ? CandidateReference.Email : '';
            self.Phone = CandidateReference ? CandidateReference.Phone : '';
            self.elementId = "Reference-" + String.randomNumber();
            self.Attachments = CandidateReference && CandidateReference.Attachments ? CandidateReference.Attachments: [];
            return self;
        };
        return resource;
    }
})();