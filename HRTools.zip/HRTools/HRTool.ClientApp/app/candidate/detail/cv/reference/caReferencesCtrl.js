﻿(function () {
    'use strict';
    angular.module('app').controller('caReferencesCtrl', CaReferencesCtrl);
    CaReferencesCtrl.$inject = ['caCvSvc', 'validationSvc', 'styleSvc', 'messageHandleSvc', 'permissionSvc', 'caDetailSvc', "objectSvc",
        'constants', 'caConstants', 'message', 'caMessage', 'caReferenceModel',
        '$stateParams', '$scope', '$filter', '$timeout', 'comparisonUtilSvc', 'loadingSvc'];
    function CaReferencesCtrl(caCvSvc, validationSvc, styleSvc, messageHandleSvc, permissionSvc, caDetailSvc, objectSvc,
            constants, caConstants, message, caMessage, caReferenceModel,
            $stateParams, $scope, $filter, $timeout, comparisonUtilSvc, loadingSvc) {
        var self = this;
        var param = {};
        var oldCandidateReference = [];
        var rowIndexEditing;
        var isModifiedReference = false;
        var invalidRowIndex = constants.newRowIndex;
        var candidateId = $stateParams.id;
        self.validateEmailPhone = true;
        self.isOtherFieldChanged = false;

        self.candidateReferences = [];
        self.isReferenceEditing = false;
        self.dialogConfirm = caMessage.reference.dialogConfirm;
        self.checkNumber = objectSvc.checkNumber;

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };

        self.isReferenceRowEditing = isReferenceRowEditing;
        self.onClickEdit = onClickEdit;
        self.onClickHeader = onClickHeader;
        self.onClickCancelEditRow = onClickCancelEditRow;
        self.onClickEditRow = onClickEditRow;
        self.onClickSaveReference = onClickSaveReference;
        self.onClickAddReference = onClickAddReference;
        self.isModifiedData = isModifiedData;
        self.onClickDeleteRow = onClickDeleteRow;
        self.onYes = onYes;
        self.getCssHeaderClass = getCssHeaderClass;
        self.toggleDisplayButton = toggleDisplayButton;
        self.checkPhoneNumber = objectSvc.checkPhoneNumber;
        self.checkEitherEmailOrPhonerequired = checkEitherEmailOrPhonerequired;

        var _isAddingReference = false;
        var _isShowToogleHeader = true;
        var _isUpdatedByAddMore = false;
        var referenceDeleting;
        var referenceIdDeleting;
        var rowIndexDeleting;

        init();

        function init() {
            param.candidateId = $stateParams.id;
            caCvSvc.getReferencesResource(param).query(
                function (data) {
                    $.each(data, function (index, candidateReference) {
                        candidateReference.elementId = "Reference-" + index;
                        var referenceItem = new caReferenceModel(candidateReference);
                        self.candidateReferences.push(referenceItem);
                        oldCandidateReference.push(referenceItem);
                    });
                },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, caMessage.reference.getCandidateReferenceError, doesNotShow);
                });

            $scope.$watch('cvCtrl.isEditForm', function (value) {
                self.isReferenceEditing = value;
                resetEdit();
            }, true);

            $scope.$watch('caReCtrl.candidateReferences', function (newValue, oldValue) {
                if (newValue === oldValue) return;
                if (!comparisonUtilSvc.isNullOrUndefinedValue(oldCandidateReference) && self.candidateReferences.length > 0 && !_isAddingReference) {
                    var candidateReferencesFormat = copyReference(self.candidateReferences);
                    isModifiedReference = JSON.stringify(candidateReferencesFormat) != JSON.stringify(oldCandidateReference);
                } else {
                    if (_isAddingReference) {
                        isModifiedReference = true;
                    }
                }
            }, true);
        }

        function isReferenceRowEditing(rowIndex) {
            if (rowIndex == rowIndexEditing)
                return true;
            return false;
        }

        function resetEdit() {
            if (!self.isReferenceEditing && isModifiedReference)
                self.candidateReferences = copyReference(oldCandidateReference);
            rowIndexEditing = constants.newRowIndex;
            self.isOtherFieldChanged = false;
            isModifiedReference = false;
            _isAddingReference = false;
            if (angular.element('#candidate-references-detail').css('display') == 'none')
                self.onClickHeader();
        }

        function onClickEdit() {
            self.isReferenceEditing = !self.isReferenceEditing;
            resetEdit();
        }

        function onClickHeader() {
            _isShowToogleHeader = !_isShowToogleHeader;
            $('#candidate-references-detail').slideToggle('slow');
        }

        function onClickCancelEditRow() {

            if (_isAddingReference) {
                self.candidateReferences.pop();
            }
            self.candidateReferences = copyReference(oldCandidateReference);
            rowIndexEditing = constants.newRowIndex;
            self.validateEmailPhone = true;
            self.isOtherFieldChanged = false;
            isModifiedReference = false;
            _isAddingReference = false;
        }

        function onClickEditRow(rowIndex) {
            if (_isAddingReference && rowIndexEditing != invalidRowIndex)
                return;
            rowIndexEditing = rowIndex;
        }

        function updateReference(referenceEditing, param) {
            loadingSvc.show();
            caCvSvc.getReferencesResource(param).update(referenceEditing,
                    function () {
                        loadingSvc.close();
                        onSuccessSaveReference();
                        toastr.success($filter(constants.translate)(caMessage.reference.updateCandidateReferenceSuccess));
                    },
                    function () {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.reference.updateCandidateReferenceError);
                    });
        }

        function addNewReference(referenceEditing, param) {
            loadingSvc.show();
            caCvSvc.getReferencesResource(param).save(referenceEditing,
                   function (newReferenceId) {
                       loadingSvc.close();
                       referenceEditing.Id = arrayResourceToInt(newReferenceId);
                       onSuccessSaveReference();
                       toastr.success($filter(constants.translate)(caMessage.reference.addCandidateReferenceSuccess));
                   },
                   function () {
                       loadingSvc.close();
                       messageHandleSvc.handleResponse(xhr, caMessage.reference.insertCandidateReferenceError);
                   });
        }

        function onClickSaveReference(referenceId, rowIndex) {
            self.validateEmailPhone = true;
            var referenceEditing = getRowEditing(rowIndex);
            param.referenceId = referenceId;
            if (!_isAddingReference) {
                updateReference(referenceEditing, param);
            } else {
                addNewReference(referenceEditing, param);
            }
        }

        function getRowEditing(rowIndex) {
            var reference = new caReferenceModel(null, false);
            reference = self.candidateReferences[rowIndex];
            return reference;
        }

        function onSuccessSaveReference() {
            if (!_isUpdatedByAddMore) {
                rowIndexEditing = constants.newRowIndex;
                _isAddingReference = false;
            }

            _isUpdatedByAddMore = false;
            isModifiedReference = false;
            oldCandidateReference = copyReference(_.filter(self.candidateReferences, function (item) { return !comparisonUtilSvc.isNullOrUndefinedValue(item.Id); }));
        }

        function onClickAddReference(formName) {
            var isError = false;
            var reference = createReference();
            if (rowIndexEditing != constants.newRowIndex)
                isError = validateAddMoreAction(self.candidateReferences);
            if (isError) return;
            self.validateEmailPhone = false;
            self.candidateReferences.push(reference);
            focusInput(self.candidateReferences);
            rowIndexEditing = self.candidateReferences.length + constants.newRowIndex;
            _isAddingReference = true;
            self.isOtherFieldChanged = false;
        }

        function focusInput(references) {
            $timeout(function () {
                var newIndex = findWithAttr(references, "Id", undefined);
                var inputName = "form#{0} input[type='text']";
                inputName = String.format(inputName, references[newIndex].elementId);
                var input = angular.element($(inputName));
                input.focus();
            }, 500);
        }

        function validateAddMoreAction(list) {
            for (var i = 0; i < list.length; i++) {
                var inputHiddenError = "form#{0} input[name='inputerror']";
                inputHiddenError = String.format(inputHiddenError, list[i].elementId);
                var isError = angular.element(document.querySelector(inputHiddenError)).attr('value');
                if (isError == "true") {
                    toastr.warning($filter(caConstants.translate)(caMessage.checkInputField));
                    self.isOtherFieldChanged = true;
                    self.referenceForm.Name.$dirty = true;
                    return true;
                }
            }

            for (i = 0; i < list.length; i++) {
                var inputHiddenModified = "form#{0} input[name='inputmodified']";
                inputHiddenModified = String.format(inputHiddenModified, list[i].elementId);
                var isModifiedFiled = angular.element(document.querySelector(inputHiddenModified)).attr('value');
                if (!list[i].Id) {
                    param.referenceId = list[i].Id;
                    _isUpdatedByAddMore = true;
                    addNewReference(list[i], param);
                }
                else if (isModifiedFiled == "true") {
                    param.referenceId = list[i].Id;
                    _isUpdatedByAddMore = true;
                    updateReference(list[i], param);
                } else
                    continue;
            }
            return false;
        }

        function createReference() {
            var reference = new caReferenceModel(null);
            reference.CandidateId = candidateId;
            return reference;
        }

        function isModifiedData(rowIndex) {
            return rowIndex == rowIndexEditing && isModifiedReference;
        }

        function onClickDeleteRow(referenceId, rowIndex) {
            if (_isAddingReference) {
                $('.deleteIcon').attr('data-target', '');
                return;
            }
            $('.deleteIcon').attr('data-target', '#confirmDialog');
            referenceDeleting = getRowEditing(rowIndex);
            referenceIdDeleting = referenceId;
            rowIndexDeleting = rowIndex;
            $('#' + self.dialogConfirm.dialogId).modal('show');
        }

        function onYes() {
            loadingSvc.show();
            param.referenceId = referenceDeleting.Id;
            caCvSvc.getReferencesResource(param).delete(
                function () {
                    loadingSvc.close();
                    removeReference();
                    toastr.success($filter(constants.translate)(caMessage.reference.deleteCandidateReferenceSuccess));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, caMessage.reference.deleteCandidateReferenceError);
                });
        }

        function removeReference() {
            self.candidateReferences.splice(rowIndexDeleting, 1);
            oldCandidateReference = copyReference(self.candidateReferences);
            rowIndexEditing = constants.newRowIndex;
        }

        function copyReference(fromReference) {
            var referencesFormat = [];
            $.each(fromReference, function (item, reference) {
                referencesFormat.push(new caReferenceModel(reference));
            });
            return referencesFormat;
        }

        function getCssHeaderClass() {
            return _isShowToogleHeader && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function toggleDisplayButton() {
            return self.isReferenceEditing ? 'show' : 'hide';
        }

        function checkEitherEmailOrPhonerequired(email, phone) {
            self.isOtherFieldChanged = true;
            self.validateEmailPhone = !(email === "" && phone === "");
        }
    }
})();
