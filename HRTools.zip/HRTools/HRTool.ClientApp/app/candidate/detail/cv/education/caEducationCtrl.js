﻿(function () {
    'use strict';
    angular.module('app').controller('caEducationCtrl', CaEducationCtrl);
    CaEducationCtrl.$inject = ['caCvSvc', 'datetimeSvc', 'styleSvc', 'messageHandleSvc', 'permissionSvc', 'caDetailSvc',
        'constants', 'message', 'caMessage', 'caEducationModel',
        '$stateParams', '$scope', '$timeout', '$filter', 'caConstants', 'loadingSvc', 'countrySvc'];
    function CaEducationCtrl(caCvSvc, datetimeSvc, styleSvc, messageHandleSvc, permissionSvc, caDetailSvc,
            constants, message, caMessage, caEducationModel,
            $stateParams, $scope, $timeout, $filter, caConstants, loadingSvc, countrySvc) {
        var self = this;

        var _isRowEditing = false;
        var _isAddingEducation = false;
        self.isEducationEditing = false;
        self.isValidDate = true;
        self.candidateEducations = [];
        self.dialogConfirm = caMessage.education.dialogConfirm;
        self.isModifiedData = false;
        var _isShowToogleHeader = true;
        self.isCountryChanged = false;
        self.isSchoolLevelChanged = false;

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };

        self.schoolLevelSelected = "";
        self.schoolLevel = [{ name: '' }, { name: "Secondary School" }, { name: "High School" }, { name: "College" }, { name: "University" }, { name: "Other" }];
        self.countries = [];

        self.onClickEdit = onClickEdit;
        self.onClickAddEducation = onClickAddEducation;
        self.onClickHeader = onClickHeader;
        self.onClickSaveEducation = onClickSaveEducation;
        self.checkIsEditingRow = checkIsEditingRow;
        self.onClickEditRow = onClickEditRow;
        self.onClickCancelEdit = onClickCancelEdit;
        self.onClickDeleteRow = onClickDeleteRow;
        self.onYes = onYes;
        self.onChangeDate = onChangeDate;
        self.getCssHeaderClass = getCssHeaderClass;
        self.getDetailContentClass = getDetailContentClass;
        self.getButtonAddMoreClass = getButtonAddMoreClass;
        self.schoolLevelChanged = schoolLevelChanged;
        self.countryChanged = countryChanged;

        var param = {};
        param.candidateId = $stateParams.id;
        var oldCandidateEducations = [];
        var rowEditing;
        var rowIndexDeleting;
        var educationIdDeleting;

        init();

        function init() {
            var educations = caCvSvc.getEducationsResource(param).query(
            function () {
                $.each(educations, function (item, education) {
                    self.candidateEducations.push(new caEducationModel(education, false, true));
                    oldCandidateEducations.push(new caEducationModel(education, false, true));
                });
                formatDate(self.candidateEducations);
                formatDate(oldCandidateEducations);
            },
            function (xhr) {
                var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                caDetailSvc.setCurrentLoading(false);
                messageHandleSvc.handleResponse(xhr, caMessage.education.getCandidateEducationError, doesNotShow);
            });

            countrySvc.getAllCountries().query(function (result) {
                self.countries = result;
                var countryDefault = {
                    Id: self.countries.length + 1,
                    CountryCode: "EMPTY",
                    CountryNameEN: "",
                    CountryLocalName: "",
                    ModifiedDate: new Date()
                };

                self.countries.splice(0, 0, countryDefault);
                self.countrySelected = self.countries[0].CountryLocalName;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, caMessage.errorLoadingData);
            });

            $scope.$watch('cvCtrl.isEditForm', function (value) {
                self.isEducationEditing = value;
                resetEdit();
            }, true);

            $scope.$watch("caEdCtrl.candidateEducations", function () {
                if (self.candidateEducations.length > 0 && !_isAddingEducation) {
                    var educationsFormat = copyEducation(self.candidateEducations);
                    self.isModifiedData = JSON.stringify(educationsFormat) != JSON.stringify(oldCandidateEducations);
                } else {
                    if (_isAddingEducation)
                        self.isModifiedData = true;
                }
            }, true);
        }

        function resetEdit() {
            rowEditing = constants.newRowIndex;
            if (_isAddingEducation) {
                self.candidateEducations.pop();
                _isAddingEducation = false;
            }
            if (self.isModifiedData)
                self.candidateEducations = copyEducation(oldCandidateEducations);

            if (angular.element("#candidate-education-detail").css("display") == 'none')
                self.onClickHeader();

            if (!self.isEducationEditing) {
                _isRowEditing = false;
            }
        }

        function onClickEdit() {
            self.isEducationEditing = !self.isEducationEditing;
            resetEdit();
            $timeout(function () {
                $('html, body').animate({ scrollTop: $(document).height() }, 'slow');
            }, 200);
        }

        function formatDate(educationsFormat) {
            $.each(educationsFormat, function (item, educationFormat) {
                educationFormat.FromYear = (educationFormat.From) ? moment(educationFormat.From).format(constants.formatDateDDMMYYYY) : "";
                educationFormat.ToYear = (educationFormat.To) ? moment(educationFormat.To).format(constants.formatDateDDMMYYYY) : "";
                educationFormat.From = (educationFormat.From) ? moment(educationFormat.From).format(constants.formatDateDDMMYYYY) : "";
                educationFormat.To = (educationFormat.To) ? moment(educationFormat.To).format(constants.formatDateDDMMYYYY) : "";
            });
        }

        function onClickAddEducation() {
            if (rowEditing != constants.newRowIndex) {
                toastr.warning($filter(constants.translate)(caMessage.editingData));
                return;
            }
            _isAddingEducation = true;
            var newEducation = new caEducationModel(null, false, false);
            self.candidateEducations.push(newEducation);
            rowEditing = self.candidateEducations.length - 1;
            self.candidateEducations[rowEditing].From = moment(self.candidateEducations[rowEditing].From).format(constants.formatDateDDMMYYYY);
            self.candidateEducations[rowEditing].To = moment(self.candidateEducations[rowEditing].To).format(constants.formatDateDDMMYYYY);
            self.schoolLevelSelected = "";
            self.countrySelected = self.countries[0].CountryLocalName;
            $timeout(function () {
                $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
            });

        }

        function onClickHeader() {
            _isShowToogleHeader = !_isShowToogleHeader;
            $("#candidate-education-detail").slideToggle("slow");
        }

        function onClickSaveEducation(educationId) {
            self.candidateEducations[rowEditing].SchoolLevel = self.schoolLevelSelected;
            self.candidateEducations[rowEditing].Country = self.countrySelected;
            var educationForSaving = angular.copy(self.candidateEducations[rowEditing]);
            educationForSaving.From = datetimeSvc.convertDateForServerSide(educationForSaving.From, false);
            educationForSaving.To = datetimeSvc.convertDateForServerSide(educationForSaving.To, false);

            loadingSvc.show();
            if (_isAddingEducation) {
                param.educationId = '';
                caCvSvc.getEducationsResource(param).save(educationForSaving,
                    function (newEducationId) {
                        loadingSvc.close();
                        newEducationId = arrayResourceToInt(newEducationId);
                        onSuccessSaveEducation(newEducationId);
                        toastr.success($filter(constants.translate)(caMessage.education.addCandidateEducationSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.education.addCandidateEducationError);
                    });
            } else {
                param.educationId = educationId;
                caCvSvc.getEducationsResource(param).update(educationForSaving,
                    function () {
                        loadingSvc.close();
                        onSuccessSaveEducation();
                        toastr.success($filter(constants.translate)(caMessage.education.updateCandidateEducationSuccess));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.education.updateCandidateEducationError);
                    });
            }
        }


        function onSuccessSaveEducation(newEducationId) {
            self.candidateEducations[rowEditing].FromYear = (self.candidateEducations[rowEditing].From) ? self.candidateEducations[rowEditing].From : "";
            self.candidateEducations[rowEditing].ToYear = (self.candidateEducations[rowEditing].To) ? self.candidateEducations[rowEditing].To : "";
            self.candidateEducations[rowEditing].Id = newEducationId ? newEducationId : self.candidateEducations[rowEditing].Id;
            self.candidateEducations[rowEditing].ShowSchoolLevelLabel = (self.candidateEducations[rowEditing].SchoolLevel === null || self.candidateEducations[rowEditing].SchoolLevel === "") ? false : true;
            self.candidateEducations[rowEditing].ShowCountryLabel = (self.candidateEducations[rowEditing].Country === null || self.candidateEducations[rowEditing].Country === "") ? false : true;
            self.candidateEducations[rowEditing].ShowFieldLabel = (self.candidateEducations[rowEditing].Field === null || self.candidateEducations[rowEditing].Field === "") ? false : true;
            oldCandidateEducations = copyEducation(self.candidateEducations);
            rowEditing = constants.newRowIndex;
            _isAddingEducation = false;
            self.isModifiedData = false;
            _isRowEditing = false;
        }

        function checkIsEditingRow(rowIndex) {
            if (rowIndex == rowEditing) return true;
            return false;
        }

        function onClickEditRow(rowIndex) {
            if (_isAddingEducation) {
                toastr.warning($filter(constants.translate)(caMessage.addingData));
                return;
            }
            _isRowEditing = true;
            rowEditing = rowIndex;
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
            self.schoolLevelSelected = self.candidateEducations[rowEditing].SchoolLevel;
            self.countrySelected = self.candidateEducations[rowEditing].Country;
        }

        function onClickCancelEdit() {
            self.candidateEducations = copyEducation(oldCandidateEducations);
            rowEditing = constants.newRowIndex;
            if (_isAddingEducation)
                _isAddingEducation = false;
            _isRowEditing = false;
            self.isValidDate = true;
            self.isSchoolLevelChanged = false;
            self.isCountryChanged = false;
        }

        function copyEducation(fromEducation) {
            var educationsFormat = [];
            $.each(fromEducation, function (item, education) {
                educationsFormat.push(new caEducationModel(education, false, true));
            });
            return educationsFormat;
        }

        function onClickDeleteRow(educationId, rowIndex) {
            param.educationId = educationId;
            rowIndexDeleting = rowIndex;
            educationIdDeleting = educationId;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function onYes() {
            loadingSvc.show();
            caCvSvc.getEducationsResource(param).delete(
                function () {
                    loadingSvc.close();
                    self.candidateEducations.splice(rowIndexDeleting, 1);
                    oldCandidateEducations = copyEducation(self.candidateEducations);
                    toastr.success($filter(constants.translate)(caMessage.education.deleteCandidateEducationSuccess));
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, caMessage.education.deleteCandidateEducationError);
                });
        }

        function onChangeDate() {
            var fromDate = (self.candidateEducations[rowEditing].From) ? moment(self.candidateEducations[rowEditing].From, constants.formatDateDDMMYYYY) : "";
            var toDate = (self.candidateEducations[rowEditing].To) ? moment(self.candidateEducations[rowEditing].To, constants.formatDateDDMMYYYY) : "";
            self.isValidDate = toDate.diff(fromDate, 'days') >= 0 ? true : false;
        }

        function getCssHeaderClass() {
            return _isShowToogleHeader && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function getDetailContentClass(index, isViewMode) {
            return isViewMode ? (checkIsEditingRow(index) ? 'hide' : 'show') : (checkIsEditingRow(index) ? 'show' : 'hide');
        }

        function getButtonAddMoreClass() {
            return self.isEducationEditing && !_isAddingEducation && !_isRowEditing ? 'show' : 'hide';
        }

        function schoolLevelChanged() {
            if (self.isEducationEditing) {
                self.isSchoolLevelChanged = (self.schoolLevelSelected !== self.candidateEducations[rowEditing].SchoolLevel);
            }
            if (_isAddingEducation) {
                self.isSchoolLevelChanged = (self.schoolLevelSelected !== "");
            }
        }

        function countryChanged() {
            if (self.isEducationEditing) {
                self.isSchoolLevelChanged = (self.countrySelected !== self.candidateEducations[rowEditing].Country);
            }
            if (_isAddingEducation) {
                self.isCountryChanged = (self.countrySelected !== "");
            }
        }
    }
})();