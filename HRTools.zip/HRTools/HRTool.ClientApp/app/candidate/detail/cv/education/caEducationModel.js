﻿(function () {
    'use strict';

    angular.module('app').factory('caEducationModel', caEducationModel);
    function caEducationModel() {
        var model = function (candidateEducation, isEmployee, allowNull) {
            /* jshint -W040 */
            var self = this;
            self.Id = candidateEducation ? candidateEducation.Id : 0;
            self.CandidateId = candidateEducation ? candidateEducation.CandidateId : 0;
            self.EmployeeId = candidateEducation ? candidateEducation.EmployeeId : 0;
            self.School = candidateEducation ? candidateEducation.School : '';
            self.Field = candidateEducation ? candidateEducation.Field : '';
            self.From = candidateEducation && candidateEducation.From ? candidateEducation.From : allowNull ? '' : new Date();
            self.To = candidateEducation && candidateEducation.To ? candidateEducation.To : allowNull ? '' : new Date();
            self.FromYear = candidateEducation && candidateEducation.FromYear ? candidateEducation.FromYear : '';
            self.ToYear = candidateEducation && candidateEducation.ToYear ? candidateEducation.ToYear : '';
            self.IsEmployee = isEmployee;
            self.SchoolLevel = candidateEducation ? candidateEducation.SchoolLevel : '';
            self.Degree = candidateEducation ? candidateEducation.Degree : '';
            self.Country = candidateEducation ? candidateEducation.Country : '';
            self.ShowSchoolLevelLabel = candidateEducation && (candidateEducation.SchoolLevel === null || candidateEducation.SchoolLevel === "") ? false : true;
            self.ShowCountryLabel = candidateEducation && (candidateEducation.Country === null || candidateEducation.Country === "") ? false : true;
            self.ShowFieldLabel = candidateEducation && (candidateEducation.Field === null || candidateEducation.Field === "") ? false : true;
            self.Attachments = candidateEducation && candidateEducation.Attachments ? candidateEducation.Attachments : [];
        };
        return model;
    }
})();