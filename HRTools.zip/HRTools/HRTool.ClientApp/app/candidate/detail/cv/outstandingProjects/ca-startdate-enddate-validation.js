﻿(function () {
    "use strict";

    angular.module('app').directive('caStartdateEnddateValidation', caStartdateEnddateValidation);
    function caStartdateEnddateValidation() {
        return {
            require: 'ngModel',
            scope: {
                data: "=caStartdateEnddateValidation"
            },
            link: function (scope, elm, attrs, ctrl) {
                scope.$watch('data', function (data) {

                    if (data) {
                        if (!data.StartTime && data.EndTime) {
                            ctrl.$setValidity('startdateGreaterThanEnddate', false);
                            return undefined;
                        }
                        var dateFormat = "YYYY-MM-DD";
                        var startTime = null;
                        var endTime = null;
                        if (data.StartTime !== "" && (typeof data.StartTime == "string")) {
                            startTime = moment(data.StartTime, "DD-MM-YYYY").format(dateFormat);
                        }
                        if (data.EndTime !== "" && (typeof data.EndTime == "string")) {
                            endTime = moment(data.EndTime, "DD-MM-YYYY").format(dateFormat);
                        }
                        var isInValid = startTime && endTime && (startTime > endTime);
                        if (data.EndTime !== "" && isInValid) {
                            ctrl.$setValidity('startdateGreaterThanEnddate', false);
                            return data.StartTime;
                        }
                    }
                    ctrl.$setValidity('startdateGreaterThanEnddate', true);
                    return undefined;
                }, true);
            }
        };
    }
})();
