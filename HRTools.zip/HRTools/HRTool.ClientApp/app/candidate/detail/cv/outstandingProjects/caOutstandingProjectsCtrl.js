﻿(function () {
    'use strict';
    angular.module('app').controller('caOutstandingProjectsCtrl', CaOutstandingProjectsCtrl);
    CaOutstandingProjectsCtrl.$inject = ["$timeout", "$scope", "$stateParams", '$filter',
        'message', 'constants', 'caMessage', 'caOutstandingProjectModel', 'validationSvc',
        'datetimeSvc', 'styleSvc', 'permissionSvc', 'caCvSvc', 'handleRequestSvc', 'messageHandleSvc', 'caDetailSvc', 'loadingSvc'];
    function CaOutstandingProjectsCtrl($timeout, $scope, $stateParams, $filter,
            message, constants, caMessage, caOutstandingProjectModel, validationSvc,
            datetimeSvc, styleSvc, permissionSvc, caCvSvc, handleRequestSvc, messageHandleSvc, caDetailSvc, loadingSvc) {
        var self = this;
        var _isRowEditing = false;
        var _isAddingOutstandingProject = false;
        var _isShowToogleHeader = true;

        self.isEditMode = false;
        self.isModifiedData = false;
        self.isValidDate = true;
        self.dialogConfirm = caMessage.outstandingProject.dialogConfirm;
        self.validationStartTimeEndTime = $filter(constants.translate)(message.validatonStartDateGreaterThanEndDate);
        self.candidateOutstandingProjectHistories = [];

        self.permissionOfCurrentUser = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo),
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo),
            deleteCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            hasCandidatePermission: (permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo) ||
                permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_DeleteCandidateInfo))
        };


        self.addCandidateOutstandingProject = addCandidateOutstandingProject;
        self.toogleHeader = toogleHeader;
        self.saveCandidateOutstandingProject = saveCandidateOutstandingProject;
        self.editOutstandingProject = editOutstandingProject;
        self.cancelEditOutstandingProject = cancelEditOutstandingProject;
        self.removeOutstandingProject = removeOutstandingProject;
        self.acceptDeleteCaOutstandingProject = acceptDeleteCaOutstandingProject;
        self.onChangeDate = onChangeDate;
        self.onSalaryKeyDown = onSalaryKeyDown;
        self.getCssHeaderClass = getCssHeaderClass;
        self.getDetailContentClass = getDetailContentClass;
        self.getButtonAddMoreClass = getButtonAddMoreClass;
        self.checkPhoneCharacter = checkPhoneCharacter;
        self.toggleMoreDetail = toggleMoreDetail;
        self.validationMaxLengthMessage = validationMaxLengthMessage;

        var param = {};
        var initialCaOutstandingProjectHistories = [];
        var rowEditing;
        var rowIndexDeleting;

        init();

        function init() {
            param.candidateId = $stateParams.id;
            var outstandingProjectHistories = caCvSvc.getOutstandingProjectResource(param).query(
                function () {
                    $.each(outstandingProjectHistories, function (item, outProHis) {
                        self.candidateOutstandingProjectHistories.push(new caOutstandingProjectModel(outProHis, false, true));
                        initialCaOutstandingProjectHistories.push(new caOutstandingProjectModel(outProHis, false, true));
                    });
                    formatDate(self.candidateOutstandingProjectHistories);
                    formatDate(initialCaOutstandingProjectHistories);
                },
                function (xhr) {
                    var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                    caDetailSvc.setCurrentLoading(false);
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData, doesNotShow);
                });

            $scope.$watch('cvCtrl.isEditForm', function (value) {
                self.isEditMode = value;
                resetEdit();
            }, true);

            $scope.$watch("ctrl.candidateOutstandingProjectHistories", function (newVal, oldVal) {
                if (newVal == oldVal)
                    return;
                else if (_isAddingOutstandingProject)
                    self.isModifiedData = true;
                else {
                    var candidateOutstandingProjectHistoriesFormat = copyOutstandingProject(self.candidateOutstandingProjectHistories);
                    self.isModifiedData = JSON.stringify(candidateOutstandingProjectHistoriesFormat) != JSON.stringify(initialCaOutstandingProjectHistories);
                }
            }, true);
        }

        function resetEdit() {
            rowEditing = constants.newRowIndex;

            if (_isAddingOutstandingProject) {
                self.isEditMode = false;
            }
            if (self.isModifiedData) {
                self.candidateOutstandingProjectHistories = copyOutstandingProject(initialCaOutstandingProjectHistories);
            }
            if (angular.element("#outstanding-projects-detail").css('display') == "none") {
                self.toogleHeader();
            }

            if (!self.isEditMode) {
                resetRowIndex();
            }
        }

        function resetRowIndex() {
            _isAddingOutstandingProject = false;
            rowEditing = constants.newRowIndex;
            self.isModifiedData = false;
            self.isValidDate = true;
           _isRowEditing = false;
        }

        function formatDate(outstandingProjectHistoriesFormat) {
            $.each(outstandingProjectHistoriesFormat, function (item, outstandingProjectFormat) {
                outstandingProjectFormat.StartTime = (outstandingProjectFormat.StartTime) ? moment(outstandingProjectFormat.StartTime).format(constants.formatDateDDMMYYYY) : "";
                outstandingProjectFormat.EndTime = (outstandingProjectFormat.EndTime) ? moment(outstandingProjectFormat.EndTime).format(constants.formatDateDDMMYYYY) : "";
            });
        }

        function addCandidateOutstandingProject() {
            if (rowEditing == constants.newRowIndex) {
                _isAddingOutstandingProject = true;
                var candidateOutstandingProject = new caOutstandingProjectModel(null, false, false);
                self.candidateOutstandingProjectHistories.push(candidateOutstandingProject);
                rowEditing = self.candidateOutstandingProjectHistories.length - 1;
                self.candidateOutstandingProjectHistories[rowEditing].StartTime = moment(self.candidateOutstandingProjectHistories[rowEditing].StartTime).format(constants.formatDateDDMMYYYY);
                self.candidateOutstandingProjectHistories[rowEditing].EndTime = moment(self.candidateOutstandingProjectHistories[rowEditing].EndTime).format(constants.formatDateDDMMYYYY);
                $timeout(function () {
                    $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
                    $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
                }, 100);

            } else {
                toastr.warning(message.editingData, message.titleWarning);
            }
        }

        function toogleHeader() {
            _isShowToogleHeader = !_isShowToogleHeader;
            $("#outstanding-projects-detail").slideToggle("slow");
        }

        function saveCandidateOutstandingProject(outstandingProjectId) {
            param.outstandingProjectId = outstandingProjectId;
            var outstandingProjectForSaving = angular.copy(self.candidateOutstandingProjectHistories[rowEditing]);
            outstandingProjectForSaving.StartTime = datetimeSvc.convertDateForServerSide(outstandingProjectForSaving.StartTime, false);
            outstandingProjectForSaving.EndTime = datetimeSvc.convertDateForServerSide(outstandingProjectForSaving.EndTime, false);
            if (_isAddingOutstandingProject) {
                loadingSvc.show();
                caCvSvc.getOutstandingProjectResource(param).save(outstandingProjectForSaving,
                    function (response) {
                        loadingSvc.close();
                        saveOutstandingProjectSuccess(response);
                        toastr.success($filter(constants.translate)(caMessage.outstandingProject.addOutstandingSuccessfully));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.outstandingProject.addOutstandingFail);
                    });
            } else {
                loadingSvc.show();
                caCvSvc.getOutstandingProjectResource(param).update(outstandingProjectForSaving,
                    function (response) {
                        loadingSvc.close();
                        saveOutstandingProjectSuccess(response);
                        toastr.success($filter(constants.translate)(caMessage.outstandingProject.editOutstandingSuccessfully));
                    },
                    function (xhr) {
                        loadingSvc.close();
                        messageHandleSvc.handleResponse(xhr, caMessage.outstandingProject.editOutstandingFail);
                    });
            }
        }

        function saveOutstandingProjectSuccess(response) {
            self.candidateOutstandingProjectHistories[rowEditing].OutstandingProjectId = response.OutstandingProjectId;
            self.candidateOutstandingProjectHistories[0].SupervisorPhoneNumber = formatPhoneNumber(self.candidateOutstandingProjectHistories[0].SupervisorPhoneNumber);
            initialCaOutstandingProjectHistories = copyOutstandingProject(self.candidateOutstandingProjectHistories);
            resetRowIndex();
        }

        function checkIsEditingRow(rowIndex) {
            return rowIndex == rowEditing ? true : false;
        }

        function editOutstandingProject(rowIndex) {
            self.isValidDate = true;
            self.isEditMode = true;
           _isRowEditing = true;
            if (!_isAddingOutstandingProject) {
                rowEditing = rowIndex;
            }
            else {
                toastr.warning($filter(constants.translate)(message.addingData));
            }
            $('.from-date').datepicker({ autoclose: true, todayHighlight: true });
            $('.to-date').datepicker({ autoclose: true, todayHighlight: true });
        }

        function cancelEditOutstandingProject() {
            self.candidateOutstandingProjectHistories = copyOutstandingProject(initialCaOutstandingProjectHistories);
            resetRowIndex();
        }

        function copyOutstandingProject(fromOutstandingProject) {
            var candidateOutstandingProjectHistoriesFormat = [];
            $.each(fromOutstandingProject, function (item, outstandingProject) {
                candidateOutstandingProjectHistoriesFormat.push(new caOutstandingProjectModel(outstandingProject, false, true));
            });
            return candidateOutstandingProjectHistoriesFormat;
        }

        function removeOutstandingProject(outstandingProjectId, rowIndex, currentOutstandingProject) {
            if (_isAddingOutstandingProject) {
                toastr.warning($filter(constants.translate)(message.addingData));
                return;
            }
            rowIndexDeleting = rowIndex;
            param.outstandingProjectId = outstandingProjectId;
            param.isEmployee = currentOutstandingProject.IsEmployee;
            $("#" + self.dialogConfirm.dialogId).modal('show');
        }

        function acceptDeleteCaOutstandingProject() {
            loadingSvc.show();
            caCvSvc.getOutstandingProjectResource(param).delete(false,
                function (response) {
                    loadingSvc.close();
                    var result = handleRequestSvc.result(response);
                    if (!result) {
                        toastr.error($filter(constants.translate)(caMessage.outstandingProject.deleteOutstandingFail));
                        return;
                    }
                    self.candidateOutstandingProjectHistories.splice(rowIndexDeleting, 1);
                    initialCaOutstandingProjectHistories = copyOutstandingProject(self.candidateOutstandingProjectHistories);
                    toastr.success($filter(constants.translate)(caMessage.outstandingProject.deleteOutstandingSuccessfully));
                    resetRowIndex();
                },
                function (xhr) {
                    loadingSvc.close();
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                });
        }

        function onChangeDate() {
            var startTime = moment(self.candidateOutstandingProjectHistories[rowEditing].StartTime, constants.formatDateDDMMYYYY);
            var endTime = moment(self.candidateOutstandingProjectHistories[rowEditing].EndTime, constants.formatDateDDMMYYYY);
            var diff = endTime.diff(startTime, 'days');
            self.isValidDate = diff >= 0 ? true : false;
        }

        function onSalaryKeyDown(event) {
            validationSvc.onKeyDownTextBox(event);
        }

        function getCssHeaderClass() {
            return _isShowToogleHeader && 'col-xs-1 fa fa-2x sprite-fa-caret-down' || 'col-xs-1 fa fa-2x sprite-fa-caret-right';
        }

        function getDetailContentClass(index, isViewMode) {
            return isViewMode ? (checkIsEditingRow(index) ? 'hide' : 'show') : (checkIsEditingRow(index) ? 'show' : 'hide');
        }

        function getButtonAddMoreClass() {
            return self.isEditMode && !_isAddingOutstandingProject && !self.isRowEditing ? 'show' : 'hide';
        }

        function checkPhoneCharacter(event) {
            var eventCode = event.charCode === 0 ? event.keyCode : event.charCode;
            if (!((eventCode >= 45 && eventCode <= 57) || eventCode == 127 || eventCode == 8 || eventCode == 32 || eventCode == 40 || eventCode == 41 || eventCode == 43))
                event.preventDefault();
        }

        function toggleMoreDetail(outstandingProject) {
            outstandingProject.IsShowMoreDetail = !outstandingProject.IsShowMoreDetail;
        }

        function validationMaxLengthMessage(maxLength) {
            return String.format(message.valueLengthError, maxLength);
        }
    }
})();
