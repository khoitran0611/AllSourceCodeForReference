﻿(function () {
    'use strict';

    angular.module('app').factory('caOutstandingProjectModel', caOutstandingProjectModel);

    function caOutstandingProjectModel() {
        var model = function(outstadingProjectHistory, isEmployee, allowNull) {
            /* jshint -W040 */
            var self = this;
            self.OutstandingProjectId = outstadingProjectHistory ? outstadingProjectHistory.OutstandingProjectId : undefined;
            self.CandidateId = outstadingProjectHistory ? outstadingProjectHistory.CandidateId : undefined;
            self.EmployeeId = outstadingProjectHistory ? outstadingProjectHistory.EmployeeId : undefined;
            self.Position = outstadingProjectHistory ? outstadingProjectHistory.Position : '';
            self.ProjectName = outstadingProjectHistory ? outstadingProjectHistory.ProjectName : '';
            self.StartTime = outstadingProjectHistory && outstadingProjectHistory.StartTime ? outstadingProjectHistory.StartTime : allowNull ? "" : new Date();
            self.EndTime = outstadingProjectHistory && outstadingProjectHistory.EndTime ? outstadingProjectHistory.EndTime : allowNull ? "" : new Date();
            self.GeneralInformation = outstadingProjectHistory && outstadingProjectHistory.GeneralInformation ? outstadingProjectHistory.GeneralInformation : "";
            self.Description = outstadingProjectHistory && outstadingProjectHistory.Description ? outstadingProjectHistory.Description : '';
            self.InterfaceSystem = outstadingProjectHistory && outstadingProjectHistory.InterfaceSystem ? outstadingProjectHistory.InterfaceSystem : "";
            self.TechnologyUsed = outstadingProjectHistory && outstadingProjectHistory.TechnologyUsed ? outstadingProjectHistory.TechnologyUsed : undefined;
            self.IsEmployee = isEmployee;
            self.Attachments = outstadingProjectHistory && outstadingProjectHistory.Attachments ? outstadingProjectHistory.Attachments : [];
        };
        return model;
    }
})();