﻿(function () {
    'use strict';
    angular.module('app').factory('caOutstandingProjectsSvc', caOutstandingProjectsSvc);
    caOutstandingProjectsSvc.$inject = ['$resource', '$filter',
        'messageHandleSvc', 'caDetailSvc',
        'message', 'caMessage', 'constants'];
    function caOutstandingProjectsSvc($resource, $filter,
            messageHandleSvc, caDetailSvc,
        message, caMessage, constants) {
            var data = {
                outstandingProjects: null
            };

            var url = '/api/candidates/:candidateId/outstanding-projects/:id';

            var resourceSvc = $resource(url, {}, {
                'getOutstandingProjects': { method: 'GET', isArray: true, candidateId: '@candidateId' },
                'addOutstandingProject': { method: 'POST', candidateId: '@candidateId' },
                'editOutstandingProject': { method: 'PUT', candidateId: '@candidateId', id: '@id' },
                'deleteOutstandingProject': { method: 'DELETE', params: { candidateId: '@candidateId', id: '@id' } }
            });

            function getOutstandingProjects(candidateId, callBack) {
                resourceSvc.getOutstandingProjects({ candidateId: candidateId }).$promise.then(
                    function (result) {
                        if (typeof (callBack) == 'function') {
                            callBack(result);
                        }
                        data.outstandingProjects = result;
                        window.angular.forEach(data.outstandingProjects, function (outstandingProject) {
                            outstandingProject.IsShowMoreDetail = false;
                        });
                    }, function (xhr) {
                        var doesNotShow = !angular.copy(caDetailSvc.getCurrentLoading());
                        caDetailSvc.setCurrentLoading(false);
                        messageHandleSvc.handleResponse(xhr, caMessage.outstandingProject.getOutstandingFail, doesNotShow);
                    });
                return data;
            }

            function addOutstandingProject(outstandingProject, candidateId, callBack) {
                resourceSvc.addOutstandingProject({ candidateId: candidateId }, outstandingProject).$promise.then(
                    function (result) {
                        if (typeof (callBack) == 'function') {
                            callBack(result);
                        }
                        messageHandleSvc.handleResponse(result, caMessage.outstandingProject.addOutstandingSuccessfully);
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, caMessage.outstandingProject.addOutstandingFail);
                    });
            }

            function editOutstandingProject(outstandingProject, candidateId, outstandingProjectId, callBack) {
                resourceSvc.editOutstandingProject({ candidateId: candidateId, id: outstandingProjectId }, outstandingProject).$promise.then(
                    function (result) {
                        if (typeof (callBack) == 'function') {
                            callBack(result);
                        }
                        messageHandleSvc.handleResponse(result, caMessage.outstandingProject.editOutstandingSuccessfully);
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, caMessage.outstandingProject.editOutstandingFail);
                    });
            }

            function deleteOutstandingProject(outstandingProject, candidateId, outstandingProjectId, callBack) {
                resourceSvc.deleteOutstandingProject({ candidateId: candidateId, id: outstandingProjectId }, outstandingProject).$promise.then(
                    function (result) {
                        if (typeof (callBack) == 'function') {
                            callBack(result);
                        }
                        messageHandleSvc.handleResponse(result, caMessage.outstandingProject.deleteOutstandingSuccessfully);
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, caMessage.outstandingProject.deleteOutstandingFail);
                    });
            }

            return {
                data: data,
                getOutstandingProjects: getOutstandingProjects,
                addOutstandingProject: addOutstandingProject,
                editOutstandingProject: editOutstandingProject,
                deleteOutstandingProject: deleteOutstandingProject
            };
    }
})();