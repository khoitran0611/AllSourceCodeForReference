﻿(function () {
    'use strict';
    angular.module('app').factory('caGridSvc', caGridSvc);
    caGridSvc.$inject = ['candidateSvc', 'gridSvc', 'messageHandleSvc', 'styleSvc', 'switchCandidateSvc',
        'gridHeader', 'caGridModel', 'message', 'constants', 'caConstants',
        '$filter', '$window', 'comparisonUtilSvc', 'loadingSvc'];
    function caGridSvc(candidateSvc, gridSvc, messageHandleSvc, styleSvc, switchCandidateSvc,
        gridHeader, caGridModel, message, constants, caConstants,
        $filter, $window, comparisonUtilSvc, loadingSvc) {


        var revealed = {
            getPagedDataAsync: getPagedDataAsync,
            gridInit: gridInit
        };
        return revealed;

        function getPagedDataAsync(self, $scope) {
            var result = self;
            self.isSearching = self.query ? true : false;
            if (!self.isSearching)
                $.jStorage.deleteKey(constants.localStorageKey.candidateSearch);
            result.isLoadingInfor = true;
            candidateSvc.getCandidates(self.pageIndex, self.query, self.isSearching, self.candidateGetByAction).get(function (candidateList) {
                if (self.pageIndex != candidateList.CurrentPage) {
                    self.pageIndex = candidateList.CurrentPage;
                }
                if (self.pagingOptions.currentPage != candidateList.CurrentPage)
                    self.pagingOptions.currentPage = candidateList.CurrentPage;
                $window.localStorage.setItem("currentCandidateListPage", self.pageIndex);
                $.jStorage.set(caConstants.jobCode, null);
                var gridHeaderScope = angular.element($("#candidate-list .ngSelectionHeader")).scope();
                if (gridHeaderScope)
                    gridHeaderScope.allSelected = false;
                delete window.localStorage[caConstants.jobCode];
                result.listId = [];
                result.data = [];
                if (!comparisonUtilSvc.isNullOrUndefinedValue(candidateList.Data) && candidateList.Data.length > 0) {
                    for (var i = 0; i < candidateList.Data.length; i++) {
                        var candidate = new caGridModel(candidateList.Data[i]);
                        result.data.push(candidate);
                        result.listId.push(candidate.CandidateId);
                    }
                }
                var dataFilter = {
                    isSearching: result.isSearching,
                    listId: result.listId,
                    pageIndex: result.pageIndex,
                    query: result.query,
                    totalPages: candidateList.TotalPages
                };
                var key = $.jStorage.get('currentList');
                key = (!comparisonUtilSvc.isNullOrUndefinedValue(key) && typeof (key) == "string") ? key : 'currentList';
                switchCandidateSvc.setFilterData(key, dataFilter);
                result.totalPages = candidateList.TotalPages;
                result = gridSvc.setPagingData(result, $scope);
                result.isLoadingInfor = false;
                loadingSvc.close();
                return result;
            },
                function (xhr) {
                    result.isLoadingInfor = false;
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData);
                    loadingSvc.close();
                }
            );
            return result;
        }

        function gridInit(self, $scope) {
            var result = self;
            self.removeCaLocalStorage = function () {
                if (self.canViewJobsSnapshot) {
                    $.jStorage.deleteKey('caGrid');
                }
            };
            result.columnDefs = [
                   new gridHeader("IsExpanded", '', "", true),
                   new gridHeader("FullName", 'Full_Name', "", true),
                   new gridHeader("DateOfBirth", 'Date_Of_Birth', constants.formatDateTimeFilter, false),
                   new gridHeader("Phone", 'Phone', "", false),
                   new gridHeader("OtherPhone", 'Other_Phone', "", false),
                   new gridHeader("CompleteScore", 'Complete_Percent_Header', "", false),
                   new gridHeader("PositionName", 'Position', "", true),
                   new gridHeader("JobCode", 'Job_Code', "", false),
                   new gridHeader("ApplyDate", 'Apply', constants.formatDateTimeFilter, true),
                   new gridHeader("ModifiedDate", 'CV_Update_Date', "", false),
                   new gridHeader("YearOfExperience", 'Exp_Year', "", false),
                   new gridHeader("Domain", 'Domain', "", false),
                   new gridHeader("Profession", 'Profession', "", false),
                   new gridHeader("TotalApplication", 'Applications', "", false),
                   new gridHeader("CvScreenFlag", 'Screen_CV', "",  !self.lockColumnsCustomization),
                   new gridHeader("Interviews", 'Interviews', "", !self.lockColumnsCustomization),
                   new gridHeader("LastJob", 'Status_Header', "", true),
                   new gridHeader("StartDateSuggestion", 'Start_Date_Suggestion', constants.formatDateTimeFilter, false),
                   new gridHeader("OfferSendDate", 'Offer_Sent_Date', constants.formatDateTimeFilter, false),
                   new gridHeader("AcceptDate", 'Accept_Date', constants.formatDateTimeFilter, false),
                   new gridHeader("Note", 'Note', "", !self.lockColumnsCustomization),
                   new gridHeader("TagInfo", 'Tags', "", false),
                   new gridHeader("ResponsibleEmployeeFullName", 'Responsive_Person', "", false)
            ];

            result.customCss.setStatusInterview = styleSvc.setStatus;
            result.customCss.setTitleInterview = styleSvc.setTitle;
            result.customCss.convertCurrentStatus = styleSvc.convertJobApplicationStatus;
            result.customCss.setDeletedCandidateName = setDeletedCandidateName;
            result = gridSvc.init(result, $scope);
            return result;
        }

        function setDeletedCandidateName(isDeleted) {
            if (!isDeleted || isDeleted.toLowerCase() === "false") return "";
            return $filter(constants.translate)('Deleted');
        }

    }

})();
