﻿(function () {
    "use strict";
    angular.module('app').factory('caGridModel', caGridModel);
    caGridModel.$inject = ['constants', '$filter', 'datetimeSvc', 'comparisonUtilSvc'];

    function caGridModel(constants, $filter, datetimeSvc, comparisonUtilSvc) {
        function interviewRoundDisplay(interview) {
            /* jshint -W040 */
            var self = this;
            self.result = interview.result;
            if (interview.result == constants.stringEmpty && interview.bookRoomDate != constants.stringEmpty) {
                if (interview.overallStatus == constants.applicationStatus.Other.RejectAll)
                    self.result = constants.applicationStatus.Other.RejectAll;
                else self.result = constants.interviewResult.scheduledDate;
                interview.title = interview.title + interview.bookRoomDate;
            }
            self.id = interview.interviewId;
            self.ScheduleId = interview.scheduleId;
            self.currentStatus = interview.currentStatus;
            self.isFinish = interview.isFinished;
            self.isCanceled = interview.isCanceled;
            self.bookRoomDate = interview.bookRoomDate;
            self.title = interview.isCanceled ? $filter(constants.translate)("Canceled") + ": " + interview.title : interview.title;
            self.visible = interview.result || interview.bookRoomDate != constants.stringEmpty ? true : false;
            return self;
        }

        function createDisplayInterviewsByJob(job) {
            var list = [];
            var historyCandidate = job;
            var firstInterviewResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.FirstInterviewResult : "";
            var firstInterviewId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.FirstInterviewId : 0;
            var firstScheduleId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.FirstScheduleId : 0;
            var isFirstInterviewFinished = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsFirstInterviewFinish) ? true : false) : false;
            var firstInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.FirstInterviewBookRoomDate) ? moment(historyCandidate.FirstInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var isCanceledFirstInterview = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsCanceledFirstInterview) ? true : false) : false;

            var secondInterviewResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.SecondInterviewResult : "";
            var secondInterviewId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.SecondInterviewId : 0;
            var secondScheduleId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.SecondScheduleId : 0;
            var isSecondInterviewFinished = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsSecondInterviewFinish) ? true : false) : false;
            var secondInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.SecondInterviewBookRoomDate) ? moment(historyCandidate.SecondInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var isCanceledSecondInterview = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsCanceledSecondInterview) ? true : false) : false;

            var thirdInterviewResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.ThirdInterviewResult : "";
            var thirdInterviewId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.ThirdInterviewId : 0;
            var thirdScheduleId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.ThirdScheduleId : 0;
            var isThirdInterviewFinished = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsThirdInterviewFinish) ? true : false) : false;
            var thirdInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.ThirdInterviewBookRoomDate) ? moment(historyCandidate.ThirdInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var isCanceledThirdInterview = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsCanceledThirdInterview) ? true : false) : false;
            var currentStatus = historyCandidate ? historyCandidate.OverallStatus : "";

            var firstInterview = {
                interviewId: firstInterviewId, scheduleId: firstScheduleId, isFinished: isFirstInterviewFinished,
                isCanceled: isCanceledFirstInterview, result: firstInterviewResult, bookRoomDate: firstInterviewBookRoomDate,
                title: $filter(constants.translate)("1st_Interview") + $filter(constants.translate)(firstInterviewResult),
                currentStatus: currentStatus
            };
            var secondInterview = {
                interviewId: secondInterviewId, scheduleId: secondScheduleId, isFinished: isSecondInterviewFinished,
                isCanceled: isCanceledSecondInterview, result: secondInterviewResult, bookRoomDate: secondInterviewBookRoomDate,
                title: $filter(constants.translate)("2nd_Interview") + $filter(constants.translate)(secondInterviewResult),
                currentStatus: currentStatus
            };
            var thirdInterview = {
                interviewId: thirdInterviewId, scheduleId: thirdScheduleId, isFinished: isThirdInterviewFinished,
                isCanceled: isCanceledThirdInterview, result: thirdInterviewResult, bookRoomDate: thirdInterviewBookRoomDate,
                title: $filter(constants.translate)("3rd_Interview") + $filter(constants.translate)(thirdInterviewResult),
                currentStatus: currentStatus
            };

            var firstInterviewDisplay = new interviewRoundDisplay(firstInterview);
            var secondInterviewDisplay = new interviewRoundDisplay(secondInterview);
            var thirdInterviewDisplay = new interviewRoundDisplay(thirdInterview);
            if (firstInterviewBookRoomDate)
                list.push(firstInterviewDisplay);
            if (secondInterviewBookRoomDate)
                list.push(secondInterviewDisplay);
            if (thirdInterviewBookRoomDate)
                list.push(thirdInterviewDisplay);
            return list;
        }

        function createDisplayInterviews(candidate) {
            var list = [];
            var historyCandidate = candidate ? candidate.HistoryJobApplications[0] : null;
            var firstInterviewResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.FirstInterviewResult : "";
            var firstInterviewId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.FirstInterviewId : 0;
            var firstScheduleId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.FirstScheduleId : 0;
            var isFirstInterviewFinished = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsFirstInterviewFinish) ? true : false) : false;
            var firstInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.FirstInterviewBookRoomDate) ? moment(historyCandidate.FirstInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var isCanceledFirstInterview = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsCanceledFirstInterview) ? true : false) : false;

            var secondInterviewResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.SecondInterviewResult : "";
            var secondInterviewId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.SecondInterviewId : 0;
            var secondScheduleId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.SecondScheduleId : 0;
            var isSecondInterviewFinished = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsSecondInterviewFinish) ? true : false) : false;
            var secondInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.SecondInterviewBookRoomDate) ? moment(historyCandidate.SecondInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var isCanceledSecondInterview = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsCanceledSecondInterview) ? true : false) : false;

            var thirdInterviewResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.ThirdInterviewResult : "";
            var thirdInterviewId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.ThirdInterviewId : 0;
            var thirdScheduleId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.ThirdScheduleId : 0;
            var isThirdInterviewFinished = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsThirdInterviewFinish) ? true : false) : false;
            var thirdInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.ThirdInterviewBookRoomDate) ? moment(historyCandidate.ThirdInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var isCanceledThirdInterview = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsCanceledThirdInterview) ? true : false) : false;
            var currentStatus = historyCandidate ? historyCandidate.OverallStatus : "";

            var firstInterview = {
                interviewId: firstInterviewId, scheduleId: firstScheduleId, isFinished: isFirstInterviewFinished,
                isCanceled: isCanceledFirstInterview, result: firstInterviewResult, bookRoomDate: firstInterviewBookRoomDate,
                title: $filter(constants.translate)("1st_Interview") + $filter(constants.translate)(firstInterviewResult),
                currentStatus: currentStatus
            };
            var secondInterview = {
                interviewId: secondInterviewId, scheduleId: secondScheduleId, isFinished: isSecondInterviewFinished,
                isCanceled: isCanceledSecondInterview, result: secondInterviewResult, bookRoomDate: secondInterviewBookRoomDate,
                title: $filter(constants.translate)("2nd_Interview") + $filter(constants.translate)(secondInterviewResult),
                currentStatus: currentStatus
            };
            var thirdInterview = {
                interviewId: thirdInterviewId, scheduleId: thirdScheduleId, isFinished: isThirdInterviewFinished,
                isCanceled: isCanceledThirdInterview, result: thirdInterviewResult, bookRoomDate: thirdInterviewBookRoomDate,
                title: $filter(constants.translate)("3rd_Interview") + $filter(constants.translate)(thirdInterviewResult),
                currentStatus: currentStatus
            };

            var firstInterviewDisplay = new interviewRoundDisplay(firstInterview);
            var secondInterviewDisplay = new interviewRoundDisplay(secondInterview);
            var thirdInterviewDisplay = new interviewRoundDisplay(thirdInterview);
            if (firstInterviewBookRoomDate)
                list.push(firstInterviewDisplay);
            if (secondInterviewBookRoomDate)
                list.push(secondInterviewDisplay);
            if (thirdInterviewBookRoomDate)
                list.push(thirdInterviewDisplay);
            return list;
        }

        function createCurrentJobByJobApplication(historyCandidate) {
            var overallStatus = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.OverallStatus : "";
            var firstInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.FirstInterviewBookRoomDate) ? moment(historyCandidate.FirstInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var secondInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.SecondInterviewBookRoomDate) ? moment(historyCandidate.SecondInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var thirdInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.ThirdInterviewBookRoomDate) ? moment(historyCandidate.ThirdInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            return {
                OverallStatus: overallStatus, FirstInterviewBookRoomDate: firstInterviewBookRoomDate,
                SecondInterviewBookRoomDate: secondInterviewBookRoomDate, ThirdInterviewBookRoomDate: thirdInterviewBookRoomDate
            };
        }

        function getApplicationList(candidate) {
            var applicationList = [];
            if (!candidate || candidate.HistoryJobApplications.length <= 0) return applicationList;
            var count = candidate.HistoryJobApplications.length;
            for (var index = 1; index < count; index++) {
                var historyCandidate = candidate.HistoryJobApplications[index];
                var temp = {
                    ApplyDate: datetimeSvc.convertDate(historyCandidate.ApplyDate),
                    PositionName: getJobTitle(historyCandidate),
                    JobCode: historyCandidate.JobCode,
                    LastJob: createCurrentJobByJobApplication(historyCandidate),
                    JobCodeId: historyCandidate.JobCodeId,
                    CvScreenFlag: historyCandidate.CvScreenFlag,
                    CvScreenResult: historyCandidate.CvScreenResult,
                    Interviews: createDisplayInterviewsByJob(historyCandidate),
                    YearOfExperience: historyCandidate.YearOfExperience,
                    StartDateSuggestion: datetimeSvc.convertDate(historyCandidate.StartDateSuggestion),
                    OfferSendDate: datetimeSvc.convertDate(historyCandidate.OfferSendDate),
                    AcceptDate: datetimeSvc.convertDate(historyCandidate.AcceptDate),
                    ConfirmLetterDate: datetimeSvc.convertDate(historyCandidate.ConfirmLetterDate),
                    SignLetterDate: datetimeSvc.convertDate(historyCandidate.SignLetterDate),
                    Skills: historyCandidate.Skills,
                    JobApplicationId: historyCandidate.JobApplicationId,
                    IsHide: historyCandidate.IsHide
                };
                applicationList.push(temp);
            }
            return applicationList;
        }

        function getJobTitle(job) {
            if (job.JobTitle !== '' && !comparisonUtilSvc.isNullOrUndefinedValue(job.JobTitle)) return job.JobTitle;
            if (job.PositionName !== '' && !comparisonUtilSvc.isNullOrUndefinedValue(job.PositionName)) return job.PositionName;
            if (job.CategoryName !== '' && !comparisonUtilSvc.isNullOrUndefinedValue(job.CategoryName)) return job.CategoryName;
            return "";
        }

        function createCurrentJob(candidate) {
            var historyCandidate = candidate ? candidate.HistoryJobApplications[0] : null;
            var overallStatus = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.OverallStatus : "";
            var firstInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.FirstInterviewBookRoomDate) ? moment(historyCandidate.FirstInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var secondInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.SecondInterviewBookRoomDate) ? moment(historyCandidate.SecondInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            var thirdInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.ThirdInterviewBookRoomDate) ? moment(historyCandidate.ThirdInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
            return {
                OverallStatus: overallStatus, FirstInterviewBookRoomDate: firstInterviewBookRoomDate,
                SecondInterviewBookRoomDate: secondInterviewBookRoomDate, ThirdInterviewBookRoomDate: thirdInterviewBookRoomDate
            };
        }

        function convertTagsToString(tags) {
            var result = "";
            for (var index = 0; index < tags.length; index++) {
                result += (result) ? "; " + tags[index].TagName : tags[index].TagName;
            }
            return result;
        }

        var model = function (candidate) {
            /* jshint -W040 */
            var self = this;
            var historyCandidate = candidate ? candidate.HistoryJobApplications[0] : null;
            self.IsExpanded = (!candidate.HistoryJobApplications || candidate.HistoryJobApplications.length <= 1) ? false : true;
            self.Applications = getApplicationList(candidate);
            self.FullName = candidate ? isValidEmailAddress(candidate.FirstName) && isValidEmailAddress(candidate.LastName) && candidate.FirstName === candidate.LastName ? candidate.FirstName : candidate.FullName : "";
            self.MiddleName = constants.stringEmpty;
            self.Gender = candidate ? candidate.Gender : "";
            self.DateOfBirth = candidate ? datetimeSvc.convertDate(candidate.DateOfBirth) : "";
            self.Phone = candidate ? candidate.Phone : "";
            self.OtherPhone = candidate ? candidate.OtherPhone : "";
            self.ApplyDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? datetimeSvc.convertDate(historyCandidate.ApplyDate) : "";
            self.ModifiedDate = candidate ? datetimeSvc.convertDate(candidate.ModifiedDate) : "";
            self.CompleteScore = candidate ? candidate.CompleteScore : 0;
            self.PositionName = comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? "" : getJobTitle(historyCandidate);
            self.TotalApplication = candidate ? candidate.TotalApplications : "0";
            self.JobCode = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.JobCode : "";
            self.JobCodeId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.JobCodeId : "";
            self.LastJob = createCurrentJob(candidate);
            self.CvScreenFlag = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.CvScreenFlag : "";
            self.CvScreenResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.CvScreenResult : "";
            self.Interviews = createDisplayInterviews(candidate);
            self.YearOfExperience = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.YearOfExperience : "";
            self.Domain = candidate ? candidate.Domain : "";
            self.Profession = candidate ? candidate.Profession : "";
            self.StartDateSuggestion = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? datetimeSvc.convertDate(historyCandidate.StartDateSuggestion) : "";
            self.OfferSendDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? datetimeSvc.convertDate(historyCandidate.OfferSendDate) : "";
            self.AcceptDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? datetimeSvc.convertDate(historyCandidate.AcceptDate) : "";
            self.Note = candidate.JobApplicationNote;
            self.TagInfo = candidate.Tags ? convertTagsToString(candidate.Tags) : "";
            self.ResponsibleEmployeeFullName = candidate ? candidate.ResponsibleEmployeeFullName : "";
            self.ConfirmLetterDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? datetimeSvc.convertDate(historyCandidate.ConfirmLetterDate) : "";
            self.SignLetterDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? datetimeSvc.convertDate(historyCandidate.SignLetterDate) : "";
            self.Skills = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.Skills : "";
            self.IsCheck = false;
            self.CandidateId = candidate ? candidate.CandidateId : "";
            self.JobApplicationId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.JobApplicationId : "";
            self.IsHide = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.IsHide : true;
            self.IsDeleted = candidate ? candidate.IsDeleted : null;
            self.candidateInfo = candidate;
        };
        return model;
    }
})();