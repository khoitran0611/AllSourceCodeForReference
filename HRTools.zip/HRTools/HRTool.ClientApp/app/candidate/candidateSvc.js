﻿(function () {
    'use strict';
    angular.module('app').factory('candidateSvc', candidateSvc);
    candidateSvc.$inject = [
        "messageHandleSvc", "caDetailSvc", "constants", "caConstants", "caMessage", "message",
        "$resource", "$stateParams", "$filter", "$rootScope", "comparisonUtilSvc"];
    function candidateSvc(
        messageHandleSvc, caDetailSvc, constants, caConstants, caMessage, message,
        $resource, $stateParams, $filter, $rootScope, comparisonUtilSvc) {
        var candidateDataMainPage = {
            FullName: "",
            JobApplicationId: "",
            IsAccepted: false,
            CandidateId: "",
            PositionName: "empty"
        };

        function getCandidateDataMainPage() {
            return candidateDataMainPage;
        }

        var candidateInforData = {
            candidateBasicInfo: null,
            cvSources: null,
            jobCodes: null,
            positions: null,
            openPositions: null,
            JobApplicationName: "",
            AppliedDate: ""
        };

        var uploadImage = { isUpdate: false };

        var setUpdateImage = function () {
            uploadImage.isUpdate = true;
        };

        var disableUpdateImage = function () {
            uploadImage.isUpdate = false;
        };

        var getUpdateImage = function () {
            return uploadImage;
        };

        /*--------------------------------Candidate Tag--------------------------------------*/
        function tags() {
            return $resource(constants.apiUrl + 'tags/:id', {});
        }

        /*--------------------------------Candidate List-------------------------------------*/
        var getCandidates = function (pageIndex, inputQuery, isSearching, action) {
            if (isSearching)
                return $resource(constants.apiUrl + 'candidates?page=:page', { page: pageIndex, action: "getbysearchbox", querySearch: inputQuery });
            else if (action === "")
                return $resource(constants.apiUrl + 'candidates?page=:page', { page: pageIndex });
            else
                return $resource(constants.apiUrl + 'candidates?page=:page', { page: pageIndex, action: "getallbysortcolumnmodifieddate" });

        };
        var sendMultiMailUpdateToCv = function (param) {
            return $resource(constants.apiUrl + 'emails/', {},
            { "sendMultiMailUpdateCV": { method: "POST", headers: { ActionName: "sendMultiMailUpdateCV", DataJsonFormat: JSON.stringify(param) } } });
        };

        var restoreDeleteCandidates = function (param) {
            return $resource(constants.apiUrl + 'candidates/:id', { id: "0" }, { "RestoreDeleteCandidate": { method: "PATCH", headers: { ActionName: "RestoreDeleteCandidate", DataJsonFormat: JSON.stringify(param) } } });
        };

        var deleteCandidates = function (param) {
            return $resource(constants.apiUrl + 'candidates/:id', { id: "0" }, { "DeleteCandidates": { method: "DELETE", headers: { DataJsonFormat: JSON.stringify(param) } } });
        };

        var makeUserResponseCandidates = function (param, currentUser) {
            return $resource(constants.apiUrl + 'candidates/:id', { id: "0", currentUser: JSON.stringify(currentUser) }, { "MakeUserResponseCandidate": { method: "PATCH", headers: { ActionName: "MakeUserResponseCandidate", DataJsonFormat: JSON.stringify(param) } } });
        };

        /*-------------------------------Candidate Detail--------------------------------------*/

        var getCurrentOpenPositions = function () {
            return $resource(constants.apiUrl + 'openpositions', { filter: '', action: 'getCurrentOpenPositions' });
        };

        var getSendMailOpenPositions = function () {
            return $resource(constants.apiUrl + 'openpositions', { filter: '', action: 'getSendMailOpenPositions' });
        };

        var addNewCandidateResource = function () {
            return $resource(constants.apiUrl + 'candidates');
        };

        var getCandidateInforData = function (id, callback) {
            $resource(constants.apiUrl + 'candidates/:id', { id: id, action: "getGeneralInfo" }).get(function (data) {
                candidateInforData.candidateBasicInfo = data.CandidateBasicInfo;
                if (candidateDataMainPage.CandidateId != id) {
                    candidateDataMainPage.JobApplicationId = "";
                    candidateDataMainPage.CandidateId = id;
                }
                var currentJobApplicationId = "";
                if ($rootScope.isComeBackInterviewTab && $rootScope.currentJobApplicationIdOfCandidate) currentJobApplicationId = $rootScope.currentJobApplicationIdOfCandidate;
                else {
                    currentJobApplicationId = candidateDataMainPage.JobApplicationId ? candidateDataMainPage.JobApplicationId : data.CandidateBasicInfo.JobApplicationId;
                }
                candidateDataMainPage.IsAccepted = data.CandidateBasicInfo.IsAccepted;
                candidateDataMainPage.FullName = String.format("{0} : {1}", $filter(constants.translate)("Candidate"), candidateInforData.candidateBasicInfo.FullName);
                candidateInforData.candidateBasicInfo.JobApplicationId = currentJobApplicationId;
                setJobApplication(candidateInforData.candidateBasicInfo, data.CandidateBasicInfo);
                if (candidateInforData.candidateBasicInfo) {
                    setCurrentInterviewStatus(candidateInforData.candidateBasicInfo);
                    formatCandidateBasicInfo();
                }
                candidateDataMainPage.FullName = !candidateInforData.candidateBasicInfo.FullName ? $filter(constants.translate)("Candidate_Is_Not_Updated") : String.format("{0} : {1}", $filter(constants.translate)("Candidate"), candidateInforData.candidateBasicInfo.FullName);
                candidateDataMainPage.FullName = candidateInforData.candidateBasicInfo.IsDelete ? $filter(constants.translate)('Deleted_Candidate') + candidateDataMainPage.FullName : candidateDataMainPage.FullName;
                candidateDataMainPage.JobApplicationId = currentJobApplicationId;
                candidateDataMainPage.PositionName = candidateInforData.candidateBasicInfo.PositionName;

                candidateInforData.cvSources = data.CvSources;
                var defaultCvSource = {
                    Code: undefined,
                    Id: data.CvSources.length + 1,
                    Text: "",
                    Name: ""
                };
                candidateInforData.cvSources.splice(0, 0, defaultCvSource);
                caDetailSvc.setCvSources(candidateInforData.cvSources);
                candidateInforData.jobCodes = data.JobCodes;
                candidateInforData.positions = data.Positions;
                candidateInforData.openPositions = data.OpenPositions;
                if ($.isFunction(callback)) callback();

            },
                function (xhr) {
                    if (window.location.hash.indexOf("#/candidates/") > -1) {
                        return;
                    }
                    messageHandleSvc.handleResponse(xhr, message.errorLoadingData);

                });
            return candidateInforData;
        };

        function getCandidateInfoOfCurrentJob(candidateId, jobApplicationId) {
            getAppliedPosition(jobApplicationId, candidateId).get(function (currentJobInfor) {
                candidateInforData.candidateBasicInfo = currentJobInfor.CandidateBasicInfo;
                candidateInforData.JobApplicationName = currentJobInfor.CandidateBasicInfo.PositionName;
                candidateInforData.AppliedDate = currentJobInfor.CandidateBasicInfo.AppliedDate;
                candidateInforData.candidateBasicInfo.JobApplicationId = jobApplicationId;
                setJobApplication(candidateInforData.candidateBasicInfo, currentJobInfor.CandidateBasicInfo);
                if (candidateInforData.candidateBasicInfo) {
                    setCurrentInterviewStatus(candidateInforData.candidateBasicInfo);
                    formatCandidateBasicInfo();
                }
                candidateDataMainPage.FullName = String.format("{0} : {1}", $filter("translate")("Candidate"), candidateInforData.candidateBasicInfo.FullName);
                candidateDataMainPage.FullName = candidateInforData.candidateBasicInfo.IsDelete ? $filter(constants.translate)('Deleted_Candidate') + candidateDataMainPage.FullName : candidateDataMainPage.FullName;
                candidateDataMainPage.JobApplicationId = jobApplicationId;
                candidateDataMainPage.PositionName = currentJobInfor.CandidateBasicInfo.PositionName;

            });
        }

        var clearCandidateInforData = function () {
            candidateInforData.candidateBasicInfo = {};
            candidateDataMainPage.FullName = "";
            candidateDataMainPage.PositionName = "";
        };

        function setJobApplication(candidateBasicInfo, candidateBasicInfoOfCurrentJob) {
            candidateBasicInfo.ExperienceYear = candidateBasicInfoOfCurrentJob.ExperienceYear;
            candidateBasicInfo.StatusResult = candidateBasicInfoOfCurrentJob.StatusResult;
            candidateBasicInfo.FirstInterview = candidateBasicInfoOfCurrentJob.FirstInterview;
            candidateBasicInfo.FirstInterviewId = candidateBasicInfoOfCurrentJob.FirstInterviewId;
            candidateBasicInfo.SecondInterview = candidateBasicInfoOfCurrentJob.SecondInterview;
            candidateBasicInfo.SecondInterviewId = candidateBasicInfoOfCurrentJob.SecondInterviewId;
            candidateBasicInfo.ThirdInterview = (candidateBasicInfoOfCurrentJob.ThirdInterview) ? candidateBasicInfoOfCurrentJob.ThirdInterview : "";
            candidateBasicInfo.ThirdInterviewId = (candidateBasicInfoOfCurrentJob.ThirdInterviewId) ? candidateBasicInfoOfCurrentJob.ThirdInterviewId : null;
            setCurrentInterviewStatus(candidateBasicInfo);
            candidateBasicInfo.CvFiles = candidateBasicInfoOfCurrentJob.CvFiles;
            candidateBasicInfo.CvSources = candidateBasicInfoOfCurrentJob.CvSrcName;
            candidateBasicInfo.JobApplicationNote = candidateBasicInfoOfCurrentJob.JobApplicationNote;
        }

        function getAppliedPosition(jobApplicationId, candidateId) {
            return $resource(constants.apiUrl + 'appliedpositions/:jobApplicationId/candidates/:candidateId', { jobApplicationId: jobApplicationId, candidateId: candidateId });
        }

        function formatCandidateBasicInfo() {
            if (!comparisonUtilSvc.isNullOrUndefinedValue(candidateInforData.candidateBasicInfo.Birthday)) {
                var inputDate = new Date(moment(candidateInforData.candidateBasicInfo.Birthday));
                candidateInforData.candidateBasicInfo.Birthday = moment(inputDate).format(constants.formatDateDDMMYYYY);
            }
        }

        function setCurrentInterviewStatus(candidateBasicInfo) {
            if (!comparisonUtilSvc.isNullOrUndefinedValue(candidateBasicInfo.ThirdInterview) && candidateBasicInfo.ThirdInterview !== "") {
                candidateInforData.candidateBasicInfo.CurrentInterviewStatusDisplay = "Third Interview";
                candidateInforData.candidateBasicInfo.CurrentInterviewStatusId = candidateBasicInfo.ThirdInterviewId;
                candidateInforData.candidateBasicInfo.CurrentInterviewStatus = candidateBasicInfo.ThirdInterview;
                return;
            }
            if (!comparisonUtilSvc.isNullOrUndefinedValue(candidateBasicInfo.SecondInterview) && candidateBasicInfo.SecondInterview !== "") {
                candidateInforData.candidateBasicInfo.CurrentInterviewStatusDisplay = "Second Interview";
                candidateInforData.candidateBasicInfo.CurrentInterviewStatusId = candidateBasicInfo.SecondInterviewId;
                candidateInforData.candidateBasicInfo.CurrentInterviewStatus = candidateBasicInfo.SecondInterview;
                return;
            }
            if (!comparisonUtilSvc.isNullOrUndefinedValue(candidateBasicInfo.FirstInterview) && candidateBasicInfo.FirstInterview !== "") {
                candidateInforData.candidateBasicInfo.CurrentInterviewStatusDisplay = "First Interview";
                candidateInforData.candidateBasicInfo.CurrentInterviewStatusId = candidateBasicInfo.FirstInterviewId;
                candidateInforData.candidateBasicInfo.CurrentInterviewStatus = candidateBasicInfo.FirstInterview;
                return;
            }
            if (candidateBasicInfo.StatusResult !== "") {
                candidateInforData.candidateBasicInfo.CurrentInterviewStatusDisplay = "Cv Status";
                candidateInforData.candidateBasicInfo.IsScreenCv = true;
                candidateInforData.candidateBasicInfo.CurrentInterviewStatusId = candidateBasicInfo.StatusId;
                candidateInforData.candidateBasicInfo.CurrentInterviewStatus = candidateBasicInfo.StatusResult;
            }
        }

        var getCandidateInformation = function (id) {
            return $resource(constants.apiUrl + 'candidates/:id', { id: id });
        };

        var updateSeletedJobApplication = function (jobApplicationId) {
            candidateDataMainPage.JobApplicationId = jobApplicationId;
        };

        var saveCandidateImage = function () {
            return $resource(constants.apiUrl + 'files');
        };

        var checkCandidateEmail = function (id, emailToCheckDuplicate) {
            return $resource(constants.apiUrl + 'candidates/:id', { id: id, emailToCheckDuplicate: emailToCheckDuplicate, action: "getGeneralInfo" });
        };

        var checkDuplicateInfo = function (id, dataToCheckDuplicate) {
            return $resource(constants.apiUrl + 'candidates/:id', { id: id, dataToCheckDuplicate: dataToCheckDuplicate, action: "checkDuplicateInfo" });
        };

        var updateCandidateGeneralInformation = function (id) {
            candidateDataMainPage.FullName = String.format("{0} : {1}", $filter(constants.translate)("Candidate"), candidateInforData.candidateBasicInfo.FirstName + ' ' + candidateInforData.candidateBasicInfo.LastName);
            return $resource(constants.apiUrl + 'candidates/:id', { id: id }, { UpdateCandidateGeneralInformation: { method: "PUT" } });
        };

        var resetPasswordCandidate = function (candidateId) {
            return $resource(constants.apiUrl + 'candidates/:id', { id: candidateId }, { "update": { method: "PATCH", headers: { ActionName: "ResetPassword" } } });
        };

        /*-------------------------------- Summary Skill-------------------------------------------*/
        var summarySkillResource = function (candidateId, skillId) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/skills/:skillId', { candidateId: candidateId, skillId: skillId },
            { "update": { method: "PUT" } });
        };

        /*------------------------------------- Education--------------------------------------------*/
        var educationsResource = function (candidateId, educationId) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/educations/:educationId', { candidateId: candidateId, educationId: educationId },
            { "update": { method: "PUT" } });
        };

        /*------------------------------------- Interview--------------------------------------------*/
        var interviewResource = function (candidateId, jobApplicationId, action) {
            return $resource(constants.apiUrl + 'candidates/:id/job-application/:jobApplicationId', { id: candidateId, jobApplicationId: jobApplicationId }, { "update": { method: "PUT", headers: { ActionName: action } } });
        };

        /*------------------------------------- Email--------------------------------------------*/
        var emailTrackingResource = function (candidateId, jobApplicationId) {
            return $resource(constants.apiUrl + 'candidates/:id/job-application/:jobApplicationId/email-tracking', { id: candidateId, jobApplicationId: jobApplicationId }, {});
        };

        /*------------------------------------- Experience Skills--------------------------------------------*/
        var updateCandidateExperienceSkills = function (id) {
            return $resource(constants.apiUrl + 'candidates/:id', { id: id }, { update: { method: "PUT" } });
        };

        var addNewScreeningCVHistory = function (candidateId, jobApplicationId) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/job-application/:jobApplicationId/cscreening-cv-history', { candidateId: candidateId, jobApplicationId: jobApplicationId });
        };
        /*------------------------------------- Employment Histories--------------------------------------------*/
        var employmentHistoryResource = function (param) {
            return $resource(
                constants.apiUrl + 'candidates/:candidateId/employment-histories/:employmentHistoryId',
                { candidateId: param.candidateId, employmentHistoryId: param.employmentHistoryId, isEmployee: param.isEmployee },
                { "update": { method: "PUT" } });
        };

        /*------------------------------------- Administration--------------------------------------------*/
        var getCandidateAdministration = function (candidateId) {
            return $resource(caConstants.urlResource.getCandidateNoteById, { id: candidateId });
        };

        var addNewCandidateNote = function (candidateId) {
            return $resource(caConstants.urlResource.addNewCandidateNode, { id: candidateId });
        };

        function addNewOfferLetter(letter, action) {
            return $resource(constants.apiUrl + 'offer-letters?actionName=:actionName', { actionName: action });
        }

        function offerLetter(letter) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/job-application/:jobApplicationId/offer-letters/:id', { candidateId: letter.CandidateId, appliedId: letter.JobApplicationId, id: letter.ContractCodeId }, { update: { method: "PUT" } });
        }

        function setCandidateDataMainPagePositionName(name) {
            candidateDataMainPage.PositionName = name;
        }

        function getCvSources() {
            return $resource(constants.apiUrl + 'candidates/cv-source');
        }
        return {
            getCandidateDataMainPage: getCandidateDataMainPage,
            updateSeletedJobApplication: updateSeletedJobApplication,
            candidateInforData: candidateInforData,
            uploadImage: uploadImage,
            setUpdateImage: setUpdateImage,
            disableUpdateImage: disableUpdateImage,
            getUpdateImage: getUpdateImage,
            getCandidates: getCandidates,
            sendMultiMailUpdateToCv: sendMultiMailUpdateToCv,
            restoreDeleteCandidates: restoreDeleteCandidates,
            makeUserResponseCandidates: makeUserResponseCandidates,
            getCurrentOpenPositions: getCurrentOpenPositions,
            getSendMailOpenPositions: getSendMailOpenPositions,
            addNewCandidateResource: addNewCandidateResource,
            getCandidateInforData: getCandidateInforData,
            getCandidateInfoOfCurrentJob: getCandidateInfoOfCurrentJob,
            clearCandidateInforData: clearCandidateInforData,
            getCandidateInformation: getCandidateInformation,
            saveCandidateImage: saveCandidateImage,
            checkCandidateEmail: checkCandidateEmail,
            checkDuplicateInfo: checkDuplicateInfo,
            updateCandidateGeneralInformation: updateCandidateGeneralInformation,
            resetPasswordCandidate: resetPasswordCandidate,
            summarySkillResource: summarySkillResource,
            educationsResource: educationsResource,
            interviewResource: interviewResource,
            emailTrackingResource: emailTrackingResource,
            updateCandidateExperienceSkills: updateCandidateExperienceSkills,
            addNewScreeningCVHistory: addNewScreeningCVHistory,
            employmentHistoryResource: employmentHistoryResource,
            getCandidateAdministration: getCandidateAdministration,
            addNewCandidateNote: addNewCandidateNote,
            addNewOfferLetter: addNewOfferLetter,
            offerLetter: offerLetter,
            setCandidateDataMainPagePositionName: setCandidateDataMainPagePositionName,
            deleteCandidates: deleteCandidates,
            getCvSources: getCvSources,
            tags: tags
        };
    }

})();
