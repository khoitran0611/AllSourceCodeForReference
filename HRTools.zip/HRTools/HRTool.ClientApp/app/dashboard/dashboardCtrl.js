(function () {
    'use strict';
    angular.module("app").controller('dashboardCtrl', DashboardCtrl);
    DashboardCtrl.$inject = ['constants', 'dbConstants', 'message', 'permissionSvc', 'messageHandleSvc', 'dashboardSvc', '$filter', '$rootScope', '$scope'];

    function DashboardCtrl(constants, dbConstants, message, permissionSvc, messageHandleSvc, dashboardSvc, $filter, $rootScope, $scope) {
        var self = this;
        var _isLoadError = false;
        self.currentUserPermission = permissionSvc.getCurrentUserPermission();

        init();

        function init() {
            $scope.$on(constants.broadCastTile.dasboardLoadFail, function () {
                if (_isLoadError) return;
                _isLoadError = true;
                messageHandleSvc.handleResponse("", $filter(constants.translate)(message.errorLoadingData));
            });

            $rootScope.$on('$stateChangeStart', function (event, toState, toParams, fromState, fromParams) {
                $rootScope.isComeFromDashboard = (fromState.name.indexOf('dashboard') > -1) ? true : false;
            });
            dashboardSvc.redirectForPermission(self.currentUserPermission);
        }
    }
})();
