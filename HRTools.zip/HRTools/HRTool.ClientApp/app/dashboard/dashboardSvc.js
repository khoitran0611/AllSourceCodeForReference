﻿(function () {
    'use strict';
    angular.module("app").service('dashboardSvc', dashboardSvc);
    dashboardSvc.$inject = ['dbConstants', 'constants', '$resource', '$filter', '$state'];
    function dashboardSvc(dbConstants, constants, $resource, $filter, $state) {
        var revealed = {
            getLatestApplications: getLatestApplications,
            getLatestCvUpdates: getLatestCvUpdates,
            getClosedJobs: getClosedJobs,
            getClosingJobs: getClosingJobs,
            getStatictisByJobCode: getStatictisByJobCode,
            getCurrentOpenPosition: getCurrentOpenPosition,
            templatePathDirectives: templatePathDirectives,
            redirectForPermission: redirectForPermission,
            getListOrderJobTitle: getListOrderJobTitle,
            setListOrderJobTitle: setListOrderJobTitle,
            convertSinglePositionNameToPlural: convertSinglePositionNameToPlural
        };

        var listOrderJobTitle = {};

        return revealed;

        function getLatestApplications(id) {
            if (id && id > 0) return $resource(constants.apiUrl + 'job-application/latest/jobs/:id', { id: id });
            return $resource(constants.apiUrl + 'job-application/latest');
        }

        function getLatestCvUpdates() {
            return $resource(constants.apiUrl + 'cv-updates/latest');
        }

        function getClosedJobs() {
            return $resource(constants.apiUrl + 'closed-positions');
        }

        function getClosingJobs() {
            return $resource(constants.apiUrl + 'closing-positions');
        }

        function getStatictisByJobCode() {
            return $resource(constants.apiUrl + 'statictis/open-position', {}, { query: { method: "GET", isArray: true, headers: { 'If-None-Match': '' } } });
        }

        function getCurrentOpenPosition() {
            return $resource(constants.apiUrl + 'openpositions', { filter: '', action: 'getCurrentOpenPositions' }, { query: { method: "GET", isArray: true, headers: { 'If-None-Match': '' } } });
        }

        function templatePathDirectives() {
            var rootPath = 'common/directives/dashboard/';
            var templatePath = {
                latestApplications: rootPath + 'latestApplications/latestApplications.html',
                latestCvUpdates: rootPath + 'latestCvUpdates/latestCvUpdates.html',
                jobSnapshot: rootPath + 'jobSnapshot/jobSnapshot.html',
                jobActivity: rootPath + 'jobActivity/jobActivity.html',
                closedJobs: rootPath + 'closedJobs/closedJobs.html',
                closingJobs: rootPath + 'closingJobs/closingJobs.html'

            };
            return templatePath;
        }

        function redirectForPermission(currentUserPermission) {
            if (currentUserPermission.canViewDashboard) return;
            if (currentUserPermission.canViewOpenPositions) return $state.go('jobs');
            if (currentUserPermission.canViewCandidate) return $state.go('candidates');
            if (currentUserPermission.canViewInterview) return $state.go('interviewSchedule');
            if (currentUserPermission.canViewEmployees) return $state.go('employees');
        }

        function getListOrderJobTitle() {
            return listOrderJobTitle;
        }

        function setListOrderJobTitle(data) {
            listOrderJobTitle = data;
        }

        function convertSinglePositionNameToPlural(positionName) {
            if (!positionName) return "";
            return String.format($filter(constants.translate)("Plural_Text.Open_Application"), positionName);
        }
    }
})();