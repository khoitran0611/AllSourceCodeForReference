﻿(function () {
    'use strict';
    angular.module("app").controller('dbLatestCvUpdateCtrl', DbLatestCvUpdateCtrl);
    DbLatestCvUpdateCtrl.$inject = ['dbConstants', 'dashboardSvc', 'constants'];
    function DbLatestCvUpdateCtrl(dbConstants, dashboardSvc, constants) {
        var param = {
            action: dbConstants.action.getLatestCvUpdate,
            filter: ''
        };
        var self = this;

        self.lastestCv = [];
        self.icon = {
            dashboardLine: 'Content/app/images/dashboard_line.png',
            horizontalGreyLine: 'Content/app/images/horizontal_grey_line.png'
        };


        self.viewAll = viewAll;
        self.getImageLink = getImageLink;

        init();

        function init() {
            reload();
        }

        function reload() {
            dashboardSvc.getDashboardResource(param).query().$promise.then(
                function (data) {
                    self.lastestCv = formatDate(data);
                });
            return;

            function formatDate(data) {
                var newData = [];
                data.forEach(function (record) {
                    record.ModifiedDate = moment(record.ModifiedDate).format(constants.formatDateDDMMYYYY);
                    newData.push(record);
                });
                return newData;
            }
        }

        function viewAll() {
            param.action = dbConstants.action.getAllLatestCvUpdate;
            reload();
        }

        function getImageLink(image) {
            return (IS_PRODUCT_MODE) ? '../../../../' + image : image;
        }
    }
})();