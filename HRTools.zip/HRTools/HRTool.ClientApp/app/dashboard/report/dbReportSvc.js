﻿(function () {
    'use strict';
    angular.module("app").service('dbReportSvc', dbReportSvc);
    dbReportSvc.$inject = [];

    function dbReportSvc() {
      
    }
})();