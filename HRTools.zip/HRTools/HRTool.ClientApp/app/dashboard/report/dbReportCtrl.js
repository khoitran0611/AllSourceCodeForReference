﻿(function () {
    'use strict';
    angular.module("app").controller('dbReportCtrl', DbReportCtrl);
    DbReportCtrl.$inject = ['constants', 'dbConstants', 'message', 'chartModel', 'messageHandleSvc', 'datetimeSvc', 'positionSvc', 'dashboardSvc', '$scope', '$filter'];
    function DbReportCtrl(constants, dbConstants, message, chartModel, messageHandleSvc, datetimeSvc, positionSvc, dashboardSvc, $scope, $filter) {
        /* jshint -W040 */
        var self = this;
        var param = {};

        var _filter = { fromDate: constants.stringEmpty, toDate: constants.stringEmpty, postionId: undefined, compareCondition: undefined };
        self.seletedDate = moment().format(constants.formatDateDDMMYYYY);
        self.dateRange = constants.stringEmpty;
        self.selectedPostion = {};
        self.chartData = { data: [] };
        self.isShowNoData = true;
        self.initListPostion = {
            service: positionSvc.getAllPositions(), id: "PstId", text: "PstName", option: {
                placeholder: $filter(constants.translate)(message.defaultPlaceholderDropdownPosition),
                multiple: false
            }
        };
        self.chartConfig = {
            tooltips: true,
            labels: false,
            colors: constants.colorChart,
            isAnimate: true
        };

        self.getReportData = getReportData;

        init();

        function init() {
            param.action = dbConstants.action.getOverviewReport;
            param.filter = _filter;

            activeBinding();

            $scope.$watch("reportCtrl.selectedPostion", function (newValue, oldValue) {
                if (newValue != oldValue)
                    getReportData();
            });

            $('.date').datepicker({ autoclose: true, todayHighlight: true });
            $(".date").datepicker("setDate", new Date());
        }

        function activeBinding() {
            getReportData();
        }

        function getReportData() {
            param.filter = getCurentFilter();
            dashboardSvc.getDashboardResource(param).query(
               function (data) {
                   bindingChart(data);
               },
               function (xhr) {
                   messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
               });
            return;

            function getCurentFilter() {
                var result = {};
                self.dateRange =
                    moment(self.seletedDate, constants.formatDateDDMMYYYY).format(constants.formatDateDDMM) + "-" +
                    moment(self.seletedDate, constants.formatDateDDMMYYYY).add(dbConstants.weekRangeFilter, 'weeks').format(constants.formatDateDDMM);
                result.fromDate = datetimeSvc.convertDateForServerSide(self.seletedDate, false);
                result.toDate = datetimeSvc.convertDateForServerSide(moment(self.seletedDate, constants.formatDateDDMMYYYY).add(dbConstants.weekRangeFilter, 'weeks'), false);
                result.compareCondition = constants.compareCondition.between;
                result.postionId = self.selectedPostion.id;
                return result;
            }

            function bindingChart(data) {
                self.isShowNoData = data.length === 0;
                self.chartData.data = [];
                var xAxisTemplate = "{0}.{1}";
                for (var i = 0; i < dbConstants.dateRangeDisplayChart; i++) {
                    var item, xAxis;
                    for (var j = 0; j < data.length; j++) {
                        if (moment(self.seletedDate, constants.formatDateDDMMYYYY).add(i, "days").format(constants.formatDateDDMMYYYY) != moment(data[j].CreatedDate).format(constants.formatDateDDMMYYYY))
                            continue;
                        xAxis = String.format(xAxisTemplate, datetimeSvc.getDayOfDate(data[j].CreatedDate).charAt(0), moment(data[j].CreatedDate).date());
                        item = new chartModel(xAxis, [data[j].TotalJobApplied], 'Sample tooltip');
                        self.chartData.data.push(item);
                        break;
                    }
                    xAxis = String.format(xAxisTemplate, datetimeSvc.getDayOfDate(
                        moment(self.seletedDate, constants.formatDateDDMMYYYY).add(i, "days", constants.formatDateDDMMYYYY)).charAt(0),
                        moment(self.seletedDate, constants.formatDateDDMMYYYY).add(i, "days", constants.formatDateDDMMYYYY).date());
                    item = new chartModel(xAxis, [0], 'Sample tooltip');
                    self.chartData.data.push(item);
                }
            }
        }
    }
})();