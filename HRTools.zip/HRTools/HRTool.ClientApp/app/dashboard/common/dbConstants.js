﻿(function () {
    'use strict';
    angular.module("app").constant('dbConstants', {
        jobCode: 'JobCodeFilter',
        //urlResource:
        //{
        //    latestApplication: "../api/job-application/latest",
        //    latestApplicationByJobId: "../api/job-application/latest/jobs/:id",
        //    latestCvUpdate: "../api/cv-updates/latest",
        //    statictisJobCode: "../api/statictis/open-position",
        //    currentOpenPositions: "../api/openpositions",
        //    jobActivity: "../api/statictis/jobactivity"

        //},
        dashboardChild: {
            contentImgUrl: "Content/app/images/dashboard_line.png",
            candidateUrl: "#/candidates",
            openPositionUrl: "#/open-positions",
            dashboardJob: "#/dashboard/jobs",
            formatDate: "dd.MM.yyyy",
            candidateLatestCVUpdateUrl: "#/candidates/latest-cv-updates"
        },
        action: {
            getOverviewReport: "getOverviewReport",
            getOverviewList: "getOverviewList",
            getAllLatestApplication: "getAllLatestJobApplication",
            getLatestCvUpdate: "getLatestCvUpdate",
            getAllLatestCvUpdate: "getAllLatestCvUpdate",
            getApplicationStatus: "getApplicationStatus"
        },
        tableSnapshotTitle: {
            job: "Job",
            all: "All",
            new: "New",
            interested: "Interested",
            interviewing: "Interviewing",
            shortlisted: "Shortlisted",
            offered: "Offered",
            hired: "Hired",
            open: "Open"
        },
        tableSnapshotTitleShort: {
            job: "Job",
            all: "All",
            new: "New",
            interested: "Inte-<br />rested",
            interviewing: "Inter-<br />viewing",
            shortlisted: "Short-<br />listed",
            offered: "Offered",
            hired: "Hired"
        },
        weekRangeFilter: 2,
        dateRangeDisplayChart: 14,
        dashboardJobMenuListName: {
            invitation: "invitation", all: "all", new: "new", interested: "interested",
            interviewing: "interviewing", shortlisted: "shortlisted", offered: "offered", hired: "hired"
        }
    });
})();
