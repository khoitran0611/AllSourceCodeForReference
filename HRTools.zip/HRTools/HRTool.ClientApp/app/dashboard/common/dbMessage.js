﻿(function () {
    "use strict";
    angular.module("app").constant('dbMessage', {
        messageAppEmpty: "Message.No_Application",
        messageCvEmpty: "Message.No_CV",
        messageAppointmentEmpty: "Message.No_Appointment",
        messageJobSnapshotEmpty: "Message.No_JobSnapshot",
        messageClosedJobEmpty: "Message.No_ClosedJobs",
        messageclosingJobEmpty: "Message.No_ClosingJobs"
    });
})();


