﻿(function () {
    'use strict';
    angular.module("app").controller('dbApplicationStatusCtrl', DbApplicationStatusCtrl);
    DbApplicationStatusCtrl.$inject = ['dashboardSvc', 'dbConstants', 'constants', 'datetimeSvc', 'positionSvc', '$scope', '$filter', 'message'];

    function DbApplicationStatusCtrl(dashboardSvc, dbConstants, constants, datetimeSvc, positionSvc, $scope, $filter, message) {
        var self = this;

        self.statusData = [];
        self.selectedPostion = {};
        self.dateRange = '';
        self.seletedDate = moment().format(constants.formatDateDDMMYYYY);
        self.initListPostion = {
            service: positionSvc.getAllPositions(), id: "PstId", text: "PstName", option: {
                placeholder: $filter(constants.translate)(message.defaultPlaceholderDropdownPosition),
                multiple: false
            }
        };

        self.getReportData = getReportData;

        var param = {
            action: dbConstants.action.getApplicationStatus,
            filter: ''
        };

        init();

        function init() {
            getReportData();

            $scope.$watch("ctrl.selectedPostion", function (newValue, oldValue) {
                if (newValue != oldValue)
                    getReportData();
            });

            $('.date-range').datepicker({ autoclose: true, todayHighlight: true });
        }

        function getReportData() {
            param.filter = getCurrentFilter();
            dashboardSvc.getDashboardResource(param).query().$promise.then(function(response) {
                self.statusData = response;
            });
            return;

            function getCurrentFilter() {
                var result = {};
                self.dateRange =
                    moment(self.seletedDate, constants.formatDateDDMMYYYY).format(constants.formatDateDDMM) + "-" +
                    moment(self.seletedDate, constants.formatDateDDMMYYYY).add(dbConstants.weekRangeFilter, 'weeks').format(constants.formatDateDDMM);
                result.fromDate = datetimeSvc.convertDateForServerSide(self.seletedDate, false);
                result.toDate = datetimeSvc.convertDateForServerSide(moment(self.seletedDate, constants.formatDateDDMMYYYY).add(dbConstants.weekRangeFilter, 'weeks'), false);
                result.compareCondition = constants.compareCondition.between;
                result.postionId = self.selectedPostion.id;
                return result;
            }
        }
    }
})();