﻿(function () {
    'use strict';
    angular.module("app").controller('dbLatestApplicationCtrl', DbLatestApplicationCtrl);
    DbLatestApplicationCtrl.$inject = ['dashboardSvc', 'dbConstants'];
    function DbLatestApplicationCtrl(dashboardSvc, dbConstants) {
        var param = {
            action: dbConstants.action.getLatestApplication,
            filter: ''
        };
        var self = this;

        self.applications = [];
        self.icon = {
            dashboardLine: 'Content/app/images/dashboard_line.png',
            horizontalGreyLine: 'Content/app/images/horizontal_grey_line.png'
        };

        self.viewAll = viewAll;
        self.getImageLink = getImageLink;

        init();

        function init() {
            reload();
        }

        function reload() {
            dashboardSvc.getDashboardResource(param).query().$promise.then(
                function (data) {
                    self.applications = data;
                });
        }

        function viewAll() {
            param.action = dbConstants.action.getAllLatestApplication;
            reload();
        }

        function getImageLink(image) {
            return (IS_PRODUCT_MODE) ? '../../../../' + image : image;
        }
    }
})();