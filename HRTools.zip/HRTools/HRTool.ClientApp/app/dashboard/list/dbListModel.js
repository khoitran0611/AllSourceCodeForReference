﻿(function () {
    'use strict';
    angular.module("app").factory('dbListModel', dbListModel);
    dbListModel.$inject = ['constants', 'comparisonUtilSvc'];
    function dbListModel(comparisonUtilSvc) {
        var resource = function (candidate) {
            /* jshint -W040 */
            var self = this;
            self.IsCheck = false;
            self.CandidateId = candidate.CandidateId || '';
            var historyCandidate = candidate.HistoryJobApplications[0];
            self.FullName = candidate.FullName || '';
            self.PositionName = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.PositionName : '';
            self.Applied = '';
            self.Status = 'OK';
            return self;
        };
        return resource;
    }
})();