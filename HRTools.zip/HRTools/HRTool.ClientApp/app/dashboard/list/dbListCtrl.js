﻿(function () {
    'use strict';
    angular.module("app").controller('dbListCtrl', DbListCtrl);
    DbListCtrl.$inject = ['constants', 'message', 'languageHelperSvc', 'dbListSvc', 'positionSvc', '$scope', '$filter'];
    function DbListCtrl(constants, message, languageHelperSvc, dbListSvc, positionSvc, $scope, $filter) {
        /* jshint -W040 */
        var self = this;
        self.pageIndex = constants.paging.firstPage;
        self.totalPages = constants.totalPagesInitial;
        self.pagingOptions = {};
        self.showSelectionCheckbox = true;
        self.query = constants.stringEmpty;
        self.showColumnMenu = false;
        self.dataGrid = 'listCtrl.data';
        self.pagingEvent = 'listCtrl.pagingOptions';
        self.gridOptionsAlias = "listCtrl.gridOptions";
        self.gridTemplate = 'app/dashboard/list/dbGridTemplate.html';
        self.aggregateTemplate = 'app/dashboard/list/dbAggregateTemplate.html';
        self.headerRowTemplate = 'app/dashboard/list/dbHeaderRowTemplate.html';
        self.rowTemplate = 'app/dashboard/list/dbRowTemplate.html';
        self.gridId = 'dbGrid';
        self.columnDefs = [];
        self.customCss = {};
        self.showFooter = false;
        self.enablePaging = false;
        self.groups = ['PositionName'];
        self.i18n = languageHelperSvc.getLanguage();
        self.selectedPostion = {};
        self.initListPostion = {
            service: positionSvc.getAllPositions(), id: "PstId", text: "PstName", option: {
                placeholder:  $filter(constants.translate)(message.defaultPlaceholderDropdownPosition),
                multiple: false
            }
        };

        self.getPagedDataAsync = getPagedDataAsync;

        init();

        function init() {
            self = self.getPagedDataAsync();

            $scope.$watch("listCtrl.selectedPostion", function (newValue, oldValue) {
                if (newValue == oldValue)
                    return;
                self.pageIndex = constants.paging.firstPage;
                self.isSearching = true;
                var queryTemplate = "applyPosition:({0})";
                self.query = String.format(queryTemplate, newValue.text);
                self = dbListSvc.getPagedDataAsync(self, $scope);
            });
        }

        function getPagedDataAsync() {
            self = dbListSvc.getPagedDataAsync(self, $scope);
            return self;
        }
    }
})();