﻿(function () {
    'use strict';
    angular.module("app").service('dbListSvc', dbListSvc);
    dbListSvc.$inject = [
        'dbConstants', 'gridSvc', 'gridHeader', 'messageHandleSvc', 'styleSvc', 'candidateSvc',
        '$filter', 'dbListModel', 'message', 'constants', 'comparisonUtilSvc', 'loadingSvc'];
    function dbListSvc(
        dbConstants, gridSvc, gridHeader, messageHandleSvc, styleSvc, candidateSvc,
        $filter, dbListModel, message, constants, comparisonUtilSvc, loadingSvc) {
        var service = {
            getPagedDataAsync: getPagedDataAsync

        };
        return service;

        function getPagedDataAsync(self, $scope) {
            var result = self;
            result = initColumsDefinition(result);
            var candidateList = candidateSvc.getCandidates(self.pageIndex, self.query, self.isSearching).get(
                function () {
                    $.jStorage.set(dbConstants.jobCode, null);
                    delete window.localStorage[dbConstants.jobCode];
                    result.data = [];
                    if (!comparisonUtilSvc.isNullOrUndefinedValue(candidateList.Data)) {
                        for (var i = 0; i < candidateList.Data.length; i++) {
                            var candidate = new dbListModel(candidateList.Data[i]);
                            result.data.push(candidate);
                        }
                    }
                    result = gridSvc.createGroup(self, $scope);
                    loadingSvc.close();
                    return result;
                },
                function (xhr) {
                    messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    loadingSvc.close();
                }
            );
            return result;
        }

        function initColumsDefinition(self) {
            var result = self;
            result.columnDefs = [
                new gridHeader('FullName', $filter(constants.translate)('Position_Name'), '', true, { css: "col-xs-3" }),
                new gridHeader('Applied', $filter(constants.translate)('Applied'), '', true, { css: "col-xs-1" }),
                new gridHeader('Status', $filter(constants.translate)('Status'), '', true, { css: "col-xs-1" })
            ];

            result.customCss.setStatusInterview = styleSvc.setStatus;
            result.customCss.setTitleInterview = styleSvc.setTitle;
            return result;
        }
    }
})();