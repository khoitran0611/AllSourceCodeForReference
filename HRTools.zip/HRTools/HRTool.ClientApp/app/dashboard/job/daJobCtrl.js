﻿(function () {
    "use strict";
    angular.module("app").controller('daJobCtrl', DaJobCtrl);
    DaJobCtrl.$inject = [
        'daJobSvc', 'datetimeSvc', 'jobSvc', 'permissionSvc', 'objectSvc', 'actionMenuSvc', 'loadingSvc', 'joGridSvc',
        'switchCandidateSvc', 'historyPageSvc', 'styleSvc',
        'constants', 'dbConstants',
        '$state', '$scope', '$timeout', '$filter', 'message', 'messageHandleSvc', '$compile', '$stateParams'
    ];
    function DaJobCtrl(daJobSvc, datetimeSvc, jobSvc, permissionSvc, objectSvc, actionMenuSvc, loadingSvc, joGridSvc,
            switchCandidateSvc, historyPageSvc, styleSvc,
            constants, dbConstants,
            $state, $scope, $timeout, $filter, message, messageHandleSvc, $compile, $stateParams) {
        /* jshint -W040 */
        var self = this;
        self.currentUserPermission = permissionSvc.getCurrentUserPermission();
        if (!self.currentUserPermission.canViewDashboard) {
            $state.go("dashboard");
            window.location.reload();
            return;
        }
        var updateActionTilte = "Update_Action";
        var showChar = 140; // How many characters are shown by default
        var ellipsesText = $filter(constants.translate)('Ellipsis');
        var moreText = $filter(constants.translate)('ShowMore');
        var lessText = $filter(constants.translate)('ShowLess');
        var _listName = dbConstants.dashboardJobMenuListName;

        var menuIndex = {
            invitation: 0,
            all: 1,
            new: 2,
            interested: 3,
            interviewing: 4,
            shortlisted: 5,
            offered: 6,
            hired: 7
        };

        self.isShowLoading = false;
        self.isPublishJobCompleted = false;
        self.positionName = "";
        self.publishDate = datetimeSvc.convertDate(new Date());
        self.status = -1;
        self.isPositionHide = true;
        self.allCandidates = [];
        self.interestedCandidates = [];
        self.invitationCandidates = [];
        self.interviewingCandidates = [];
        self.shortListCandidates = [];
        self.offeredCandidate = [];
        self.startWorkingDate = datetimeSvc.convertDate(new Date());
        self.note = "";
        self.displayvalue = "";
        self.id = $state.params.id;
        self.itemPerPage = 50;
        self.positionStatus = "";
        self.openPosition = { Id: self.id };

        self.getCssClass = getCssClass;
        self.getMessage = getMessage;
        self.canShow = canShow;
        self.goBack = goBack;
        self.setValue = setValue;
        self.updateNote = updateNote;
        self.showMoreLess = showMoreLess;

        self.clickCalendar = clickCalendar;
        self.onChangeDate = onChangeDate;

        init();

        function init() {
            loadMenu();
            getData();
            $('#applyBeforeDate').datepicker();
            $scope.$on(updateActionTilte, function () {
                $timeout(function () {
                    getData();
                }, 1000);
            });

            $scope.$on(constants.broadCastTile.updateCandidateRating, function () {
                $timeout(function () {
                    getData();
                }, 1000);
            });

            $scope.$on(constants.broadCastTile.updateCandidateNode, function () {
                $timeout(function () {
                    getData();
                }, 1000);
            });

            $scope.$watch("daJobCtrl.menus", function (newValue, oldValue) {
                setCandidateList();
            }, true);

            setDelay(false);

            $scope.$on(constants.broadCastTile.rejectCandidate, function (event, rootScopeParams) {
                self.emailData = rootScopeParams;
                $("#reviewMailModal").modal('show');
            });

            $scope.$watch('daJobCtrl.note', function (newValue) {
                self.displayvalue = self.note ? self.note.replace(/\r?\n/g, '<br/>') : "";
                var htmlContain = "<div>" + self.displayvalue + "</div>";
                var content = $(htmlContain);
                var shortContent = "";
                var extendContent = "";
                if (content.children('br').length > 0) {
                    var index = self.displayvalue.indexOf('<br/>');
                    if (index < showChar) {
                        shortContent = self.displayvalue.substr(0, index);
                    } else {
                        shortContent = self.displayvalue.substr(0, showChar);
                    }
                    extendContent = self.displayvalue.substr(shortContent.length, self.displayvalue.length);
                    self.displayvalue = shortContent + '<span class="moreellipses">' + ellipsesText + '&nbsp;</span><span class="morecontent">' + extendContent + '</span>&nbsp;&nbsp;';
                    $timeout(function () {
                        $('#job-note-content-show > span').append($compile('<i class="morelink" ng-click="daJobCtrl.showMoreLess($event)">' + moreText + '</i>')($scope));
                    }, 200);
                } else {
                    if (self.displayvalue.length > showChar) {
                        shortContent = self.displayvalue.substr(0, showChar);
                        extendContent = self.displayvalue.substr(showChar, self.displayvalue.length);
                        self.displayvalue = shortContent + '<span class="moreellipses">' + ellipsesText + '&nbsp;</span><span class="morecontent">' + extendContent + '</span>&nbsp;&nbsp;';
                        $timeout(function () {
                            $('#job-note-content-show > span').append($compile('<i class="morelink" ng-click="daJobCtrl.showMoreLess($event)">' + moreText + '</i>')($scope));
                        }, 200);
                    }
                }
            }, true);

            $scope.$watch('daJobCtrl.isPublishJobCompleted', function (newValue) {
                if (!newValue) return;
                self.startWorkingDate = self.openPosition.StartWorkingDate;
                self.publishDate = self.openPosition.PostDate;
                self.status = self.openPosition.Status;
                self.isPublishJobCompleted = false;
            }, true);
            return;

            function loadMenu() {
                self.menus = [
                    { name: $filter(constants.translate)("Action_Menu.Invitation"), url: "/all", enable: true, isActive: false, number: 0, isHide: true },
                    { name: $filter(constants.translate)("Action_Menu.All"), url: "/all", enable: true, isActive: false, number: 0 },
                    { name: $filter(constants.translate)("Action_Menu.New"), url: "/interested", enable: true, isActive: false, number: 0 },
                    { name: $filter(constants.translate)("Action_Menu.Interested"), url: "/interested", enable: true, isActive: false, number: 0 },
                    { name: $filter(constants.translate)("Action_Menu.Interviewing"), url: "/interviewing", enable: true, isActive: false, number: 0 },
                    { name: $filter(constants.translate)("Action_Menu.Shortlisted"), url: "/Short-listed", enable: true, isActive: false, number: 0 },
                    { name: $filter(constants.translate)("Action_Menu.Offered"), url: "/offered", enable: true, isActive: false, number: 0 },
                    { name: $filter(constants.translate)("Action_Menu.Hired"), url: "/hired", enable: true, isActive: false, number: 0 }
                ];
                var previousTagIdex = historyPageSvc.getPreviousTag(window.location.href);
                if (previousTagIdex === null || previousTagIdex === undefined || previousTagIdex < 0 || previousTagIdex > self.menus.length) {
                    self.menus[menuIndex.all].isActive = true;
                    return;
                }
                self.menus[previousTagIdex].isActive = true;
            }

            function getData() {
                self.isShowLoading = true;
                daJobSvc.jobs(self.id).get(function (data) {
                    self.positionName = data.PositionName;
                    self.startWorkingDate = datetimeSvc.convertDate(data.StartWorkingDate, false);
                    self.publishDate = datetimeSvc.convertDate(data.PublicDate, false);
                    self.quantity = data.Quantity;
                    self.applied = data.Data.Applied;
                    self.jobCode = data.JobCode;
                    self.isPositionHide = data.IsHide;
                    self.id = data.Id;
                    self.status = data.Status;
                    self.positionStatus = styleSvc.setPositionStatus(data.Status);
                    self.note = data.Note;
                    self.openPosition = { Id: data.Id, Status: data.Status, PostDate: self.publishDate, StartWorkingDate: self.startWorkingDate, PstName: data.PositionName };
                    prepareCandidatesForAllTabs(data);
                    setSwitchList();
                    setCandidateList();
                    if (!$scope.$$phase) {
                        $scope.$apply();
                    }
                }, function () {
                    self.isShowLoading = false;
                });
            }

            function prepareCandidatesForAllTabs(data) {
                self.invitationCandidates = data.InvitationList;
                self.menus[menuIndex.invitation].number = self.invitationCandidates ? self.invitationCandidates.length : 0;
                self.menus[menuIndex.invitation].isHide = (self.menus[menuIndex.invitation].number === 0);

                self.allCandidates = data.Data.AllCandidates;
                self.menus[menuIndex.all].number = data.Data.AllCandidates ? data.Data.AllCandidates.length : 0;

                self.newCandidates = data.Data.NewCandidates;
                self.menus[menuIndex.new].number = data.Data.NewCandidates ? data.Data.NewCandidates.length : 0;

                self.interestedCandidates = data.Data.InterestedCandidates;
                self.menus[menuIndex.interested].number = data.Data.InterestedCandidates ? data.Data.InterestedCandidates.length : 0;

                self.interviewingCandidates = data.Data.InterviewingCandidates;
                self.menus[menuIndex.interviewing].number = data.Data.InterviewingCandidates ? data.Data.InterviewingCandidates.length : 0;

                self.shortListCandidates = data.Data.ShortListCandidates;
                self.menus[menuIndex.shortlisted].number = data.Data.ShortListCandidates ? data.Data.ShortListCandidates.length : 0;

                self.offeredCandidate = data.Data.OfferedCandidate;
                self.menus[menuIndex.offered].number = data.Data.OfferedCandidate ? data.Data.OfferedCandidate.length : 0;

                self.acceptedCandidates = data.Data.AcceptedCandiate;
                self.menus[menuIndex.hired].number = data.Data.AcceptedCandiate ? data.Data.AcceptedCandiate.length : 0;

                self.hired = self.acceptedCandidates ? self.acceptedCandidates.length : 0;

                self.isShowLoading = false;
                self.convertSinglePositionNameToPlural = convertSinglePositionNameToPlural;
            }

            function setSwitchList() {
                addDataToSwitchList(self.invitationCandidates, _listName.invitation);
                addDataToSwitchList(self.allCandidates, _listName.all);
                addDataToSwitchList(self.newCandidates, _listName.new);
                addDataToSwitchList(self.interestedCandidates, _listName.interested);
                addDataToSwitchList(self.interviewingCandidates, _listName.interviewing);
                addDataToSwitchList(self.shortListCandidates, _listName.shortlisted);
                addDataToSwitchList(self.offeredCandidate, _listName.offered);
                addDataToSwitchList(self.acceptedCandidates, _listName.hired);
            }

            function convertSinglePositionNameToPlural(positionName) {
                if (!positionName) return "";
                return String.format($filter(constants.translate)("Plural_Text.Open_Application"), positionName);
            }

            function addDataToSwitchList(list, nameOfList) {
                var listLength = list.length;
                var candidateIds = [];
                for (var index = 0; index < listLength; index++) {
                    candidateIds.push(list[index].CandidateId);
                }
                var dataFilter = {
                    isSearching: false,
                    listId: candidateIds,
                    pageIndex: 1,
                    totalPages: 1
                };
                var currentListName = "";
                switch (nameOfList) {
                    case _listName.invitation:
                        currentListName = constants.filterData.invitationAppliedCandidates;
                        break;
                    case _listName.all:
                        currentListName = constants.filterData.allAppliedCandidates;
                        break;
                    case _listName.new:
                        currentListName = constants.filterData.newAppliedCandidates;
                        break;
                    case _listName.interested:
                        currentListName = constants.filterData.interestedAppliedCandidates;
                        break;
                    case _listName.interviewing:
                        currentListName = constants.filterData.interviewingAppliedCandidates;
                        break;
                    case _listName.shortlisted:
                        currentListName = constants.filterData.shorlistedAppliedCandidates;
                        break;
                    case _listName.offered:
                        currentListName = constants.filterData.offeredAppliedCandidates;
                        break;
                    case _listName.hired:
                        currentListName = constants.filterData.hiredAppliedCandidates;
                        break;
                }
                switchCandidateSvc.setFilterData(currentListName, dataFilter);
            }

            function setCandidateList() {
                if (self.menus[menuIndex.invitation].isActive) {
                    self.currentList = JSON.parse(JSON.stringify(self.invitationCandidates));
                    self.currentTypeList = JSON.parse(JSON.stringify(_listName.invitation));
                    return;
                }
                if (self.menus[menuIndex.all].isActive) {
                    self.currentList = JSON.parse(JSON.stringify(self.allCandidates));
                    self.currentTypeList = JSON.parse(JSON.stringify(_listName.all));
                    return;
                }
                if (self.menus[menuIndex.new].isActive) {
                    self.currentList = JSON.parse(JSON.stringify(self.newCandidates));
                    self.currentTypeList = JSON.parse(JSON.stringify(_listName.new));
                    return;
                }
                if (self.menus[menuIndex.interested].isActive) {
                    self.currentList = JSON.parse(JSON.stringify(self.interestedCandidates));
                    self.currentTypeList = JSON.parse(JSON.stringify(_listName.interested));
                    return;
                }
                if (self.menus[menuIndex.interviewing].isActive) {
                    self.currentList = JSON.parse(JSON.stringify(self.interviewingCandidates));
                    self.currentTypeList = JSON.parse(JSON.stringify(_listName.interviewing));
                    return;
                }
                if (self.menus[menuIndex.shortlisted].isActive) {
                    self.currentList = JSON.parse(JSON.stringify(self.shortListCandidates));
                    self.currentTypeList = JSON.parse(JSON.stringify(_listName.shortlisted));
                    return;
                }
                if (self.menus[menuIndex.offered].isActive) {
                    self.currentList = JSON.parse(JSON.stringify(self.offeredCandidate));
                    self.currentTypeList = JSON.parse(JSON.stringify(_listName.offered));
                    return;
                }
                if (self.menus[menuIndex.hired].isActive) {
                    self.currentList = JSON.parse(JSON.stringify(self.acceptedCandidates));
                    self.currentTypeList = JSON.parse(JSON.stringify(_listName.hired));
                    return;
                }
            }

            function setDelay(isDelay) {
                if (isDelay) {
                    $(constants.loadingIcon.overlay).show();
                    $(constants.loadingIcon.indicator).show();
                    return;
                }
                $(constants.loadingIcon.overlay).hide();
                $(constants.loadingIcon.indicator).hide();
            }
        }

        function getCssClass(divId) {
            switch (divId) {
                case 'Invitation':
                    return self.menus[menuIndex.invitation].isActive ? 'show-display row' : 'hide-display';
                case 'All':
                    return self.menus[menuIndex.all].isActive ? 'show-display row' : 'hide-display';
                case 'New':
                    return self.menus[menuIndex.new].isActive ? 'show-display row' : 'hide-display';
                case 'Interested':
                    return self.menus[menuIndex.interested].isActive ? 'show-display row' : 'hide-display';
                case 'Interviewing':
                    return self.menus[menuIndex.interviewing].isActive ? 'show-display row' : 'hide-display';
                case 'Short-list':
                    return self.menus[menuIndex.shortlisted].isActive ? 'show-display row' : 'hide-display';
                case 'Offered':
                    return self.menus[menuIndex.offered].isActive ? 'show-display row' : 'hide-display';
                case 'Hired':
                    return self.menus[menuIndex.hired].isActive ? 'show-display row' : 'hide-display';
                default:
                    return "hide-display";
            }
        }

        function getMessage(list) {
            if (self.status === 0) return $filter(constants.translate)("Position_Not_Public");
            if (!list || list.length === 0) return $filter(constants.translate)("No_Candidate_In_Category");
            return "";
        }

        function canShow(list) {
            return (list && list.length > 0);
        }

        function goBack() {
            var previousUrl = historyPageSvc.getPreviousUrl(window.location.href);
            if (previousUrl) {
                historyPageSvc.setPreviousUrl(window.location.href, "");
                window.location.href = previousUrl;
                return;
            }
            $state.go("dashboard");
        }

        function setValue() {
            $timeout(function () {
                var elementButton = angular.element(document.querySelector("#btn-note-save"));
                elementButton.bind('click', function () {
                    updateNote();
                });
            }, 200);
        }

        function updateNote() {
            var noteContent = angular.element(document.querySelector("#job-note-content"));
            $(".job-note").popover('hide');
            $(".job-note").siblings('.popover').remove();
            var noteUpdated = {
                Id: self.id,
                Note: noteContent.val()
            };
            daJobSvc.updateNoteOnly(noteUpdated.Id).update(noteUpdated, function (result) {
                self.note = result.Note;
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
                var successMessage = "Update_Job_Note_Successful";
                toastr.success($filter(constants.translate)(successMessage));
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorInSaveData));
            });
        }

        function showMoreLess(event) {
            var target = $(event.target);
            if ($(target).hasClass("less")) {
                $(target).removeClass("less");
                $(target).html(moreText);
                $('.moreellipses').show();
            } else {
                $(target).addClass("less");
                $('.moreellipses').hide();
                $(target).html(lessText);
            }
            $(target).parent().prev().slideToggle();
            $(target).prev().toggle();
            event.stopPropagation();
            return false;
        }

        function onChangeDate() {
            var oldApplyDate = angular.copy(self.startWorkingDate);
            var newApplyDateConverted = moment(self.newApplyDate, "DD-MM-YYYY");
            var oldApplyDateConverted = moment(oldApplyDate, "DD-MM-YYYY");
            if (!self.newApplyDate || (datetimeSvc.isEqual(newApplyDateConverted, oldApplyDateConverted))) return;

            var today = datetimeSvc.convertToShortDateString(new Date());
            if (datetimeSvc.compareDate(moment(self.newApplyDate, "DD-MM-YYYY"), moment(today, "DD-MM-YYYY"), 0)) {
                toastr.error($filter(constants.translate)("Job.Apply_Date_Smaller_Than_Current_Date"));
                $('#applyBeforeDate').datepicker("hide");
                return;
            }
            var oldPublishDate = angular.copy(self.publishDate);
            if (datetimeSvc.compareDate(moment(self.newApplyDate, "DD-MM-YYYY"), moment(oldPublishDate, "DD-MM-YYYY"), 0)) {
                toastr.error($filter(constants.translate)("Job.Apply_Date_Smaller_Than_Published_Date"));
                $('#applyBeforeDate').datepicker("hide");
                return;
            }

            loadingSvc.show();
            var startWorkingDate = datetimeSvc.convertDateForServerSide(moment(self.newApplyDate, constants.formatDateDDMMYYYY));
            var publishDate = datetimeSvc.convertDateForServerSide(moment(self.publishDate, constants.formatDateDDMMYYYY));
            var newData = { Id: self.id, PostDate: publishDate, StartWorkingDate: startWorkingDate };

            jobSvc.updateJobProperty(newData, 'updateApplyDate')
                .update(newData,
                    function () {
                        self.startWorkingDate = angular.copy(self.newApplyDate);
                        toastr.success($filter(constants.translate)("Job.Update_Job_Success"));
                        loadingSvc.close();
                    },
                    function () {
                        toastr.error($filter(constants.translate)("Job.Update_Job_Fail"));
                        loadingSvc.close();
                    });

            $('#applyBeforeDate').datepicker("hide");
        }

        function clickCalendar() {
            self.newApplyDate = angular.copy(self.startWorkingDate);
            $('#applyBeforeDate').datepicker('setDate', self.newApplyDate);
        }
    }
})();
