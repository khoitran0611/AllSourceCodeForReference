﻿(function () {
    'use strict';
    angular.module("app").factory('daJobSvc', daJobSvc);
    daJobSvc.$inject = ['$resource', 'constants'];
    function daJobSvc($resource, constants) {
        var url = constants.apiUrl + "dashboard/jobs/:id";
         return {
             jobs: jobs,
             updateNoteOnly: updateNoteOnly
         };

         function jobs(id) {
             return $resource(url, { id: id });
         }

         function updateNoteOnly(id) {
             return $resource(url, { id: id }, { update: { method: 'PUT' } });
         }
     }
})();