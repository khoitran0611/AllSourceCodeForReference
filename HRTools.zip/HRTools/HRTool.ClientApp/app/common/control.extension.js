﻿$(window).resize(function() {
    $('div.select2-container-multi').removeClass("select2-dropdown-open").removeClass("select2-container-active");
    $("li.select2-search-field").hide();
    $("div.select2-drop-mask").hide();
    $("div.select2-drop.select2-drop-multi").hide();
});

function autobreakline() {
	var noteElementWidth = $(".comment-note").width();
	var inputPopOverWidth = $("textarea#" + scope.ipvCtrl.id + scope.ipvCtrl.candidateid).width();
	var sigma = noteElementWidth / inputPopOverWidth;
}

function applyLineBreaks(strTextAreaId) {
	var oTextarea = document.getElementById(strTextAreaId);
	oTextarea.setAttribute("wrap", "off");
	var newArea = oTextarea.cloneNode(true);
	newArea.value = oTextarea.value;
	oTextarea.parentNode.replaceChild(newArea, oTextarea);
	oTextarea = newArea;

	var strRawValue = oTextarea.value;
	oTextarea.value = "";
	var nEmptyWidth = oTextarea.scrollWidth;
	var nLastWrappingIndex = -1;
	for (var i = 0; i < strRawValue.length; i++) {
		var curChar = strRawValue.charAt(i);
		if (curChar == ' ' || curChar == '-' || curChar == '+')
			nLastWrappingIndex = i;
		oTextarea.value += curChar;
		if (oTextarea.scrollWidth > nEmptyWidth) {
			var buffer = "";
			if (nLastWrappingIndex >= 0) {
				for (var j = nLastWrappingIndex + 1; j < i; j++)
					buffer += strRawValue.charAt(j);
				nLastWrappingIndex = -1;
			}
			buffer += curChar;
			oTextarea.value = oTextarea.value.substr(0, oTextarea.value.length - buffer.length);
			oTextarea.value += "\n" + buffer;
		}
	}
	oTextarea.setAttribute("wrap", "");
}
