﻿(function () {
    angular.module('app').filter('truncateByCharacter', TruncateByCharacter);
    TruncateByCharacter.$inject = ["stringUtilitySvc", "comparisonUtilSvc"];

    function TruncateByCharacter(stringUtilitySvc, comparisonUtilSvc) {
        return function (inputText, maxCharacters, appendText) {
            var defaultMaxCharacters = 50,
                defaultAppendText = '...';

            if (comparisonUtilSvc.isNullOrUndefinedValue(inputText)) return inputText;
            return stringUtilitySvc.truncateText(
                inputText,
                comparisonUtilSvc.isNullOrUndefinedValue(maxCharacters) ? defaultMaxCharacters : maxCharacters,
                comparisonUtilSvc.isNullOrUndefinedValue(appendText) ? defaultAppendText : appendText);
        };
    }
})();