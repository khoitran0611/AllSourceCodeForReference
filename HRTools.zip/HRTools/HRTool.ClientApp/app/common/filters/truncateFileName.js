﻿(function () {
    angular.module('app').filter('truncateFileName', TruncateFileName);
    TruncateFileName.$inject = ["stringUtilitySvc", "comparisonUtilSvc"];

    function TruncateFileName(stringUtilitySvc, comparisonUtilSvc) {
        return function (inputText, maxCharacters, appendText) {
            var MAX_CHARACTERS = 10,
                EXTEND_STRING = '...';

            if (comparisonUtilSvc.isNullOrUndefinedValue(inputText)) return inputText;
            var fileNameCoponents = inputText.split('.');
            var extension = fileNameCoponents.pop();
            return stringUtilitySvc.truncateText(fileNameCoponents.join('.'),
                comparisonUtilSvc.isNullOrUndefinedValue(maxCharacters) ? MAX_CHARACTERS : maxCharacters,
                comparisonUtilSvc.isNullOrUndefinedValue(appendText) ? EXTEND_STRING : appendText) + '.' + extension;
        };
    }
})();