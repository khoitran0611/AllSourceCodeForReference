﻿(function () {
    "use strict";
    angular.module('app').service('validationSvc',
        function () {
            var backSpaceKeyCode = 8;
            var tabKeyCode = 9;
            var zeroKeyCode = 48;
            var nineKeyCode = 57;
            var numpadZeroKeyCode = 96;
            var numpadNineKeyCode = 105;
            var backSlashKeyCode = 95;
            var revealed = {
                checkWebsiteUrl: checkWebsiteUrl,
                onKeyDownTextBox: onKeyDownTextBox,
                onKeyDownTextBoxDecimalType: onKeyDownTextBoxDecimalType
            };

            return revealed;

            function checkWebsiteUrl(url) {
                return /^(https?|ftp):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(url);
            }

            function onKeyDownTextBox(event) {
                if (event.shiftKey) event.preventDefault(event);
                else {
                    var nKeyCode = event.keyCode;
                    if (nKeyCode == backSpaceKeyCode || nKeyCode == tabKeyCode) {
                        return;
                    }
                    if (nKeyCode < backSlashKeyCode) {
                        if (nKeyCode < zeroKeyCode || nKeyCode > nineKeyCode) {
                            event.preventDefault();
                        }
                    } else {
                        if (nKeyCode < numpadZeroKeyCode || nKeyCode > numpadNineKeyCode)
                            event.preventDefault();
                    }
                }
            }

            function onKeyDownTextBoxDecimalType(e) {
                if (e.shiftKey) e.preventDefault(e);
                else {
                    var nKeyCode = e.keyCode;
                    if (nKeyCode == backSpaceKeyCode || nKeyCode == tabKeyCode) {
                        return;
                    }
                    if (nKeyCode < backSlashKeyCode) {
                        if (nKeyCode < zeroKeyCode || nKeyCode > nineKeyCode) {
                            e.preventDefault();
                        }
                    } else {
                        if (nKeyCode < numpadZeroKeyCode || (nKeyCode > numpadNineKeyCode && nKeyCode != 190))
                            e.preventDefault();
                    }
                }
            }
        });
})();