﻿(function () {
    angular.module('app').service('comparisonUtilSvc', ComparisonUtilSvc);

    function ComparisonUtilSvc() {
        var service = {
            isNullOrUndefinedValue: isNullOrUndefinedValue
        };
        return service;

        function isNullOrUndefinedValue(value) {
            return value === null || value === undefined;
        }
    }
})();