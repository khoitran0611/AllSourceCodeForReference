﻿(function () {
    'use strict';
    angular.module('app').factory('teamSvc', teamSvc);
    teamSvc.$inject = ['$resource', 'constants'];
    function teamSvc($resource, constants) {
        var revealed = {
            getTeams: getTeams
        };
        return revealed;

        function getTeams() {
            return $resource(constants.apiUrl + 'teams');
        }
    }
})();
