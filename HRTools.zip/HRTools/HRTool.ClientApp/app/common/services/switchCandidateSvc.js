﻿(function () {
    "use strict";
    angular.module('app').service('switchCandidateSvc', function () {
            var currentList = 'currentList';
            var service = {
                setFilterData: setFilterData,
                getFilterData: getFilterData,
                setCurrentList: setCurrentList
            };
            return service;

            function setFilterData(key, data) {
                $.jStorage.set(key, data);
            }

            function getFilterData() {
                var key = $.jStorage.get(currentList);
                if (typeof (key) == "object") return key;
                return $.jStorage.get(key);
            }

            function setCurrentList(key) {
                $.jStorage.set(currentList, key);
            }
        });
})();