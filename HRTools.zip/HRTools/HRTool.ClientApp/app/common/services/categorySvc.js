﻿(function () {
    'use strict';
    angular.module('app').factory('categorySvc', categorySvc);
    categorySvc.$inject = ["$resource", 'constants'];
    function categorySvc($resource, constants) {

        function getAllCategories() {
            return $resource(constants.apiUrl + 'categories');
        }

        function getAllSubCategories() {
            return $resource(constants.apiUrl + 'sub-categories');
        }

        function getJobTemplatesByCategoryId(id) {
            return $resource(constants.apiUrl + 'categories/:id/recruitment-templates', { id: id });
        }

        return {
            getAllCategories: getAllCategories,
            getAllSubCategories: getAllSubCategories,
            getJobTemplatesByCategoryId: getJobTemplatesByCategoryId
        };
    }
})();