﻿(function () {
    angular
        .module('app')
        .service('dropdownSvc', dropdownSvc);

    dropdownSvc.$inject = ['$timeout'];

    function dropdownSvc($timeout) {
        var service = {
            show: show,
            close: close
        };

        return service;

        function show(dropdownContainer) {
            $timeout(function () {
                $(dropdownContainer).addClass('open');
                $(dropdownContainer + ' .dropdown-toggle').attr('aria-expanded', true);
            }, 0);
        }

        function close(dropdownContainer) {
            $(dropdownContainer).removeClass('open');
            $(dropdownContainer + ' .dropdown-toggle').attr('aria-expanded', false);
        }
    }
})();