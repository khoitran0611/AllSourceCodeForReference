(function () {
    'use strict';
    angular.module('app').factory('gridSvc', gridSvc);
    gridSvc.$inject = ['pagingSvc', '$timeout', 'constants', '$filter', '$compile', 'message', 'comparisonUtilSvc'];
    function gridSvc(pagingSvc, $timeout, constants, $filter, $compile, message, comparisonUtilSvc) {
        var revealed = {
            init: init,
            initFullLoad: initFullLoad,
            setPagingData: setPagingData,
            setPagingDataFullLoad: setPagingDataFullLoad,
            checkErrorDataRow: checkErrorDataRow,
            checkIsEditingDataRow: checkIsEditingDataRow,
            createGroup: createGroup
        };

        return revealed;

        function init(self, $scope) {
            var result = self;
            result.pagingOptions = {
                currentPage: constants.paging.firstPage,
                pages: [],
                pageSize: constants.paging.pageSize
            };
            result.gridOptions = getGridOptions(self);
            initPagingEvent($scope, self);
            return result;
        }

        function initFullLoad(self) {
            var result = self;
            result.gridOptions = getGridOptions(self);
            return result;
        }

        function getGridOptions(self) {
            var gridOptions = {
                data: self.dataGrid,
                pagingOptions: self.pagingOptions,
                afterSelectionChange: self.handleSelectedItems,
                selectedItems: [],
                showSelectionCheckbox: self.showSelectionCheckbox,
                showColumnMenu: self.showColumnMenu,
                enableCellEdit: self.enableCellEdit,
                enablePaging: self.enablePaging,
                showFooter: self.showFooter,
                menuTemplate: self.menuTemplate ? self.menuTemplate : "common/templates/menuTemplate.html",
                aggregateTemplate: self.aggregateTemplate ? self.aggregateTemplate : "common/templates/aggregateTemplate.html",
                gridTemplate: self.gridTemplate ? self.gridTemplate : "common/templates/gridTemplate.html",
                rowTemplate: self.rowTemplate ? self.rowTemplate : "common/templates/rowTemplate.html",
                headerRowTemplate: self.headerRowTemplate ? self.headerRowTemplate : "common/templates/headerRowTemplate.html",
                headerCellTemplate: self.headerCellTemplate ? self.headerCellTemplate : "common/templates/headerCellTemplate.html",
                cellTemplate: self.cellTemplate ? self.cellTemplate : "common/templates/cellTemplate.html",
                cellEditTemplate: "common/templates/cellEditTemplate.html",
                editableCellTemplate: "common/templates/editableCellTemplate.html",
                visibleColumnCustom: self.columnDefs,
                gridId: self.gridId,
                isEmpty: false,
                passCustomCss: self.customCss,
                groups: self.groups,
                multiSelect: self.multiSelect !== undefined ? self.multiSelect : true,
                enableRowSelection: self.enableRowSelection !== undefined ? self.enableRowSelection : true,
                selectWithCheckboxOnly: self.selectWithCheckboxOnly !== undefined ? self.selectWithCheckboxOnly : false
            };
            return gridOptions;
        }
        function initPagingEvent($scope, self) {
            $scope.$watch(self.pagingEvent, function (newVal, oldVal) {
                if (newVal != oldVal && newVal.currentPage != oldVal.currentPage) {
                    $(constants.loadingIcon.overlay).show();
                    $(constants.loadingIcon.indicator).show();
                    self.pageIndex = self.pagingOptions.currentPage;
                    self.getPagedDataAsync();
                }
                $timeout(function () {
                    $(".ngGrid").trigger('click');
                }, 1000);

            }, true);
            $scope.$on('ngGridEventColumns', function () {
                if (self.gridOptions.groups || !self.enablePaging)
                    return;
                if (self.gridOptions.$gridScope.renderedRows.length > constants.paging.pageSize) {
                    toastr.warning($filter(constants.translate)(message.addingData));
                    self.reloadPaging();
                }
            });
        }

        function setPagingData(self, $scope) {
            var specialTag = constants.baseUrl + "#/candidates";
            var result = self;
            if (result.data.length === 0 && result.gridOptions.$gridScope) {
                if (window.location.href == specialTag && self.isSearching) {
                    var listColumns = $.jStorage.get('caGrid');
                    listColumns = listColumns ? listColumns : [];
                    for (var index = 0; index < listColumns.length; index++) {
                        if (listColumns[index].displayName)
                            for (var gridIndex = 0; gridIndex < self.columnDefs.length; gridIndex++) {
                                if (listColumns[index].displayName == self.columnDefs[gridIndex].displayName) {
                                    self.columnDefs[gridIndex].visible = angular.copy(listColumns[index].visible);
                                }
                            }
                    }
                }
                result.data = createDefaultData(self.columnDefs);
                result.pagingOptions.pages = [];
                result.gridOptions.$gridScope.isEmpty = true;

            } else if (result.data.length > 0 && result.gridOptions.$gridScope) {
                result.gridOptions.isEmpty = false;
                result.gridOptions.$gridScope.isEmpty = false;
                result.pagingOptions.pages = pagingSvc.getAllPages(self.totalPages, self.pageIndex);
            }
            if (!$scope.$$phase && !$scope.$root.$$phase) {
                $scope.$apply();
            }
            $timeout(function () {
                if (self.gridOptions.groups)
                    return;
                if (result.gridOptions.$gridScope) {
                    result.gridOptions.$gridScope.isEditingRow = {};
                    for (var i = 0; i < result.gridOptions.$gridScope.columns.length; i++) {
                        if (result.gridOptions.$gridScope.columns[i].field == "EditRow")
                            result.gridOptions.$gridScope.columns[i].hide = true;
                    }
                }

                if (self.disableSpinner) return;
                $(constants.loadingIcon.overlay).hide();
                $(constants.loadingIcon.indicator).hide();
            }, 400);
            return result;
        }

        function createDefaultData(header) {
            var result = [];
            var emptyData = {};
            for (var i = 0; i < header.length; i++) {
                emptyData[header[i].field] = null;
            }
            result.push(emptyData);
            return result;
        }
        function setPagingDataFullLoad(self, data, $scope) {
            var result = self;
            var isEmpty = false;
            if (!data || data.length === 0) {
                result.data = createDefaultData(self.columnDefs);
                result.pagingOptions.pages = [];
                isEmpty = true;
                result.totalServerItems = 0;
            } else {
                var pagedData = data.slice((self.pageIndex - 1) * self.pagingOptions.pageSize, self.pageIndex * self.pagingOptions.pageSize);
                result.data = pagedData;
                result.totalServerItems = data.length;
                result.pagingOptions.pages = pagingSvc.getAllPages(caculateTotalPage(self.totalServerItems, self.pagingOptions.pageSize), self.pageIndex);
            }

            if (!$scope.$$phase && !$scope.$root.$$phase) {
                $scope.$apply();
            }
            $(constants.loadingIcon.overlay).hide();
            $(constants.loadingIcon.indicator).hide();
            $timeout(function () {
                result.gridOptions.$gridScope.isEditingRow = {};
                result.gridOptions.$gridScope.isEmpty = isEmpty;
            }, 100);
            return result;
        }
        function caculateTotalPage(totalItems, pageSize) {
            if (totalItems === 0) {
                return 0;
            }
            return Math.ceil(totalItems / pageSize);
        }

        function checkErrorDataRow(self, row) {
            for (var i = 0; i < self.gridOptions.$gridScope.renderedColumns.length; i++) {
                for (var key in row.entity) {
                    var value = row.entity[key];
                    var valueIsEmpty = comparisonUtilSvc.isNullOrUndefinedValue(value) || value === "";
                    var isRequiredColumn = self.gridOptions.$gridScope.renderedColumns[i].option.isRequired;
                    if (self.gridOptions.$gridScope.renderedColumns[i].field == key &&
                        isRequiredColumn && valueIsEmpty && key.indexOf("Id") == -1) {
                        return true;
                    }
                }
            }
            return false;
        }

        function checkIsEditingDataRow(self) {
            if (self.data.length > 0 &&
                self.gridOptions.$gridScope.isAddNewRow[self.gridOptions.$gridScope.renderedRows[0].$$hashKey]) {
                return true;
            }
            for (var i = 0; i < self.gridOptions.$gridScope.renderedRows.length; i++) {
                if (self.gridOptions.$gridScope.isEditingRow[self.gridOptions.$gridScope.renderedRows[i].$$hashKey])
                    return true;
            }
            return false;
        }

        function createGroup(self, $scope) {
            var result = self;
            result.pagingOptions.currentPage = result.pagingOptions.currentPage ? result.pagingOptions.currentPage : constants.paging.firstPage;
            result.pagingOptions.pageSize = constants.paging.pageSize;
            var gridContainer = angular.element(document.getElementsByClassName("grid-container"));
            if (gridContainer.children().length > 0) {
                autoClickRowEvent();
                return result;
            }
            result.gridOptions = getGridOptions(self);
            initPagingEvent($scope, self);
            var gridTemplate = "<div class='col-xs-8' ng-grid=\"{0}\"><\/div>";
            gridTemplate = String.format(gridTemplate, self.gridOptionsAlias);
            angular.element(gridContainer.append($compile(gridTemplate)($scope)));

            $timeout(function () {
                autoClickRowEvent();
            }, 800);
            return result;
        }

        function autoClickRowEvent() {
            $timeout(function () {
                var canvas = angular.element(document.getElementsByClassName("ngCanvas"));
                for (var i = 0; i < canvas.children().length; i++) {
                    var item = $(canvas.children()[i]).children()[0];
                    $("#" + item.id).trigger('click');
                }
            }, 800);
        }
    }
})();
