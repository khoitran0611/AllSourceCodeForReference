(function () {
    "use strict";
    angular.module('routeResolver', []).provider('routeResolverSvc', function() {
        var self = this;
        self.$get = function() {
            return self;
        };

        self.routeConfig = function() {
            var viewsDirectory = '/app/',
                controllersDirectory = '/app/',

                setBaseDirectories = function(viewsDir, controllersDir) {
                    viewsDirectory = viewsDir;
                    controllersDirectory = controllersDir;
                },

                getViewsDirectory = function() {
                    return viewsDirectory;
                },

                getControllersDirectory = function() {
                    return controllersDirectory;
                };

            return {
                setBaseDirectories: setBaseDirectories,
                getControllersDirectory: getControllersDirectory,
                getViewsDirectory: getViewsDirectory
            };
        }();
        self.resolveController = function (path, controller) {
            return {
                controller: ['$q', function ($q) {
                var defer = $q.defer();
                require(['/app/' + path + controller + 'Ctrl.js', 'app'], function (ctrl, app) {
                        app.register.controller(controller, ctrl);
                        defer.resolve();

                }, function () {
                    var indexOfAngularUrl = location.href.indexOf("#");
                    var urlLogin = location.href.substring(0, indexOfAngularUrl);
                    window.location.assign(urlLogin);
                });
                return defer.promise;
            }]
            };
        };
        self.route = function(routeConfig) {

            var resolve = function(baseName) {
                var routeDef = {};
                routeDef.templateUrl = routeConfig.getViewsDirectory() + baseName + '.html';
                routeDef.resolve = {
                    load: ['$q', '$rootScope',
                        function($q, $rootScope) {
                            var dependencies = [routeConfig.getControllersDirectory() + baseName + 'Ctrl.js'];
                            return resolveDependencies($q, $rootScope, dependencies);
                        }
                    ]
                };

                return routeDef;
            },

                resolveDependencies = function($q, $rootScope, dependencies) {
                    var defer = $q.defer();
                    require(dependencies, function() {
                        defer.resolve();
                        $rootScope.$apply();
                    });

                    return defer.promise;
                };

            return {
                resolve: resolve
            };
        }(self.routeConfig);
    });
})();
