﻿(function () {
    "use strict";
    angular.module('app').service('permissionSvc', permissionSvc);
    permissionSvc.$inject = ['$window', 'authSvc', 'comparisonUtilSvc'];
    function permissionSvc($window, authSvc, comparisonUtilSvc) {
        var permissionNameConstant = {
            AddMemberstoRole_AddRoleMember: 'Add Members to Role_Add Role Member',
            AddMemberstoRole_ViewRoleMember: 'Add Members to Role_View Role Member',

            CandidateInfo_AddCandidateInfo: 'Candidate Info_Add Candidate Info',
            CandidateInfo_CheckEmailCandidate: 'Candidate Info_Check Email Candidate',
            CandidateInfo_DeleteCandidateInfo: 'Candidate Info_Delete Candidate Info',
            CandidateInfo_EditCandidateInfo: 'Candidate Info_Edit Candidate Info',
            CandidateInfo_Resetpassword: 'Candidate Info_Reset password',
            CandidateInfo_SendAppliedPositionEmail: 'Candidate Info_Send Applied Position Email',
            CandidateInfo_ViewCandidateInfo: 'Candidate Info_View Candidate Info',
            CandidateInfo_ViewEmailCorrespondence: 'Candidate Info_View Email Correspondence',
            CandidateInfo_ViewSelectionProcessSection: 'Candidate Info_View Selection Process section',
            CandidateInfo_ViewEmailsSection: 'Candidate Info_View Emails section',
            CandidateInfo_ViewDiscussionSection: 'Candidate Info_View Discussion section',
            CandidateInfo_ViewAdministrationSection: 'Candidate Info_View Administration section',
            CandidateInfo_AddAppliedPosition: 'Candidate Info_Add Applied Position',
            CandidateInfo_EditAppliedPosition: 'Candidate Info_Edit Applied Position',
            CandidateInfo_DeleteAppliedPosition: 'Candidate Info_Delete Applied Position',
            CandidateInfo_DownloadDocuments: 'Candidate Info_Download documents',

            CandidateOnlineInfo_AddCandidateInfo: 'Candidate Online Info_Add Candidate Info',
            CandidateOnlineInfo_Changepassword: 'Candidate Online Info_Change password',
            CandidateOnlineInfo_DeleteCandidateInfo: 'Candidate Online Info_Delete Candidate Info',
            CandidateOnlineInfo_EditCandidateInfo: 'Candidate Online Info_Edit Candidate Info',
            CandidateOnlineInfo_ViewCandidateInfo: 'Candidate Online Info_View Candidate Info',

            CreateOfferLetter_EditOfferLetter: 'Create Offer Letter_Edit Offer Letter',
            CreateOfferLetter_ViewOfferLetterPage: 'Create Offer Letter_View Offer Letter page',
            CreateOfferLetter_SendOfferLetter: 'Create Offer Letter_Send Offer Letter',

            Employeecontract_AddContract: 'Employee contract_Add Contract',
            Employeecontract_UpdateContract: 'Employee contract_Update Contract',
            Employeecontract_Uploadfile: 'Employee contract_Upload file',
            Employeecontract_ViewContract: 'Employee contract_View Contract',
            Employeecontract_ExportContract: 'Employee contract_Export Contract',

            Employeecontractupdate_Updatecontract: 'Employee contract update_Update contract',
            Employeecontractupdate_Uploadfile: 'Employee contract update_Upload file',
            Employeecontractupdate_Viewcontract: 'Employee contract update_View contract',

            EmployeeInfo_UpdateCV: 'Employee Info_Update CV',
            EmployeeInfo_AddEmployeeInfo: 'Employee Info_Update Employee Info',
            EmployeeInfo_BecomeEmployee: 'Employee Info_Become Employee',
            EmployeeInfo_DeleteEmployeeInfo: 'Employee Info_Update Employee Info',
            EmployeeInfo_EditEmployeeInfo: 'Employee Info_Update Employee Info',
            EmployeeInfo_UpdateOwnerCV: 'Employee Info_Update Owner CV',
            EmployeeInfo_SendMailWelcome: 'Employee Info_Send Mail Welcome',
            EmployeeInfo_ViewEmployeeInfo: 'Employee Info_View Employee Info',

            Employees_AddEmployee: 'Employees_Add Employee',
            Employees_ViewEmployees: 'Employees_View Employees',

            Interviewschedule_ViewInterviewSchedule: 'Interview_View Interview Schedule',
            //letter template
            LetterTemplates_EditLetterTemplate: 'Letter Templates_Edit Letter Template',
            LetterTemplates_ViewLetterTemplates: 'Letter Templates_View Letter Templates',

            Login_Login: 'Login_Login',
            Login_Logout: 'Login_Logout',
            LoginOnline_Login: 'Login Online_Login',
            LoginOnline_Logout: 'Login Online_Logout',

            //open position
            OpenPositions_ViewOpenPositionDetail: 'Open Positions_View Open Position Detail',
            OpenPositions_AddNewOpenPosition: 'Open Positions_Add New Open Position',
            OpenPositions_DeleteOpenPosition: 'Open Positions_Delete Open Position',
            OpenPositions_EditOpenPosition: 'Open Positions_Edit Open Position',
            OpenPositions_PreviewEmailOpenPosition: 'Open Positions_Preview Email Open Position',
            OpenPositions_ViewOpenPositions: 'Open Positions_View Open Positions',
            OpenPositions_CustomizeColumnsOnJobsListing: 'Open Positions_Customize columns on Jobs Listing',
            //position template

            PositionTemplates_AddPositionTemplate: 'Position Templates_Add Position Template',
            PositionTemplates_EditPositionTemplate: 'Position Templates_Edit Position Template',
            PositionTemplates_ViewDetail: 'Position Templates_View Detail',
            PositionTemplates_ViewPositionTemplates: 'Position Templates_View Position Templates',

            ProbationAppraisal_Addprobation: 'Probation Appraisal_Add probation',
            ProbationAppraisal_Editprobation: 'Probation Appraisal_Edit probation',
            ProbationAppraisal_Viewprobation: 'Probation Appraisal_View probation',
            //role
            Roles_AddRole: 'Roles_Add Role',
            Roles_DeleteRole: 'Roles_Delete Role',
            Roles_EditRole: 'Roles_Edit Role',
            Roles_ViewRoles: 'Roles_View Roles',
            //position
            Positions_Add: 'Position Categories_Add Position',
            Positions_Delete: 'Position Categories_Delete Position',
            Positions_Edit: 'Position Categories_Edit Position',
            Positions_View: 'Position Categories_View Positions',
            //remind candidate update cv
            RemindCandidates_View: 'Remind Candidate Update CV_View Remind Candidate',
            RemindCandidates_Add: 'Remind Candidate Update CV_Add Remind Candidate',
            RemindCandidates_Edit: 'Remind Candidate Update CV_Edit Remind Candidate',
            RemindCandidates_Delete: 'Remind Candidate Update CV_Delete Remind Candidate',

            //schedule interview
            ScheduleInterview_AddSchedule: 'Schedule Interview_Add Schedule',
            ScheduleInterview_DeleteSchedule: 'Schedule Interview_Delete Schedule',
            ScheduleInterview_EditSchedule: 'Schedule Interview_Edit Schedule',
            ScheduleInterview_PreviewMail: 'Schedule Interview_Preview Mail',
            ScheduleInterview_ViewScheduleInterview: 'Schedule Interview_View Schedule Interview',

            //start interview
            StartInterview_AddInterview: 'Schedule Interview_Add Interview',
            StartInterview_EditInterview: 'Schedule Interview_Edit Interview',
            StartInterview_ViewInterview: 'Schedule Interview_View Interview',

            UpdateOfferStatus_UpdateOfferStatus: 'Update Offer Status_Update Offer Status',
            UpdateOfferStatus_ViewStatusOfferLetter: 'Update Offer Status_View Status Offer Letter',
            UpdateOfferStatus_ResendOfferLetter: 'Update Offer Status_Resend Offer Letter',
            ViewEmployeeofTeam_ViewTeamEmployee: 'View Employee of Team_View Team Employee',

            WorkingTeam_AddTeam: 'Teams_Add Team',
            WorkingTeam_EditTeam: 'Teams_Edit Team',
            WorkingTeam_ViewTeam: 'Teams_View Team',

            Company_ViewCompanies: 'Companies_View Companies',
            Company_AddCompany: 'Companies_Add Company',
            Company_EditCompany: 'Companies_Edit Company',
            Company_DeleteCompany: 'Companies_Delete Company',
            Company_ViewDetail: 'Companies_View Detail',

            Candidates_AddCandidate: 'Candidates_Add Candidate',
            Candidates_SendMailUpdateCV: 'Candidates_Send Mail Update CV',
            Candidates_ViewCandidates: 'Candidates_View Candidates',
            Candidates_DeleteCandidates: 'Candidates_Delete Candidates',
            Candidates_RestoreCandidates: 'Candidates_Restore deleted Candidates',
            Candidates_SetResponseCandidates: 'Candidates_Set User Responsible for Candidates',
            Candidates_RemoveResponseCandidates: 'Candidates_Remove User Responsible for Candidates',
            Candidates_UpdateCandidateTag: 'Candidates_Update candidate tag',
            Candidates_SendJobInvitation: 'Candidates_Send Job Invitation',
            Candidates_UpdateJobInvitation: 'Candidates_Update Job Invitation',
            Candidates_ToolbarAccessOnCandidatesListing: 'Candidates_Toolbar access on Candidates Listing',
            Candidates_CustomizeColumnsOnCandidatesListing: 'Candidates_Customize columns on Candidates Listing',
            //DashBoard
            Dashboard_ViewLatestApplications: 'Dashboard_View Latest Applications',
            Dashboard_ViewLatestCvUpdates: 'Dashboard_View Latest CV Updates',
            Dashboard_ViewJobsSnapshot: 'Dashboard_View Jobs Snapshot',
            Dashboard_ViewJobActivity: 'Dashboard_View Job Activity',
            Dashboard_ViewClosedJobs: 'Dashboard_View Closed Jobs',
            Dashboard_ViewClosingJobs: 'Dashboard_View Closing Jobs',

            // Approve
            ApproveLeave_ViewList: 'Approve Leave_View Approve Leave',
            ApproveLeave_Update: 'Approve Leave_Update Approve Leave',
            ApproveLeave_ViewDetail: 'Approve Leave_View Approve Leave Detail',

            // Verify
            VerifyLeave_ViewList: 'Verify Leave_Verify Leave List',
            VerifyLeave_Update: 'Verify Leave_Update Verify Leave',
            VerifyLeave_ViewDetail: 'Verify Leave_Verify Leave Detail',

            // Payment
            Payment_ViewList: 'Payment_View Payment',
            Payment_ViewDetail: 'Payment_View Payment Detail',
            Payment_UpdatePayment: 'Payment_Update Payment',
            Payment_AddPayment: 'Payment_Add Payment',

            // Formula
            Formula_ViewList: 'Formula_View Formula',
            Formula_UpdateFormula: 'Formula_Update Formula',
            Formula_DeleteFormula: 'Formula_Delete Formula',
            Formula_AddFormula: 'Formula_Add Formula',

            // Payment Formula
            PaymentFormula_ViewList: 'Payment Formula_View Payment Formula',
            PaymentFormula_Update: 'Payment Formula_Update Payment Formula',
            PaymentFormula_Add: 'Payment Formula_Add Payment Formula',

            // Payroll File
            PayrollFile_ViewList: 'Payroll File_View Payroll File',
            PayrollFile_AddPayrollFile: 'Payroll File_Add Payroll File',
            PayrollFile_Delete: 'Payroll File_Delete Payroll File',

            // Leave Type
            LeaveType_ViewList: 'Leave Type_View Leave Type',
            LeaveType_Update: 'Leave Type_Update Leave Type',
            LeaveType_Delete: 'Leave Type_Delete Leave Type',
            LeaveType_Add: 'Leave Type_Insert Leave Type',

            // Holiday
            Holiday_ViewList: 'Payroll Setting_View Holiday',
            Holiday_Update: 'Payroll Setting_Update Holiday',
            Holiday_Delete: 'Payroll Setting_Delete Holiday',
            Holiday_Add: 'Payroll Setting_Insert Holiday',

            // Paylist
            Payslip_View: 'Payslip_View Payslip',

            // Payroll Setting
            PayrollSetting: 'Payroll Setting_Edit Balance Leave',

            // Leave Information
            LeaveInformation_View: 'Leave Information_View Leave Information',
            LeaveInformation_Insert: 'Leave Information_Insert Leave Information',
            LeaveInformation_Update: 'Leave Information_Update Leave Information',
            LeaveInformation_Delete: 'Leave Information_Delete Leave Information',
            LeaveInformation_Export: 'Leave Information_Export Leave Information',
            LeaveInformation_ViewAllLeave: 'view all leaves_view all leaves',

            // Working Hour
            WorkingHour_View: 'Working hours_View working hour',

            //Users Management
            Users_ViewUsers: 'Users_View Users',
            Users_ViewUserDetail: 'Users_View User Detail',
            Users_Add: 'Users_Add User',
            Users_Edit: 'Users_Edit User',
            Users_Delete: 'Users_Delete User',
            Users_ToggleActiveStatus: 'Users_Toggle User Active status',
            Users_CreateUsersForOtherCompanies: 'Users_Create users for other companies'

        };
        var currentUserPermissions = {
            canAddRoleMember: isHavePermission(permissionNameConstant.AddMemberstoRole_AddRoleMember),
            canViewRoleMember: isHavePermission(permissionNameConstant.AddMemberstoRole_ViewRoleMember),

            canAddCandidateInfo: isHavePermission(permissionNameConstant.CandidateInfo_AddCandidateInfo),
            canDeleteCandidateInfo: isHavePermission(permissionNameConstant.CandidateInfo_DeleteCandidateInfo),
            canViewCandidateInfo: isHavePermission(permissionNameConstant.CandidateInfo_ViewCandidateInfo),
            canViewEmailCorrespondence: isHavePermission(permissionNameConstant.CandidateInfo_ViewEmailCorrespondence),
            canEditCandidateInfo: isHavePermission(permissionNameConstant.CandidateInfo_EditCandidateInfo),
            canCheckEmailCandidate: isHavePermission(permissionNameConstant.CandidateInfo_CheckEmailCandidate),
            canResetPassword: isHavePermission(permissionNameConstant.CandidateInfo_Resetpassword),
            canSendApplicationEmail: isHavePermission(permissionNameConstant.CandidateInfo_SendAppliedPositionEmail),
            canViewCandidateSelectionProcessSection: isHavePermission(permissionNameConstant.CandidateInfo_ViewSelectionProcessSection),
            canViewCandidateEmailsSection: isHavePermission(permissionNameConstant.CandidateInfo_ViewEmailsSection),
            canViewCandidateDiscussionSection: isHavePermission(permissionNameConstant.CandidateInfo_ViewDiscussionSection),
            canViewCandidateAdministrationSection: isHavePermission(permissionNameConstant.CandidateInfo_ViewAdministrationSection),
            canAddCandidateAppliedPosition: isHavePermission(permissionNameConstant.CandidateInfo_AddAppliedPosition),
            canEditCandidateAppliedPosition: isHavePermission(permissionNameConstant.CandidateInfo_EditAppliedPosition),
            canDeleteCandidateAppliedPosition: isHavePermission(permissionNameConstant.CandidateInfo_DeleteAppliedPosition),
            canDownloadCandidateDocuments: isHavePermission(permissionNameConstant.CandidateInfo_DownloadDocuments),

            canSendJobInvitation: isHavePermission(permissionNameConstant.Candidates_SendJobInvitation),
            canUpdateInvitation: isHavePermission(permissionNameConstant.Candidates_UpdateJobInvitation),
            canToolbarAccessOnCandidatesListing: isHavePermission(permissionNameConstant.Candidates_ToolbarAccessOnCandidatesListing),
            canCustomizeColumnsOnCandidatesListing: isHavePermission(permissionNameConstant.Candidates_CustomizeColumnsOnCandidatesListing),

            canAddCandidateInforOnline: isHavePermission(permissionNameConstant.CandidateOnlineInfo_AddCandidateInfo),
            canChangePasswordCandidateOnline: isHavePermission(permissionNameConstant.CandidateOnlineInfo_Changepassword),
            canEditCandidateOnline: isHavePermission(permissionNameConstant.CandidateOnlineInfo_EditCandidateInfo),
            canViewCandidateOnline: isHavePermission(permissionNameConstant.CandidateOnlineInfo_ViewCandidateInfo),

            canEditOfferLetter: isHavePermission(permissionNameConstant.CreateOfferLetter_EditOfferLetter),
            canViewOfferLetterPage: isHavePermission(permissionNameConstant.CreateOfferLetter_ViewOfferLetterPage),
            canSendOfferLetter: isHavePermission(permissionNameConstant.CreateOfferLetter_SendOfferLetter),

            canAddEmployeeContract: isHavePermission(permissionNameConstant.Employeecontract_AddContract),
            canUpdateEmployeeContract: isHavePermission(permissionNameConstant.Employeecontract_UpdateContract),
            canUploadFileEmployee: isHavePermission(permissionNameConstant.Employeecontract_Uploadfile),
            canViewEmployeeContract: isHavePermission(permissionNameConstant.Employeecontract_ViewContract),
            canExportContract: isHavePermission(permissionNameConstant.Employeecontract_ExportContract),
            canUpdateEmployeeContractUpdate: isHavePermission(permissionNameConstant.Employeecontractupdate_Updatecontract),
            canUploadEmployeeContractUpdate: isHavePermission(permissionNameConstant.Employeecontractupdate_Uploadfile),
            canViewEmployeeContractUpdate: isHavePermission(permissionNameConstant.Employeecontractupdate_Viewcontract),

            canUpdateEmployeeInfoCV: isHavePermission(permissionNameConstant.EmployeeInfo_UpdateCV),
            canAddEmployeeInfo: isHavePermission(permissionNameConstant.EmployeeInfo_AddEmployeeInfo),
            canBecomeEmployee: isHavePermission(permissionNameConstant.EmployeeInfo_BecomeEmployee),
            canDeleteEmployeeInfo: isHavePermission(permissionNameConstant.EmployeeInfo_DeleteEmployeeInfo),
            canEditEmployeeInfo: isHavePermission(permissionNameConstant.EmployeeInfo_EditEmployeeInfo),
            canUpdateOwnerInformation: isHavePermission(permissionNameConstant.EmployeeInfo_UpdateOwnerCV),
            canSendMailWelcome: isHavePermission(permissionNameConstant.EmployeeInfo_SendMailWelcome),
            canViewEmployeeInfo: isHavePermission(permissionNameConstant.EmployeeInfo_ViewEmployeeInfo),

            canAddEmployee: isHavePermission(permissionNameConstant.Employees_AddEmployee),
            canViewEmployees: isHavePermission(permissionNameConstant.Employees_ViewEmployees),

            canViewScheduleInterview: isHavePermission(permissionNameConstant.Interviewschedule_ViewInterviewSchedule),
            //letter template
            canEditLetterTemplate: isHavePermission(permissionNameConstant.LetterTemplates_EditLetterTemplate),
            canViewLetterTemplate: isHavePermission(permissionNameConstant.LetterTemplates_ViewLetterTemplates),

            canLogin: isHavePermission(permissionNameConstant.Login_Login),
            canLogout: isHavePermission(permissionNameConstant.Login_Logout),
            canLoginOnline: isHavePermission(permissionNameConstant.LoginOnline_Login),
            canLogOutOnline: isHavePermission(permissionNameConstant.LoginOnline_Logout),

            //open position
            canViewOpenPositionDetail: isHavePermission(permissionNameConstant.OpenPositions_ViewOpenPositionDetail),
            canAddNewOpenPosition: isHavePermission(permissionNameConstant.OpenPositions_AddNewOpenPosition),
            canDeleteOpenPosition: isHavePermission(permissionNameConstant.OpenPositions_DeleteOpenPosition),
            canEditOpenPosition: isHavePermission(permissionNameConstant.OpenPositions_EditOpenPosition),
            canPreviewMailOpenPosition: isHavePermission(permissionNameConstant.OpenPositions_PreviewEmailOpenPosition),
            canViewOpenPositions: isHavePermission(permissionNameConstant.OpenPositions_ViewOpenPositions),
            canCustomizeColumnsOnJobsListing: isHavePermission(permissionNameConstant.OpenPositions_CustomizeColumnsOnJobsListing),
            //position template

            canAddPositionTemplate: isHavePermission(permissionNameConstant.PositionTemplates_AddPositionTemplate),
            canEditPositionTemplate: isHavePermission(permissionNameConstant.PositionTemplates_EditPositionTemplate),
            canViewPositionTemplateDetail: isHavePermission(permissionNameConstant.PositionTemplates_ViewDetail),
            canViewPositionTemplates: isHavePermission(permissionNameConstant.PositionTemplates_ViewPositionTemplates),

            canAddProbation: isHavePermission(permissionNameConstant.ProbationAppraisal_Addprobation),
            canEditProbation: isHavePermission(permissionNameConstant.ProbationAppraisal_Editprobation),
            canViewProbation: isHavePermission(permissionNameConstant.ProbationAppraisal_Viewprobation),
            //role
            canAddRole: isHavePermission(permissionNameConstant.Roles_AddRole),
            canDeleteRole: isHavePermission(permissionNameConstant.Roles_DeleteRole),
            canEditRole: isHavePermission(permissionNameConstant.Roles_EditRole),
            canViewRoles: isHavePermission(permissionNameConstant.Roles_ViewRoles),
            //position
            canAddPosition: isHavePermission(permissionNameConstant.Positions_Add),
            canDeletePosition: isHavePermission(permissionNameConstant.Positions_Delete),
            canEditPosition: isHavePermission(permissionNameConstant.Positions_Edit),
            canViewPositions: isHavePermission(permissionNameConstant.Positions_View),
            //remind candidate update cv
            canViewRemindCandidates: isHavePermission(permissionNameConstant.RemindCandidates_View),
            canAddRemindCandidates: isHavePermission(permissionNameConstant.RemindCandidates_Add),
            canEditRemind: isHavePermission(permissionNameConstant.RemindCandidates_Edit),

            //schedule interview
            canAddSchedule: isHavePermission(permissionNameConstant.ScheduleInterview_AddSchedule),
            canDeleteSchedule: isHavePermission(permissionNameConstant.ScheduleInterview_DeleteSchedule),
            canEditSchedule: isHavePermission(permissionNameConstant.ScheduleInterview_EditSchedule),
            canPreviewScheduleMail: isHavePermission(permissionNameConstant.ScheduleInterview_PreviewMail),
            canViewSchedule: isHavePermission(permissionNameConstant.ScheduleInterview_ViewScheduleInterview),

            //start interview
            canAddInterview: isHavePermission(permissionNameConstant.StartInterview_AddInterview),
            canEditInterview: isHavePermission(permissionNameConstant.StartInterview_EditInterview),
            canViewInterview: isHavePermission(permissionNameConstant.StartInterview_ViewInterview),

            canUpdateOfferLetterStatus: isHavePermission(permissionNameConstant.UpdateOfferStatus_UpdateOfferStatus),
            canViewOfferLetterStatus: isHavePermission(permissionNameConstant.UpdateOfferStatus_ViewStatusOfferLetter),
            canResendOfferLetter: isHavePermission(permissionNameConstant.UpdateOfferStatus_ResendOfferLetter),
            canViewTeamEmployee: isHavePermission(permissionNameConstant.ViewEmployeeofTeam_ViewTeamEmployee),
            canAddTeam: isHavePermission(permissionNameConstant.WorkingTeam_AddTeam),
            canEditTeam: isHavePermission(permissionNameConstant.WorkingTeam_EditTeam),
            canViewTeam: isHavePermission(permissionNameConstant.WorkingTeam_ViewTeam),
            canViewCompanies: isHavePermission(permissionNameConstant.Company_ViewCompanies),
            canAddCompany: isHavePermission(permissionNameConstant.Company_AddCompany),
            canEditCompany: isHavePermission(permissionNameConstant.Company_EditCompany),
            canDeleteCompany: isHavePermission(permissionNameConstant.Company_DeleteCompany),
            canViewCompanyDetail: isHavePermission(permissionNameConstant.Company_ViewDetail),
            canAddCandidate: isHavePermission(permissionNameConstant.Candidates_AddCandidate),
            canSendMailUpdateCandidateCV: isHavePermission(permissionNameConstant.Candidates_SendMailUpdateCV),
            canViewCandidate: isHavePermission(permissionNameConstant.Candidates_ViewCandidates),
            canDeleteCandidate: isHavePermission(permissionNameConstant.Candidates_DeleteCandidates),
            canRestoreCandidate: isHavePermission(permissionNameConstant.Candidates_RestoreCandidates),
            canSetResponseCandidate: isHavePermission(permissionNameConstant.Candidates_SetResponseCandidates),
            canRemoveResponeCandidate: isHavePermission(permissionNameConstant.Candidates_RemoveResponseCandidates),
            canUpdateCandidateTag: isHavePermission(permissionNameConstant.Candidates_UpdateCandidateTag),
            canViewLatestApplications: isHavePermission(permissionNameConstant.Dashboard_ViewLatestApplications),
            canViewLatestCvUpdates: isHavePermission(permissionNameConstant.Dashboard_ViewLatestCvUpdates),
            canViewJobsSnapshot: isHavePermission(permissionNameConstant.Dashboard_ViewJobsSnapshot),
            canViewJobActivity: isHavePermission(permissionNameConstant.Dashboard_ViewJobActivity),
            canViewClosedJobs: isHavePermission(permissionNameConstant.Dashboard_ViewClosedJobs),
            canViewClosingJobs: isHavePermission(permissionNameConstant.Dashboard_ViewClosingJobs),
            canViewDashboard: checkGroupOfPermissionCondition([isHavePermission(permissionNameConstant.Dashboard_ViewLatestApplications),
                                                            isHavePermission(permissionNameConstant.Dashboard_ViewLatestCvUpdates),
                                                            isHavePermission(permissionNameConstant.Dashboard_ViewJobsSnapshot),
                                                            isHavePermission(permissionNameConstant.Dashboard_ViewJobActivity)]),

            canViewUsers: isHavePermission(permissionNameConstant.Users_ViewUsers),
            canViewUserDetail: isHavePermission(permissionNameConstant.Users_ViewUserDetail),
            canAddUser: isHavePermission(permissionNameConstant.Users_Add),
            canEditUser: isHavePermission(permissionNameConstant.Users_Edit),
            canDeleteUser: isHavePermission(permissionNameConstant.Users_Delete),
            canToggleUserActiveStatus: isHavePermission(permissionNameConstant.Users_ToggleActiveStatus),
            canCreateUsersForOtherCompanies: isHavePermission(permissionNameConstant.Users_CreateUsersForOtherCompanies)
        };

        return {
            getCurrentUserPermission: getCurrentUserPermission,
            permissionNameConstant: permissionNameConstant,
            isHavePermission: isHavePermission,
            checkGroupOfPermissionCondition: checkGroupOfPermissionCondition
        };

        function checkGroupOfPermissionCondition(array) {
            var result = array.filter(function (item) {
                return item === true;
            });
            return !(('' + result) === '');
        }

        function getCurrentUserPermission() {
            return currentUserPermissions;
        }

        function isHavePermission(key) {
            var currentUser = JSON.parse($window.localStorage.getItem("currentuserlogin"));
            if (!currentUser) {
                authSvc.logout();
                return;
            }

            currentUser.ListPermissions = $.jStorage.get('ListPermissions');
            if (comparisonUtilSvc.isNullOrUndefinedValue(currentUser.ListPermissions)) return false;
            var result = _.find(currentUser.ListPermissions, function (item) {
                return item.FormName.replace(/\r\n/gi, "") + '_' + item.PermissionName == key;
            });
            return comparisonUtilSvc.isNullOrUndefinedValue(result) ? false : true;
        }
    }
})();