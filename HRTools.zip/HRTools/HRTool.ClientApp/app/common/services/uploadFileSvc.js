﻿(function () {

    'use strict';

    angular.module('app').factory('uploadFileSvc', uploadFileSvc);

    uploadFileSvc.$inject = ['$resource', 'constants', 'caConstants', 'adConstants'];

    function uploadFileSvc($resource, constants, caConstants, adConstants) {
        return {
            uploadFile: uploadFile,
            uploadEmployeeImage: uploadEmployeeImage,
            uploadFileMp3: uploadFileMp3
        };

        function encodeUTF8(source) {
            return unescape(encodeURIComponent(source));
        }

        function uploadFile(fileUpload, actionName, value) {
            var uploadForm = new FormData();
            uploadForm.append('file', fileUpload);

            return $resource(constants.apiUrl + 'files', {}, {
                'upload': {
                    method: 'POST',
                    transformRequest: angular.identity,
                    headers: { 'Content-Type': undefined, 'ActionName': actionName, 'Value': encodeUTF8(value) }
                }
            }).upload({}, uploadForm);
        }

        function uploadEmployeeImage(fileUpload, actionName, fullName, imagePath) {
            var uploadForm = new FormData();
            uploadForm.append('file', fileUpload);

            return $resource(constants.apiUrl + 'files', {}, {
                'upload': {
                    method: 'POST',
                    transformRequest: angular.identity,
                    headers: { 'Content-Type': undefined, 'ActionName': actionName, 'Value': encodeUTF8(fullName), 'ImagePath': imagePath }
                }
            }).upload({}, uploadForm);
        }

        function uploadFileMp3(fileUpload, fileName, fileNameHeader) {
            var uploadForm = new FormData();
            uploadForm.append("audio", fileUpload, fileName);

            return $resource(constants.apiUrl + 'upload/conduct-interview', {}, {
                'upload': {
                    method: 'POST',
                    transformRequest: angular.identity,
                    headers: { 'Content-Type': undefined, 'FileName': encodeUTF8(fileNameHeader) }
                }
            }).upload({}, uploadForm);
        }
    }
})();