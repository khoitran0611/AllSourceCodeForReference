﻿(function () {
    'use strict';
    angular.module('app').factory('authenticationSvc', authenticationSvc);
    authenticationSvc.$inject = ["$resource", "$location", "constants", "$rootScope", "$window", "comparisonUtilSvc"];
    function authenticationSvc($resource, $location, constants, $rootScope, $window, comparisonUtilSvc) {
        var loginUrl = constants.apiUrl + "user-login/permissions";
        var baseUrl = constants.baseUrl;

        return {
            getPermissions: getPermissions
        };

        function getPermissions() {
            $resource(loginUrl).get().$promise.then(function (data) {
                if (arrayResourceToString(data) == "null") {
                    $location.path('/error').replace();
                    $rootScope.$broadcast('gotPermissions', { permissionState: false });
                    $window.localStorage.removeItem("currentuserlogin");
                    return;
                }
                if (!comparisonUtilSvc.isNullOrUndefinedValue(data.Menu)) {
                    if (data.Menu.AdminMenus && data.Menu.AdminMenus.ChildMenus)
                        data.Menu.AdminMenus.ChildMenus = correctUrl(data.Menu.AdminMenus.ChildMenus);
                    if (data.Menu.GeneralMenus)
                        data.Menu.GeneralMenus = correctUrl(data.Menu.GeneralMenus);
                    $.jStorage.deleteKey("candidatesearch");
                    $.jStorage.set("menus", data.Menu);
                    $.jStorage.set("configMenu", data.ShowSSOSurveyToolLink);
                }
                $.jStorage.set('ListPermissions', data.ListPermissions);
                var employeeUser = 2;
                var dataStorage = {
                    "UserId": data.UserId,
                    "FullName": data.FullName,
                    "UserType": employeeUser,
                    "TokenKey": data.Token,
                    "FirstName": data.FirstName,
                    "LastName": data.LastName,
                    "RoleName": data.RoleName,
                    "CompanyId": data.CompanyId,
                    "CompanyName": data.Company,
                    "Flag": true,
                    "ListPermissions": [],
                    "JobApplicationId": "",
                    "CandidateEmail": "",
                    "CandidateName": "",
                    "PositionName": "",
                    "QuizTestStatus": "",
                    "__moduleId__": "model/current-user"
                };
                $window.localStorage.setItem("currentuserlogin", JSON.stringify(dataStorage));
                $rootScope.$broadcast('gotPermissions', { permissionState: true });
                $location.path('/').replace();
            },
            function () {
                $("#body").addClass("main-body");
            });
        }

        function correctUrl(urlArray) {
            for (var i = 0; i < urlArray.length; i++) {
                urlArray[i].Url = baseUrl + urlArray[i].Url;
            }
            return urlArray;
        }
    }
})();
