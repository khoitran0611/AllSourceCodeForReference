﻿(function () {
    'use strict';
    angular.module('app').factory('countrySvc', countrySvc);
    countrySvc.$inject = ['$resource', 'constants'];
    function countrySvc($resource, constants) {
        var service = {
            getAllCountries: getAllCountries
        };

        return service;

        function getAllCountries() {
            return $resource(constants.apiUrl + 'countries');
        }
    }
})();