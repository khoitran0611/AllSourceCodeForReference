﻿(function () {
    angular
        .module('app')
        .service('loadingSvc', loadingSvc);

    loadingSvc.$inject = ['constants'];

    function loadingSvc(constants) {
        var service = {
            show: show,
            close: close
        };

        return service;

        function show() {
            var overlay = angular.element(constants.loadingIcon.overlay),
                indicator = angular.element(constants.loadingIcon.indicator);

            if (overlay) {
                overlay.show();
            }
            if (indicator) {
                indicator.show();
            }
        }

        function close() {
            var overlay = angular.element(constants.loadingIcon.overlay),
                indicator = angular.element(constants.loadingIcon.indicator);

            if (overlay) {
                overlay.hide();
            }
            if (indicator) {
                indicator.hide();
            }
        }
    }
})();