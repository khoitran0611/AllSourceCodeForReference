﻿(function () {
    "use strict";
    angular.module('app').service('handleRequestSvc',
        function () {
            var responseSuccess = 't';
            var result = function (response) {
                return response[0] == responseSuccess ? true : false;
            };
            return {
                result: result
            };

        });
})();