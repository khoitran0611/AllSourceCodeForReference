﻿(function () {
    'use strict';
    angular.module('app').factory('positionSvc', positionSvc);
    positionSvc.$inject = ["$resource", 'constants'];
    function positionSvc($resource, constants) {
        var getAllPositions = function () {
            return $resource(constants.apiUrl + 'positions', { action: "getAllPositions" });
        };
        var getWholeCompanyPositions = function () {
            return $resource(constants.apiUrl + 'positions', { action: "getWholeCompanyPositions" });
        };
        var getJobCodes = function () {
            return $resource(constants.apiUrl + 'jobcodes', {}, { 'get': { method: "GET", isArray: true } });
        };

        var getPositionTemplates = function (filter) {
            return $resource(constants.apiUrl + 'positiontemplates', { filter: filter }).get();
        };
        var getAllPositionForSearching = function () {
            return $resource(constants.apiUrl + 'positions', { action: "getAllPositionForSearching" });
        };
        return {
            getAllPositions: getAllPositions,
            getWholeCompanyPositions: getWholeCompanyPositions,
            getJobCodes: getJobCodes,
            getPositionTemplates: getPositionTemplates,
            getAllPositionForSearching: getAllPositionForSearching
        };
    }
})();
