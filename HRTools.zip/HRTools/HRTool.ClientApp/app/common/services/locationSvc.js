﻿
(function () {
    'use strict';
    angular.module('app').factory('locationSvc', locationSvc);
    function locationSvc() {
        var revealed = {
            generateGoogleMapLink: generateGoogleMapLink,
            combineAddress: combineAddress
        };

        return revealed;

        function combineLocation(data) {
            var locationParts = [data.Address, data.City, data.State, data.Country];
            return locationParts.filter(function (part) {
                return part !== null && part !== undefined && part !== '';
            }).join(', ');
        }

        function generateGoogleMapLink(data) {
            if (!data) return "";
            var address = combineLocation(data).replace(/ /g, "+");
            return address === "" ? "" : "https://www.google.com/maps/search/" + address;
        }

        function combineAddress(data) {
            if (!data) return "";
            var addressParts = [data.Address2, data.Address];
            return addressParts.filter(function (part) {
                return part !== null && part !== undefined && part !== '';
            }).join(', ');
        }
    }
})();