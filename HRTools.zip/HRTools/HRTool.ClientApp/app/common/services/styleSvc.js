﻿(function () {
    'use strict';
    angular.module('app').factory('styleSvc', styleSvc);
    styleSvc.$inject = ['constants', 'enumGlyphicon', '$filter'];
    function styleSvc(constants, enumGlyphicon, $filter) {
        var hideButtonGoTop = function () {
            $(document).ready(function () {
                $('#back-top').hide();
                $(function () {
                    $(window).scroll(function () {
                        if ($(this).scrollTop() > 100) {
                            $('#back-top').fadeIn();
                        } else {
                            $('#back-top').fadeOut();
                        }
                    });
                });
            });
        };

        var setTitle = function (status) {
            switch (status + '') {
                case constants.applicationStatus.ScreeningCv.New:
                    return constants.interviewResult.newText;
                case constants.applicationStatus.ScreeningCv.Passed:
                    return constants.interviewResult.passText;
                case constants.applicationStatus.ScreeningCv.Rejected:
                    return constants.interviewResult.rejectText;
                case constants.applicationStatus.ScreeningCv.OnHold:
                    return constants.interviewResult.onHoldText;
                case constants.applicationStatus.ScreeningCv.Interested:
                    return constants.interviewResult.interestedText;
                case constants.applicationStatus.ScreeningCv.BlackList:
                    return constants.interviewResult.blackListTilte;
                case constants.applicationStatus.Other.Shortlist:
                    return constants.interviewResult.shortlistedText;

                case constants.applicationStatus.FirstInterview.Passed:
                case constants.applicationStatus.SecondInterview.Passed:
                case constants.applicationStatus.ThirdInterview.Passed:
                    return constants.interviewResult.passText;
                case constants.applicationStatus.FirstInterview.Rejected:
                case constants.applicationStatus.SecondInterview.Rejected:
                case constants.applicationStatus.ThirdInterview.Rejected:
                case constants.applicationStatus.Other.RejectAll:
                    return constants.interviewResult.rejectText;
                default:
                    return constants.applicationStatus.ScreeningCv.newUnknown;
            }
        };

        var setStatusCss = function (statusId) {
            switch (statusId + '') {
                case constants.applicationStatus.ScreeningCv.BlackList:
                    return 'label-warning';
                case constants.applicationStatus.ScreeningCv.Passed:
                case constants.applicationStatus.FirstInterview.Passed:
                case constants.applicationStatus.SecondInterview.Passed:
                case constants.applicationStatus.ThirdInterview.Passed:
                case constants.applicationStatus.OfferStatus.AcceptOffer:
                    return 'label-success';
                case constants.applicationStatus.ScreeningCv.OnHold:
                    return 'label-info';
                case constants.applicationStatus.ScreeningCv.Rejected:
                case constants.applicationStatus.FirstInterview.Rejected:
                case constants.applicationStatus.SecondInterview.Rejected:
                case constants.applicationStatus.ThirdInterview.Rejected:
                    return 'label-danger';
                case constants.applicationStatus.ScreeningCv.Interested:
                    return 'label-primary';
                default:
                    return 'label-default';
            }
        };

        var setStatus = function (status) {
            switch (status + '') {
                case constants.applicationStatus.ScreeningCv.Passed:
                case constants.interviewResult.passForSort:
                case constants.interviewResult.passText:
                    return enumGlyphicon.glyphiconPass;
                case constants.applicationStatus.ScreeningCv.Rejected:
                case constants.interviewResult.rejectText:
                    return enumGlyphicon.glyphiconReject;
                case constants.applicationStatus.ScreeningCv.OnHold:
                    return enumGlyphicon.glyphiconOnHold;
                case constants.applicationStatus.ScreeningCv.Open:
                    return enumGlyphicon.glyphiconStatusOpen;
                case constants.applicationStatus.ScreeningCv.BlackList:
                    return enumGlyphicon.glyphiconStatusBlackList;
                case constants.interviewResult.scheduledDate:
                    return enumGlyphicon.glyphiconCalendar;
                default:
                    return '';
            }
        };

        var getHeaderStyle = function (isEditMode) {
            var headerCss = isEditMode ? constants.editModeHeader : constants.viewModeHeader;
            return headerCss;
        };

        function convertJobApplicationStatus(jobApplication) {
            if (!jobApplication)
                return constants.applicationStatus.ScreeningCv.newUnknown;
            var status = jobApplication.OverallStatus + '';
            // Interviewing
            if ((status == constants.applicationStatus.ScreeningCv.Passed && jobApplication.FirstInterviewBookRoomDate) ||
                (status == constants.applicationStatus.ScreeningCv.Interested && jobApplication.FirstInterviewBookRoomDate)) return "Interviewing";
            switch (status) {
                // Interviewing
                case constants.applicationStatus.FirstInterview.New:
                case constants.applicationStatus.FirstInterview.Passed:
                case constants.applicationStatus.FirstInterview.Rejected:
                case constants.applicationStatus.SecondInterview.New:
                case constants.applicationStatus.SecondInterview.Passed:
                case constants.applicationStatus.SecondInterview.Rejected:
                case constants.applicationStatus.ThirdInterview.New:
                case constants.applicationStatus.ThirdInterview.Passed:
                case constants.applicationStatus.ThirdInterview.Rejected: return $filter(constants.translate)("Status.Interviewing");
                    //Offer status
                case constants.applicationStatus.OfferStatus.AcceptOffer: return $filter(constants.translate)("Status.Hired");
                case constants.applicationStatus.OfferStatus.AlreadySent:
                case constants.applicationStatus.OfferStatus.HasOffer: return $filter(constants.translate)("Status.Offered");
                case constants.applicationStatus.OfferStatus.RejectOffer: return $filter(constants.translate)("Status.Offer_Rejected");
                    // Other status
                case constants.applicationStatus.Other.Shortlist: return $filter(constants.translate)("Status.Shortlisted");
                case constants.applicationStatus.Other.RejectAll: return $filter(constants.translate)("Status.Rejected");
                case constants.applicationStatus.Other.BecomeEmployee: return $filter(constants.translate)("Status.Become_Employee");
                    // CV status
                case constants.applicationStatus.ScreeningCv.Passed: return $filter(constants.translate)("Status.CV_Passed");
                case constants.applicationStatus.ScreeningCv.New: return $filter(constants.translate)("Status.CV_New");
                case constants.applicationStatus.ScreeningCv.Rejected: return $filter(constants.translate)("Status.CV_Rejected");
                case constants.applicationStatus.ScreeningCv.OnHold: return $filter(constants.translate)("Status.CV_On_Hold");
                case constants.applicationStatus.ScreeningCv.BlackList: return $filter(constants.translate)("Status.CV_Black_List");
                case constants.applicationStatus.ScreeningCv.Interested: return $filter(constants.translate)("Status.CV_Interested");
                default: return constants.applicationStatus.ScreeningCv.newUnknown;
            }

        }

        /* Consider delete this function? */
        var setPositionCss = function (statusId) {
            var css = '';
            switch (statusId) {
                case constants.interviewResult.inProgressText:
                    css = 'label-default';
                    break;
                case constants.interviewResult.newText:
                    css = 'label-default';
                    break;
                case constants.interviewResult.rejectText:
                    css = 'label-warning';
                    break;
                case constants.interviewResult.passText:
                    css = 'label-success';
                    break;
                case constants.interviewResult.onHoldText:
                    css = 'label-info';
                    break;
                case constants.interviewResult.blackListText:
                    css = 'label-danger';
                    break;
                case constants.interviewResult.successfulText:
                    css = 'label-success';
                    break;
            }
            return css;
        };

        var setJobStatus = function (status) {
            status = status.toLowerCase();
            var cssClass = 'job-status-label ';
            if (status == constants.jobStatus.New) {
                cssClass += 'status-new';
                return cssClass;
            }
            if (status == constants.jobStatus.Published) {
                cssClass += 'status-publish';
                return cssClass;
            }
            if (status == constants.jobStatus.Closed) {
                cssClass += 'status-close';
                return cssClass;
            }
            if (status == constants.jobStatus.Ended) {
                cssClass += 'status-ended';
                return cssClass;
            }
            return cssClass;
        };

        var setPositionStatus = function (status) {

            switch (status) {
                case "New":
                case "0":
                case 0:
                    return { css: "position-status-new", text: "New" };
                case "Published":
                case "3":
                case 3:
                    return { css: "position-status-published", text: "Published" };
                case "Closed":
                case "4":
                case 4:
                    return { css: "position-status-closed", text: "Closed" };
                case "Ended":
                case "5":
                case 5:
                    return { css: "position-status-ended", text: "Ended" };
                default:
                    return { css: "", text: "" };
            }
        };

        return {
            hideButtonGoTop: hideButtonGoTop,
            setTitle: setTitle,
            setStatus: setStatus,
            getHeaderStyle: getHeaderStyle,
            setStatusCss: setStatusCss,
            convertJobApplicationStatus: convertJobApplicationStatus,
            setPositionCss: setPositionCss,
            setJobStatus: setJobStatus,
            setPositionStatus: setPositionStatus
        };
    }
})();
