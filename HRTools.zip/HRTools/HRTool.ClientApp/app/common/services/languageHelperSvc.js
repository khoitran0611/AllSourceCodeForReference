(function () {
    'use strict';
    angular.module('app').factory('languageHelperSvc', LanguageHelperSvc);
    LanguageHelperSvc.$inject = ['$translate'];
    function LanguageHelperSvc($translate) {
        var self = this;
        self.lang = "EN";
        self.controlPrefix = ['admin', 'application', 'button', 'candidate', 'cv', 'cvDetail', 'dashboard', 'email', 'employee', 'job', 'general', 'information', 'interview', 'leave',
        'payment', 'payroll', 'role', 'search', 'skill', 'template'];
        var revealed = {
            getLanguage: getLanguage,
            loadControlLanguage: loadControlLanguage,
            changeLanguage: changeLanguage
        };
        return revealed;

        function getLanguage() {
            return 'en';
        }

        function loadControlLanguage(controlPrefix) {
            var currentLanguage = getLanguage();
            var languageFilePath = String.format('i18n/{1}/{0}-{1}.json', controlPrefix, currentLanguage);
            $translate.loadLang(currentLanguage, languageFilePath);
        }

        function changeLanguage() {
            var currentLanguage = getLanguage();
            if (self.lang != currentLanguage) {
                self.lang = currentLanguage;
                var promise = $translate.use(currentLanguage);
                promise.then(function () {
                    reloadAllActiveControls();
                });
            }
        }

        function reloadAllActiveControls() {
            var leng = self.controlPrefix.length;
            for (var i = 0; i < leng; i++) {
                loadControlLanguage(self.controlPrefix[i], true);
            }
        }
    }
})();


