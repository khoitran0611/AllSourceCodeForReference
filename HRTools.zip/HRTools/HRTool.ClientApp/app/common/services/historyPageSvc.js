﻿(function () {
    "use strict";
    angular.module('app').service('historyPageSvc',function () {
            var candidateIdKey = "currentCandidateIdIndexFromList";
            var service = {
                setPreviousUrl: setPreviousUrl,
                getPreviousUrl: getPreviousUrl,
                setPreviousTag: setPreviousTag,
                getPreviousTag: getPreviousTag,
                setPreviousQuery: setPreviousQuery,
                getPreviousQuery: getPreviousQuery,
                setPreviousRemoveField: setPreviousRemoveField,
                getPreviousRemoveField: getPreviousRemoveField,
                setCurrentCandidateIdIndex: setCurrentCandidateIdIndex,
                getCurrentCandidateIdIndex: getCurrentCandidateIdIndex
            };
            return service;

            function setPreviousUrl(currentUrl, previousUrl) {
                $.jStorage.set(currentUrl, previousUrl);
            }

            function getPreviousUrl(currentUrl) {
                return $.jStorage.get(currentUrl);
            }

            function setPreviousTag(currentUrl, tagName) {
                var url = currentUrl + "/tagIndex";
                $.jStorage.set(url, tagName);
            }

            function getPreviousTag(currentUrl) {
                var url = currentUrl + "/tagIndex";
                return $.jStorage.get(url);
            }

            function setPreviousQuery(currentUrl, query) {
                var url = currentUrl + "/query";
                $.jStorage.set(url, query);
            }

            function getPreviousQuery(currentUrl) {
                var url = currentUrl + "/query";
                return $.jStorage.get(url);
            }


            function setPreviousRemoveField(currentUrl, query) {
                var url = currentUrl + "/remove-field";
                $.jStorage.set(url, query);
            }

            function getPreviousRemoveField(currentUrl) {
                var url = currentUrl + "/remove-field";
                return $.jStorage.get(url);
            }

            function getCurrentCandidateIdIndex() {
                var value = $.jStorage.get(candidateIdKey);
                if (value === null || value === undefined) return -1;
                return value;
            }

            function setCurrentCandidateIdIndex(index) {
                $.jStorage.set(candidateIdKey, index);
            }
        });
})();