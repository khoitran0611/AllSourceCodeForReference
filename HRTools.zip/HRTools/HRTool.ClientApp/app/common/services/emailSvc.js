﻿(function () {
    'use strict';
    angular.module('app').factory('emailSvc', emailSvc);
    emailSvc.$inject = ['$resource', '$filter', 'messageHandleSvc', 'message', 'constants', 'caConstants'];
    function emailSvc($resource, $filter, messageHandleSvc, message, constants, caConstants) {
        var data = {
            emailDto: null
        };

        var urlEmail = constants.apiUrl + 'emails/:id';

        var resourceEmailSvc = $resource(urlEmail, {}, { 'getEmailTemplateByIdType': { method: 'GET', id: '@id', mailData: '@mailData' } });

        return {
            data: data,
            getEmailTempateByIdType: getEmailTempateByIdType,
            getEmail: getEmail,
            sendEmail: sendEmail,
            getLetter: getLetter,
            sendRejectEmail: sendRejectEmail,
            welcomeNewEmployeeEmail: welcomeNewEmployeeEmail,
            jobApplicationUpdateCvEmail: jobApplicationUpdateCvEmail,
            getEmailDataForRequestUpdateCv: getEmailDataForRequestUpdateCv,
            sendTheTemplateTextUpdated: sendTheTemplateTextUpdated,
            getEmailDataForThankYouLetter: getEmailDataForThankYouLetter,
            sendTheThankYouLetterTemplateTextUpdated: sendTheThankYouLetterTemplateTextUpdated,
            sendMultiThankYouLetter: sendMultiThankYouLetter
        };

        function getEmailTempateByIdType(idType, scheduleDetailDto, callback) {
            resourceEmailSvc.getEmailTemplateByIdType({ id: idType, mailData: JSON.stringify(scheduleDetailDto) }).$promise.then(function (result) {
                data.emailDto = result;
            }, function (error) {
                messageHandleSvc.handleResponse(error, $filter(constants.translate)(message.getEmailError));
            }).then(callback);
        }

        function getEmail(actionId, jobApplicationId) {
            return $resource(constants.apiUrl + 'emails/:actionId?mailData=:jobApplicationId', { actionId: actionId, jobApplicationId: jobApplicationId },
                { method: "GET", headers: { ActionName: "GetEmail" } });
        }

        function welcomeNewEmployeeEmail(employeeId) {
            return $resource(constants.apiUrl + 'employees/:id/email-new-comer', { id: employeeId });
        }

        function jobApplicationUpdateCvEmail(jobApplicationId) {
            return $resource(constants.apiUrl + 'job-applications/:id/email-update-cv', { id: jobApplicationId });
        }

        function sendEmail() {
            return $resource(constants.apiUrl + 'emails/', {}, { "send": { method: "POST", headers: { ActionName: "UpdateRequestEmail" } } });
        }

        function sendRejectEmail() {
            return $resource(constants.apiUrl + 'emails/', {}, { "send": { method: "POST", headers: { ActionName: "SendRejectMail" } } });
        }
        function getLetter(idType, offer) {
            return $resource(urlEmail, { method: 'GET', id: idType, mailData: JSON.stringify(offer) });
        }

        function getEmailDataForRequestUpdateCv() {
            return $resource(constants.apiUrl + 'email/email-update-cv', {});
        }

        function sendTheTemplateTextUpdated(jobApplicationId) {
            return $resource(constants.apiUrl + 'job-applications/:id/email-update-cv-first-candidate', { id: jobApplicationId });
        }

        function getEmailDataForThankYouLetter() {
            return $resource(constants.apiUrl + 'email/email-thank-you-letter', {});
        }

        function sendTheThankYouLetterTemplateTextUpdated(jobApplicationId) {
            return $resource(constants.apiUrl + 'job-applications/:id/email-thank-you-letter-first-candidate', { id: jobApplicationId });
        }

        function sendMultiThankYouLetter(param) {
            return $resource(constants.apiUrl + 'emails/', {},
            { "sendMultiThankYouLetter": { method: "POST", headers: { ActionName: "sendMultiThankYouLetter", DataJsonFormat: JSON.stringify(param) } } });
        }
    }
})();


