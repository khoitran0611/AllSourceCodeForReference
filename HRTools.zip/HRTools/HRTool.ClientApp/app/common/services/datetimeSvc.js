﻿(function () {
    'use strict';
    angular.module('app').factory('datetimeSvc', datetimeSvc);
    datetimeSvc.$inject = ['constants', 'comparisonUtilSvc'];
    function datetimeSvc(constants, comparisonUtilSvc) {
        var revealed = {
            convertDateForServer: convertDateForServer,
            convertDateForServerSide: convertDateForServerSide,
            convertDateHour: convertDateHour,
            getYears: getYears,
            getDayOfDate: getDayOfDate,
            convertDate: convertDate,
            getWorkingDaysBetweenDates: getWorkingDaysBetweenDates,
            formatDateFromServer: formatDateFromServer,
            convertToLongDate: convertToLongDate,
            convertDateToLongDate12HourFormat: convertDateToLongDate12HourFormat,
            convertDateToShortDate12HourFormat: convertDateToShortDate12HourFormat,
            compareDate: compareDate,
            convertToShortDateString: convertToShortDateString,
            convertStringToDate: convertStringToDate,
            isEqual: isEqual,
            convertDateNowToString: convertDateNowToString,
            isValidDateString: isValidDateString
        };

        return revealed;

        function convertDateForServer(date, isDateTime) {
            var dateFormat = isDateTime ? "YYYY-MM-DD HH:mm" : "YYYY-MM-DD";
            return moment(date).format(dateFormat);
        }

        function convertDateForServerSide(date, isDateTime) {
            if (comparisonUtilSvc.isNullOrUndefinedValue(date) || date === "") {
                return "";
            }
            var dateFormat = isDateTime ? "YYYY-MM-DD HH:mm" : "YYYY-MM-DD";
            if (typeof date === "string") {
                var dateInputFormat = isDateTime ? "DD-MM-YYYY HH:mm" : "DD-MM-YYYY";
                return moment(date, dateInputFormat).format(dateFormat);
            }
            return moment(date).format(dateFormat);
        }

        function convertDateHour(date, isDatetime) {
            if (comparisonUtilSvc.isNullOrUndefinedValue(date) || date === "") {
                return "";
            }

            var dateFormat = isDatetime ? "DD-MM-YYYY HH:mm" : "DD-MM-YYYY";
            return moment(date).format(dateFormat);
        }

        function getYears() {
            var list = [];
            var date = new Date();
            var year = date.getFullYear();
            for (var i = year; i >= year - 10; i--) {
                list.push({ value: i });
            }
            return list;
        }

        function getDayOfDate(value) {
            var numberDayOfWeek = moment(value).weekday();
            switch (numberDayOfWeek) {
                case constants.numberDayOfWeek.Sunday:
                    return "Sunday";
                case constants.numberDayOfWeek.Monday:
                    return "Monday";
                case constants.numberDayOfWeek.Tuesday:
                    return "Tuesday";
                case constants.numberDayOfWeek.Wednesday:
                    return "Wednesday";
                case constants.numberDayOfWeek.Thursday:
                    return "Thursday";
                case constants.numberDayOfWeek.Friday:
                    return "Friday";
                case constants.numberDayOfWeek.Saturday:
                    return "Saturday";
                default:
                    return null;
            }
        }

        function convertDate(date, isServerType) {
            if (!date) return "";
            if (isServerType) return convertDateForServerSide(date, true);
            return moment(date).format(constants.formatDateDDMMYYYY);
        }

        function getWorkingDaysBetweenDates(from, to) {
            if (to < from)
                return 0;
            var hoursPerDay = 24;
            var secondsPerMinute = 60;
            var millisecondsPerSecond = 1000;
            var millisecondsPerDay = secondsPerMinute * secondsPerMinute * hoursPerDay * millisecondsPerSecond;

            var hourAfterMidnight = 0;
            var minuteAfterMidnight = 0;
            var secondAfterMidnight = 0;
            var millisecondAfterMidnight = 1;
            from.setHours(hourAfterMidnight, minuteAfterMidnight, secondAfterMidnight, millisecondAfterMidnight);

            var hourBeforeMidnight = 23;
            var minuteBeforeMidnight = 59;
            var secondBeforeMidnight = 59;
            var millisecondBeforeMidnight = 999;
            to.setHours(hourBeforeMidnight, minuteBeforeMidnight, secondBeforeMidnight, millisecondBeforeMidnight);
            var millisecondBetweenDates = to - from;
            var days = Math.ceil(millisecondBetweenDates / millisecondsPerDay);

            var weekendCount = 2;
            var dayOfWeekCount = 7;
            var weeks = Math.floor(days / dayOfWeekCount);
            days = days - (weeks * weekendCount);

            var startDay = from.getDay();
            var endDay = to.getDay();

            if (startDay - endDay > 1)
                days = days - weekendCount;

            var saturday = 6;
            var sunday = 0;
            if (startDay === sunday && endDay !== saturday)
                days = days - 1;

            if (endDay === saturday && startDay !== sunday)
                days = days - 1;
            return days;
        }

        function formatDateFromServer(date) {
            var formattedDate = moment(date).format(constants.formatDateTimeServer);
            formattedDate = moment(formattedDate).format(constants.dateTimeFormatDefault);
            return formattedDate;
        }

        function convertToLongDate(date) {
            if (!date) return "";
            return moment(date).format("DDMMMMYYYY");
        }

        function convertDateToLongDate12HourFormat(date) {
            if (!date) return '';
            var dayOfWeek = moment(date).format('dddd');
            var dayAndMonth = moment(date).format('Do MMM');
            var year = moment(date).format('YYYY');
            var hour = moment(date).format('HH');
            var minute = moment(date).format('mm');
            return dayOfWeek + ", " + dayAndMonth + ", " + year + " " + ConvertHourTo12HourFormat(hour, minute);
        }

        function convertDateToShortDate12HourFormat(date) {
            if (!date) return '';
            var day = moment(date).format('DD-MM-YYYY');
            var hour = moment(date).format('HH');
            var minute = moment(date).format('mm');
            return day + " " + ConvertHourTo12HourFormat(hour, minute);
        }

        function ConvertHourTo12HourFormat(hour, minute) {
            if (!hour || !minute) return "";
            var hourTemp = parseInt(hour);
            if (hourTemp === 12) return hourTemp + ":" + minute + " PM";
            return (hourTemp > 12) ? (((hourTemp - 12) < 10) ? "0" : "") + (hourTemp - 12) + ":" + minute + " PM" : hour + ":" + minute + " AM";
        }

        function compareDate(from, to, condition) {
            var diff = to.diff(from, 'days');
            return diff >= condition;
        }

        function isEqual(from, to) {
            var diff = to.diff(from, 'days');
            return diff === 0;
        }

        function convertToShortDateString(date) {
            var defaultDuration = 1;
            var day = date.getDate();
            day = (day < 10) ? '0' + day : day;
            var month = (date.getMonth() + defaultDuration);
            month = (month < 10) ? '0' + month : month;
            var year = date.getFullYear();
            return (date + "-" + month + "-" + year);
        }

        function convertStringToDate(string) {
            return moment(string).format(constants.formatDateDDMMYYYY);
        }

        function convertDateNowToString() {
            var today = new Date();
            var date = today.getDate();
            var month = today.getMonth() + 1;
            var year = today.getFullYear();

            date = (date < 10 ? '0' : '') + date;
            month = (month < 10 ? '0' : '') + month;
            return date + '-' + month + '-' + year;
        }

        function isValidDateString(value, format) {
            return moment(value, format, true).isValid();
        }
    }
})();
