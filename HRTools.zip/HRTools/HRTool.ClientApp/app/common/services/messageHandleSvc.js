﻿(function () {
    'use strict';
    angular.module('app').factory('messageHandleSvc', messageHandleSvc);
    messageHandleSvc.$inject = ['$location', '$filter', '$state', '$window', 'constants', 'message'];
    function messageHandleSvc($location, $filter, $state, $window, constants, message) {
        var revealed = {
            handleResponse: handleResponse,
            handlePermission: handlePermission
        };
        return revealed;
        function handleResponse(response, messageContent, isNotShowMessage) {
            if (response.$resolved) {
                toastr.success($filter(constants.translate)(messageContent));
                return;
            } else if (!response.$resolved && !response.status) {
                if (!isNotShowMessage) toastr.error($filter(constants.translate)(messageContent));
                return;
            }
            var messageError = (response.data) ? response.data.Message : $filter(constants.translate)("Default_Error_Message");

            switch (response.status) {
                case constants.httpCodes.forbidden:
                    if (!isNotShowMessage) toastr.error(response.status + ' - ' + response.data);
                    $window.localStorage.removeItem(constants.currentUserLoginCookie, { path: "/" });
                    var currentUrl = $location.$$absUrl;
                    var indexOfAngularUrl = currentUrl.indexOf("#");
                    var urlLogin = currentUrl.substring(0, indexOfAngularUrl);
                    window.location.assign(urlLogin);
                    break;
                case constants.httpCodes.unauthorized:
                    if (!isNotShowMessage) toastr.error(response.status + ' - ' + $filter(constants.translate)(message.dontHavePermissionAccess));
                    break;
                case constants.httpCodes.serverError:
                    messageError = messageContent ? $filter(constants.translate)(messageContent) : response.status + ' - ' + messageError;
                    if (!isNotShowMessage) toastr.error(messageError);
                    break;
                case constants.httpCodes.notFound:
                    if (!isNotShowMessage) toastr.error(response.status + ' - ' + messageError);
                    break;
                case constants.httpCodes.preconditionFailed:
                    if (!isNotShowMessage) toastr.warning($filter(constants.translate)(message.dontHaveCompanyEmail));
                    break;
                case constants.httpCodes.badRequest:
                    if (!isNotShowMessage) toastr.error(response.status + ' - ' + messageError);
                    break;
                case constants.httpCodes.success:
                    if (!isNotShowMessage) toastr.success($filter(constants.translate)(messageContent));
                    break;
                default:
                    break;
            }

        }

        function handlePermission(notLoadPage) {
            toastr.error('403 - ' + $filter(constants.translate)(message.dontHavePermissionAccess));
            if (!notLoadPage) $state.go("dashboard");
        }
    }
})();

