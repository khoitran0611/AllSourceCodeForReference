﻿(function () {
    "use strict";
    angular.module('app').service('moneySvc', MoneySvc);
    MoneySvc.$inject = ['comparisonUtilSvc'];

    function MoneySvc(comparisonUtilSvc) {

        var revealed = {
        	formatMoney: formatMoney,
        	formatMoneyToShowGrid: formatMoneyToShowGrid,
        	formatMoneyToServerSide: formatMoneyToServerSide
        };
        return revealed;

        function formatMoney(pNumber, pPlaces, pSymbol, pThousand) {
        	var number = pNumber || 0;
        	var places = !isNaN(pPlaces = Math.abs(pPlaces)) ? pPlaces : 2;
        	var symbol = !comparisonUtilSvc.isNullOrUndefinedValue(pSymbol) ? pSymbol : " VND";
        	var thousand = pThousand || ",";
        	var negative = number < 0 ? "-" : "";
        	var money = parseInt(Math.abs(+number || 0).toFixed(places), 10) + "";
        	var separator = (separator = money.length) > 3 ? separator % 3 : 0;
        	return negative + (separator ? money.substr(0, separator) + thousand : "") + money.substr(separator).replace(/(\d{3})(?=\d)/g, "$1" + thousand) + symbol;
        }

        function formatMoneyToShowGrid(n, currency) {
            if (n === "" || comparisonUtilSvc.isNullOrUndefinedValue(n)) return "";

        	return currency + "" + n.toFixed(0).replace(/./g, function (c, i, data) {
        		return i > 0 && c !== "." && (data.length - i) % 3 === 0 ? " " + c : c;
        	});
        }

        function formatMoneyToServerSide(value) {
            if (value === "" || comparisonUtilSvc.isNullOrUndefinedValue(value)) return "";
            value = value.split(" ").join("");
            return parseFloat(value);
        }
    }
})();
