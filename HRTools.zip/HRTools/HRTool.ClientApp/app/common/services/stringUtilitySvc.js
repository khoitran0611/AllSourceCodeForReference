﻿(function () {
    "use strict";
    angular.module('app').service('stringUtilitySvc',
			function () {
			    var revealed = {
			        isNullOrEmpty: isNullOrEmpty,
			        truncateText: truncateText
			    };
			    return revealed;

			    function isNullOrEmpty(value) {
			        return (value === "" || value === null || value === undefined);
			    }

			    function truncateText(text, maxCharacters, appendText) {
			        return text.length > maxCharacters ?
                        text.substring(0, maxCharacters) + appendText : text;
			    }
			});
})();