﻿(function () {
    'use strict';
    angular.module('app').factory('accountSvc', accountSvc);
    accountSvc.$inject = ["$resource", 'constants'];
    function accountSvc($resource, constants) {
        function createUser(user) {
            $.ajax({
                method: "POST",
                url: constants.userAccountUrl + 'Account/RegisterAccount',
                data:
                {
                    password: user.password,
                    confirmPassword: user.confirmPassword,
                    email: user.email,
                },
                success: function() {
                    toastr.success('Companies.Creating_User_Was_Successful');
                }
            });
        }

        return {
            createUser: createUser
        };
    }
})();