﻿(function () {
    'use strict';
    angular.module('app').factory('pagingSvc', pagingSvc);
    pagingSvc.$inject = ['constants'];
    function pagingSvc(constants) {
        var revealed = {
            getAllPages: getAllPages
        };
        return revealed;
        /*
        *   firstDots: page1 (firstDots....) page4 page5 page6 (secondDots....) lastpage         
        */
        function getAllPages(totalPage, currentPageNumber) {
            var pages = [], item;
            /*
            *   total page less than define total button for paging
            */
            if (totalPage <= constants.paging.gridPageNavigateButtonNumberMax) {
                for (var i = 1; i <= totalPage; i++) {
                    item = new itemPager(i, '', false);
                    pages.push(item);
                }
                return createPager(pages, totalPage, currentPageNumber);
            }
            /*
            *   total page greater than define total button for paging and current page number less than divider range
            */
            if (currentPageNumber < constants.paging.dividerPager && totalPage > constants.paging.gridPageNavigateButtonNumberMax) {
                for (var j = 1; j <= constants.paging.gridPageNavigateButtonNumberMax; j++) {
                    item = new itemPager(j,
                        j == constants.paging.secondDots ? constants.paging.classDots : constants.paging.classNormal, false);
                    pages.push(item);
                }
                pages[constants.paging.secondDots].pageNumber = totalPage;
                pages[constants.paging.secondDots].displayNumber = totalPage;
                return createPager(pages, totalPage, currentPageNumber);
            }
            /*
            *   total page greater than define total button for paging and current page number outer divider range
            */
            if (currentPageNumber > totalPage - constants.paging.dividerPager && totalPage > constants.paging.gridPageNavigateButtonNumberMax) {
                var k = totalPage;
                for (var l = 1; l <= constants.paging.gridPageNavigateButtonNumberMax; l++) {
                    item = new itemPager(k--,
                        l == constants.paging.secondDots ? constants.paging.classDots : constants.paging.classNormal, false);
                    pages.push(item);
                }
                pages.reverse();
                pages[constants.paging.secondDots].pageNumber = totalPage;
                pages[constants.paging.secondDots].displayNumber = totalPage;
                return createPager(pages, totalPage, currentPageNumber);
            }
            /*
            *   total page greater than define total button for paging and current page number between divider range
            */
            if (currentPageNumber <= totalPage - constants.paging.dividerPager && currentPageNumber >= constants.paging.dividerPager && totalPage > constants.paging.gridPageNavigateButtonNumberMax) {
                var previousDtep = -(constants.paging.dividerPager - constants.paging.firstDots);
                var nextStep = 1;
                var lastStep = -(constants.paging.gridPageNavigateButtonNumberMax - constants.paging.secondDots - 1);
                for (var m = 1; m <= constants.paging.gridPageNavigateButtonNumberMax; m++) {
                    //less than first dot
                    if (m < constants.paging.firstDots || m > constants.paging.secondDots) {
                        item = new itemPager(m, constants.paging.classNormal, false);
                        pages.push(item);
                        continue;
                    }
                    //equal first dot
                    if (m == constants.paging.firstDots) {
                        item = new itemPager(currentPageNumber + angular.copy(previousDtep), constants.paging.classDots, false);
                        previousDtep++;
                        pages.push(item);
                        continue;
                    }

                    //less than dividerPager and greater than first dot
                    if (m > constants.paging.firstDots && m < constants.paging.dividerPager) {
                        item = new itemPager(currentPageNumber + angular.copy(previousDtep), constants.paging.classNormal, false);
                        previousDtep++;
                        pages.push(item);
                        continue;
                    }

                    //equal dividerPager
                    if (m == constants.paging.dividerPager) {
                        item = new itemPager(currentPageNumber, constants.paging.classNormal, false);
                        pages.push(item);
                        continue;
                    }

                    // less than sencond dot and greater than dividerPage
                    if (m < constants.paging.secondDots && m > constants.paging.dividerPager) {
                        item = new itemPager(currentPageNumber + angular.copy(nextStep), constants.paging.classNormal, false);
                        nextStep++;
                        pages.push(item);
                        continue;
                    }

                    //equal second dot
                    if (m == constants.paging.secondDots) {
                        item = new itemPager(currentPageNumber + angular.copy(nextStep), constants.paging.classDots, false);
                        pages.push(item);
                        continue;
                    }

                    //greater than second dot
                    if (m > constants.paging.secondDots) {
                        item = new itemPager(totalPage + angular.copy(lastStep), constants.paging.classDots, false);
                        lastStep++;
                        pages.push(item);
                        continue;
                    }
                }
                pages[constants.paging.secondDots].pageNumber = totalPage;
                pages[constants.paging.secondDots].displayNumber = totalPage;
                return createPager(pages, totalPage, currentPageNumber);
            }
            return pages;
        }

        function itemPager(pageNumber, cssPageNumber, isActive) {
            /* jshint -W040 */
            var self = this;
            self.pageNumber = pageNumber;
            self.cssPageNumber = cssPageNumber;
            self.isActive = isActive;
            if (cssPageNumber == "dots")
                self.displayNumber = "...";
            else
                self.displayNumber = pageNumber;

            return self;
        }

        function createPager(pages, totalPage, currentPageNumber) {
            if (totalPage > 0) {
                pages[0].pageNumber = 1;
                pages[0].displayNumber = 1;
            }

            for (var i = 0; i < pages.length; i++) {
                pages[i].cssPageNumber = pages[i].pageNumber == currentPageNumber ? constants.paging.classActived : pages[i].cssPageNumber;
                pages[i].isActive = pages[i].pageNumber == currentPageNumber ? true : false;
            }
            return pages;
        }
    }
})();

