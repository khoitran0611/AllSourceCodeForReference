﻿(function () {
    'use strict';
    angular.module('app').factory('objectSvc', objectSvc);
    objectSvc.$inject = ['constants', 'message', '$filter', 'comparisonUtilSvc'];
    function objectSvc(constants, message, $filter, comparisonUtilSvc) {
        var keyCode = {
            backspace: 8, tab: 9, enter: 13,
            shift: 16, ctrl: 17, alt: 18, esc: 27,
            space: 32, page_up: 33, page_down: 34,
            end: 35, home: 36, left: 37, up: 38,
            down: 40, right: 39,
            codeDelete: 46, zeroNumber: 48, nineNumber: 57,
            add: 107, subtract: 109,
            comma: 188,
            dash: 189,
            dot: 190,
            open_bracket: 219,
            close_braket: 221,
            isArrow: function (k) {
                k = k.which ? k.which : k;
                switch (k) {
                    case keyCode.left:
                    case keyCode.right:
                    case keyCode.up:
                    case keyCode.down:
                        return true;
                }
                return false;
            }
        };

        var charCode = {
            delete: 127,
            escapse: 27,
            space: 32, tight: 39,
            open_bracket: 40,
            close_bracket: 41,
            add: 43, comma: 44,
            dash: 45, dot: 46,
            zero: 48, one: 49,
            two: 50, three: 51,
            four: 52, five: 53,
            six: 54, seven: 55,
            einght: 56, nine: 57
        };

        var revealed = {
            checkObjectHasValueUndefined: checkObjectHasValueUndefined,
            findObjectInArray: findObjectInArray,
            findAllItemsInArray: findAllItemsInArray,
            getArray: getArray,
            checkPermission: checkPermission,
            convertHtmlTextView: convertHtmlTextView,
            checkNumber: checkNumber,
            checkPhoneNumber: checkPhoneNumber,
            checkNaturalNumber: checkNaturalNumber,
            isNullOrUndefined: isNullOrUndefined
        };
        return revealed;

        function checkObjectHasValueUndefined(object) {
            for (var key in object) {
                var value = object[key];
                if (comparisonUtilSvc.isNullOrUndefinedValue(value) && key.indexOf("Id") == -1)
                    return true;
            }
            return false;
        }

        function findObjectInArray(item, array) {
            for (var i = 0; i < array.length; i++) {
                if (JSON.stringify(item) == JSON.stringify(array[i]))
                    return i;
            }
            return -1;
        }

        function findAllItemsInArray(value, property, array) {
            /*
            * this metthod is not implemented find with unicode character yet,
            * currently, the function cannot find item has value with input unicode charater like "â, ă..."
            */
            var result = [];
            for (var i = 0; i < array.length; i++) {
                if (array[i][property].toUpperCase().indexOf(value.toUpperCase()) > -1) {
                    result.push(array[i]);
                }
            }
            return result;
        }

        function getArray(object) {
            var length = object.length;
            var array = [];
            for (var index = 0; index < length; index++) {
                array.push(object[index]);
            }
            return array;
        }

        function checkPermission(hasPermission, warningMessage, isShowMessage) {
            if (!hasPermission) {
                if (isShowMessage) toastr.warning($filter(constants.translate)(warningMessage));
                return false;
            }
            return true;
        }

        function convertHtmlTextView(text) {
            if (!text) return "";
            var newText = text.replace(/\r?\n/g, '</p> <p>');
            if (newText === "") return "";
            return '<p>' + newText + '</p>';
        }

        //TODO: Change all implement from objectSvc to keyboardSvc then remove this function
        function checkNumber(event) {
            var eventCode = 0;
            if (event.charCode !== 0) {
                eventCode = event.charCode;
                if (!(eventCode == charCode.delete || (eventCode >= charCode.zero && eventCode <= charCode.nine) ||
                    eventCode == charCode.comma || eventCode == charCode.dot))
                    event.preventDefault();
                return;
            }
            if (event.keyCode !== 0) {
                eventCode = event.keyCode;
                if (!((eventCode >= keyCode.zeroNumber && eventCode <= keyCode.nineNumber) || eventCode == keyCode.codeDelete ||
                    eventCode == keyCode.comma || eventCode == keyCode.tab || eventCode == keyCode.home
                    (eventCode >= keyCode.page_up && eventCode <= keyCode.down)))
                    event.preventDefault();
                return;
            }
        }

        //TODO: Change all implement from objectSvc to keyboardSvc then remove this function
        function checkPhoneNumber(event) {
            var eventCode = 0;
            if (event.charCode !== 0) {
                eventCode = event.charCode;
                if (!(eventCode == charCode.delete || (eventCode >= charCode.zero && eventCode <= charCode.nine) ||
                    eventCode == charCode.dash || eventCode == charCode.add || eventCode == charCode.space ||
                    eventCode == charCode.open_bracket || eventCode == charCode.close_bracket))
                    event.preventDefault();
                return;
            }
            if (event.keyCode !== 0) {
                eventCode = event.keyCode;
                if (!((eventCode >= keyCode.zeroNumber && eventCode <= keyCode.nineNumber) || eventCode == keyCode.codeDelete ||
                    eventCode == keyCode.tab || eventCode == keyCode.backspace || eventCode == keyCode.space ||
                    (eventCode >= keyCode.page_up && eventCode <= keyCode.down)))
                    event.preventDefault();
                return;
            }
        }

        //TODO: Change all implement from objectSvc to keyboardSvc then remove this function
        function checkNaturalNumber(event) {
            var eventCode = 0;
            if (event.charCode !== 0) {
                eventCode = event.charCode;
                if (!(eventCode == charCode.delete || (eventCode >= charCode.zero && eventCode <= charCode.nine)))
                    event.preventDefault();
                return;
            }
            if (event.keyCode !== 0) {
                eventCode = event.keyCode;
                if (!((eventCode >= keyCode.zeroNumber && eventCode <= keyCode.nineNumber) ||
                      eventCode == keyCode.codeDelete ||
                      eventCode == keyCode.tab || eventCode == keyCode.home ||
                      (eventCode >= keyCode.page_up && eventCode <= keyCode.down)))
                    event.preventDefault();
                return;
            }
        }

        function isNullOrUndefined(object) {
            return object === null || object === undefined;
        }

    }
})();