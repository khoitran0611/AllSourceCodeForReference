﻿String.format = function () {
    var s = arguments[0];
    for (var i = 0; i < arguments.length - 1; i++) {
        var reg = new RegExp("\\{" + i + "\\}", "gm");
        s = s.replace(reg, arguments[i + 1]);
    }
    return s;
};

String.randomString = function () {
    var charSet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    var randomString = '';
    var len = 15;
    for (var i = 0; i < len; i++) {
        var randomPoz = Math.floor(Math.random() * charSet.length);
        randomString += charSet.substring(randomPoz, randomPoz + 1);
    }
    return randomString;
};


function findWithAttr(array, attr, value) {
    for (var i = 0; i < array.length; i += 1) {
        if (array[i][attr] == value) {
            return i;
        }
    }
    return -1;
}

function safeToString(x) {
    switch (typeof x) {
        case 'object':
            return '';
        case 'function':
            return 'function';
        default:
            return x + '';
    }
}

function arrayResourceToInt(object) {
    var result = $.map(object, function (element) {
        return element;
    }).join("");
    return parseInt(result.substring(0, result.indexOf("[")));
}

function arrayResourceToString(object) {
    var result = $.map(object, function (element) {
        return element;
    }).join("");
    return result.substring(0, result.indexOf("["));
}

function findObjectInArray(item, arr) {
    for (var i = 0; i < arr.length; i++) {
        if (JSON.stringify(item) == JSON.stringify(arr[i]))
            return i;
    }
    return -1;
}

function findAngularObjectInArray(item, arr) {
    for (var i = 0; i < arr.length; i++) {
        if (JSON.stringify(item) == JSON.stringify(arr[i]))
            return i;
    }
    return -1;
}

function formatPhoneNumber(phoneNum) {
    if (phoneNum === null || phoneNum === undefined || phoneNum.length === 0) return "";
    var phoneFormated = "";
    if (phoneNum[0] == '+' || (phoneNum[0] >= '0' && phoneNum[0] <= '9')) {
        phoneFormated += phoneNum[0];
        for (var i = 1; i < phoneNum.length; i++) {
            if (phoneNum[i] >= '0' && phoneNum[i] <= '9')
                phoneFormated += phoneNum[i];
        }
        return phoneFormated;
    }

    if (phoneNum[0] != '+' || (phoneNum[0] <= '0' && phoneNum[0] >= 9)) {
        if ((phoneNum[1] == '+' || (phoneNum[1] >= '0' && phoneNum[1] <= '9'))) {
            phoneFormated += phoneNum[1];
            for (var j = 2; j < phoneNum.length; j++) {
                if (phoneNum[j] >= '0' && phoneNum[j] <= '9')
                    phoneFormated += phoneNum[j];
            }
        } else {
            for (var k = 1; k < phoneNum.length; k++) {
                if (phoneNum[k] >= '0' && phoneNum[k] <= '9')
                    phoneFormated += phoneNum[k];
            }
        }
    }
    return phoneFormated;
}

function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
}

String.prototype.replaceAll = function (find, replace) {
    var str = this;
    return str.replace(new RegExp(find.replace(/[-\/\\^$*+?.()|[\]{}]/g, '\\$&'), 'g'), replace);
};

function omitKeys(array, ignoreKey) {
    var result = array;
    for (var i = 0; i < result.length; i++) {
        for (var key in result[i]) {
            if (ignoreKey==key)
                result[i][key] = key;
        }
    }
    return result;
}

String.randomNumber = function () {
    var charSet = '0123456789';
    var randomString = '';
    var len = 3;
    for (var i = 0; i < len; i++) {
        var randomPoz = Math.floor(Math.random() * charSet.length);
        randomString += charSet.substring(randomPoz, randomPoz + 1);
    }
    return randomString;
};

function placeholderTextInLetterTemplate(text, candidateInfo) {
    var result = "";
    result = text.replace('{Title}', candidateInfo.Title);
    result = result.replace('{Candidate Name}', candidateInfo.FirstName);
    result = result.replace('{Position}', candidateInfo.Position);
    result = result.replace('{Login Username}', candidateInfo.Username);
    return result;
}

function convertGenderToTitle(gender) {
    var title = gender === "" || gender === undefined ? "" : gender === "Male" ? "Mr." : "Ms.";
    return title;
}

function addHoverElement(element) {
    var iconElement = angular.element(element);
    var iconParentElement = iconElement.parent('div.icon-box');
    iconElement.addClass('icon-hover');
    iconParentElement.addClass('icon-box-hover');
}

function removeHoverElement(element) {
    var iconElement = angular.element(element);
    var iconParentElement = iconElement.parent('div.icon-box');
    iconElement.removeClass('icon-hover');
    iconParentElement.removeClass('icon-box-hover');
}
