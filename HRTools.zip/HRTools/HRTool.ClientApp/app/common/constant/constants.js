﻿(function () {
    "use strict";
    var BASE_HOST = '/* @echo hrtoolAPIUrl *//';
    var BASE_HOST_API = '/* @echo hrtoolAPIUrl *//api/';
    var AUTHORITY_URL = '/* @echo authorityUrl */';
    var SERVEYTOOL_URL = '/* @echo surveyToolUrl */';
    var CLIENTAPP_BASEPATH = '/* @echo clientAppUrl *//';
    var USER_ACCOUNT_API = '/* @echo userAccountAPIUrl *//';
    var SSO_CLIENT_ID = '/* @echo ssoClientId */';

    /* @ifndef hrtoolAPIUrl */
    BASE_HOST = "http://localhost:10924/";
    BASE_HOST_API = 'http://localhost:10924/api/';
    /*@endif*/

    /* @ifndef userAccountAPIUrl */
    USER_ACCOUNT_API = 'https://localhost:44300/';
    /*@endif*/

    /* @ifndef authorityUrl */
    AUTHORITY_URL = 'https://localhost:44300/';
    /*@endif*/

    /* @ifndef surveyToolUrl */
    SERVEYTOOL_URL = 'http://localhost:4001/app';
    /*@endif*/

    /* @ifndef clientAppUrl */
    CLIENTAPP_BASEPATH = window.location.protocol + '//' + window.location.host + window.location.pathname;
    /*@endif*/

    /* @ifndef ssoClientId */
    SSO_CLIENT_ID = 'ResponsiveHR';
    /*@endif*/

    angular.module('app').constant('constants', {
        serverUrl: BASE_HOST,
        signalRUrl: BASE_HOST,
        apiUrl: BASE_HOST_API,
        baseUrl: CLIENTAPP_BASEPATH,
        userAccountUrl: USER_ACCOUNT_API,
        surveyToolUrl: SERVEYTOOL_URL,
        authorityUrl: AUTHORITY_URL,
        ssoClientId: SSO_CLIENT_ID,
        currentCompany: 2,
        createAction: "create",
        inProgress: "In Progress",
        newStatus: "New",
        successfull: "Successful",
        error: "Error",
        undefined: "undefined",
        activeClass: "active",
        buttonCircleClass: "sprite-ellipsis",
        buttonCircleActiveClass: "sprite-ellipsis active",
        disabledClass: "disabled",
        betweenCondition: "between",
        noCondition: "",
        AllExceptEnded: "6",
        jobCode: "JobCodeFilter",
        localStorageKey: {
            candidateSearch: "candidatesearch",
            employeeSearch: "employeesearch",
            jobSearch: "jobFilterQuery",
            jobHeaderToogle: "jobFilterToogleState",
            jobSearchCondition: "jobFilterCondition",
            currentCandidateListPage: "currentCandidateListPage",
            currentUsersListPage: "currentUsersListPage"
        },
        compareCondition: {
            between: "between",
            lessthan: "less than",
            greaterthan: "greater than",
            equal: "equal"
        },
        interviewResult:
        {
            reject: "0",
            newStatus: "4",
            newUnknown: undefined,
            pass: "1",
            passForSort: "9",
            standBy: "2",
            onHold: "2",
            open: "5",
            blackList: "3",
            shortlisted: "21",
            sentOffer: "22",
            acceptOffer: "23",
            rejectOffer: "24",
            rejectAll: "25",
            firstInterviewOngoing: "30",
            firstInterviewPassed: "31",
            firstInterviewFailed: "32",
            scondInterviewOngoing: "40",
            secondInterviewPassed: "41",
            secondInterviewFailed: "42",
            thirdInterviewOngoing: "50",
            thirdInterviewPassed: "51",
            thirdInterviewFailed: "52",
            scheduledDate: "10",
            blackListTilte: "Black List",
            rejectText: "Rejected",
            passText: "Passed",
            onHoldText: "On Hold",
            standByText: "Stand By",
            blackListText: "Black List",
            newText: "New",
            successfulText: "Successful",
            inProgressText: "In Progress",
            interestedText: "Interested",
            shortlistedText: "Shortlist"
        },

    gridPageNavigateButtonNumberMax: 7,
    gridPageNavigateButtonNumber: 4,
    sortTypeDes: "DES",
    forbidden: "403",
    unauthorized: "401",
    notfound: "404",
    sortTypeAsc: "ASC",
    interviewResultReject: "0",
    interviewResultPass: "1",
    interviewResultPassForSort: "9",
    interviewResultStandBy: "2",
    interviewResultOnHold: "2",
    interviewResultOpen: "5",
    interviewResultRejectText: "Rejected",
    interviewResultPassText: "Passed",
    interviewResultStandByText: "Stand By",
    interviewResultOnHoldText: "On Hold",
    interviewResultBlackListText: "Black List",
    interviewResultNewText: "New",
    interviewResultOpenText: "Open",
    interviewResultSuccessfulText: "Successful",
    interviewResultInProgressText: "In Progress",
    linkToViewOpenPosition: "open-positions",
    slideDuration: 600,
    notAvailable: "N/A",
    offerLetterAcceptedStatus: "Accepted",
    offerLetterRejectedStatus: "Rejected",
    iconArrUp: 'icon-arr-up',
    iconArrDown: 'icon-arr-down',
    enterKeyCode: 13,
    pageSizeOfGridView: 10,
    formatDateDDMMYYYY: "DD-MM-YYYY",
    formatDateDDMM: "DD.MM",
    formatDateServer: "YYYY-MM-DD",
    formatDateTimeServer: "YYYY-MM-DD HH:mm:ss",
    dateTimeFormatDefault: "DD-MM-YYYY HH:mm:ss",
    dateFormatForPayroll: "DD-MMM-YYYY",
    timeFormatForPayrollServer: "HH:mm:ss",
    timeFormatForPayroll: "HH:mm",
    timeInOut: "HH:mm",
    currentUserLoginCookie: "currentuserlogin",
    currentCandidateLoginCookie: "currentcandidatelogin",
    EtagArray: [],

    paging:
    {
        classActived: 'active',
        classNormal: '',
        classDots: 'dots',
        gridPageNavigateButtonNumberMax: 12,
        firstDots: 2,
        secondDots: 11,
        dividerPager: 6,
        pageSize: 10,
        firstPage: 1,
        totalPagesInitial: 0

    },
    levels: [
        { 'Id': 0, 'Name': 'Not Set' },
        { 'Id': 1, 'Name': 'Beginner' },
        { 'Id': 2, 'Name': 'Intermediate' },
        { 'Id': 3, 'Name': 'Advanced' }
    ],

    languageLevels: [
        { 'Id': 0, 'Name': 'Beginner' },
        { 'Id': 1, 'Name': 'Elementary' },
        { 'Id': 2, 'Name': 'Intermediate' },
        { 'Id': 3, 'Name': 'Advanced' },
        { 'Id': 4, 'Name': 'Fluent' },
        { 'Id': 5, 'Name': 'Native' }
    ],

    genders: [
        { 'Code': 'Male', 'Name': 'Male' },
        { 'Code': 'Female', 'Name': 'Female' },
        { 'Code': 'Other', 'Name': 'Other' }
    ],

    maritalStatusList: [
        { 'Code': 'Single', 'Name': 'Single' },
        { 'Code': 'Married', 'Name': 'Married' }
    ],

    quiztest: {
        resultQuizTestPageTitle: "Result Quiz Test",
        resultUpdateQuizTestPageTitle: "Update Result Quiz Test"
    },
    emailCode: {
        openPosition: 1,
        interview: 2,
        informInterviewResult: 3,
        offerLetter: 4,
        remindUpdateCV: 5,
        welcomeNewComer: 6,
        thankYouLetter: 7
    },
    fileType: {
        contract: "Contract",
        candidateFile: "CandidateFile",
        payroll: "Payroll"
    },

    jobStatus: {
        New: "new",
        Published: "published",
        Closed: "closed",
        Ended: "ended"
    },
    jobStatusId: {
        New: 0,
        Published: 3,
        Closed: 4,
        Ended: 5
    },
    invitationStatusId: {
        New: 0,
        Accept: 1,
        Closed: 2
    },
    httpCodes: {
        success: 200,
        badRequest: 400,
        unauthorized: 401,
        forbidden: 403,
        notFound: 404,
        notAcceptable: 406,
        serverError: 500,
        serviceUnavailable: 503,
        conflict: 409,
        preconditionFailed: 412
    },
    numberDayOfWeek: {
        Sunday: 0,
        Monday: 1,
        Tuesday: 2,
        Wednesday: 3,
        Thursday: 4,
        Friday: 5,
        Saturday: 6
    },
    sortType: {
        des: "des",
        asc: "asc"
    },
    workingStatus: [
        { Id: 1, Name: "Probation" },
        { Id: 2, Name: "Official" },
        { Id: 3, Name: "StoppedWorking" },
        { Id: 4, Name: "Temporary" },
        { Id: 5, Name: "BlackList" }
    ],

    rootPath: "app",
    formatDateTimeFilter: 'date:\"dd-MM-yyyy\"',
    formatFullDateTimeFilter: 'date:\"dd-MM-yyyy HH:mm:ss\"',
    translate: "translate",
    activeSearch: true,
    callSearchApi: { search: "search", clearSearch: "clearSearch" },
    editModeHeader: 'row bg-info',
    viewModeHeader: 'row bg-primary',
    firstPage: 1,
    newRowIndex: -1,
    newGroupIndex: -1,
    stringEmpty: "",
    noAvatar: window.location.protocol + '//' + window.location.host + "/Content/app/images/applicants-image-placeholder.png",
    loadingIcon: {
        overlay: "#ajax-overlay",
        indicator: "#ajax-indicator"
    },
    fileSizeInMegabyte: 1048576,
    colorChart: ['#F3A5A7'],
    arrayUrl: {
        jobs: [{ url: "#/jobs" }, { url: "#/open-positions" }],
        candidates: [{ url: "#/candidates" }, { url: "#/interviews" }],
        interview: [{ url: "#/interview-schedule" }],
        employees: [{ url: "#/employees" }],
        dashboard: [{ url: "#/dashboard" }],
        payroll: [{ url: "#/payroll" }],
    },
    offerLetter: {
        listOfferStatus: [
            { id: 0, name: "" },
            { id: 1, name: "Accepted" },
            { id: 2, name: "Rejected" }
        ]
    },
    numberMonthInYear: [
        { id: -1, name: "" },
        { id: 0, name: "1" },
        { id: 1, name: "2" },
        { id: 2, name: "3" },
        { id: 3, name: "4" },
        { id: 4, name: "5" },
        { id: 5, name: "6" },
        { id: 6, name: "7" },
        { id: 7, name: "8" },
        { id: 8, name: "9" },
        { id: 9, name: "10" },
        { id: 10, name: "11" },
        { id: 11, name: "12" }
    ],
    slash: "/",
    empty: "",
    recruitment: {
        create: 0,
        update: 1,
        deleteData: 2
    },
    maxFileSizeUploaded: 5242880,
    initSelectedValue: -1,
    listAction: [
        { key: "Mark_Candidate_As_Interesting_Action", displayName: "Interviews.Mark_Candidate_As_Interesting_Action", isShow: false },
        { key: "Pass_Screening_Action", displayName: "Interviews.Pass_Screening_Action", isShow: false },
        { key: "Pass_Screening_And_Schedule_Interview_Action", displayName: "Interviews.Pass_Screening_And_Schedule_Interview_Action", isShow: false },
        { key: "Schedule_Interview_Action", displayName: "Interviews.Schedule_Interview_Action", isShow: false },
        { key: "Shortlist_Candidate_Action", displayName: "Interviews.Shortlist_Candidate_Action", isShow: false },
        { key: "Reject_Candidate_Action", displayName: "Interviews.Reject_Candidate_Action", isShow: false },
        { key: "Offer_Job_Action", displayName: "Interviews.Offer_Job_Action", isShow: false },
        { key: "Become_Employee_Action", displayName: "Interviews.Become_Employee_Action", isShow: false },
        { key: "Update_Offer_Status_Action", displayName: "Interviews.Update_Offer_Status_Action", isShow: false },
        { key: "Reject_CV_Action", displayName: "Interviews.Reject_CV_Action", isShow: false },
        { key: "Candidate_Accepted_Offer_Action", displayName: "Interviews.Candidate_Accepted_Offer_Action", isShow: false },
        { key: "Candidate_Rejected_Offer_Action", displayName: "Interviews.Candidate_Rejected_Offer_Action", isShow: false },
        { key: "Create_New_Offer_Action", displayName: "Interviews.Create_New_Offer_Action", isShow: false },
        { key: "Mark_Candidate_As_Shorlisted_Action", displayName: "Interviews.Mark_Candidate_As_Shorlisted", isShow: false },
        { key: "Mark_Candidate_As_Hired_Action", displayName: "Interviews.Mark_Candidate_As_Hired", isShow: false },
        { key: "Mark_Candidate_As_Rejected_Action", displayName: "Interviews.Mark_Candidate_As_Rejected", isShow: false }
    ],
    numberInterviews: 3,
    applicationStatus: {
        OfferStatus:
        {
            HasOffer: "65536",
            AlreadySent: "67108864",
            AcceptOffer: "134217728",
            RejectOffer: "268435456"
        },
        ScreeningCv:
        {
            New: "1048577",
            Interested: "2097153",
            Open: "2097153",
            Rejected: "4194305",
            Passed: "8388609",
            OnHold: "16777216",
            BlackList: "33554433",
            newUnknown: undefined
        },
        FirstInterview:
        {
            New: "1048578",
            Rejected: "4194306",
            Passed: "8388610"
        },
        SecondInterview:
        {
            New: "1048580",
            Rejected: "4194308",
            Passed: "8388612"
        },
        ThirdInterview:
        {
            New: "1048584",
            Rejected: "4194312",
            Passed: "8388616"
        },
        Other:
        {
            Shortlist: "8192",
            RejectAll: "16384",
            BecomeEmployee: "536870912"
        }
    },
    filterData: {
        upComingCandidate: 'upComingCandidate',
        latestApplication: 'latestApplication',
        latestCvUpdate: 'latestCvUpdate',
        latestCvUpdateViewAll: 'latestCvUpdateViewAll',
        latestApplicationViewAll: 'latestApplicationViewAll',
        addNewCandidate: 'addNewCandidate',
        candidateList: 'candidateList',
        interviewSchedule: 'interviewSchedule',
        invitationAppliedCandidates: "invitationAppliedCandidates",
        allAppliedCandidates: "allAppliedCandidates",
        newAppliedCandidates: "newAppliedCandidates",
        interestedAppliedCandidates: "interestedAppliedCandidates",
        interviewingAppliedCandidates: "interviewingAppliedCandidates",
        shorlistedAppliedCandidates: "shorlistedAppliedCandidates",
        offeredAppliedCandidates: "offeredAppliedCandidates",
        hiredAppliedCandidates: "hiredAppliedCandidates"
    },
    resetCommand: "resetSeleted",
    broadCastTile: {
        updateCandidateNode: "updateCandidateNode",
        updateCandidateRating: "updateCandidateRating",
        dasboardLoadFail: "dashboardLoadFail",
        rejectCandidate: "rejectCandidate",
        emailSent: "emailSent",
        requestUpdateCV: "requestUpdateCV",
        createNewCandidate: "createNewCandidate",
        createNewJob: "createNewJob",
        sendJobInvitation: "sendJobInvitation",
        storeJobFilter: "storeJobFilter",
        clearSearch: "clearSearch"
    },
    invitationMenuIndex: {
        invitation: 0,
        all: 1, new: 2,
        interested: 3, interviewing: 4,
        shortlisted: 5, offered: 6, hired: 7
    }
});
})();
