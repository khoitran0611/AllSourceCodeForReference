﻿(function () {
    "use strict";
    angular.module('app').constant('enumGlyphicon', {
        glyphiconPass: "glyphicon glyphicon-ok",
        glyphiconReject: "glyphicon glyphicon-thumbs-down",
        glyphiconStandBy: "glyphicon glyphicon-standby",
        glyphiconOnHold: "glyphicon glyphicon-hand-up",
        glyphiconStatusOpen: "glyphicon glyphicon-statusopen",
        glyphiconStatusBlackList: "glyphicon glyphicon-black-list",
        glyphiconEditButton: "glyphicon glyphicon-edit",
        glyphiconNewWindowButton: "glyphicon glyphicon-new-window",
        glyphiconDeleteButton: "glyphicon glyphicon-trash",
        glyphiconSaveButton: "glyphicon glyphicon-floppy-disk",
        glyphiconDisableSaveButton: "glyphicon-floppy-remove",
        glyphiconCancelButton: "glyphicon glyphicon-ban-circle",
        glyphiconCalendar: "glyphicon glyphicon-calendar"
    });
})();
