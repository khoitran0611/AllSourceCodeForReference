﻿var loginModule = angular.module('loginModule', ['ngRoute', 'ngResource', 'pascalprecht.translate']);

loginModule.controller('signInViewCtrl', ['$resource', '$scope', '$timeout', '$window', 'constants', 'comparisonUtilSvc',
    function ($resource, $scope, $timeout, $window, constants, comparisonUtilSvc) {
        var self = this;
        self.menuForm = { "GeneralMenus": undefined, "AdminMenus": undefined };
        self.isShowFailMessage = false;
        self.isShowLogin = true;
        self.systemFailMessage = '';
        self.systemMessage = '';
        self.isUsernameChanged = false;
        self.isPasswordChanged = false;

        self.loginRequestToServer = loginRequestToServer;
        self.getPlaceholder = getPlaceholder;
        self.changeUsernameValue = changeUsernameValue;
        self.changePasswordValue = changePasswordValue;
        self.submitForm = submitForm;

        var loginInput = function () {
            this.userName = self.userName;
            this.passWord = angular.element(document.getElementsByName('password')).val();
        };

        // Move
        var loginUrl = "http://localhost:10924/api/UserLogin/Login";
        var baseUrl = window.location.protocol + '//' + window.location.host + window.location.pathname;
        var surveyToolSSOUrl = "htpp://surveytool.orientsoftware.net/#/surveys";

        function loginRequestToServer() {
            //TODO: Move this code into a service. Change the loginInput.
            $resource(loginUrl).save(new loginInput()).$promise.then(function (data) {
                $("#body").removeClass("main-body");
                self.isShowFailMessage = false;
                self.isShowLogin = false;
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
                if (!comparisonUtilSvc.isNullOrUndefinedValue(data.Menu)) {
                    data.Menu.AdminMenus.ChildMenus = correctUrl(data.Menu.AdminMenus.ChildMenus);
                    self.menuForm.GeneralMenus = correctUrl(data.Menu.GeneralMenus);
                    self.menuForm.AdminMenus = data.Menu.AdminMenus;
                    $.jStorage.deleteKey("candidatesearch");
                    $.jStorage.set("menus", data.Menu);
                    $.jStorage.set("configMenu", data.ShowSSOSurveyToolLink);
                }
                $.jStorage.set('ListPermissions', data.ListPermissions);
                var employeeUser = 2;
                var dataStorage = {
                    "UserId": data.UserId,
                    "FullName": data.FullName,
                    "UserType": employeeUser,
                    "TokenKey": data.Token,
                    "FirstName": data.FirstName,
                    "LastName": data.LastName,
                    "RoleName": data.RoleName,
                    "CompanyId": data.CompanyId,
                    "CompanyName": data.Company,
                    "Flag": true,
                    "ListPermissions": [],
                    "JobApplicationId": "",
                    "CandidateEmail": "",
                    "CandidateName": "",
                    "PositionName": "",
                    "QuizTestStatus": "",
                    "__moduleId__": "model/current-user"
                };
                $window.localStorage.setItem("currentuserlogin", dataStorage, { path: '/' });

                $("#applicationHost").show();
                $timeout(function () {
                    $("#idscript").append('<script src="/app/main.js"></script>');
                    $("#idscript").append('<script src="/app/main.js"></script>');
                    //$("#applicationHost").attr("ng-app", "app");
                    $("#applicationHost").append('<script src="' + constants.apiUrl + 'Signalr/hubs"></script>');
                }, 300);

            },
            function () {
                self.isShowFailMessage = true;
                self.isShowLogin = true;
                $("#body").addClass("main-body");
                self.systemFailMessage = "Username or Password is not correct";
            });
        }

        function getPlaceholder(condition, firstValue, secondValue) {
            if (condition) return secondValue;
            return firstValue;
        }

        function changeUsernameValue() {
            self.isUsernameChanged = true;
        }

        function changePasswordValue() {
            self.isPasswordChanged = true;
        }

        function submitForm($event) {
            self.isUsernameChanged = true;
            self.isPasswordChanged = true;
            if (!self.userName || !self.password) $event.preventDefault();
        }

        function correctUrl(urlArray) {
            for (var i = 0; i < urlArray.length; i++) {
                urlArray[i].Url = baseUrl + urlArray[i].Url;
            }
            return urlArray;
        }
    }]);
