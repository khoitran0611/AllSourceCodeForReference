﻿(function () {
    "use strict";
    angular.module('app').directive('ngUploader', ngUploader);
    function ngUploader() {
        return {
            controller: 'uploaderCtrl',
            scope:{
                sourceFile: '=bindingSourceFile'
            },
            link: function ($scope, el) {
                el.bind("change", function (e) {
                    $scope.file = (e.srcElement || e.target).files[0];
                    $scope.getFile();
                });
            }
        };
    }
})();
