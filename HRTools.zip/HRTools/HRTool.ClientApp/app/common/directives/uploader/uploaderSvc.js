﻿(function () {
    'use strict';
    angular.module('app').factory('uploaderService', uploaderService);
    uploaderService.$inject = ['$q'];
    function uploaderService($q) {
        var onLoad = function (reader, deferred) {
            return function () {
                deferred.resolve(reader.result);
            };
        };

        var onError = function (reader, deferred) {
            return function () {
                deferred.reject(reader.result);
            };
        };

        var getReader = function (deferred) {
            var reader = new FileReader();
            reader.onload = onLoad(reader, deferred);
            reader.onerror = onError(reader, deferred);

            return reader;
        };

        var readAsDataUrl = function (file) {
            var deferred = $q.defer();
            var reader = getReader(deferred);
            reader.readAsDataURL(file);

            return deferred.promise;
        };

        return {
            readAsDataUrl: readAsDataUrl
        };
    }
})();
