﻿(function () {
    'use strict';
    angular.module('app').controller('uploaderCtrl', uploaderCtrl);
    uploaderCtrl.$inject = ["$scope", "uploaderService", 'candidateSvc'];
    function uploaderCtrl($scope, uploaderService, candidateSvc) {
        $scope.getFile = getFile;

        function getFile() {
            if (typeof (FileReader) != "undefined") {
                uploaderService.readAsDataUrl($scope.file)
                    .then(function (result) {
                        $scope.sourceFile = result;
                        candidateSvc.setUpdateImage();
                    });
            }
        }
    }
})();

