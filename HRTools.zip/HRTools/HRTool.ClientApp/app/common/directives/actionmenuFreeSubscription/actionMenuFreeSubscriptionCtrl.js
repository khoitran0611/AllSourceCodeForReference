﻿(function () {
    'use strict';
    angular.module('app').controller('actionMenuFreeSubscriptionCtrl', actionMenuFreeSubscriptionCtrl);
    actionMenuFreeSubscriptionCtrl.$inject = ['constants', '$filter'];
    function actionMenuFreeSubscriptionCtrl(constants, $filter) {
        var self = this;

        self.currentListAction = JSON.parse(JSON.stringify(constants.listAction));
        self.id = String.randomString();
        self.showMenu = true;
        self.disableMenu = false;
        self.dialogConfirm = {
            dialogId: "menuaction" + self.id,
            dialogTitle: "Interviews.Confirm_Action",
            dialogMessage: ""
        };

        init();

        function init() {
            for (var m = 0; m < self.currentListAction.length; m++) {
                self.currentListAction[m].displayName = $filter(constants.translate)(self.currentListAction[m].displayName);
            }

            $(document).bind('click', function (e) {
                var $clicked = $(e.target);
                if (!$clicked.parents().hasClass("dropdown-menu-action")) {
                    var dropdownElement = $("#dropdown-menu-action .dropdown");
                    dropdownElement.removeClass("open");
                }
            });
        }
    }
})();