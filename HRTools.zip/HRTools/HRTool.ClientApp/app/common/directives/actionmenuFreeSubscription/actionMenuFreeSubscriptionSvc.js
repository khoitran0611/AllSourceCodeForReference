﻿(function () {
    'use strict';
    angular.module('app').factory('actionMenuFreeSubscriptionSvc', actionMenuFreeSubscriptionSvc);
    actionMenuFreeSubscriptionSvc.$inject = ["constants", "$filter", "$resource", "$rootScope",
        "caDetailSvc", "messageHandleSvc", "caMessage"];
    function actionMenuFreeSubscriptionSvc(constants, $filter, $resource, $rootScope,
        caDetailSvc, messageHandleSvc, caMessage) {
        var revealed = {
            setStatusDisplayMenu: setStatusDisplayMenu,
            triggerAction: triggerAction,
            acceptAction: acceptAction
        };

        var updateActionTilte = "Update_Action";
        return revealed;

        function setStatusDisplayMenu(scope, currentListAction) {
            var result = scope;
            result.listaction = angular.copy(currentListAction);
            var inputAction = angular.element(document.getElementById('action-menu-clickable'));
            var navAction = angular.element(document).find(".action-menu nav.navbar");
            inputAction.removeClass("non-clickable");
            navAction.removeClass("non-clickable");

            var indexAction = {
                "Mark_Candidate_As_Shorlisted_Action": 13,
                "Mark_Candidate_As_Hired_Action": 14,
                "Mark_Candidate_As_Rejected_Action": 15
            };

            result.disableMenu = false;
            result.listaction[indexAction.Mark_Candidate_As_Shorlisted_Action].isShow = true;
            result.listaction[indexAction.Mark_Candidate_As_Hired_Action].isShow = true;
            result.listaction[indexAction.Mark_Candidate_As_Rejected_Action].isShow = true;
            scope.actionMenuFreeSubscriptionCtrl.showMenu = true;

            return result;
        }

        function triggerAction(action, scope) {
            switch (action.key) {
                case "Mark_Candidate_As_Shorlisted_Action":
                    scope.isActionProcessing = true;
                    getJobApplicationResource(scope.candidateid, scope.jobapplicationid).update({ Id: scope.jobapplicationid, CandidateId: scope.candidateid, OverallStatus: constants.applicationStatus.Other.Shortlist }).$promise.then(
                    function () {
                        scope.lastupdatestatus = constants.applicationStatus.Other.Shortlist;
                        $rootScope.$broadcast(updateActionTilte, {});
                        toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                        scope.isActionProcessing = false;
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, caMessage.generalInformation.updateCvStatusError);
                        scope.isActionProcessing = false;

                    });

                    break;
                case "Mark_Candidate_As_Rejected_Action":
                    scope.actionMenuFreeSubscriptionCtrl.dialogConfirm.dialogMessage = "Interviews.Reject_Candidate_Confirmation";
                    $("#" + scope.actionMenuFreeSubscriptionCtrl.dialogConfirm.dialogId).modal('show');
                    break;
                case "Mark_Candidate_As_Hired_Action":
                    scope.isActionProcessing = true;
                    getJobApplicationResource(scope.candidateid, scope.jobapplicationid).update({ Id: scope.jobapplicationid, CandidateId: scope.candidateid, OverallStatus: constants.applicationStatus.OfferStatus.AcceptOffer }).$promise.then(
                    function () {
                        scope.lastupdatestatus = constants.applicationStatus.OfferStatus.AcceptOffer;
                        $rootScope.$broadcast(updateActionTilte, {});
                        toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                        scope.isActionProcessing = false;
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, caMessage.generalInformation.updateCvStatusError);
                        scope.isActionProcessing = false;

                    });

                    break;
                default:
                    break;
            }
        }

        function getJobApplicationResource(candidateId, jobApplicationId) {
            return $resource(constants.apiUrl + "candidates/:candidateId/job-application/:jobApplicationId", { candidateId: candidateId, jobApplicationId: jobApplicationId }, { "update": { method: "PUT", headers: { ActionName: "UpdateOverallStatus" } } });
        }

        function acceptAction(scope) {
            scope.isActionProcessing = true;
            getJobApplicationResource(scope.candidateid, scope.jobapplicationid).update({ Id: scope.jobapplicationid, CandidateId: scope.candidateid, OverallStatus: constants.applicationStatus.Other.RejectAll }).$promise.then(
            function () {
                scope.lastupdatestatus = constants.applicationStatus.Other.RejectAll;
                caDetailSvc.updateLastUpdateStatus(constants.applicationStatus.Other.RejectAll, scope.jobapplicationid);
                $rootScope.$broadcast(updateActionTilte, {});
                toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                scope.isActionProcessing = false;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.updateCvStatusError));
                scope.isActionProcessing = false;

            });
        }
    }
})();


