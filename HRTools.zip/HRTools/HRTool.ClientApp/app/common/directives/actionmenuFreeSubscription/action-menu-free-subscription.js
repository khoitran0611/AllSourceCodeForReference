﻿(function () {
    'use strict';
    angular.module('app').directive('actionMenuFreeSubscription', actionMenuFreeSubscription);
    actionMenuFreeSubscription.$inject = ['actionMenuFreeSubscriptionSvc', 'comparisonUtilSvc'];
    function actionMenuFreeSubscription(actionMenuFreeSubscriptionSvc, comparisonUtilSvc) {
        return {
            restrict: 'A',
            transclude: true,
            controller: 'actionMenuFreeSubscriptionCtrl',
            controllerAs: 'actionMenuFreeSubscriptionCtrl',
            templateUrl: "common/directives/actionmenuFreeSubscription/actionMenuFreeSubscription.html",
            scope: {
                "listaction": "=",
                "jobapplicationid": "=",
                "candidateid": "@",
                "interviews": "=",
                "lastupdatestatus": "=",
                "didNotLoadCandidate": "@",
                "isActionProcessing": "="
            },
            link: function (scope, element) {
                scope.$watch('lastupdatestatus', function (newValue, oldValue) {
                    if (comparisonUtilSvc.isNullOrUndefinedValue(newValue)) return;
                    if (scope.actionMenuFreeSubscriptionCtrl.currentListAction && scope.actionMenuFreeSubscriptionCtrl.currentListAction.length > 0)
                        scope = actionMenuFreeSubscriptionSvc.setStatusDisplayMenu(scope, scope.actionMenuFreeSubscriptionCtrl.currentListAction);

                }, true);

                scope.triggerAction = function (action) {
                    var dropdownElement = element.find(".dropdown.open");
                    $('.dropdown-toggle').dropdown();
                    dropdownElement.removeClass("open");
                    actionMenuFreeSubscriptionSvc.triggerAction(action, scope);
                };

                scope.onYes = function () {
                    actionMenuFreeSubscriptionSvc.acceptAction(scope);
                };

            }
        };
    }
})();