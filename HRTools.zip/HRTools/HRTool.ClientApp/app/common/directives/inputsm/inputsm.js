﻿(function () {
    'use strict';
    angular.module('app').directive('inputsm', inputsm);

    function inputsm() {
        return {
            restrict: 'A',
            transclude: true,
            controller: 'inputsmCtrl',
            controllerAs: 'ipsmCtrl',
            templateUrl: "common/directives/inputsm/inputsm.html",
            scope: {
                "value": "=",
                "placeholder": "@",
                "name": "@",
                "id": "@",
                "isrequired": "@",
                "action": "&",
                "type": "@",
                "classcss": "@"
            },
            link: function (scope) {
                scope.hidePlaceholer = false;
            }
        };
    }
})();


