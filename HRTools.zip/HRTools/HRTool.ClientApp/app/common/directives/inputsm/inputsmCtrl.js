﻿(function () {
    'use strict';
    angular.module('app').controller('inputsmCtrl', InputsmCtrl);
    InputsmCtrl.$inject = ['$scope'];
    function InputsmCtrl($scope) {
        var self = this;
        var backSpaceKeyCode = 8;
        var tabKeyCode = 9;
        var zeroKeyCode = 48;
        var nineKeyCode = 57;
        var numpadZeroKeyCode = 96;
        var numpadNineKeyCode = 105;
        var backSlashKeyCode = 95;
        var leftArrow = 37;
        var rightArrow = 39;
        var deleteKey = 46;

        $scope.isInputInvalid = false;
        $scope.changeValue = changeValue;
        $scope.checkValue = checkValue;
        $scope.blur = blurEvent;

        function changeValue() {
            $scope.isInputInvalid = true && !$scope.value;

        }

        function checkValue(event) {
            if (event.shiftKey) event.preventDefault(event);
            else {
                var eventCode = event.charCode === 0 ? event.keyCode : event.charCode;
                var nKeyCode = eventCode;
                if (nKeyCode == backSpaceKeyCode || nKeyCode == tabKeyCode) {
                    return;
                }
                if (nKeyCode < backSlashKeyCode) {
                    if (nKeyCode == zeroKeyCode && !$scope.value) event.preventDefault();
                    if (nKeyCode == leftArrow || nKeyCode == rightArrow || nKeyCode == deleteKey) return;
                    if (nKeyCode < zeroKeyCode || nKeyCode > nineKeyCode) {
                        event.preventDefault();
                    }
                } else {
                    if (nKeyCode == numpadZeroKeyCode && !$scope.value) event.preventDefault();
                    if (nKeyCode < numpadZeroKeyCode || nKeyCode > numpadNineKeyCode)
                        event.preventDefault();
                    if (nKeyCode === numpadZeroKeyCode && !$scope.value) event.preventDefault();
                }
            }
        }


        function blurEvent() {
            if (!$scope.value || $scope.value < 1) $scope.value = 1;
        }
    }
})();
