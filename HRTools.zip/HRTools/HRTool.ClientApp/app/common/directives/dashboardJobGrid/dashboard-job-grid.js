﻿(function () {
    'use strict';
    angular.module('app').filter('offset', function () {
        return function (input, start) {
            start = parseInt(start, 10);
            return input.slice(start);
        };
    });

    angular.module('app').directive('dashboardJobGrid', dashboardJobGrid);
    dashboardJobGrid.$inject = ['dbConstants'];
    function dashboardJobGrid(dbConstants) {
        return {
            restrict: 'E',
            transclude: true,
            controller: 'dashboardJobGridCtrl',
            controllerAs: 'dajobGridCtrl',
            templateUrl: "common/directives/dashboardJobGrid/dashboardJobGrid.html",
            scope: {
                "itemsPerPage": "=",
                "candidatesList": "=",
                "jobId": "=",
                "listType": "=",
                "jobStatus": "="
            },
            link: function (scope) {
                function init() {
                    var menu = dbConstants.dashboardJobMenuListName;
                    switch (scope.listType) {
                        case menu.invitation:
                            scope.addonDashboardTableCss = "invitation-tab";
                            scope.isInvitationTab = true;
                            return;
                        case menu.all:
                        case menu.new:
                        case menu.interested:
                        case menu.interviewing:
                        case menu.shortlisted:
                        case menu.offered:
                        case menu.hired:
                            scope.addonDashboardTableCss = "";
                            scope.isInvitationTab = false;
                            return;
                        default:
                            scope.addonDashboardTableCss = "";
                            scope.isInvitationTab = false;
                            return;
                    }
                }
                init();

                scope.$watch("listType", function () {
                    init();
                }, true);
            }
        };
    }
})();

