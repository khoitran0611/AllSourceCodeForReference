﻿(function () {
    'use strict';
    angular.module('app').controller('dashboardJobGridCtrl', DashboardJobGridCtrl);
    DashboardJobGridCtrl.$inject = ['$timeout', 'datetimeSvc', 'styleSvc', 'permissionSvc', 'switchCandidateSvc', 'historyPageSvc', 'candidateSvc',
        'constants', 'dbConstants',
        '$scope', '$filter', '$state', 'comparisonUtilSvc'];
    function DashboardJobGridCtrl($timeout, datetimeSvc, styleSvc, permissionSvc, switchCandidateSvc, historyPageSvc, candidateSvc,
            constants, dbConstants,
            $scope, $filter, $state, comparisonUtilSvc) {
        var self = this;
        var menu = dbConstants.dashboardJobMenuListName;

        self.listName = dbConstants.dashboardJobMenuListName;
        self.serverUrl = constants.serverUrl;
        $scope.currentPage = 1;
        $scope.listAction = [];
        self.setStatusInterview = styleSvc.setStatus;
        self.invitationStatus = constants.invitationStatusId;
        self.candidates = ($scope.listType == menu.invitation) ? convertInvitationList() : covertCandidatesList();
        self.canEditCandidateInfor = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo);
        self.canViewCandidateDetail = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewCandidateInfo);
        self.canViewInterview = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview);
        self.canViewSchedule = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_ViewScheduleInterview);
        self.canEditSchedule = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_EditSchedule);
        self.canUpdateInvitation = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_UpdateJobInvitation);
        self.defaultImage = constants.noAvatar;

        self.paginate = paginate;
        self.getTotal = getTotal;
        self.pagingAction = pagingAction;
        self.setCandidateDetailData = setCandidateDetailData;
        self.isViewHiredDate = isViewHiredDate;

        init();

        function init() {
            $scope.$watch('candidatesList', function (newValue, oldValue) {
                if (newValue != oldValue) self.candidates = ($scope.listType == menu.invitation) ? convertInvitationList() : covertCandidatesList();
                $timeout(function () {
                    $(".dashboard-job-grid").trigger('click');
                }, 1000);
            }, true);
        }

        function convertInvitationList() {
            var resultList = [];
            if (!$scope.candidatesList || $scope.candidatesList.length === 0) return resultList;
            for (var index = 0; index < $scope.candidatesList.length; index++) {
                var temp = $scope.candidatesList[index];
                $scope.candidatesList[index].FullName = $scope.candidatesList[index].CandidateName;
                $scope.candidatesList[index].Email = $scope.candidatesList[index].CandidateEmail;
                $scope.candidatesList[index].ImagePath = getImageLink($scope.candidatesList[index].CandidateImage);
                $scope.candidatesList[index].invitationStatus = $scope.candidatesList[index].Status;
                $scope.candidatesList[index].note = $scope.candidatesList[index].Note;
                $scope.candidatesList[index].invitationDate = datetimeSvc.convertDate($scope.candidatesList[index].InvitationDate);
                $scope.candidatesList[index].replyDate = datetimeSvc.convertDate($scope.candidatesList[index].ReplyDate);
                $scope.candidatesList[index].nameTitle = $scope.candidatesList[index].CandidateName;
                $scope.candidatesList[index].StatusInfor = convertInvatationStatus($scope.candidatesList[index].Status);
                $scope.candidatesList[index].jobApplicationId = 0;
                if ($scope.jobStatus == constants.jobStatusId.Closed || $scope.jobStatus == constants.jobStatusId.Ended) {
                    $scope.candidatesList[index].StatusInfor.isShowAction = false;
                }
                $scope.candidatesList[index].status = $scope.candidatesList[index].StatusInfor.status;
                $scope.candidatesList[index].jobId = $state.params.id;
            }
            return !$scope.candidatesList ? [] : $scope.candidatesList;

            function convertInvatationStatus(status) {
                switch (status) {
                    case self.invitationStatus.New:
                        return { status: "", isShowAction: true };
                    case self.invitationStatus.Accept:
                        return { status: "Invitation_Status.Added", isShowAction: false };
                    case self.invitationStatus.Closed:
                        return { status: "Invitation_Status.Closed", isShowAction: false };
                    default:
                        return { status: "", isShowAction: false };
                }
            }
        }

        function getImageLink(link) {
            if (!link || link.toLowerCase().indexOf("image-placeholder") >= 0) return angular.copy(constants.noAvatar);
            var linkInLowerCase = link.toLowerCase();
            if (linkInLowerCase.indexOf("http://") === 0 || linkInLowerCase.indexOf("https://") === 0 || linkInLowerCase.indexOf("www.") >= 0) return link;
            return (constants.serverUrl + link);
        }

        function covertCandidatesList() {
            var length = $scope.candidatesList ? $scope.candidatesList.length : 0;
            for (var index = 0; index < length; index++) {
                var historyJob = $scope.candidatesList[index].HistoryJobApplications ? $scope.candidatesList[index].HistoryJobApplications[0] : undefined;
                $scope.candidatesList[index].overallStatus = historyJob ? historyJob.OverallStatus : constants.applicationStatus.Other.RejectAll;
                $scope.candidatesList[index].hiredDate = historyJob ? datetimeSvc.convertDate(historyJob.AcceptDate, false) : "";
                $scope.candidatesList[index].interviews = convertInterview($scope.candidatesList[index]);
                $scope.candidatesList[index].jobApplicationId = historyJob ? historyJob.JobApplicationId : 0;
                $scope.candidatesList[index].rating = historyJob ? historyJob.Rating : 0;
                $scope.candidatesList[index].note = $scope.candidatesList[index].JobApplicationNote;
                $scope.candidatesList[index].appliedDate = datetimeSvc.convertDate(historyJob.ApplyDate, false);
                $scope.candidatesList[index].status = getStatus(historyJob);
                $scope.candidatesList[index].ImagePath = getImageLink($scope.candidatesList[index].CandidateImage);
                $scope.candidatesList[index].nameTitle = isValidEmailAddress($scope.candidatesList[index].FirstName) && isValidEmailAddress($scope.candidatesList[index].LastName) && $scope.candidatesList[index].FirstName == $scope.candidatesList[index].LastName ? $scope.candidatesList[index].FirstName : $scope.candidatesList[index].FirstName + " " + $scope.candidatesList[index].LastName;
            }
            return !$scope.candidatesList ? [] : $scope.candidatesList;

            function convertInterview(candidate) {
                var list = [];
                var historyCandidate = candidate.HistoryJobApplications ? candidate.HistoryJobApplications[0] : null;

                var firstInterviewResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.FirstInterviewResult : "";
                var firstInterviewId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.FirstInterviewId : 0;
                var firstScheduleId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.FirstScheduleId : 0;
                var isFirstInterviewFinished = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsFirstInterviewFinish) ? true : false) : false;
                var firstInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.FirstInterviewBookRoomDate) ? moment(historyCandidate.FirstInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
                var isCanceledFirstInterview = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsCanceledFirstInterview) ? true : false) : false;

                var secondInterviewResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.SecondInterviewResult : "";
                var secondInterviewId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.SecondInterviewId : 0;
                var secondScheduleId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.SecondScheduleId : 0;
                var isSecondInterviewFinished = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsSecondInterviewFinish) ? true : false) : false;
                var secondInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.SecondInterviewBookRoomDate) ? moment(historyCandidate.SecondInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
                var isCanceledSecondInterview = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsCanceledSecondInterview) ? true : false) : false;

                var thirdInterviewResult = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.ThirdInterviewResult : "";
                var thirdInterviewId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.ThirdInterviewId : 0;
                var thirdScheduleId = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? historyCandidate.ThirdScheduleId : 0;
                var isThirdInterviewFinished = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsThirdInterviewFinish) ? true : false) : false;
                var thirdInterviewBookRoomDate = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? (!comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate.ThirdInterviewBookRoomDate) ? moment(historyCandidate.ThirdInterviewBookRoomDate).format(constants.formatDateDDMMYYYY) : "") : "";
                var isCanceledThirdInterview = !comparisonUtilSvc.isNullOrUndefinedValue(historyCandidate) ? ((historyCandidate.IsCanceledThirdInterview) ? true : false) : false;

                var currentStatus = historyCandidate ? historyCandidate.OverallStatus : "";

                var firstInterview = {
                    interviewId: firstInterviewId, scheduleId: firstScheduleId, isFinished: isFirstInterviewFinished,
                    isCanceled: isCanceledFirstInterview, result: firstInterviewResult, bookRoomDate: firstInterviewBookRoomDate,
                    title: $filter(constants.translate)("1st_Interview") + $filter(constants.translate)(firstInterviewResult),
                    currentStatus: currentStatus
                };
                var secondInterview = {
                    interviewId: secondInterviewId, scheduleId: secondScheduleId, isFinished: isSecondInterviewFinished,
                    isCanceled: isCanceledSecondInterview, result: secondInterviewResult, bookRoomDate: secondInterviewBookRoomDate,
                    title: $filter(constants.translate)("2nd_Interview") + $filter(constants.translate)(secondInterviewResult),
                    currentStatus: currentStatus
                };
                var thirdInterview = {
                    interviewId: thirdInterviewId, scheduleId: thirdScheduleId, isFinished: isThirdInterviewFinished,
                    isCanceled: isCanceledThirdInterview, result: thirdInterviewResult, bookRoomDate: thirdInterviewBookRoomDate,
                    title: $filter(constants.translate)("3rd_Interview") + $filter(constants.translate)(thirdInterviewResult),
                    currentStatus: currentStatus
                };

                var firstInterviewDisplay = new interviewRoundDisplay(firstInterview);
                var secondInterviewDisplay = new interviewRoundDisplay(secondInterview);
                var thirdInterviewDisplay = new interviewRoundDisplay(thirdInterview);

                if (firstInterviewBookRoomDate)
                    list.push(firstInterviewDisplay);
                if (secondInterviewBookRoomDate)
                    list.push(secondInterviewDisplay);
                if (thirdInterviewBookRoomDate)
                    list.push(thirdInterviewDisplay);
                return list;
            }

            function interviewRoundDisplay(interview) {
                /* jshint -W040 */
                var self = this;
                self.result = interview.result;
                if (interview.result == constants.stringEmpty && interview.bookRoomDate != constants.stringEmpty) {
                    if (interview.overallStatus == constants.applicationStatus.Other.RejectAll)
                        self.result = constants.applicationStatus.Other.RejectAll;
                    else self.result = constants.interviewResult.scheduledDate;
                    interview.title = interview.title + interview.bookRoomDate;
                }
                self.id = interview.interviewId;
                self.ScheduleId = interview.scheduleId;
                self.currentStatus = interview.currentStatus;
                self.isFinish = interview.isFinished;
                self.isCanceled = interview.isCanceled;
                self.bookRoomDate = interview.bookRoomDate;
                self.title = interview.isCanceled ? $filter(constants.translate)("Canceled") + ": " + interview.title : interview.title;
                self.visible = interview.result || interview.bookRoomDate != constants.stringEmpty ? true : false;
                return self;
            }

            function getStatus(jobApplication) {
                if (!jobApplication) return "";
                return styleSvc.convertJobApplicationStatus(jobApplication);
            }
        }

        function paginate(value) {
            var begin = ($scope.currentPage - 1) * $scope.itemsPerPage;
            var end = begin + $scope.itemsPerPage;
            var index = $scope.candidatesList.indexOf(value);
            return (begin <= index && index < end);
        }

        function getTotal() {
            if (!$scope.candidatesList || $scope.candidatesList.length === 0 || !$scope.itemsPerPage) return 0;
            return $scope.candidatesList.length;
        }

        function pagingAction() {
        }

        function setCandidateDetailData(listType, candidateId, index) {
            switch (listType) {
                case self.listName.invitation:
                    switchCandidateSvc.setCurrentList(constants.filterData.invitationAppliedCandidates);
                    break;
                case self.listName.all:
                    switchCandidateSvc.setCurrentList(constants.filterData.allAppliedCandidates);
                    break;
                case self.listName.new:
                    switchCandidateSvc.setCurrentList(constants.filterData.newAppliedCandidates);
                    break;
                case self.listName.interested:
                    switchCandidateSvc.setCurrentList(constants.filterData.interestedAppliedCandidates);
                    break;
                case self.listName.interviewing:
                    switchCandidateSvc.setCurrentList(constants.filterData.interviewingAppliedCandidates);
                    break;
                case self.listName.shortlisted:
                    switchCandidateSvc.setCurrentList(constants.filterData.shorlistedAppliedCandidates);
                    break;
                case self.listName.offered:
                    switchCandidateSvc.setCurrentList(constants.filterData.offeredAppliedCandidates);
                    break;
                case self.listName.hired:
                    switchCandidateSvc.setCurrentList(constants.filterData.hiredAppliedCandidates);
                    break;
            }
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + candidateId, window.location.href);
            historyPageSvc.setCurrentCandidateIdIndex(index);
        }

        function isViewHiredDate(candidate) {
            if ((candidate.overallStatus == constants.applicationStatus.Other.BecomeEmployee ||
                 candidate.overallStatus == constants.applicationStatus.OfferStatus.AcceptOffer) &&
                candidate.hiredDate) return true;
            return false;
        }
    }
})();
