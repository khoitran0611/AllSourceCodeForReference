﻿(function () {
    "use strict";
    angular.module('app').directive('uploadFiles', uploadFiles);

    function uploadFiles() {
        return {
            restrict: 'E',
            controller: 'uploadFilesCtrl',
            controllerAs: 'uploadCtrl',
            templateUrl: 'common/directives/uploadFiles/uploadFiles.html',
            scope: {
                cvFiles: '=cvFiles',
                fileType: '=fileType',
                candidateName: '=candidateName'
            },
            link: function (scope, el) {
                el.bind("change", function () {
                    scope.uploadFile();
                });
            }
        };
    }
})();

