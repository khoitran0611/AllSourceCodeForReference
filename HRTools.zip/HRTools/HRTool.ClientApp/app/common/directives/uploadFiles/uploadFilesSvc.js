﻿(function () {
    'use strict';
    angular.module('app').factory('uploadFilesSvc', uploadFilesSvc);
    uploadFilesSvc.$inject = ['constants', '$resource', '$filter', '$window', 'uploadFileSvc', 'comparisonUtilSvc'];
    function uploadFilesSvc(constants, $resource, $filter, $window, uploadFileSvc, comparisonUtilSvc) {

        var cvFilesRemoving = [];
        var inputFormId = '';
        var isUpdating = false;

        var revealed = {
            uploadFile: uploadFile,
            removeCvFile: removeCvFile,
            updateCvFile: updateCvFile,
            clearInputForm: clearInputForm,
            getCvAttachments: getCvAttachments,
            showingProgressbar: showingProgressbar
        };
        return revealed;

        ////////////////////////////////////////////////////////

        function uploadFile(scope, formId) {
            inputFormId = formId;
            var fileSize = $('#' + inputFormId + ' input')[0].files[0].size;
            if (fileSize >= constants.maxFileSizeUploaded) {
                toastr.warning($filter(constants.translate)("Warning"), $filter(constants.translate)("CV.File_Size_Less_Than"));
                var control = $('#' + inputFormId + ' input');
                control.replaceWith(control = control.clone(true));
                return;
            }

            var candidateName = scope.candidateName ? scope.candidateName : '';
            var fileCvUpload = $('#' + inputFormId + ' input')[0].value;
            if (fileCvUpload !== '') {

                var file = $('#' + inputFormId + ' input')[0].files[0];
                var actionName = scope.fileType;
                $window.localStorage.setItem('CandidateFullName', candidateName, { expires: 1 });
                uploadFileSvc.uploadFile(file, actionName, candidateName).$promise.then(function (data) {
                    switch (actionName) {
                        case constants.fileType.candidateFile:
                            onUploadCvFileSuccess(data, scope);
                            break;
                        case constants.fileType.payroll:
                            onUploadCvFileSuccess(data, scope);
                            break;
                        case constants.fileType.contract:
                            onUploadContractFileSuccess(data, scope);
                            break;
                    }
                });
            }
        }

        function onUploadCvFileSuccess(data, scope) {
            if (comparisonUtilSvc.isNullOrUndefinedValue(scope.cvFiles)) scope.cvFiles = [];
            var dataArray = data.value.split(',');
            if (dataArray.length > 0) {
                var cvFile = {};
                cvFile.Url = dataArray[0].substring(1, dataArray[0].length);
                cvFile.FileName = dataArray[1].substring(0, dataArray[1].length);
                cvFile.NewItem = true;
                scope.cvFiles.push(cvFile);
            }
        }

        function onUploadContractFileSuccess(data, scope) {
            scope.cvFiles = [];
            var cvFile = {};
            cvFile.Url = data;
            var subString = data.value.split("/");
            cvFile.FileName = subString[subString.length - 1].slice(0, -1);
            scope.cvFiles.push(cvFile);
            scope.$apply();
        }

        function removeCvFile(fileId, index, parentScope, formId) {
            inputFormId = formId;
            if (fileId) {
                cvFilesRemoving.push(fileId);
            }

            switch (parentScope.$parent.fileType) {
                case constants.fileType.candidateFile:
                    parentScope.$parent.cvFiles.splice(index, 1);
                    break;
                case constants.fileType.contract:
                case constants.fileType.payroll:
                    parentScope.$parent.cvFiles = [];
                    break;
            }
        }

        function updateCvFile(params) {
            var numberOfFile = 1;
            params.cvFiles.forEach(function (cvFile) {
                if (cvFile.NewItem) {
                    cvFile.NewItem = false;
                    cvFile.FileType = "cv";
                    addCvFilesResource(params.jobApplicationId).save(cvFile).$promise.then(function (data) {
                        cvFile.FileId = data.FileId;
                        if (numberOfFile <= 1)
                            toastr.success($filter(constants.translate)("Success"), $filter(constants.translate)("CV.Add_Cv_File_Successful"));
                        numberOfFile++;
                        return true;
                    }, function () {
                        toastr.error($filter(constants.translate)("Error"), $filter(constants.translate)("CV.Add_Cv_File_Fail"));
                        return false;
                    });
                }
            });

            if (cvFilesRemoving.length > 0) {
                var numOfFile = 1;
                cvFilesRemoving.forEach(function (fileId) {
                    deleteCvFilesResource(params.candidateId, fileId).$promise.then(function (response) {
                        var updateFail = "f";
                        if (response[0] == updateFail) {
                            toastr.error($filter(constants.translate)("Error"), $filter(constants.translate)("CV.Delete_Cv_File_Fail"));
                        } else if (numOfFile <= 1) {
                            toastr.success($filter(constants.translate)("Success"), $filter(constants.translate)("CV.Delete_Cv_File_Success"));
                        }
                        numOfFile++;
                    });
                });
                cvFilesRemoving = [];
            }
        }

        function addCvFilesResource(jobApplicationId) {
            return $resource(constants.apiUrl + 'candidates/:applyPositionId/candidate-files', { applyPositionId: jobApplicationId });
        }

        function deleteCvFilesResource(candidateId, fileId) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/candidate-files/:fileId', { candidateId: candidateId, fileId: fileId }).delete(false);
        }

        function getFilesAttachment(params) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/job-applications/:jobApplicationId/candidate-files', { candidateId: params.candidateId, jobApplicationId: params.jobApplicationId });
        }

        function getCvAttachments(params) {
            return $resource(constants.apiUrl + 'candidates/:candidateId/job-applications/:jobApplicationId/cv-files', { candidateId: params.candidateId, jobApplicationId: params.jobApplicationId });
        }

        function showingProgressbar() {
            return isUpdating;
        }
        function clearInputForm() {
            cvFilesRemoving = [];
            if (inputFormId !== '') {
                var control = angular.element('#' + inputFormId + ' input');
                control.replaceWith(control = control.clone(true));
            }
        }
    }
})();

