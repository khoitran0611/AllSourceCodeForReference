﻿(function () {
    'use strict';
    angular.module('app').controller('uploadFilesCtrl', UploadFilesCtrl);
    UploadFilesCtrl.$inject = ['uploadFilesSvc', '$modal', '$filter', '$scope', 'constants'];
    function UploadFilesCtrl(uploadFilesSvc, $modal, $filter, $scope, constants) {
        var self = this;
        self.id = String.randomString() + 'File';

        self.remove = remove;
        $scope.uploadFile = uploadFile;

        function remove(fileId, index, parentScope) {
            $modal.open({
                templateUrl: 'common/directives/uploadFiles/dialogConfirmModal.html',
                controller: ['$scope', '$modalInstance', function ($scope, $modalInstance) {
                    $scope.header = $filter(constants.translate)('CV.Confirm_Delete');
                    $scope.message = $filter(constants.translate)('CV.Confirm_Delete_Message');
                    $scope.ok = function () {
                        uploadFilesSvc.removeCvFile(fileId, index, parentScope, self.id);
                        $modalInstance.dismiss('cancel');
                    };
                    $scope.cancel = function () {
                        $modalInstance.dismiss('cancel');
                    };
                }]
            });
        }

        function uploadFile() {
            uploadFilesSvc.uploadFile($scope, self.id);
        }
    }
})();
