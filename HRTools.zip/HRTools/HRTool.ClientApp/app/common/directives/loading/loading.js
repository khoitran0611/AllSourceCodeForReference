﻿(function () {
    'use strict';
    angular.module('app').directive('loading', loading);
    loading.$inject = ['constants'];
    function loading(constants) {
        return {
            priority: 1000,
            restrict: "A",            
            template: "<div ng-class=\"{ready:ready=='active'}\"></div>",
            link: function (scope, element, attrs) {
                scope.ready = 'active';               
            }
        };
    }
})();
