﻿(function () {
    'use strict';
    angular.module('app').directive('dialogConfirm', dialogConfirm);
    function dialogConfirm() {
        return {
            restrict: 'A',
            controller: 'DialogConfirmCtrl',
            controllerAs: 'dialogConfirmCtrl',
            templateUrl: 'common/directives/modal/dialog-confirm/dialogConfirm.html',
            scope: {
                'accept': '&',
                'dismiss': '&',
                'init': '=init'
            },
            link: function () {

            }
        };
    }
})();
