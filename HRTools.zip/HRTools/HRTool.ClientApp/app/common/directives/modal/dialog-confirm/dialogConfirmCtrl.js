﻿(function () {
    'use strict';
    angular.module('app').controller('DialogConfirmCtrl', DialogConfirmCtrl);
    DialogConfirmCtrl.$inject = ["$scope", "$filter", "constants"];
    function DialogConfirmCtrl(scope, $filter, constants) {
        scope.init.dialogTitle = $filter(constants.translate)(scope.init.dialogTitle);
        scope.init.dialogMessage = $filter(constants.translate)(scope.init.dialogMessage);
    }
})();


