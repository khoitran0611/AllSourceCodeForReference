﻿(function () {
    "use strict";
    angular.module('app').controller('thankYouLetterCtrl', function () {
            var self = this;
        });
})();

