﻿(function () {
    'use strict';
    angular.module('app').directive('ngThankYouLetter', ngThankYouLetter);
    ngThankYouLetter.$inject = ['emailSvc', 'messageHandleSvc', 'constants', 'message', 'candidateSvc', 'objectSvc', 'caMessage', 'permissionSvc', '$filter', '$rootScope', '$timeout'];
    function ngThankYouLetter(emailSvc, messageHandleSvc, constants, message, candidateSvc, objectSvc, caMessage, permissionSvc, $filter, $rootScope, $timeout) {
        return {
            restrict: 'A',
            controller: 'thankYouLetterCtrl',
            controllerAs: 'thankYouLetterCtrl',
            templateUrl: 'common/directives/modal/thank-you-letter/thankYouLetter.html',
            scope: {
                'emailData': '='
            },
            link: function (scope, element) {
                var permissionOfCurrentUser = {
                    sendMailUpdateCV: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SendMailUpdateCV)
                };
                scope.isDisablePrevious = true;
                scope.isDisableNext = false;
                var indexCandidate = 0;
                var originText = "";
                var originContent = "";
                var originSubject = "";
                scope.previewEmailThankYouLetter = function () {
                    var firstJobApplication = scope.emailData.listOfJobApplication[0].JobApplicationId;
                    indexCandidate = 0;
                    originContent = JSON.stringify(scope.emailData.Content);
                    originSubject = JSON.stringify(scope.emailData.Subject);
                    emailSvc.sendTheThankYouLetterTemplateTextUpdated(firstJobApplication).save(scope.emailData, function (data) {
                        scope.isDisablePrevious = true;
                        scope.isDisableNext = false;
                        scope.emailData.dataForPreview = data;
                        originText = angular.copy(scope.emailData.dataForPreview.Content);
                        scope.emailData.listOfJobApplication[0].Title = convertGenderToTitle(scope.emailData.listOfJobApplication[0].Gender);
                        scope.emailData.dataForPreview.Content = placeholderTextInLetterTemplate(originText, scope.emailData.listOfJobApplication[0]);
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
                    $("#reviewThankYouMailModal").modal('show');
                };

                scope.sendMail = function () {
                    if (!objectSvc.checkPermission(permissionOfCurrentUser.sendMailUpdateCV, message.dontHavePermissionAccess, true)) return;
                    if (scope.emailData.listOfJobApplication.length === 1) {
                        emailSvc.sendRejectEmail().send(scope.emailData.dataForPreview,
                            function () {
                                toastr.success($filter(constants.translate)(message.sendMailUpdateCVSuccess));
                                $rootScope.$broadcast(constants.broadCastTile.emailSent);
                            }, function (xhr) {
                                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                            }
                         );
                        return;
                    }
                    emailSvc.sendMultiThankYouLetter(scope.emailData.JobId).sendMultiThankYouLetter(scope.emailData,
                    function () {
                        toastr.success($filter(constants.translate)(caMessage.SendEmailsSuccessFull));
                        scope.emailData.Content = JSON.parse(scope.emailData.originContent);
                        scope.emailData.Subject = JSON.parse(scope.emailData.originSubject);
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.sendMailUpdateCvError));
                    });
                };

                scope.closeReviewEmail = function () {
                    if (scope.emailData.listOfJobApplication.length > 1) {
                        $("#thankYouLetter").modal("show");
                        scope.emailData.Content = JSON.parse(originContent);
                        scope.emailData.Subject = JSON.parse(originSubject);
                    }
                    scope.emailData.dataForPreview = {};
                };

                scope.cancelSendThankYouLetter = function () {
                    scope.emailData.Content = JSON.parse(scope.emailData.originContent);
                    scope.emailData.Subject = JSON.parse(scope.emailData.originSubject);
                };

                scope.previousCandidate = function () {
                    if (indexCandidate <= 0) return;
                    scope.isDisableNext = false;
                    indexCandidate--;
                    $timeout(function () {
                        scope.emailData.dataForPreview.To = scope.emailData.listOfJobApplication[indexCandidate].Email;
                        scope.emailData.listOfJobApplication[indexCandidate].Title = convertGenderToTitle(scope.emailData.listOfJobApplication[indexCandidate].Gender);
                        scope.emailData.dataForPreview.Content = placeholderTextInLetterTemplate(originText, scope.emailData.listOfJobApplication[indexCandidate]);
                    }, 200);
                    if (indexCandidate === 0) {
                        scope.isDisablePrevious = true;
                    }
                };

                scope.nextCandidate = function () {
                    if (indexCandidate >= scope.emailData.listOfJobApplication.length - 1) return;
                    scope.isDisablePrevious = false;
                    indexCandidate++;
                    $timeout(function () {
                        scope.emailData.dataForPreview.To = scope.emailData.listOfJobApplication[indexCandidate].Email;
                        scope.emailData.listOfJobApplication[indexCandidate].Title = convertGenderToTitle(scope.emailData.listOfJobApplication[indexCandidate].Gender);
                        scope.emailData.dataForPreview.Content = placeholderTextInLetterTemplate(originText, scope.emailData.listOfJobApplication[indexCandidate]);
                    }, 200);
                    if (indexCandidate === scope.emailData.listOfJobApplication.length - 1) {
                        scope.isDisableNext = true;
                    }
                };
            }
        };
    }
})();