﻿(function () {
    'use strict';
    angular.module('app').controller('reviewEmailCtrl', ReviewEmailCtrl);
    ReviewEmailCtrl.$inject = ['emailSvc', 'messageHandleSvc', 'message', '$filter', 'constants'];
    function ReviewEmailCtrl(emailSvc, messageHandleSvc, message, $filter, constants) {
        var self = this;
        self.sendMail = sendMail;

        function sendMail(email) {
            if (email.isRejectMail) {
                emailSvc.sendRejectEmail().send(email,
                    function () {
                        toastr.success($filter(constants.translate)(message.sendMailUpdateCVSuccess));
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    }
                 );
            }
            else {
                emailSvc.sendEmail().send(email,
                    function () {
                        toastr.success($filter(constants.translate)(message.sendMailUpdateCVSuccess));
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    }
                 );
            }
        }
    }
})();


