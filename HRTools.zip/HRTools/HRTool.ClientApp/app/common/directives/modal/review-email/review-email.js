﻿(function () {
    "use strict";
    angular.module('app').directive('ngReviewEmail', ngReviewEmail);

    function ngReviewEmail() {
        return {
            restrict: 'A',
            controller: 'reviewEmailCtrl',
            controllerAs: 'reviewEmailCtrl',
            templateUrl: 'common/directives/modal/review-email/reviewEmail.html',
            scope: {
                'email': '='
            }
        };

    }
})();
