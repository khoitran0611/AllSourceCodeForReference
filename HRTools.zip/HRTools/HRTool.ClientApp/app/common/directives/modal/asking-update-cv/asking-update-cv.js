﻿(function () {
    'use strict';
    angular.module('app').directive('ngAskingUpdateCv', ngAskingUpdateCv);
    ngAskingUpdateCv.$inject = [
        'emailSvc', 'messageHandleSvc', 'constants', 'message', 'candidateSvc',
        'objectSvc', 'caMessage', 'permissionSvc', '$filter', '$timeout', '$rootScope', 'comparisonUtilSvc'];
    function ngAskingUpdateCv(
        emailSvc, messageHandleSvc, constants, message, candidateSvc,
        objectSvc, caMessage, permissionSvc, $filter, $timeout, $rootScope, comparisonUtilSvc) {
        return {
            restrict: 'A',
            controller: 'askingUpdateCvCtrl',
            controllerAs: 'askingUpdateCvCtrl',
            templateUrl: 'common/directives/modal/asking-update-cv/askingUpdateCv.html',
            scope: {
                'emailData': '='
            },
            link: function (scope, element) {
                var permissionOfCurrentUser = {
                    sendMailUpdateCV: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SendMailUpdateCV)
                };
                scope.isDisablePrevious = true;
                scope.isDisableNext = false;
                var indexCandidate = 0;
                var originText = "";
                var originContent = "";
                var originSubject = "";
                scope.previewEmailRequestingUpdateCv = function () {
                    var firstJobApplication = scope.emailData.listOfJobApplication[0].JobApplicationId;
                    indexCandidate = 0;
                    originContent = JSON.stringify(scope.emailData.Content);
                    originSubject = JSON.stringify(scope.emailData.Subject);
                    emailSvc.sendTheTemplateTextUpdated(firstJobApplication).save(scope.emailData, function (data) {
                        scope.isDisablePrevious = true;
                        scope.isDisableNext = false;
                        scope.emailData.dataForPreview = data;
                        originText = angular.copy(scope.emailData.dataForPreview.Content);
                        scope.emailData.listOfJobApplication[0].Title = convertGenderToTitle(scope.emailData.listOfJobApplication[0].Title);
                        scope.emailData.dataForPreview.Content = placeholderTextInLetterTemplate(originText, scope.emailData.listOfJobApplication[0]);
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
                    $("#reviewUpdateCvMailModal").modal('show');
                };

                scope.sendMail = function () {
                    if (!objectSvc.checkPermission(permissionOfCurrentUser.sendMailUpdateCV, message.dontHavePermissionAccess, true)) return;
                    var jobApplicationIdList = [];
                    $.each(scope.emailData.listOfJobApplication, function (i, item) {
                        jobApplicationIdList.push(item.JobApplicationId);
                    });
                    if (scope.emailData.listOfJobApplication.length === 1) {
                        candidateSvc.sendMultiMailUpdateToCv(jobApplicationIdList).sendMultiMailUpdateCV(scope.emailData,
                        function () {
                            toastr.success($filter(constants.translate)(caMessage.sendMailUpdateCVSuccess));
                            $rootScope.$broadcast(constants.broadCastTile.requestUpdateCV, {});
                            scope.cancelSendRequestUpdateCv();
                        },
                        function (xhr) {
                            messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.sendMailUpdateCvError));
                            scope.emailData.Content = JSON.parse(scope.emailData.originContent);
                            scope.emailData.Subject = JSON.parse(scope.emailData.originSubject);
                        });

                        return;
                    }
                    candidateSvc.sendMultiMailUpdateToCv(jobApplicationIdList).sendMultiMailUpdateCV(scope.emailData,
                    function () {
                        toastr.success($filter(constants.translate)(caMessage.SendEmailsSuccessFull));
                        $rootScope.$broadcast(constants.broadCastTile.requestUpdateCV, {});
                        scope.emailData.Content = JSON.parse(scope.emailData.originContent);
                        scope.emailData.Subject = JSON.parse(scope.emailData.originSubject);
                        scope.cancelSendRequestUpdateCv();
                    },
                    function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.sendMailUpdateCvError));
                    });
                };

                scope.cancelSendRequestUpdateCv = function () {
                    removeHoverElement('.sprite-chat');
                    if (!comparisonUtilSvc.isNullOrUndefinedValue(scope.$parent.caCtrl)) {
                        scope.$parent.caCtrl.isAskUpdateCv = false;
                    }
                    if (!comparisonUtilSvc.isNullOrUndefinedValue(scope.$parent.$parent.cdCtrl)) {
                        scope.$parent.cdCtrl.isAskUpdateCv = false;
                    }
                    scope.emailData = {};
                    scope.emailData.dataForPreview = {};
                    scope.emailData.listOfJobApplication = {};
                };

                scope.closeReviewEmail = function () {
                    if (scope.emailData.listOfJobApplication.length > 1) {
                        $("#askingUpdateCvModal").modal("show");
                        scope.emailData.Subject = JSON.parse(originSubject);
                        scope.emailData.Content = JSON.parse(originContent);
                    }
                    scope.emailData.dataForPreview = {};
                };

                scope.previousCandidate = function () {
                    if (indexCandidate <= 0) return;
                    scope.isDisableNext = false;
                    indexCandidate--;
                    $timeout(function () {
                        scope.emailData.dataForPreview.To = scope.emailData.listOfJobApplication[indexCandidate].Email;
                        scope.emailData.listOfJobApplication[indexCandidate].Title = convertGenderToTitle(scope.emailData.listOfJobApplication[indexCandidate].Gender);
                        scope.emailData.dataForPreview.Content = placeholderTextInLetterTemplate(originText, scope.emailData.listOfJobApplication[indexCandidate]);
                    }, 200);
                    if (indexCandidate === 0) {
                        scope.isDisablePrevious = true;
                    }
                };

                scope.nextCandidate = function () {
                    if (indexCandidate >= scope.emailData.listOfJobApplication.length - 1) return;
                    scope.isDisablePrevious = false;
                    indexCandidate++;
                    $timeout(function () {
                        scope.emailData.dataForPreview.To = scope.emailData.listOfJobApplication[indexCandidate].Email;
                        scope.emailData.listOfJobApplication[indexCandidate].Title = convertGenderToTitle(scope.emailData.listOfJobApplication[indexCandidate].Gender);
                        scope.emailData.dataForPreview.Content = placeholderTextInLetterTemplate(originText, scope.emailData.listOfJobApplication[indexCandidate]);
                    }, 200);
                    if (indexCandidate === scope.emailData.listOfJobApplication.length - 1) {
                        scope.isDisableNext = true;
                    }
                };
            }
        };
    }
})();

