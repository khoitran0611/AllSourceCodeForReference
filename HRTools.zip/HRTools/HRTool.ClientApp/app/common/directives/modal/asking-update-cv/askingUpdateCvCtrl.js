﻿(function () {
    "use strict";
    angular.module('app').controller('askingUpdateCvCtrl', function () {
        var self = this;
    });
})();

