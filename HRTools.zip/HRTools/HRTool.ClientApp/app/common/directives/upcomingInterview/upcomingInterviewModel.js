﻿(function () {
    'use strict';
    angular.module('app').factory('upcomingInterviewModel', upcomingInterviewModel);
    upcomingInterviewModel.$inject = ['upcomingInterviewSvc', '$window'];
    function upcomingInterviewModel(upcomingInterviewSvc, $window) {
        var upcomingInterviewData = [];
        var changeData = false;
        var userCookie = JSON.parse($window.localStorage.getItem("currentuserlogin"));
        var currentShowFirstIndex = -1;
        var currentShowLastIndex = -1;
        var maxItemShow = 3;
        var upcomingInterviewAllData = [];

        return {
            refresh: init,
            getChange: getChange,
            getUpcomingInterviewData: getUpcomingInterviewData,
            hasNextUpcomingInterview: hasNextUpcomingInterview,
            hasPreviousUpcomingInterview: hasPreviousUpcomingInterview,
            getNextUpcomingInterview: getNextUpcomingInterview,
            getPreviousUpcomingInterview: getPreviousUpcomingInterview
        };

        function init() {
            currentShowFirstIndex = -1;
            currentShowLastIndex = -1;
            upcomingInterviewSvc.getUpcomingInterviewSchedulesByEmployeeId(userCookie.UserId, getNextUpcomingInterview);
        }

        function getChange() {
            return changeData;
        }

        function getUpcomingInterviewData() {
            return upcomingInterviewData;
        }

        function hasNextUpcomingInterview() {
            return !!upcomingInterviewAllData.length && currentShowLastIndex < upcomingInterviewAllData.length - 1;
        }

        function hasPreviousUpcomingInterview() {
            return currentShowFirstIndex > 0;
        }

        function getNextUpcomingInterview() {
            upcomingInterviewAllData = upcomingInterviewSvc.getUpcomingInterviews();
            var totalUpcomingInterview = upcomingInterviewAllData.length;
            if (currentShowLastIndex < totalUpcomingInterview) {
                currentShowFirstIndex = currentShowLastIndex;
                currentShowLastIndex = (currentShowLastIndex + maxItemShow) < totalUpcomingInterview ? (currentShowLastIndex + maxItemShow) : (totalUpcomingInterview - 1);
            }
            if (currentShowFirstIndex != currentShowLastIndex) {
                upcomingInterviewData = upcomingInterviewAllData.slice(currentShowFirstIndex + 1, currentShowLastIndex + 1);
                changeData = !changeData;
            }

        }

        function getPreviousUpcomingInterview() {
            if (currentShowFirstIndex > -1) {
                currentShowLastIndex = currentShowFirstIndex;
                currentShowFirstIndex = (currentShowFirstIndex - maxItemShow) > -1 ? (currentShowFirstIndex - maxItemShow) : -1;
            }
            if (currentShowFirstIndex != currentShowLastIndex) {
                upcomingInterviewData = upcomingInterviewAllData.slice(currentShowFirstIndex + 1, currentShowLastIndex + 1);
                changeData = !changeData;
            }
        }
    }
})();
