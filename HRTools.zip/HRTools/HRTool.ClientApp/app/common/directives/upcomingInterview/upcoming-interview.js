﻿(function () {
    "use strict";
    angular.module('app').directive('upcomingInterview', upcomingInterview);

    function upcomingInterview() {
        return {
            restrict: 'E',
            controller: 'upcomingInterviewCtrl',
            controllerAs: 'directiveCtrl',
            templateUrl: 'common/directives/upcomingInterview/upcomingInterview.html',
            scope: {
            }
        };
    }
})();
