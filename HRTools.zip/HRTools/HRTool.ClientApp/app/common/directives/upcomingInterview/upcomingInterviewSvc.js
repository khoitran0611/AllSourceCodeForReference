﻿(function () {
    'use strict';
    angular.module('app').factory('upcomingInterviewSvc', UpcomingInterviewSvc);
    UpcomingInterviewSvc.$inject = [
        'interviewScheduleSvc', 'messageHandleSvc', 'candidateSvc', 'constants', 'dbMessage',
        '$filter', '$rootScope', 'comparisonUtilSvc'];
    function UpcomingInterviewSvc(
        interviewScheduleSvc, messageHandleSvc, candidateSvc, constants, dbMessage,
        $filter, $rootScope, comparisonUtilSvc) {
        var upcomingInterviews = []; //Format: [{ date: "", interviews: [], message: "" }, { date: "", interviews: [], message: "" }, { date: "", interviews: [], message: "" }];
        return {
            getUpcomingInterviewSchedulesByEmployeeId: getUpcomingInterviewSchedulesByEmployeeId,
            getUpcomingInterviews: getUpcomingInterviews
        };

        function getUpcomingInterviewSchedulesByEmployeeId(id, callback) {
            upcomingInterviews = [];
            interviewScheduleSvc.getUpComingInterview(id).query().$promise.then(function (data) {
                if (!comparisonUtilSvc.isNullOrUndefinedValue(data)) {
                    var today = moment().startOf('day');
                    var selectedDate = today;
                    var targetDate;
                    var count = 0;
                    upcomingInterviews.push({});
                    upcomingInterviews[count].interviews = [];
                    angular.forEach(data, function (interview, key) {
                        targetDate = moment(interview.FromBookRoomDate + " " + interview.FromBookRoomTime, constants.formatDateTimeServer).startOf('day');
                        var candidateInterview;
                        if (!key) {
                            upcomingInterviews[count].date = "TODAY";
                            if (today.diff(targetDate, 'days')) {
                                upcomingInterviews[count].message = $filter(constants.translate)(dbMessage.messageAppointmentEmpty);
                                count++;
                                selectedDate = targetDate;
                                upcomingInterviews.push({});
                                upcomingInterviews[count].date = interview.FromBookRoomDate;
                                upcomingInterviews[count].interviews = [];
                                upcomingInterviews[count].message = "";
                                candidateInterview = candidateSvc.interviewResource(interview.CandidateId, interview.JobApplicationId).get(function () {
                                    interview.LastUpdateStatus = candidateInterview.LastUpdateStatus == constants.applicationStatus.Other.RejectAll ? true : false;
                                    interview.HasOfferLetter = candidateInterview.HasOfferLetter;
                                });
                                upcomingInterviews[count].interviews.push(interview);
                            } else {
                                upcomingInterviews[count].message = "";
                                candidateInterview = candidateSvc.interviewResource(interview.CandidateId, interview.JobApplicationId).get(function () {
                                    interview.LastUpdateStatus = candidateInterview.LastUpdateStatus == constants.applicationStatus.Other.RejectAll ? true : false;
                                    interview.HasOfferLetter = candidateInterview.HasOfferLetter;
                                });
                                upcomingInterviews[count].interviews.push(interview);
                            }
                        } else {
                            if (selectedDate.diff(targetDate, 'days')) {
                                count++;
                                selectedDate = targetDate;
                                upcomingInterviews.push({});
                                upcomingInterviews[count].date = interview.FromBookRoomDate;
                                upcomingInterviews[count].interviews = [];
                                upcomingInterviews[count].message = "";
                            }
                            candidateInterview = candidateSvc.interviewResource(interview.CandidateId, interview.JobApplicationId).get(function () {
                                interview.LastUpdateStatus = candidateInterview.LastUpdateStatus == constants.applicationStatus.Other.RejectAll ? true : false;
                                interview.HasOfferLetter = candidateInterview.HasOfferLetter;
                            });
                            upcomingInterviews[count].interviews.push(interview);
                        }
                    });
                    if (!data.length) {
                        upcomingInterviews.push({ date: "TODAY", interviews: [], message: $filter(constants.translate)(dbMessage.messageAppointmentEmpty) });
                    }
                } else {
                    upcomingInterviews.push({ date: "TODAY", interviews: [], message: $filter(constants.translate)(dbMessage.messageAppointmentEmpty) });
                }
            }, function (error) {
                // messageHandleSvc.handleResponse(error);
                $rootScope.$broadcast(constants.broadCastTile.dasboardLoadFail, {});
            }).then(callback);
        }

        function getUpcomingInterviews() {
            return upcomingInterviews;
        }
    }
})();

