﻿(function () {
    'use strict';
    angular.module('app').controller('upcomingInterviewCtrl', UpcomingInterviewCtrl);
    UpcomingInterviewCtrl.$inject = ["upcomingInterviewModel", "constants",
        "$scope", "$state", "$timeout",
        "historyPageSvc", "permissionSvc", "switchCandidateSvc"];
    function UpcomingInterviewCtrl(upcomingInterviewModel, constants,
        $scope, $state, $timeout,
        historyPageSvc, permissionSvc, switchCandidateSvc) {
        var self = this;

        self.isShowLoading = true;
        self.hasNextUpcomingInterview = hasNextUpcomingInterview;
        self.hasPreviousUpcomingInterview = hasPreviousUpcomingInterview;
        self.getNextUpcomingInterview = getNextUpcomingInterview;
        self.getPreviousUpcomingInterview = getPreviousUpcomingInterview;
        self.goToInterview = goToInterview;
        self.canViewInterview = permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview);
        self.setHistoryDirectCandidateDetail = setHistoryDirectCandidateDetail;

        init();
        function init() {
            upcomingInterviewModel.refresh();
            $scope.$watch(function () { return upcomingInterviewModel.getChange(); }, function () {
                self.upcomingInterviewData = upcomingInterviewModel.getUpcomingInterviewData();
                $timeout(function () {
                    self.isShowLoading = false;
                }, 500);
            });
        }

        function hasNextUpcomingInterview() {
            return upcomingInterviewModel.hasNextUpcomingInterview();
        }

        function hasPreviousUpcomingInterview() {
            return upcomingInterviewModel.hasPreviousUpcomingInterview();
        }

        function getNextUpcomingInterview() {
            upcomingInterviewModel.getNextUpcomingInterview();
        }

        function getPreviousUpcomingInterview() {
            upcomingInterviewModel.getPreviousUpcomingInterview();
        }

        function goToInterview(interviewId) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/interviews/" + interviewId + "/conduct-interview", window.location.href);
            $state.go("conductInterview", { interviewId: interviewId });
        }

        function setHistoryDirectCandidateDetail(id) {
            var url = constants.baseUrl + "#/candidates/" + id;
            historyPageSvc.setPreviousUrl(url, window.location.href);
            var dataFilter = {
                listId: [id],
                pageIndex: 1,
                totalPages: 1
            };
            switchCandidateSvc.setFilterData(constants.filterData.upComingCandidate, dataFilter);
            switchCandidateSvc.setCurrentList(constants.filterData.upComingCandidate);
        }
    }
})();

