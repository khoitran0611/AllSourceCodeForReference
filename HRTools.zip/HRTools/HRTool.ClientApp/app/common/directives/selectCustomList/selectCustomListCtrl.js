﻿(function () {
    "use strict";
    angular.module('app').controller('selectCustomListCtrl',
        function () {
            /* jshint -W040 */
            var self = this;
            self.id = String.randomString();
        });
})();