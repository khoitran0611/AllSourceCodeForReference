﻿(function () {
    'use strict';
    angular.module('app').directive('selectCustomList', selectCustomList);
    selectCustomList.$inject = ['$timeout'];
    function selectCustomList($timeout) {
        return {
            restrict: 'A',
            priority: 1000,
            transclude: true,
            controller: 'selectCustomListCtrl',
            controllerAs: 'selectCustomListCtrl',
            templateUrl: 'common/directives/selectCustomList/selectCustomList.html',
            scope: {
                'value': '=',
                'data': '=',
                'makeFilter': '=',
                'placeHolder': '=',
                'init': '='
            },
            compile: function () {
                function filter(listItem, value) {
                    if (!value) return listItem;
                    var result = [];
                    for (var index = 0; index < listItem.length; index++) {
                        if (listItem[index].text.toLowerCase().indexOf(value.toLowerCase()) >= 0) {
                            result.push(listItem[index]);
                        }
                    }
                    return result;
                }
                function setCss(list, id) {
                    if (!list || list.length === 0) {
                        $("#" + id + "-selection").css("overflow-y", "hidden");
                        $("#" + id + "-selection .select-combox-item").css("cursor", "default");
                        $("#" + id + "-selection .select-combox-item").width($("#" + id + " input").width());
                        return;
                    }
                    if (list.length < 10) {
                        $("#" + id + "-selection").css("overflow-y", "hidden");
                        $("#" + id + "-selection .select-combox-item").css("cursor", "pointer");
                        $("#" + id + "-selection .select-combox-item").width($("#" + id + " input").width());
                        return;
                    }
                    $("#" + id + "-selection").css("overflow-y", "scroll");
                    $("#" + id + "-selection .select-combox-item").css("cursor", "pointer");
                    $("#" + id + "-selection .select-combox-item").width($("#" + id + " input").width() - 17);
                }


                return {
                    pre: function (scope) {
                        function changeValue() {
                            if (scope.makeFilter) scope.dataList = filter(scope.list, scope.value);
                            setCss(scope.dataList, scope.selectCustomListCtrl.id);
                            $("#" + scope.selectCustomListCtrl.id + "-selection").slideDown();
                        }
                        function chooseValue(text) {
                            scope.value = text; $("#" + scope.selectCustomListCtrl.id + "-selection").slideUp();
                            if (scope.makeFilter) scope.dataList = filter(scope.list, scope.value);
                            setCss(scope.dataList, scope.selectCustomListCtrl.id);
                        }
                        function onfocus() {
                            setCss(scope.dataList, scope.selectCustomListCtrl.id);
                            $("#" + scope.selectCustomListCtrl.id + "-selection").slideDown();
                        }
                        function onblur() {
                            $("#" + scope.selectCustomListCtrl.id + "-selection").slideUp();
                        }
                        scope.changeValue = changeValue;
                        scope.chooseValue = chooseValue;
                        scope.onfocus = onfocus;
                        scope.onblur = onblur;
                        scope.dataLis = [];
                        scope.$watch('data', function () {
                            scope.list = [];
                            var list = [];
                            if (!scope.data || scope.data.length === 0) return;
                            for (var i = 0; i < scope.data.length; i++) {
                                var item = {
                                    id: scope.data[i][scope.init.id],
                                    text: scope.data[i][scope.init.text]
                                };
                                list.push(item);
                            }
                            scope.list = list.sort(function (a, b) {
                                var key1 = a.text;
                                var key2 = b.text;
                                if (!key1) return -1;
                                if (!key2) return 1;
                                return key1.localeCompare(key2);
                            });
                            scope.dataList = (scope.makeFilter) ? filter(scope.list, scope.value) : scope.list;
                        }, true);

                    },

                    post: function (scope, element) {

                    }
                };
            }
        };
    }
})();
