﻿(function () {
    'use strict';
    angular.module('app').directive('jobApplicationVote', jobApplicationVote);
    jobApplicationVote.$inject = ['$timeout', '$resource', '$q', '$filter', '$rootScope', 'constants', 'message', 'messageHandleSvc'];
    function jobApplicationVote($timeout, $resource, $q, $filter, $rootScope, constants, message, messageHandleSvc) {
        return {
            restrict: 'EA',
            transclude: true,
            controller: 'jobApplicationVoteCtrl',
            controllerAs: 'jobVoteCtrl',
            templateUrl: "common/directives/jobApplicationVote/jobApplicationVote.html",
            scope: {
                vote: "@",
                candidateId: "@",
                jobApplicationId: "@",
                isReload: "@"
            },
            link: function (scope, element) {
                var filled = 'filled';
                var unfilled = 'unfilled';
                var stars = [{ id: 0, fill: unfilled }, { id: 1, fill: unfilled }, { id: 2, fill: unfilled }, { id: 3, fill: unfilled }, { id: 4, fill: unfilled }];
                scope.tempStars = [];
                scope.stars = [];
                scope.showRating = showRating;
                scope.rating = rating;
                scope.voteCandidate = voteCandidate;
                scope.isSaved = false;
                scope.cancelRating = cancelRating;
                scope.saveRating = saveRating;
                scope.clear = clear;
                scope.mouseHover = mouseHover;
                scope.mouseLeave = mouseLeave;
                function voteCandidate(number) {
                    scope.tempVote = number + 1;
                    scope.tempStars = rating(number);
                }
                function showRating() {
                    scope.isSaved = false;
                    if (!scope.vote) scope.vote = 0;
                    scope.tempStars = rating(scope.vote - 1);
                    scope.tempVote = parseInt(scope.vote);
                    $('#' + scope.jobVoteCtrl.id + "-Rating").modal('show');
                }
                function rating(number) {
                    for (var index = 0; index < stars.length; index++) {
                        stars[index].fill = (stars[index].id <= number) ? filled : unfilled;
                    }
                    return stars;
                }

                scope.$watch("vote", function (newVal, oldVal) {
                    angular.copy(rating(scope.vote - 1), scope.stars);
                    scope.tempVote = parseInt(scope.vote);
                }, true);
                function cancelRating() {
                    scope.isSaved = false;
                    $('#' + scope.jobVoteCtrl.id + "-Rating").modal('hide');
                }
                function saveRating() {
                    if (scope.isSaved) return;
                    scope.isSaved = true;
                    var deferred = $q.defer();
                    var jobApplicationResource = $resource(constants.apiUrl + "candidates/:candidateId/job-application/:jobApplicationId/rating",
                        { candidateId: scope.candidateId, jobApplicationId: scope.jobApplicationId },
                        {
                            "update": { method: "PUT", headers: { ActionName: "UpdateJobApplicationRating" } }
                        });
                    var data = { Id: scope.jobApplicationId, CandidateId: scope.candidateId, Rating: scope.tempVote };
                    jobApplicationResource.update(data).$promise.then(
                        function (value) {
                            $rootScope.$broadcast(constants.broadCastTile.updateCandidateRating, data);
                            $('#' + scope.jobVoteCtrl.id + "-Rating").modal('hide');
                            toastr.success($filter(constants.translate)("General_Information.Rating_Is_Updated_Successfully"));
                            scope.vote = parseInt(scope.tempVote);
                            angular.copy(rating(scope.vote - 1), scope.stars);
                            deferred.resolve(value);
                        }, function (reason) {
                            $('#' + scope.jobVoteCtrl.id + "-Rating").modal('hide');
                            messageHandleSvc.handleResponse(reason, $filter(constants.translate)(message.errorInSavingData));
                            deferred.reject(reason);
                        });
                }
                function clear() {
                    voteCandidate(-1);
                }

                function mouseHover(number) {
                    scope.tempStars = rating(number);
                }
                function mouseLeave() {
                    scope.tempStars = rating(parseInt(scope.tempVote) - 1);
                }
            }
        };
    }
})();


