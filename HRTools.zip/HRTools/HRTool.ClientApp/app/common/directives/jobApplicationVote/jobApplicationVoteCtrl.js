﻿(function () {
    'use strict';
    angular.module('app').controller('jobApplicationVoteCtrl', JobApplicationVoteCtrl);
    JobApplicationVoteCtrl.$inject = ['permissionSvc'];
    function JobApplicationVoteCtrl(permissionSvc) {
        var self = this;
        self.id = String.randomString();
        self.userPermission = {
            editCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_EditCandidateInfo)
        };
    }
})();
