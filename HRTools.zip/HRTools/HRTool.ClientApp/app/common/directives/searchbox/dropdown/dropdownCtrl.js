﻿(function () {
    'use strict';
    angular.module('app').controller('dropdownBox', DropdownBox);
    DropdownBox.$inject = ['searchBoxSvc'];
    function DropdownBox(searchBoxSvc) {
        var self = this;
        self.id = String.randomString();
        self.removeFieldSearch = removeFieldSearch;
        self.callSearchApi = callSearchApi;
        self.focusSelectOption = focusSelectOption;

        function removeFieldSearch(scope) {
            searchBoxSvc.removeFieldSearch(scope);
        }
        function callSearchApi(scope) {
            searchBoxSvc.callSearchApi(scope);
        }
        function focusSelectOption() {
            var select = angular.element(document.getElementById(self.id));
            select.focus();
        }
    }
})();