﻿(function () {
    'use strict';
    angular.module('app').directive('sbDropDown', sbDropDown);
    sbDropDown.$inject = ['searchBoxSvc', '$timeout'];
    function sbDropDown(searchBoxSvc, $timeout) {
        return {
            restrict: 'A',
            controller: 'dropdownBox',
            controllerAs: 'drdsearh',
            templateUrl: searchBoxSvc.templatePathDiective().dropdown,
            scope: {
                'data': '=',
                'value': '='
            },
            link: function (scope, element) {
                scope.dropdownData = scope.data.initdata;

                searchBoxSvc.setBackgroundColorSearchBox();

                scope.$on('selfRemoveItem', function () {
                    searchBoxSvc.removeFieldSearch(scope);
                });

                scope.$on("$destroy", function () {
                    angular.element(element).remove();
                });
                $timeout(function () {
                    var input = angular.element(document.getElementById(scope.drdsearh.id));
                    input.focus();
                }, 500);
            }
        };
    }
})();
