﻿(function () {
    'use strict';
    angular.module('app').controller('dropdownCheckboxCtrl', DropdownCheckboxCtrl);
    DropdownCheckboxCtrl.$inject = ['searchBoxSvc'];
    function DropdownCheckboxCtrl(searchBoxSvc) {
        var self = this;
        self.id = String.randomString();
        self.randomKey = String.randomString();

        self.removeFieldSearch = removeFieldSearch;
        self.callSearchApi = callSearchApi;

        init();

        function init() {
            $(".dropdown-checkbox ul").hide();
            $(".dropdown-checkbox  ul li a").on('click', function () {
                $(".dropdown-checkbox  ul").hide();
            });
            $(document).bind('click', function (e) {
                var $clicked = $(e.target);
                if (!$clicked.parents().hasClass("dropdown-checkbox")) {
                    $(".dropdown-checkbox  ul").hide();
                    $(".mutliSelect").removeClass("mutliSelect-border");
                }
            });
        }

        function removeFieldSearch(scope) {
            searchBoxSvc.removeFieldSearch(scope);
        }

        function callSearchApi(scope) {
            searchBoxSvc.callSearchApi(scope);
        }
    }
})();
