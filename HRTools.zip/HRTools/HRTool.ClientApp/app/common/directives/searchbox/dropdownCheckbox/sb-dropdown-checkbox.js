﻿(function () {
    'use strict';
    angular.module('app').directive('sbDropdownCheckbox', sbDropdownCheckbox);
    sbDropdownCheckbox.$inject = ['searchBoxSvc', '$timeout'];
    function sbDropdownCheckbox(searchBoxSvc, $timeout) {
        return {
            restrict: 'A',
            controller: 'dropdownCheckboxCtrl',
            controllerAs: 'drdcheckbox',
            templateUrl: searchBoxSvc.templatePathDiective().dropdowncheckbox,
            scope: {
                'data': '=',
                'value': '='
            },
            link: function (scope, element) {
                scope.randomKey = String.randomString();
                for (var i = 0; i < scope.data.initData.length; i++) {
                    scope.data.initData[i].isActive = false;
                }
                scope.dropdownCheckboxData = scope.data.initData;
                scope.slectedItems = "";
                scope.tempArray = [];
                var input;
                scope.statusSelected = function (item) {
                    var temp = [];
                    var itemTitle = item.displayValue + ",";
                    if (!item.isActive) {
                        scope.slectedItems = scope.slectedItems + itemTitle;
                        scope.tempArray.push(item);
                    } else {
                        scope.slectedItems = scope.slectedItems.replace(itemTitle, '');
                        var indexOfSelected = scope.tempArray.indexOf(item);
                        scope.tempArray.splice(indexOfSelected, 1);
                    }
                    if (scope.tempArray && scope.tempArray.length > 0) {
                        temp.push(scope.tempArray);
                    }
                    scope.value = temp;
                };
                scope.toogleDropdown = function () {
                    toogleDropdownAction();
                };

                function toogleDropdownAction() {
                    var tempActiveItem = ".dropdown-checkbox.{0} ul";
                    tempActiveItem = String.format(tempActiveItem, scope.randomKey);
                    var tempBorder = ".{0} .mutliSelect";
                    tempBorder = String.format(tempBorder, scope.randomKey);
                    var status = $(tempActiveItem).is(":hidden");
                    if (status) {
                        $(tempBorder).addClass("mutliSelect-border");
                    } else {
                        $(tempBorder).removeClass("mutliSelect-border");
                    }
                    $(tempActiveItem).slideToggle('fast');
                }
                searchBoxSvc.setBackgroundColorSearchBox();

                scope.$on('selfRemoveItem', function () {
                    searchBoxSvc.removeFieldSearch(scope);
                });

                scope.$on("$destroy", function () {
                    angular.element(element).remove();
                });
                scope.focusInput = function () {
                    toogleDropdownAction();
                };
                $timeout(function () {
                    input = angular.element(document.getElementById(scope.drdcheckbox.id));
                    input.focus();
                }, 500);
            }
        };
    }
})();
