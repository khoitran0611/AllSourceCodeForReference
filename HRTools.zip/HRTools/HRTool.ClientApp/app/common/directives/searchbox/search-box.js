﻿(function () {
    'use strict';
    angular.module('app').directive('ngSearchBox', ngSearchBox);
    ngSearchBox.$inject = ['searchBoxSvc', '$compile', '$timeout', '$document', 'constants'];
    function ngSearchBox(searchBoxSvc, $compile, $timeout, $document, constants) {
        return {
            restrict: 'A',
            controller: 'searchBoxCtrl',
            controllerAs: 'sb',
            templateUrl: searchBoxSvc.templatePathDiective().searchbox,
            scope: {
                'data': '=',
                'query': '=',
                'callapi': '&',
                'collapsable': '='
            },

            link: function (scope, element) {
                scope.sb.query.value = scope.query;
                scope.sb.isCollapsable = scope.collapsable;

                var input = angular.element(document.getElementsByClassName('input-main-query'));
                if (scope.sb.isCollapsable) {
                    input.addClass("input-collapse");
                }

                $document.bind('click', function (event) {
                    scope.sb.isInputFocused = false;
                    if (!scope.$$phase || !scope.$root.$$phase) {
                        scope.$apply();
                    }
                });

                scope.addFieldSearch = function (fieldSearch) {
                    scope.sb.isSearchAdvanced = true;
                    searchBoxSvc.addFieldSearch(fieldSearch, $compile, scope);
                };

                scope.search = function (item) {
                    if (item.Phone) {
                        item.Phone = item.Phone.replace(/\s+/g, '');
                    }
                    if (item.OtherPhone) {
                        item.OtherPhone = item.OtherPhone.replace(/\s+/g, '');
                    }
                    var api = { method: "search", query: item.sb.query };
                    scope.callapi(api);
                };

                scope.clearSearch = function (item) {
                    item.sb.isSearchCondition = false;
                    item.sb.isInputFocused = false;
                    item.sb.isSearchAdvanced = false;
                    item.sb.query.value = "";
                    var api = { method: "clearSearch", query: undefined };
                    searchBoxSvc.removeAllChildInput(scope);
                    searchBoxSvc.clearBackgroundColorSearchBox();
                    scope.callapi(api);
                };
                scope.changeValue = function (item) {
                    var query = item.sb.query ? item.sb.query.value : "";
                    searchBoxSvc.changeQuery(query, scope);
                };

                scope.$on(constants.broadCastTile.clearSearch, function (event, rootScopeParams) {
                    scope.sb.isSearchCondition = false;
                    scope.sb.isInputFocused = false;
                    scope.sb.isSearchAdvanced = false;
                    searchBoxSvc.removeAllChildInput(scope);
                    searchBoxSvc.clearBackgroundColorSearchBox();
                    var oldQuery = scope.sb.query.value;
                    scope.sb.query.value = "";
                    $.jStorage.deleteKey(constants.localStorageKey.candidateSearch);
                    var api = { method: "clearSearch", query: undefined };
                    if (oldQuery !== '')
                        scope.callapi(api);
                });
            }
        };
    }
})();