﻿(function () {
    'use strict';
    angular.module('app').controller('datepickerCtrl', DatepickerCtrl);
    DatepickerCtrl.$inject = ['searchBoxSvc'];
    function DatepickerCtrl(searchBoxSvc) {
        var self = this;
        self.id = String.randomString();

        self.removeFieldSearch = removeFieldSearch;
        self.callSearchApi = callSearchApi;

        init();

        function init() {
            $('.date').datepicker({
                changeMonth: true, changeYear: true, autoclose: true, todayHighlight: true
            });
        }

        function removeFieldSearch(scope) {
            searchBoxSvc.removeFieldSearch(scope);
        }

        function callSearchApi(scope) {
            searchBoxSvc.callSearchApi(scope);
        }
    }
})();
