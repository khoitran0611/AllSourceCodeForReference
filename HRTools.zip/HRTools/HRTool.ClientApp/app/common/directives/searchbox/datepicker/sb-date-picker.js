﻿(function () {
    'use strict';
    angular.module('app').directive('sbDatePicker', sbDatePicker);
    sbDatePicker.$inject = ['searchBoxSvc', '$timeout'];
    function sbDatePicker(searchBoxSvc, $timeout) {
        return {
            restrict: 'A',
            controller: 'datepickerCtrl',
            controllerAs: 'dpksearh',
            templateUrl: searchBoxSvc.templatePathDiective().datepicker,
            scope: {
                'data': '=',
                'value': '='
            },
            link: function (scope, element) {
                searchBoxSvc.setBackgroundColorSearchBox();

                scope.$on('selfRemoveItem', function () {
                    searchBoxSvc.removeFieldSearch(scope);
                });

                scope.$on("$destroy", function () {
                    angular.element(element).remove();
                });
                $timeout(function () {
                    var input = angular.element(document.getElementById(scope.dpksearh.id));
                    input.focus();
                }, 500);
            }
        };
    }
})();
