﻿(function () {
    'use strict';
    angular.module('app').factory('searchBoxSvc', searchBoxSvc);
    searchBoxSvc.$inject = ['searchBoxModel', 'searchBoxConstant', 'historyPageSvc', '$timeout', '$compile', 'comparisonUtilSvc'];
    function searchBoxSvc(searchBoxModel, searchBoxConstant, historyPageSvc, $timeout, $compile, comparisonUtilSvc) {
        var queryInputValue = {
            value: ""
        };

        var numOfSearchCondition = 0;

        var revealed = {
            templatePathDiective: templatePathDirective,
            initFieldSearch: initFieldSearch,
            callSearchApi: callSearchApi,
            addFieldSearch: addFieldSearch,
            removeFieldSearch: removeFieldSearch,
            getQueryInput: getQueryInput,
            clearQueryInput: clearQueryInput,
            removeAllChildInput: removeAllChildInput,
            setBackgroundColorSearchBox: setBackgroundColorSearchBox,
            clearBackgroundColorSearchBox: clearBackgroundColorSearchBox,
            increaseNumOfSearchCondition: increaseNumOfSearchCondition,
            decreaseNumOfSearchCondition: decreaseNumOfSearchCondition,
            changeQuery: changeQuery
        };
        return revealed;

        function templatePathDirective() {
            var rootPath = "common/directives/searchbox/";
            var templatePath = {
                searchbox: rootPath + "searchBox.html",
                textfield: rootPath + "textfield/textfield.html",
                numberfield: rootPath + "numberField/numberField.html",
                selectnumber: rootPath + "selectNumber/selectNumber.html",
                datepicker: rootPath + "datepicker/datepicker.html",
                daterangepicker: rootPath + "dateRangePickerBox/dateRangePickerBox.html",
                dropdown: rootPath + "dropdown/dropdown.html",
                dropdowncheckbox: rootPath + "dropdownCheckbox/dropdownCheckbox.html",
                selecttwo: rootPath + "select2/select2.html"
            };
            return templatePath;
        }

        function initFieldSearch(initData) {
            var initField = [];
            for (var i = 0; i < initData.fieldSearch.length; i++) {
                var temp = initData.fieldSearch[i];
                var searchBoxField = new searchBoxModel();
                searchBoxField.fieldName = temp.field;
                searchBoxField.displayName = temp.displayName;
                searchBoxField.value = temp.value;
                searchBoxField.controlType = temp.type;
                searchBoxField.status = searchBoxConstant.status.deActive;
                searchBoxField.optionStyle = temp.optionStyle;
                searchBoxField.parent = temp.parent;

                historyPageSvc.setPreviousQuery(initData.listType + temp.field, null);
                initField.push(searchBoxField);
            }
            return initField;
        }

        function callSearchApi(scope) {
            var api = { method: "search", query: scope.$parent.sb.query };
            historyPageSvc.setPreviousQuery(window.location.href, api.query ? api.query.value : "");
            scope.$parent.callapi(api);
        }

        function buildingQueryString(parentScope) {
            var tempArrayQuery = [];
            var currentType = parentScope.data.listType;
            for (var i = 0; i < parentScope.data.fieldSearch.length; i++) {
                var object;
                var tempFieldSearch = parentScope.data.fieldSearch[i].field;
                var tempValueSearch = parentScope.data.fieldSearch[i].value;
                var paramObject = parentScope[tempFieldSearch];
                var curentValue = parentScope[tempValueSearch];
                if (checkControlTypeValue(paramObject, curentValue)) {
                    object = getKeyandValueforQuery(paramObject, curentValue);
                    tempArrayQuery.push(object);
                } else {
                    removeEmptyFieldSearch(tempFieldSearch, currentType);
                }
            }

            var query = passArrayQueryToString(tempArrayQuery, currentType);
            return query;
        }

        function removeEmptyFieldSearch(key, type) {

            var previousValue = historyPageSvc.getPreviousQuery(type + key);
            if (!previousValue) return;
            var previousQuery = historyPageSvc.getPreviousQuery(window.location.href);
            var lastIndex = previousQuery ? previousQuery.lastIndexOf(previousValue) : -1;
            var lastIndexOfOr = previousQuery ? previousQuery.lastIndexOf(previousValue + "OR") : -1;
            if (lastIndex < 0 || (lastIndexOfOr > -1 && lastIndexOfOr == lastIndex)) {
                historyPageSvc.setPreviousQuery(type + key, null);
                return;
            }
            var pre = previousQuery.slice(0, lastIndex);
            var lastIndexOfText = (lastIndex + previousValue.length + 1) > previousQuery.length ? previousQuery.length : (lastIndex + previousValue.length + 1);
            var end = previousQuery.slice(lastIndex + previousValue.length, previousQuery.length);
            previousQuery = pre + end;
            historyPageSvc.setPreviousQuery(window.location.href, previousQuery);
            historyPageSvc.setPreviousQuery(type + key, null);

        }

        function nothingToDo(fieldSearch) {
            if (fieldSearch.parent == searchBoxConstant.parentMenu)
                return searchBoxConstant.doNothing;
            var temp = fieldSearch.status;
            if (temp == searchBoxConstant.status.isActive)
                return searchBoxConstant.doNothing;
            else
                fieldSearch.status = searchBoxConstant.status.isActive;
            return !searchBoxConstant.doNothing;
        }

        function addFieldSearch(fieldSearch, $compile, scope) {
            if (searchBoxConstant.doNothing == nothingToDo(fieldSearch))
                return;
            var searchBoxObj = scope.data.fieldSearch;
            var templateDirective;
            var indexOfField;
            switch (fieldSearch.controlType) {
                case searchBoxConstant.controlType.dropdown:
                    {
                        fieldSearch.initdata = searchBoxConstant.booleanValue;
                        templateDirective = "<div class='row' sb-drop-down data='{0}' value='{1}'></span>";
                        break;
                    }
                case searchBoxConstant.controlType.select2:
                    {
                        scope[fieldSearch.value] = [];
                        indexOfField = findWithAttr(searchBoxObj, 'field', fieldSearch.fieldName);
                        fieldSearch.initData = searchBoxObj[indexOfField].initData;
                        templateDirective = "<div class='row' sb-select-two data='{0}' value='{1}'></span>";
                        break;
                    }
                case searchBoxConstant.controlType.dropdowncheckbox:
                    {
                        scope[fieldSearch.value] = [];
                        indexOfField = findWithAttr(searchBoxObj, 'field', fieldSearch.fieldName);
                        fieldSearch.initData = searchBoxObj[indexOfField].initData;
                        templateDirective = "<div class='row' sb-dropdown-checkbox data='{0}' value='{1}'></span>";
                        break;
                    }
                case searchBoxConstant.controlType.datepicker:
                    {
                        scope[fieldSearch.value] = "";
                        templateDirective = "<div class='row' sb-date-picker data='{0}' value='{1}'></span>";
                        break;
                    }
                case searchBoxConstant.controlType.numberfield:
                    {
                        scope[fieldSearch.value] = "";
                        templateDirective = "<div class='row' sb-number-field data='{0}' value='{1}'></span>";
                        break;
                    }
                case searchBoxConstant.controlType.selectnumber:
                    {
                        scope[fieldSearch.value] = "";
                        indexOfField = findWithAttr(searchBoxObj, 'field', fieldSearch.fieldName);
                        fieldSearch.initData = searchBoxObj[indexOfField].initData;
                        templateDirective = "<div class='row' sb-select-number data='{0}' value='{1}'></span>";
                        break;
                    }
                case searchBoxConstant.controlType.daterangepicker:
                    {
                        scope[fieldSearch.value] = "";
                        templateDirective = "<div class='row' sb-date-range-picker-box data='{0}' is-limit='false' value='{1}'></span>";
                        break;
                    }
                case searchBoxConstant.controlType.daterangepickerLimit:
                    {
                        scope[fieldSearch.value] = "";
                        templateDirective = "<div class='row' sb-date-range-picker-box data='{0}' is-limit='true' value='{1}'></span>";
                        break;
                    }
                default:
                    {
                        scope[fieldSearch.value] = "";
                        templateDirective = "<div class='row' sb-text-field data='{0}' value='{1}'></span>";
                        break;
                    }
            }
            increaseNumOfSearchCondition();
            scope[fieldSearch.fieldName] = fieldSearch;
            templateDirective = String.format(templateDirective, fieldSearch.fieldName, fieldSearch.value);
            angular.element(document.getElementsByClassName('addsearchcondition')).append($compile(templateDirective)(scope));
            scope.$watch(fieldSearch.value, function (newValue, oldValue) {
                var parentScope = scope;
                queryInputValue.value = buildingQueryString(parentScope);
                $timeout(function () {
                });
            });
        }

        function removeFieldSearch(scope) {
            getContainQuery(scope);
            scope.value = "";
            scope.$parent[scope.data.fieldName].status = false;
            $timeout(function () {
                scope.$destroy();
            }, 200);
            decreaseNumOfSearchCondition();
            if (numOfSearchCondition === 0) {
                scope.$parent.sb.isInputFocused = false;
                scope.$parent.sb.isSearchCondition = false;
                scope.$parent.sb.isSearchAdvanced = false;
                clearBackgroundColorSearchBox();
            }
        }

        function getContainQuery(scope) {
            var key = scope.data.fieldName;
            var value = "";
            if (typeof (scope.value) == 'object') {
                if (scope.tempArray.length > 1) {
                    value = "(" + scope.tempArray[0].value + ")";
                    for (var index = 1; index < scope.tempArray.length; index++) {
                        value += " OR (" + scope.tempArray[index].value + ")";
                    }
                }
            }
            if (typeof (scope.value) == 'string') {
                value = "(" + scope.value + ")";
            }
            if (value)
                historyPageSvc.setPreviousRemoveField(window.location.href, key + ":" + value);
        }

        function getQueryInput() {
            return queryInputValue;
        }

        function clearQueryInput() {
            queryInputValue.value = "";
        }

        function removeAllChildInput(scope) {
            scope.$broadcast('selfRemoveItem');
        }

        function setBackgroundColorSearchBox() {
            var rootElement = angular.element(document.getElementsByClassName('search-box-style'));
            rootElement.addClass('border-input-forcus');
        }

        function clearBackgroundColorSearchBox() {
            var rootElement = angular.element(document.getElementsByClassName('search-box-style'));
            rootElement.removeClass('border-input-forcus');
        }

        function increaseNumOfSearchCondition() {
            numOfSearchCondition += 1;
        }

        function decreaseNumOfSearchCondition() {
            numOfSearchCondition -= 1;
        }

        function changeQuery(query, parentScope) {
            query = query ? query.trim() + " " : "";
            historyPageSvc.setPreviousQuery(window.location.href, query);
            var currentType = parentScope.data.listType;
            for (var i = 0; i < parentScope.data.fieldSearch.length; i++) {
                var object;
                var tempFieldSearch = parentScope.data.fieldSearch[i].field;
                var tempValueSearch = parentScope.data.fieldSearch[i].value;
                var paramObject = parentScope[tempFieldSearch];
                var currentValue = parentScope[tempValueSearch];
                if (checkControlTypeValue(paramObject, currentValue)) {
                    object = getKeyandValueforQuery(paramObject, currentValue);
                    var templateQuery = "{0}:({1}) ";
                    var newQuery = String.format(templateQuery, object.key, object.value);
                    var previousQueryValue = historyPageSvc.getPreviousQuery(currentType + object.key);
                    if (!previousQueryValue || !query) {
                        historyPageSvc.setPreviousQuery(currentType + object.key, undefined);
                        parentScope[tempValueSearch] = "";
                        if (!parentScope.$$phase) parentScope.$apply();
                        continue;
                    }
                    var lastIndex = query.lastIndexOf(previousQueryValue);
                    var lastIndexOfOr = query.lastIndexOf(previousQueryValue + "OR");
                    if (lastIndex < 0 || (lastIndexOfOr > -1 && lastIndexOfOr == lastIndex)) {
                        historyPageSvc.setPreviousQuery(currentType + object.key, undefined);
                        parentScope[tempValueSearch] = "";
                    }
                }
            }
        }

        /*
        *   Region for local function only
        */
        function checkControlTypeValue(paramObject, curentValue) {
            if (comparisonUtilSvc.isNullOrUndefinedValue(paramObject))
                return false;
            if (!paramObject.status)
                return false;
            switch (paramObject.controlType) {
                case searchBoxConstant.controlType.dropdowncheckbox:
                    {
                        return curentValue.length === 0 || curentValue === "" ? false : true;
                    }
                case searchBoxConstant.controlType.dropdown:
                    {
                        return comparisonUtilSvc.isNullOrUndefinedValue(curentValue) || curentValue === "" ? false : true;
                    }
                case searchBoxConstant.controlType.select2:
                    {
                        return curentValue.length === 0 || curentValue === "" ? false : true;
                    }
                default:
                    {
                        return curentValue === "" ? false : true;
                    }
            }
        }

        function getKeyandValueforQuery(paramObject, curentValue) {
            var keyValue = { key: "", value: "" };
            keyValue.key = paramObject.fieldName;
            switch (paramObject.controlType) {
                case searchBoxConstant.controlType.dropdown:
                    keyValue.value = curentValue.key;
                    break;
                case searchBoxConstant.controlType.select2:
                case searchBoxConstant.controlType.dropdowncheckbox:
                    keyValue.value = buildingQueryMultiSelect(curentValue);
                    break;
                default:
                    keyValue.value = curentValue;
                    break;
            }
            return keyValue;
        }

        function buildingQueryMultiSelect(curentValue) {
            var selectedValue = "";
            for (var i = 0; i < curentValue[0].length; i++) {
                var temp = curentValue[0][i];
                if (i < curentValue[0].length - 1)
                    selectedValue = selectedValue + temp.value + ") OR (";
                else
                    selectedValue = selectedValue + temp.value;
            }
            return selectedValue;
        }

        function passArrayQueryToString(arrayQuery, type) {
            var previousQuery = historyPageSvc.getPreviousQuery(window.location.href);
            previousQuery = previousQuery ? previousQuery.trim() + " " : "";
            var query = "";
            var firstIndexOfText = 0;
            var lastIndexOfText = 0;
            for (var i = 0; i < arrayQuery.length; i++) {
                var templateQuery = "{0}:({1}) ";
                var newQuery = String.format(templateQuery, arrayQuery[i].key, arrayQuery[i].value);
                var previousQueryValue = historyPageSvc.getPreviousQuery(type + arrayQuery[i].key);
                if (!previousQueryValue || !previousQuery) {
                    query = query + newQuery;
                    historyPageSvc.setPreviousQuery(type + arrayQuery[i].key, newQuery);
                    continue;
                }
                var oldQuery = previousQueryValue;

                var lastIndex = previousQuery.lastIndexOf(oldQuery);
                var lastIndexOfOr = previousQuery.lastIndexOf(oldQuery + "OR");
                if (lastIndex < 0 || (lastIndexOfOr > -1 && lastIndexOfOr == lastIndex)) {
                    query = query + newQuery;
                    historyPageSvc.setPreviousQuery(type + arrayQuery[i].key, newQuery);
                    continue;
                }
                var pre = previousQuery.slice(0, lastIndex);

                lastIndexOfText = ((lastIndex + oldQuery.length + 1) < previousQuery.length) ? (lastIndex + oldQuery.length + 1) : previousQuery.length;
                var end = previousQuery.slice(lastIndex + oldQuery.length, previousQuery.length);
                previousQuery = pre + newQuery + end;
                historyPageSvc.setPreviousQuery(type + arrayQuery[i].key, newQuery);
            }

            var current = previousQuery ? previousQuery + query : query;

            var removeKey = historyPageSvc.getPreviousRemoveField(window.location.href);
            if (removeKey) {
                var index = current.lastIndexOf(removeKey);
                var indexOfOr = current.lastIndexOf(removeKey + " OR");
                firstIndexOfText = index - 1 >= 0 ? index - 1 : 0;
                lastIndexOfText = ((index + removeKey.length + 1) < current.length) ? index + removeKey.length + 1 : current.length;
                if (index > -1 && indexOfOr != index) {
                    current = current.slice(0, firstIndexOfText) + current.slice(lastIndexOfText, current.length);
                }
                historyPageSvc.setPreviousRemoveField(window.location.href, "");
            }
            historyPageSvc.setPreviousQuery(window.location.href, current);
            return current;
        }
    }
})();


