﻿
(function () {
    'use strict';
    angular.module('app').controller('select2Ctrl', Select2Ctrl);
    Select2Ctrl.$inject = ['searchBoxSvc'];
    function Select2Ctrl(searchBoxSvc) {
        var self = this;
        self.id = String.randomString();
        self.removeFieldSearch = removeFieldSearch;

        function removeFieldSearch(scope) {
            searchBoxSvc.removeFieldSearch(scope);
        }
    }
})();
