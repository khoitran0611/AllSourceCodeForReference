﻿(function () {
    'use strict';
    angular.module('app').directive('sbSelectTwo', sbSelectTwo);
    sbSelectTwo.$inject = ['searchBoxSvc', '$timeout'];
    function sbSelectTwo(searchBoxSvc, $timeout) {
        return {
            restrict: 'A',
            controller: 'select2Ctrl',
            controllerAs: 'sl2',
            templateUrl: searchBoxSvc.templatePathDiective().selecttwo,
            scope: {
                'data': '=',
                'value': '='
            },
            compile: function () {
                return {
                    pre: function preLink(scope, iElement, iAttrs, controller) {
                        var templateHtmlSelect2 = "";
                        var acceptionItem = "";
                        for (var i = 0; i < scope.data.initData.length; i++) {
                            if (scope.data.initData[i].isHide) {

                                var specialItem = "<option  class=\"add-on-option\" value=\"{0}\">{1}</option>";
                                specialItem = String.format(specialItem, scope.data.initData[i].id, scope.data.initData[i].text);
                                acceptionItem = acceptionItem + specialItem;
                            } else {
                                var item = "<option value=\"{0}\">{1}</option>";
                                item = String.format(item, scope.data.initData[i].id, scope.data.initData[i].text);
                                templateHtmlSelect2 = templateHtmlSelect2 + item;
                            }
                        }
                        templateHtmlSelect2 = acceptionItem + templateHtmlSelect2;
                        $timeout(function () {
                            $('#' + controller.id).select2().html(templateHtmlSelect2);
                        });

                    },
                    post: function postLink(scope, element) {
                        scope.tempArray = [];
                        searchBoxSvc.setBackgroundColorSearchBox();
                        element.on("select2-selecting", function (item) {
                            var object = { key: "", value: "" };
                            var indexOfExistedItem = findWithAttr(scope.tempArray, "key", item.val);
                            var selectedArray = [];
                            if (indexOfExistedItem > -1) {
                                var newData = $.grep($('#' + scope.sl2.id).select2('data'), function (value) {
                                    return value.id != scope.tempArray[indexOfExistedItem].key;
                                });
                                $('#' + scope.sl2.id).select2('data', newData);
                            }
                            else {
                                object.key = item.val;
                                object.value = item.object.text;
                                scope.tempArray.push(object);
                            }
                            selectedArray.push(scope.tempArray);
                            $timeout(function () {
                                scope.value = selectedArray;
                                $('#' + scope.sl2.id).removeAttr('placeholder');
                            });

                        });
                        element.on("select2-removing", function (item) {
                            var indexOfSelected = findWithAttr(scope.tempArray, 'key', item.val);
                            var selectedArray = [];
                            scope.tempArray.splice(indexOfSelected, 1);
                            if (scope.tempArray && scope.tempArray.length > 0) {
                                selectedArray.push(scope.tempArray);
                            }
                            $timeout(function () {
                                scope.value = selectedArray;
                                if (!selectedArray || !selectedArray[0] || selectedArray[0].length === 0)
                                    $('#' + scope.sl2.id).attr("placeholder", scope.data.optionStyle);
                            });
                        });
                        scope.$on('selfRemoveItem', function () {
                            searchBoxSvc.removeFieldSearch(scope);
                        });
                        scope.$on("$destroy", function () {
                            angular.element(element).remove();
                        });
                        $timeout(function () {
                            $('#' + scope.sl2.id).select2('open');
                        }, 500);

                    }
                };
            }

        };
    }
})();
