﻿(function () {
    'use strict';
    angular.module('app').controller('textFieldCtrl', TextFieldCtrl);
    TextFieldCtrl.$inject = ['searchBoxSvc'];
    function TextFieldCtrl(searchBoxSvc) {
        var self = this;
        self.id = String.randomString();
        self.removeFieldSearch = removeFieldSearch;
        self.callSearchApi = callSearchApi;

        function removeFieldSearch(scope) {
            searchBoxSvc.removeFieldSearch(scope);
        }

        function callSearchApi(scope) {
            searchBoxSvc.callSearchApi(scope);
        }
    }
})();
