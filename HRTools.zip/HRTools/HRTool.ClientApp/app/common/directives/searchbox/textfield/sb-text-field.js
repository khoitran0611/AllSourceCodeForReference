﻿(function () {
    'use strict';
    angular.module('app').directive('sbTextField', sbTextField);
    sbTextField.$inject = ['searchBoxSvc', '$timeout'];
    function sbTextField(searchBoxSvc, $timeout) {
        return {
            restrict: 'A',
            controller: 'textFieldCtrl',
            controllerAs: 'tfsearh',
            templateUrl: searchBoxSvc.templatePathDiective().textfield,
            scope: {
                'data': '=',
                'value': '='
            },
            link: function (scope, element) {
                scope.$on('selfRemoveItem', function () {
                    searchBoxSvc.removeFieldSearch(scope);
                });
                searchBoxSvc.setBackgroundColorSearchBox();
                scope.$on("$destroy", function () {
                    angular.element(element).remove();
                });
                $timeout(function () {
                    var input = angular.element(document.getElementById(scope.tfsearh.id));
                    input.focus();
                }, 500);

            }
        };
    }
})();


