﻿(function () {
    'use strict';
    angular.module('app').directive('sbSelectNumber', sbSelectNumber);
    sbSelectNumber.$inject = ['searchBoxSvc', '$timeout', "$filter"];
    function sbSelectNumber(searchBoxSvc, $timeout, $filter) {
        return {
            restrict: 'A',
            controller: 'selectNumberCtrl',
            controllerAs: 'selectNumberSearch',
            templateUrl: searchBoxSvc.templatePathDiective().selectnumber,
            scope: {
                'data': "=",
                'value': "="
            },
            link: function (scope, element) {
                scope.conditionValue = "";
                scope.$on('selfRemoveItem', function () {
                    searchBoxSvc.removeFieldSearch(scope);
                });
                searchBoxSvc.setBackgroundColorSearchBox();
                scope.$on("$destroy", function () {
                    angular.element(element).remove();
                });


                setDefaultCondition();
                function setDefaultCondition() {
                    var completeness = $filter('translate')("CV_Completeness_Percent");
                    var starRating = $filter('translate')("Star_Rating");
                    var passInterview = $filter('translate')("Passed_Interviews_Key");
                    var failInterview = $filter('translate')("Failed_Interviews_Key");
                    scope.equalText = "Math_Conditions.Equal";
                    switch (scope.data.displayName) {
                        case completeness:
                        case starRating:
                            scope.conditionValue = ">=";
                            scope.equalText = "Math_Conditions.Equals";
                            break;

                        case passInterview:
                            scope.conditionValue = ">=";
                            break;

                        case failInterview:
                            scope.conditionValue = "<";
                            break;
                        default:
                            scope.conditionValue = "";
                            break;
                    }
                }

                var defaultValue = 0;
                scope.numbers = scope.data.initData;
                if (scope.numbers && scope.numbers.length > 0) {
                    defaultValue = scope.numbers[0].value;
                }

                scope.changeValue = function () {
                    scope.value = (scope.conditionValue ? scope.conditionValue : "") + (scope.numberValue ? scope.numberValue : defaultValue);
                };

            }
        };
    }
})();


