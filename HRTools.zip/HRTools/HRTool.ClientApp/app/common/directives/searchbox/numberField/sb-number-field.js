﻿(function () {
    'use strict';
    angular.module('app').directive('sbNumberField', sbNumberField);
    sbNumberField.$inject = ['searchBoxSvc', '$timeout', "$filter"];
    function sbNumberField(searchBoxSvc, $timeout, $filter) {
        return {
            restrict: 'A',
            controller: 'numberFieldCtrl',
            controllerAs: 'nfsearh',
            templateUrl: searchBoxSvc.templatePathDiective().numberfield,
            scope: {
                'data': '=',
                'value': '='
            },
            link: function (scope, element) {
                scope.conditionValue = "";
                scope.$on('selfRemoveItem', function () {
                    searchBoxSvc.removeFieldSearch(scope);
                });
                searchBoxSvc.setBackgroundColorSearchBox();
                scope.$on("$destroy", function () {
                    angular.element(element).remove();
                });
                $timeout(function () {
                    var input = angular.element(document.getElementById(scope.nfsearh.id));
                    input.focus();
                }, 500);

                setDefaultCondition();
                function setDefaultCondition() {
                    var completeness = $filter('translate')("CV_Completeness_Percent");
                    var starRating = $filter('translate')("Star_Rating");
                    var passInterview = $filter('translate')("Passed_Interviews_Key");
                    var failInterview = $filter('translate')("Failed_Interviews_Key");
                    scope.equalText = "Math_Conditions.Equal";
                    switch (scope.data.displayName) {
                        case completeness:
                        case starRating:
                            scope.conditionValue = ">=";
                            scope.equalText = "Math_Conditions.Equals";
                            break;

                        case passInterview:
                            scope.conditionValue = ">=";
                            break;

                        case failInterview:
                            scope.conditionValue = "<";
                            break;
                        default:
                            scope.conditionValue = "";
                            break;
                    }
                }

                scope.checkKeyCharater = function(event) {
                    var eventCode = event.charCode === 0 ? event.keyCode : event.charCode;
                    if (!((eventCode > 47 && eventCode < 58) || eventCode == 46 ||
                        eventCode == 44 || eventCode == 127 || eventCode == 9 || eventCode == 8 ||
                        (eventCode > 34 && eventCode < 38) || eventCode == 39))
                        event.preventDefault();
                };
                scope.changeValue = function() {
                    scope.value = (scope.conditionValue ? scope.conditionValue : "") + (scope.numberValue ? scope.numberValue : "");
                };

            }
        };
    }
})();


