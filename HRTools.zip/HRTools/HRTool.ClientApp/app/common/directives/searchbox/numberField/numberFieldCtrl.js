﻿(function () {
    'use strict';
    angular.module('app').controller('numberFieldCtrl', NumberFieldCtrl);
    NumberFieldCtrl.$inject = ["$filter", "searchBoxSvc"];
    function NumberFieldCtrl($filter, searchBoxSvc) {
        var self = this;
        self.id = String.randomString();
        self.removeFieldSearch = removeFieldSearch;
        self.callSearchApi = callSearchApi;
        function removeFieldSearch(scope) {
            searchBoxSvc.removeFieldSearch(scope);
        }

        function callSearchApi(scope) {
            searchBoxSvc.callSearchApi(scope);
        }
    }
})();
