﻿(function () {
    "use strict";
    angular.module('app').factory('searchBoxModel',
        function () {
            var searchBoxModel = function (fieldName, value, displayName, controlType, initData, status, optionStyle, parent) {
                this.fieldName = fieldName;
                this.displayName = displayName;
                this.value = value;
                this.controlType = controlType;
                this.initData = initData;
                this.status = status;
                this.optionStyle = optionStyle;
                this.parent = parent;
            };
            return searchBoxModel;
        });
})();
