﻿(function () {
    "use strict";
    angular.module('app').constant('searchBoxConstant', {
        controlType:
            {
                textfield: 'textfield',
                numberfield: 'numberfield',
                selectnumber: 'selectnumber',
                dropdown: 'dropdown',
                select2: 'select2',
                dropdowncheckbox: 'dropdowncheckbox',
                daterangepicker: 'daterangepicker',
                daterangepickerLimit: 'daterangepickerLimit',
                datepicker: 'datepicker'
            },
        status: {
            isActive: true,
            deActive: false
        },
        booleanValue: [
                {
                    key: 'Yes',
                    value: true
                },
                {
                    key: 'No',
                    value: false
                }
        ],
        keyValue: { key: "", value: "" },
        parentMenu: "none",
        doNothing: true,
        method: { search: "clearSearch", clearSearch: "clearSearch" },
        mainClassCss: ".search-box-style",
        enterKey:13
    });
})();