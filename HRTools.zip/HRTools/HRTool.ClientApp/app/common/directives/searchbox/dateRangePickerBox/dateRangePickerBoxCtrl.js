﻿(function () {
    'use strict';
    angular.module('app').controller('dateRangePickerBoxCtrl', DateRangePickerBoxCtrl);
    DateRangePickerBoxCtrl.$inject = ['searchBoxSvc'];
    function DateRangePickerBoxCtrl(searchBoxSvc) {
        var self = this;
        self.id = String.randomString();
        self.conditionValue = "-1";
        self.removeFieldSearch = removeFieldSearch;
        self.callSearchApi = callSearchApi;
        function removeFieldSearch(scope) {
            searchBoxSvc.removeFieldSearch(scope);
        }

        function callSearchApi(scope) {
            searchBoxSvc.callSearchApi(scope);
        }
    }
})();
