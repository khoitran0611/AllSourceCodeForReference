﻿(function () {
    'use strict';
    angular.module('app').directive('sbDateRangePickerBox', sbDateRangePickerBox);
    sbDateRangePickerBox.$inject = ['searchBoxSvc', '$timeout'];
    function sbDateRangePickerBox(searchBoxSvc, $timeout) {
        return {
            restrict: 'A',
            controller: 'dateRangePickerBoxCtrl',
            controllerAs: 'drpCtrl',
            templateUrl: searchBoxSvc.templatePathDiective().daterangepicker,
            scope: {
                'data': '=',
                'value': '=',
                'isLimit': '@'
            },
            link: function (scope, element) {
                var timeFormat = "DD-MM-YYYY";
                scope.conditionValue = "";
                scope.$on('selfRemoveItem', function () {
                    searchBoxSvc.removeFieldSearch(scope);
                });
                searchBoxSvc.setBackgroundColorSearchBox();
                scope.$on("$destroy", function () {
                    angular.element(element).remove();
                });

                $timeout(function () {
                    var input = angular.element(document.getElementById(scope.drpCtrl.id));
                    input.focus();
                    $('#' + scope.drpCtrl.id + "-at").datepicker({ autoclose: true, todayHighlight: true });
                    $('#' + scope.drpCtrl.id + "-from").datepicker({ autoclose: true, todayHighlight: true });
                    $('#' + scope.drpCtrl.id + "-to").datepicker({ autoclose: true, todayHighlight: true });
                    $(".from-date").datepicker({ autoclose: true, todayHighlight: true });
                }, 500);

                scope.changeCondition = function () {
                    scope.from = false;
                    scope.to = false;
                    switch (scope.drpCtrl.conditionValue) {
                        case "0":
                            scope.value = ">=" + moment().startOf('week').format(timeFormat);
                            break;
                        case "1":
                            scope.value = ">=" + moment().subtract(6, 'days').format(timeFormat);
                            break;
                        case "2":
                            scope.value = ">=" + moment().startOf('month').format(timeFormat);
                            break;
                        case "3":
                            scope.value = ">=" + moment().subtract(29, 'days').format(timeFormat);
                            break;
                        case "4":
                            scope.value = ">=" + moment().subtract(89, 'days').format(timeFormat);
                            break;
                        case "5":
                            scope.value = ">=" + moment().subtract(179, 'days').format(timeFormat);
                            break;
                        case "6":
                            break;
                        case "7":
                            scope.fromDate = "";
                            scope.toDate = "";
                            scope.from = false;
                            scope.to = true;
                            scope.value = "";
                            break;
                        case "8": case "9": case "10":
                            scope.from = true;
                            scope.to = false;
                            scope.atDate = "";
                            scope.value = "";
                            break;
                        default:
                            scope.from = false;
                            scope.to = false;
                            scope.value = "";
                            break;
                    }
                };

                scope.changeDate = function () {
                    if (scope.fromDate && scope.toDate) {
                        scope.value = "(>=" + scope.fromDate + ")" + " AND (<=" + scope.toDate + ")";
                        return;
                    }
                    scope.value = "";
                };

                scope.changeAtDate = function () {
                    if (!scope.atDate) {
                        scope.value = "";
                        return;
                    }
                    switch (scope.drpCtrl.conditionValue) {
                        case "8":
                            scope.value = "<" + scope.atDate;
                            break;
                        case "9":
                            scope.value = ">" + scope.atDate;
                            break;
                        case "10":
                            scope.value = scope.atDate;
                            break;
                        default:
                            break;
                    }
                };

                scope.checkCustomSearch = function (object) {
                    if (scope.fromDate && scope.toDate) {
                        scope.drpCtrl.callSearchApi(object);
                    }
                };
                scope.checkDate = function (object) {
                    if (scope.atDate) {
                        scope.drpCtrl.callSearchApi(object);
                    }
                };
            }
        };
    }
})();

