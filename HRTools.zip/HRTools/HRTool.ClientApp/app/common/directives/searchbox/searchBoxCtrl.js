﻿(function () {
    'use strict';
    angular.module('app').controller('searchBoxCtrl', SearchBoxCtrl);
    SearchBoxCtrl.$inject = ['searchBoxSvc', '$scope'];
    function SearchBoxCtrl(searchBoxSvc, $scope) {
        var self = this;
        self.isSearchCondition = false;
        self.isInputFocused = false;
        self.isSearchAdvanced = false;
        self.fieldSearch = searchBoxSvc.initFieldSearch($scope.data);

        init();

        function init() {
            searchBoxSvc.clearQueryInput();
            if (!self.isInputFocused)
                self.query = searchBoxSvc.getQueryInput();
            $('input, textarea').placeholder();
            $('input.input-main-query').on('');

            $scope.$watch('sb.isSearchCondition', collapsableSearchBox());

            $scope.$watch('sb.query.value', collapsableSearchBox());

            $scope.$watch('sb.isInputFocused', collapsableSearchBox());

            $scope.$watch('sb.isSearchAdvanced', collapsableSearchBox());
            return;

            function collapsableSearchBox() {
                return function (newValue, oldValue) {
                    if ($scope.sb.isSearchCondition || $scope.sb.query.value || $scope.sb.isInputFocused || $scope.sb.isSearchAdvanced) {
                        $('input.input-main-query').addClass("collapsable");
                        if ($scope.$parent.$parent.caCtrl) {
                            $scope.$parent.$parent.caCtrl.isSendJobInvitation = false;
                            $scope.$parent.$parent.caCtrl.isCreateNewCandidate = false;
                        }
                        removeHoverElement('.sprite-invitation');
                        removeHoverElement('.sprite-add-user');
                    } else {
                        $('input.input-main-query').removeClass("collapsable");
                    }
                };
            }
        }
    }
})();
