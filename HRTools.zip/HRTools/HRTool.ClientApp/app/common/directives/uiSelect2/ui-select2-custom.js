﻿(function () {
    'use strict';
    angular.module('app').directive('uiSelect2Custom', uiSelect2Custom);
    uiSelect2Custom.$inject = ['$timeout', 'comparisonUtilSvc'];
    function uiSelect2Custom($timeout, comparisonUtilSvc) {
        return {
            restrict: 'A,E',
            priority: 1000,
            transclude: true,
            controller: 'uiSelect2Ctrl',
            controllerAs: 'uiSl2Ctrl',
            templateUrl: 'common/directives/uiSelect2/uiSelect2.html',
            scope: {
                'init': '=',
                'value': '=',
                'isSetDefault': '='
            },
            compile: function () {
                var listItem = [];
                var defaultList = [];
                var isResetSeleted = false;

                function templateResult(item) {
                    var template = "";
                    template += "<div class=\"{0}\">";
                    template += "    <span>{1}<\/span>";
                    template += "<\/div>";
                    template = String.format(template, item.optionClass, item.text);
                    return template;
                }

                function createSelect2Items(scope) {
                    if (isResetSeleted || !scope[scope.uiSl2Ctrl.id])
                        scope[scope.uiSl2Ctrl.id] = true;
                    var placeholder = { value: null };
                    function getPlaceholder() {
                        return placeholder;
                    }

                    var indexOfSelected = -1;
                    if (listItem.length > 0) {
                        indexOfSelected = scope.value.indexOfSelected > -1 ? scope.value.indexOfSelected : findObjectInArray(scope.value, listItem);
                        if (!scope.value || indexOfSelected == -1) {
                            placeholder.value = scope.init.option.placeholder;
                        }
                        $('#' + scope.uiSl2Ctrl.id).select2({
                            data: { results: listItem },
                            placeholder: getPlaceholder().value,
                            initSelection: function (element, callback) {
                                if (indexOfSelected != -1) {
                                    placeholder.value = null;
                                    callback(listItem[indexOfSelected]);
                                }
                            },
                            multiple: scope.init.option.multiple,
                            templateResult: templateResult,
                            allowClear: true
                        });
                    } else {
                        setDefaultSelect2Items(scope, indexOfSelected);
                    }
                }

                function setDefaultSelect2Items(scope, indexOfSelected) {
                    var placeholder = { value: null };
                    function getPlaceholder() {
                        return placeholder;
                    }
                    $('#' + scope.uiSl2Ctrl.id).select2({
                        data: { results: defaultList },
                        placeholder: getPlaceholder().value,
                        initSelection: function (element, callback) {
                            if (indexOfSelected != -1) {
                                placeholder.value = null;
                                callback(listItem[indexOfSelected]);
                            }
                            callback("");
                        },
                        multiple: scope.init.option.multiple,
                        templateResult: templateResult,
                        allowClear: true
                    });
                }

                return {
                    pre: function preLink(scope) {
                        scope.init.service.query().$promise.then(function (data) {
                            listItem = [];
                            scope[scope.uiSl2Ctrl.id] = false;
                            var tempData = [];
                            for (var i = 0; i < data.length; i++) {
                                var optionClass = undefined;
                                var item = {};
                                if (data[i].IsHide) {
                                    optionClass = "add-on-option";
                                    item = {
                                        id: data[i][scope.init.id],
                                        text: data[i][scope.init.text],
                                        optionsValue: data[i][scope.init.optionsValue],
                                        optionsText: data[i][scope.init.optionsText],
                                        optionClass: optionClass
                                    };
                                    if (scope.isSetDefault && !scope.value) {
                                        scope.value = { id: item.id, text: item.text, optionsValue: item.optionsValue, optionsText: item.optionsText };
                                    }
                                    listItem.push(item);
                                } else {
                                    item = {
                                        id: data[i][scope.init.id],
                                        text: data[i][scope.init.text],
                                        optionsValue: data[i][scope.init.optionsValue],
                                        optionsText: data[i][scope.init.optionsText],
                                        optionClass: optionClass
                                    };
                                    tempData.push(item);
                                }
                            }
                            listItem = listItem.concat(tempData);
                            if (listItem.length >= 0 && !comparisonUtilSvc.isNullOrUndefinedValue(scope.value)) {
                                createSelect2Items(scope);
                            } else {
                                var defaultIndexOfSelected = -1;
                                setDefaultSelect2Items(scope, defaultIndexOfSelected);
                            }
                        }, function () {
                            //toastr.error("Loading data error !", "Error");
                        });
                    },

                    post: function postLink(scope, element) {
                        scope.tempArray = [];
                        element.on("select2-selecting", function (item) {
                            var object = {};
                            object.id = item.val;
                            object.text = item.object.text;
                            object.optionsValue = item.object.optionsValue;
                            object.optionsText = item.object.optionsText;
                            scope.value = object;
                            $timeout(function () {
                                scope.value = object;
                            });
                            $timeout(function () {
                                $("#s2id_" + scope.uiSl2Ctrl.id + " .select2-choice .select2-chosen").text(item.object.text);
                            }, 100);
                        });

                        scope.$watch("value", function (newValue) {
                            if (listItem.length > 0 && !comparisonUtilSvc.isNullOrUndefinedValue(scope.value)) {
                                var resetValue = "resetSeleted";
                                isResetSeleted = newValue.optionsValue == resetValue;
                                $timeout(function () {
                                    $("#s2id_" + scope.uiSl2Ctrl.id + " .select2-choice .select2-chosen").text(newValue.text);
                                }, 100);
                                scope.value.optionsValue = isResetSeleted ? undefined : scope.value.optionsValue;
                                createSelect2Items(scope);
                            }

                        });

                        scope.$on("$destroy", function () {
                            scope[scope.uiSl2Ctrl.id] = false;
                        });

                    }
                };
            }
        };
    }
})();

