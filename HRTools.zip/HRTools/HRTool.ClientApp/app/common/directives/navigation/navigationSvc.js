﻿(function () {
    'use strict';
    angular.module('app').factory('navigationSvc', navigationSvc);
    navigationSvc.$inject = ['constants'];
    function navigationSvc(constants) {
        var menu = {};
        var setMenu = function (data) {
            $.jStorage.set("menus", data);
        };
        var getMenu = function () {
            var stringUndefined = "undefined";
            var storedMenu = $.jStorage.get("menus", stringUndefined);
            var showSSOSurveyToolLink = $.jStorage.get("configMenu", stringUndefined);
            if (storedMenu !== stringUndefined) {
                menu = storedMenu;

                menu.SSOMenu = [];
                var ssoRecruitmentItem = {
                    IsActive: true,
                    Path: "#/dashboard/",
                    Name: "Recruitment"
                };
                menu.SSOMenu.push(ssoRecruitmentItem);
                if (showSSOSurveyToolLink) {
                    var ssoSurveyToolItem = {
                        IsActive: false,
                        Path: constants.surveyToolUrl,
                        Name: "Surveys"
                    };
                    menu.SSOMenu.push(ssoSurveyToolItem);
                }
            }
            return menu;
        };
        return {
            setMenu: setMenu,
            getMenu: getMenu
        };
    }
})();


