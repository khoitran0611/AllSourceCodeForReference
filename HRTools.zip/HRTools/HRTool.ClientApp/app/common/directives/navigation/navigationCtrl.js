﻿(function () {
    'use strict';
    angular.module('app').controller('navigationCtrl', NavigationCtrl);
    NavigationCtrl.$inject = ["$scope", "$location", "$state", "$window", "$rootScope",
        "navigationSvc", "authSvc", "constants", "switchCandidateSvc", "comparisonUtilSvc"];
    function NavigationCtrl($scope, $location, $state, $window, $rootScope,
        navigationSvc, authSvc, constants, switchCandidateSvc, comparisonUtilSvc) {

        $scope.$state = $state;
        $scope.isActiveSSORecruimentMenuItem = false;
        $scope.isActiveSSOSurveyMenuItem = false;

        $scope.getActiveTag = getActiveTag;

        var self = this;
        self.menu = navigationSvc.getMenu();

        self.logout = logout;
        self.toCandidateList = toCandidateList;
        self.onChildMenuClick = onChildMenuClick;

        var currentUser = JSON.parse($window.localStorage.getItem("currentuserlogin"));
        var baseUrl = constants.baseUrl;

        init();

        function init() {
            if (!comparisonUtilSvc.isNullOrUndefinedValue(currentUser)) {
                $scope.FullName = currentUser.FullName;
                $scope.CompanyName = currentUser.CompanyName;
            }

            // show navbar when the current page isn't the login page
            // $watch forces to apply two-way binding with $location
            // $watch may causes errors, so you need to use with cautions
            // otherwise, you can disable it or use another mechanism to show/hide the navbar
            // I haven't figure out the way to use 'this' instead of '$scope' here
            $scope.$watch(function () { return $location.path(); },
                function (path) { $scope.showNav = path != "/login"; });

            $scope.$on(constants.currentUserLoginCookie, function () {
                var currentUser = JSON.parse($window.localStorage.getItem("currentuserlogin"));
                if (currentUser)
                    $scope.FullName = currentUser.FullName;
                if (!$scope.$$phase && !$scope.$root.$$phase)
                    $scope.$apply();
            });
        }

        function getActiveTag(itemUrl) {
            var url = (window.location.href);
            if (itemUrl === baseUrl + ("#/jobs")) {
                return checkUrl(url, constants.arrayUrl.jobs);
            }
            if (itemUrl === baseUrl + ("#/candidates")) {
                return checkUrl(url, constants.arrayUrl.candidates);
            } if (itemUrl === baseUrl + ("#/interview-schedule")) {
                return checkUrl(url, constants.arrayUrl.interview);
            }
            if (itemUrl === baseUrl + ("#/employees")) {
                return checkUrl(url, constants.arrayUrl.employees);
            }
            if (itemUrl === baseUrl + ("#/dashboard")) {
                return checkUrl(url, constants.arrayUrl.dashboard);
            }
            if (itemUrl === baseUrl + ("#/payroll")) {
                return checkUrl(url, constants.arrayUrl.payroll);
            }
            return false;
        }

        function checkUrl(url, arrayUrl) {
            if (!url) return false;
            for (var index = 0; index < arrayUrl.length; index++) {
                var tagUrl = arrayUrl[index].url.substring(2, arrayUrl[index].url.length);
                var currentUrl = url.substr(url.indexOf("#/"), url.length).split("/")[1];
                if (currentUrl == tagUrl) return true;
            }
            return false;
        }

        function logout() {
            $window.localStorage.removeItem("currentuserlogin");
            $rootScope.$broadcast('loggedOut');
            authSvc.logout();
        }

        function toCandidateList(url) {
            $.jStorage.deleteKey("candidatesearch");
            $.jStorage.deleteKey("employeesearch");
            if (angular.equals(url, constants.baseUrl + "#/candidates")) {
                $window.localStorage.setItem(constants.localStorageKey.currentCandidateListPage, 1);
                switchCandidateSvc.setCurrentList(constants.filterData.candidateList);
            }
        }

        function onChildMenuClick(name)
        {
            if (name == "Users") {
                $window.localStorage.removeItem("currentUsersListPage");
            }
        }
    }
})();

