﻿(function () {
    "use strict";
    angular.module('app').directive('navigation', navigation);

    function navigation() {
        return {
            restrict: 'A',
            templateUrl: 'common/directives/navigation/navigation.html',
            controller: 'navigationCtrl',
            controllerAs: 'nv',
            scope: {}
        };
    }
})();