﻿(function () {
    'use strict';
    angular.module('app').controller('jobSnapshotCtrl', JobSnapshotCtrl);
    JobSnapshotCtrl.$inject = ['dashboardSvc', 'messageHandleSvc', 'historyPageSvc',
        'dbMessage', 'dbConstants', 'constants',
        '$filter', '$timeout', '$scope', '$window', '$state', '$rootScope'];
    function JobSnapshotCtrl(dashboardSvc, messageHandleSvc, historyPageSvc,
        dbMessage, dbConstants, constants,
        $filter, $timeout, $scope, $window, $state, $rootScope) {
        var self = this;
        self.isShowLoading = true;
        self.headerTitleFull = dbConstants.tableSnapshotTitle;
        self.headerTitleShort = dbConstants.tableSnapshotTitleShort;
        self.jobPublishingUrl = dbConstants.dashboardChild.dashboardJob;
        self.messageJobSnapshotEmpty = $filter(constants.translate)(dbMessage.messageJobSnapshotEmpty);
        self.jobPublishing = [];
        self.result = [];
        self.jobPublishingEmpty = false;
        self.isFullHeader = true;

        self.toJobFilter = toJobFilter;
        self.toJobDashboard = toJobDashboard;
        self.convertSinglePositionNameToPlural = convertSinglePositionNameToPlural;

        init();

        function init() {
            var reloadingTime = 500;
            dashboardSvc.getStatictisByJobCode().query().$promise.then(
                function (response) {
                    if (response && response.length > 0) {
                        for (var i = 0; i < response.length; i++) {
                            var formatResult = {};
                            formatResult.jobId = response[i].JobId;
                            formatResult.isHide = response[i].IsHide === 'True' ? true : false;
                            formatResult.jobName = response[i].JobTitle;
                            formatResult.jobCode = response[i].JobCode;
                            formatResult.all = response[i].All;
                            formatResult.new = response[i].New;
                            formatResult.interested = response[i].Interested;
                            formatResult.interviewing = response[i].Interviewing;
                            formatResult.shortlisted = response[i].Shortlisted;
                            formatResult.offered = response[i].Offered;
                            formatResult.accepted = response[i].Accepted;
                            formatResult.quantity = response[i].Quantity;
                            self.result.push(formatResult);
                        }

                        dashboardSvc.setListOrderJobTitle(self.result);
                    } else {
                        self.jobPublishingEmpty = true;
                    }
                    $timeout(function () {
                        self.isShowLoading = false;
                    }, reloadingTime);

                }, function (error) {
                    $timeout(function () {
                        self.isShowLoading = false;
                    }, reloadingTime);
                    $rootScope.$broadcast(constants.broadCastTile.dasboardLoadFail, {});
                });


            var bigScreenWidth = 1280;
            $scope.$watch(function () {
                return $window.innerWidth;
            }, function () {
                if ($window.innerWidth >= bigScreenWidth) {
                    self.isFullHeader = true;
                } else {
                    self.isFullHeader = false;
                }
            });

            window.onresize = function () {
                $scope.$apply(function () {
                    if ($window.innerWidth >= bigScreenWidth) {
                        self.isFullHeader = true;
                    } else {
                        self.isFullHeader = false;
                    }
                });
            };
        }

        function toJobFilter(jobCode, type) {
            var query = {};
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates", window.location.href);
            switch (type) {
                case self.headerTitleFull.new:
                    query.value = String.format('jobCode:({0}) candidateStatus:({1})', jobCode, self.headerTitleFull.new);
                    break;
                case self.headerTitleFull.interested:
                    query.value = String.format('jobCode:({0}) candidateStatus:({1})', jobCode, self.headerTitleFull.interested);
                    break;
                case self.headerTitleFull.shortlisted:
                    query.value = String.format('jobCode:({0}) candidateStatus:({1})', jobCode, self.headerTitleFull.shortlisted);
                    break;
                case self.headerTitleFull.interviewing:
                    query.value = String.format('jobCode:({0}) isInterviewing:({1})', jobCode, 'true');
                    break;
                case self.headerTitleFull.offered:
                    query.value = String.format('jobCode:({0}) hasOfferLetter:({1})', jobCode, 'true');
                    break;
                case self.headerTitleFull.hired:
                    query.value = String.format('jobCode:({0}) isAcceptOffer:({1})', jobCode, 'true');
                    break;
                default:
                    query.value = String.format('jobCode:({0})', jobCode);
                    break;
            }
            $.jStorage.set(constants.localStorageKey.candidateSearch, query, 1);
            if (type === self.headerTitleFull.hired) {
                $state.go('candidates');
            }
        }

        function toJobDashboard(id) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/jobs/" + id + "/dashboard", window.location.href);
            historyPageSvc.setPreviousTag(constants.baseUrl + "#/jobs/" + id + "/dashboard", constants.invitationMenuIndex.all);
        }

        function convertSinglePositionNameToPlural(positionName, isHide) {
            if (!isHide || isHide === false || isHide === "False") return positionName;
            return dashboardSvc.convertSinglePositionNameToPlural(positionName);
        }
    }
})();