﻿(function () {
    'use strict';
    angular.module('app').directive('ngJobSnapshot', ngJobSnapshot);
    function ngJobSnapshot() {
        return {
            restrict: 'E',
            controller: 'jobSnapshotCtrl',
            controllerAs: 'jsCtrl',
            templateUrl: 'common/directives/dashboard/jobSnapshot/jobSnapshot.html'
        };
    }
})();
