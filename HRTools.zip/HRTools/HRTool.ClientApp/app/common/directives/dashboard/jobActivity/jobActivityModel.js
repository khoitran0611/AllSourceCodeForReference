﻿(function () {
    'use strict';
    angular.module('app').factory('jobActivityModel', jobActivityModel);
    jobActivityModel.$inject = ['constants', '$filter'];
    function jobActivityModel(constants, $filter) {
        return jobActivityModel;
        function jobActivityModel(jobActivity) {
            /* jshint -W040 */
            var self = this;
            self.JobId = jobActivity.JobId;
            self.isHide = jobActivity.IsHide;
            self.JobTitle = $filter(constants.translate)(jobActivity.JobTitle);
            self.TotalAppliedLastPeriodTime = jobActivity.TotalAppliedLastPeriodTime;
            self.TotalAppliedDoubleLastPeriodTime = jobActivity.TotalAppliedDoubleLastPeriodTime;
            self.TotalAppliedChange = caculateChangePercent(self.TotalAppliedLastPeriodTime, self.TotalAppliedDoubleLastPeriodTime);
            self.TotalScreenedLastPeriodTime = jobActivity.TotalScreenedLastPeriodTime;
            self.TotalScreenedDoubleLastPeriodTime = jobActivity.TotalScreenedDoubleLastPeriodTime;
            self.TotalScreenedChange = caculateChangePercent(self.TotalScreenedLastPeriodTime, self.TotalScreenedDoubleLastPeriodTime);
            self.TotalInterviewedLastPeriodTime = jobActivity.TotalInterviewedLastPeriodTime;
            self.TotalInterviewedDoubleLastPeriodTime = jobActivity.TotalInterviewedDoubleLastPeriodTime;
            self.TotalInterviewedChange = caculateChangePercent(self.TotalInterviewedLastPeriodTime, self.TotalInterviewedDoubleLastPeriodTime);

            return self;
        }

        function caculateChangePercent(value1, value2) {
            var hundredPercent = 100;
            var demicalNumber = 0;
            if (value1 == value2)
                return 0;
            if (value2 === 0 && value1 > 0)
                return hundredPercent;
            return ((value1 / value2 * hundredPercent) - hundredPercent).toFixed(demicalNumber);
        }
    }
})();
