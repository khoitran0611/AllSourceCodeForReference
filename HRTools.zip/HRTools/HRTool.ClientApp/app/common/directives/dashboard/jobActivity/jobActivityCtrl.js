﻿(function () {
    'use strict';
    angular.module('app').controller('jobActivityCtrl', JobActivityCtrl);
    JobActivityCtrl.$inject = ['$scope', '$filter', '$timeout', '$state', 'dashboardSvc', 'jobActivitySvc', 'datetimeSvc', 'historyPageSvc', 'constants'];
    function JobActivityCtrl($scope, $filter, $timeout, $state, dashboardSvc, jobActivitySvc, datetimeSvc, historyPageSvc, constants) {
        var self = this;

        self.timePeriods = [
                { id: "past7day", displayName: $filter(constants.translate)("Dashboard.Past_7_Days"), value: 6 },
                { id: "past14day", displayName: $filter(constants.translate)("Dashboard.Past_14_Days"), value: 13 },
                { id: "past1month", displayName: $filter(constants.translate)("Dashboard.Past_1_Month"), value: 1 },
                { id: "past3month", displayName: $filter(constants.translate)("Dashboard.Past_3_Months"), value: 3 }
        ];

        self.jobData = [];
        self.selectedTime = self.timePeriods[0];
        self.today = moment().get('date');
        self.currentMonth = moment().get('month');

        self.selectTimePeriod = selectTimePeriod;
        self.convertSinglePositionNameToPlural = convertSinglePositionNameToPlural;
        self.goToDashboardJob = goToDashboardJob;

        var caculateDate = jobActivitySvc.caculateDate(self.selectedTime);
        self.dateRange1 = caculateDate.dateRange1;
        self.dateRange2 = caculateDate.dateRange2;
        self.dateRange3 = caculateDate.dateRange3;

        function selectTimePeriod(param) {
            caculateDate = jobActivitySvc.caculateDate(param);
            self.dateRange1 = caculateDate.dateRange1;
            self.dateRange2 = caculateDate.dateRange2;
            self.dateRange3 = caculateDate.dateRange3;
        }

        function convertSinglePositionNameToPlural(positionName, isHide) {
            if (isHide) return dashboardSvc.convertSinglePositionNameToPlural(positionName);
            return positionName;
        }

        function goToDashboardJob(id) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/jobs/" + id + "/dashboard", window.location.href);
            historyPageSvc.setPreviousTag(constants.baseUrl + "#/jobs/" + id + "/dashboard", constants.invitationMenuIndex.all);
        }
    }
})();

