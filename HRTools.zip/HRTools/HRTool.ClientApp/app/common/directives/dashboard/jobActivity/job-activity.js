﻿(function () {
    'use strict';
    angular.module('app').directive('jobActivity', jobActivity);
    jobActivity.$inject = ['$timeout', '$filter', '$rootScope',
        'dashboardSvc', 'jobActivitySvc', 'datetimeSvc', 'messageHandleSvc',
        'jobActivityModel', 'constants', 'message'];
    function jobActivity($timeout, $filter, $rootScope,
            dashboardSvc, jobActivitySvc, datetimeSvc, messageHandleSvc,
            jobActivityModel, constants, message) {
        return {
            restrict: 'E',
            controller: 'jobActivityCtrl',
            controllerAs: 'jaCtrl',
            templateUrl: dashboardSvc.templatePathDirectives().jobActivity,
            link: function (scope) {
                init();

                function init() {
                    scope.$watch(function () { return dashboardSvc.getListOrderJobTitle(); }, function (newValue, oldValue) {
                        if (!newValue || newValue == oldValue)
                            return;
                        $timeout(function () {
                            loadJobActivity();
                        }, 1000);
                    });

                    scope.$watch('jaCtrl.selectedTime', function (newValue, oldValue) {
                        if (newValue == oldValue) return;
                        loadJobActivity();
                    }, true);
                }
                function loadJobActivity() {
                    scope.jaCtrl.isShowLoading = true;
                    var param = {
                        dateRange1: datetimeSvc.convertDateForServerSide(scope.jaCtrl.dateRange1, false),
                        dateRange2: datetimeSvc.convertDateForServerSide(scope.jaCtrl.dateRange2, false),
                        dateRange3: datetimeSvc.convertDateForServerSide(scope.jaCtrl.dateRange3, false)
                    };
                    jobActivitySvc.getJobActivity(param).query().$promise.then(function (responseList) {
                        var tempListOrderJob = dashboardSvc.getListOrderJobTitle();
                        scope.jaCtrl.jobData = [];
                        if (!responseList || !tempListOrderJob) {
                            scope.jaCtrl.isShowLoading = false;
                            return;
                        }
                        for (var i = 0; i < tempListOrderJob.length; i++) {
                            for (var j = 0; j < responseList.length; j++) {
                                if (tempListOrderJob[i].jobCode != responseList[j].JobCode)
                                    continue;
                                var temp = new jobActivityModel(responseList[j]);
                                scope.jaCtrl.jobData.push(temp);
                            }
                        }
                        $timeout(function () {
                            scope.jaCtrl.isShowLoading = false;
                        }, 500);
                    },
                    function (xhr) {
                        $rootScope.$broadcast(constants.broadCastTile.dasboardLoadFail, {});
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
                    });
                }
            }
        };
    }
})();
