﻿(function () {
    'use strict';
    angular.module('app').factory('jobActivitySvc', jobActivitySvc);
    jobActivitySvc.$inject = ['$resource', 'constants'];
    function jobActivitySvc($resource, constants) {
        var revealed = {
            caculateDate: caculateDate,
            getJobActivity: getJobActivity
        };

        return revealed;

        function caculateDate(param) {
            var result = { dateRange1: null, dateRange2: null, dateRange3: null, today: moment() };
            var addDayNumber = 1;
            var doubleRange = 2;
            switch (param.id) {
                case "past7day":
                case "past14day":
                    result.dateRange1 = moment().subtract(param.value * doubleRange + addDayNumber, 'day');
                    result.dateRange2 = moment().subtract(param.value + addDayNumber, 'day');
                    result.dateRange3 = moment().subtract(param.value, 'day');
                    break;
                case "past1month":
                case "past3month":
                    result.dateRange1 = moment().subtract(param.value * doubleRange, 'month').subtract(addDayNumber, "day");
                    result.dateRange2 = moment().subtract(param.value, 'month').subtract(addDayNumber, "day");
                    result.dateRange3 = moment().subtract(param.value, 'month');
                    break;
                default:
                    break;
            }
            return result;
        }

        function getJobActivity(param) {
            return $resource(constants.apiUrl + 'statictis/jobactivity', {
                dateRange1: param.dateRange1,
                dateRange2: param.dateRange2,
                dateRange3: param.dateRange3
            }, { query: { method: "GET", isArray: true, headers: { 'If-None-Match': '' } } });
        }
    }
})();

