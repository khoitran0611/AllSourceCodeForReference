﻿(function () {
    'use strict';
    angular.module('app').controller('latestApplicationsCtrl', LatestApplicationsCtrl);
    LatestApplicationsCtrl.$inject = ['dashboardSvc', 'messageHandleSvc', 'switchCandidateSvc', 'datetimeSvc', 'historyPageSvc', 'permissionSvc',
        'dbMessage', 'dbConstants', 'constants',
        '$scope', '$filter', '$timeout', '$rootScope', '$state'];
    function LatestApplicationsCtrl(dashboardSvc, messageHandleSvc, switchCandidateSvc, datetimeSvc, historyPageSvc, permissionSvc,
        dbMessage, dbConstants, constants,
        $scope, $filter, $timeout, $rootScope, $state) {
        var self = this;

        self.isShowLoading = true;
        self.latestApplications = [];
        self.latestAppNull = false;
        self.messageAppEmpty = $filter(constants.translate)(dbMessage.messageAppEmpty);
        self.permissionOfCurrentUser = {
            viewCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewCandidateInfo)
        };

        self.toCandidateDetail = toCandidateDetail;
        self.toCandidateList = toCandidateList;
        self.toDashboardJobs = toDashboardJobs;

        var dataFilter;

        init();

        function init() {
            dashboardSvc.getLatestApplications($scope.jobId).query().$promise.then(
                function (data) {
                    self.latestApplications = data;
                    if (!self.latestApplications || self.latestApplications.length === 0) {
                        self.latestAppNull = true;
                    } else {
                        var ids = [];
                        data.forEach(function (candidate) {
                            candidate.AppliedDate = datetimeSvc.convertDate(candidate.AppliedDate);
                            ids.push(candidate.CandidateId);
                        });
                        dataFilter = {
                            isSearching: false,
                            listId: ids,
                            pageIndex: 1,
                            totalPages: 1
                        };
                        switchCandidateSvc.setFilterData(constants.filterData.latestApplication, dataFilter);
                    }
                    $timeout(function () {
                        self.isShowLoading = false;
                    }, 500);
                }, function (error) {
                    $rootScope.$broadcast(constants.broadCastTile.dasboardLoadFail, {});
                    messageHandleSvc.handleResponse(error);
                });
        }

        function toCandidateDetail(id, index) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + id, window.location.href);
            historyPageSvc.setCurrentCandidateIdIndex(index);
            switchCandidateSvc.setCurrentList(constants.filterData.latestApplication);
        }

        function toCandidateList() {
            $.jStorage.deleteKey("candidatesearch");
            switchCandidateSvc.setCurrentList(constants.filterData.latestApplicationViewAll);
        }

        function toDashboardJobs(id) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/jobs/" + id + "/dashboard", window.location.href);
            historyPageSvc.setPreviousTag(constants.baseUrl + "#/jobs/" + id + "/dashboard", constants.invitationMenuIndex.all);
        }
    }
})();


