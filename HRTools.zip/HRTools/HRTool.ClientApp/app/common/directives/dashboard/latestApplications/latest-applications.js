﻿(function () {
    'use strict';
    angular.module('app').directive('ngLatestApplications', ngLatestApplications);
    ngLatestApplications.$inject = ['dashboardSvc'];
    function ngLatestApplications(dashboardSvc) {
        return {
            restrict: 'E',
            controller: 'latestApplicationsCtrl',
            controllerAs: 'latestAppCtrl',
            scope: {
                "jobId": "=",
                "isShowDate": "@",
                "jobCode": "="
            },
            templateUrl: dashboardSvc.templatePathDirectives().latestApplications,
            link: function (scope) {
            }
        };
    }
})();

