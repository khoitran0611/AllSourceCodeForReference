﻿(function () {
    'use strict';
    angular.module('app').controller('closingJobsCtrl', closingJobsCtrl);
    closingJobsCtrl.$inject = ['dashboardSvc', 'messageHandleSvc', 'datetimeSvc', 'switchCandidateSvc', 'historyPageSvc', 'permissionSvc',
        'dbMessage', 'dbConstants', 'constants',
        '$scope', '$filter', '$timeout', '$rootScope', '$state'];
    function closingJobsCtrl(dashboardSvc, messageHandleSvc, datetimeSvc, switchCandidateSvc, historyPageSvc, permissionSvc,
        dbMessage, dbConstants, constants,
        $scope, $filter, $timeout, $rootScope, $state) {
        var self = this;
        self.isShowLoading = true;
        self.closingJobs = [];
        self.closingJobsNull = false;
        self.messageclosingJobEmpty = $filter(constants.translate)(dbMessage.messageclosingJobEmpty);
        self.permissionOfCurrentUser = {
            viewClosingJobsInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewClosingJobs)
        };

        self.toJobDetail = toJobDetail;


        init();

        function init() {
            dashboardSvc.getClosingJobs().query().$promise.then(
                function (data) {
                    self.closingJobs = data;
                    if (!self.closingJobs || self.closingJobs.length === 0) {
                        self.closingJobsNull = true;
                    } else {
                        data.forEach(function (job) {
                            job.Date = datetimeSvc.convertDate(job.Date);
                        });
                    }
                    $timeout(function () {
                        self.isShowLoading = false;
                    }, 500);
                }, function (error) {
                    $rootScope.$broadcast(constants.broadCastTile.dasboardLoadFail, {});
                    messageHandleSvc.handleResponse(error);
                });
        }

        function toJobDetail(id, index) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/jobs/" + id + "/dashboard", window.location.href);
        }
    }
})();
