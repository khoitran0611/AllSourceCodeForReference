﻿(function () {
    'use strict';
    angular.module('app').directive('ngClosingJobs', ngClosingJobs);
    ngClosingJobs.$inject = ['dashboardSvc'];
    function ngClosingJobs(dashboardSvc) {
        return {
            restrict: 'E',
            controller: 'closingJobsCtrl',
            controllerAs: 'closingJobsCtrl',
            scope: {
                "jobId": "="
            },
            templateUrl: dashboardSvc.templatePathDirectives().closingJobs
        };
    }
})();