﻿(function () {
    'use strict';
    angular.module('app').directive('ngLatestCvUpdates', ngLatestCvUpdates);
    ngLatestCvUpdates.$inject = ['dashboardSvc'];
    function ngLatestCvUpdates(dashboardSvc) {
        return {
            restrict: 'E',
            controller: 'latestCvUpdatesCtrl',
            controllerAs: 'latestCvCtrl',
            scope: {
                "jobId": "=",
                "jobCode": "="
            },
            templateUrl: dashboardSvc.templatePathDirectives().latestCvUpdates
        };
    }
})();
