﻿(function () {
    'use strict';
    angular.module('app').controller('latestCvUpdatesCtrl', LatestCvUpdatesCtrl);
    LatestCvUpdatesCtrl.$inject = ['dashboardSvc', 'messageHandleSvc', 'datetimeSvc', 'switchCandidateSvc', 'historyPageSvc', 'permissionSvc',
        'dbMessage', 'dbConstants', 'constants',
        '$scope', '$filter', '$timeout', '$rootScope', '$state'];
    function LatestCvUpdatesCtrl(dashboardSvc, messageHandleSvc, datetimeSvc, switchCandidateSvc, historyPageSvc, permissionSvc,
            dbMessage, dbConstants, constants,
            $scope, $filter, $timeout, $rootScope, $state) {
        var self = this;
        self.isShowLoading = true;
        self.latestCvUpdates = [];
        self.latestCvNull = false;
        self.messageCvEmpty = $filter(constants.translate)(dbMessage.messageCvEmpty);
        self.permissionOfCurrentUser = {
            viewCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_ViewCandidateInfo)
        };

        self.toCandidateDetail = toCandidateDetail;
        self.toCandidateList = toCandidateList;

        var dataFilter;

        init();

        function init() {
            dashboardSvc.getLatestCvUpdates().query().$promise.then(
                function (data) {
                    self.latestCvUpdates = data;
                    if (!self.latestCvUpdates || self.latestCvUpdates.length === 0) {
                        self.latestCvNull = true;
                    } else {
                        var ids = [];
                        data.forEach(function (candidate) {
                            candidate.ModifiedDate = datetimeSvc.convertDate(candidate.ModifiedDate);
                            ids.push(candidate.Id);
                        });
                        dataFilter = {
                            isSearching: false,
                            listId: ids,
                            pageIndex: 1,
                            totalPages: 1
                        };
                        switchCandidateSvc.setFilterData(constants.filterData.latestCvUpdate, dataFilter);
                    }
                    $timeout(function () {
                        self.isShowLoading = false;
                    }, 500);
                }, function (error) {
                    $rootScope.$broadcast(constants.broadCastTile.dasboardLoadFail, {});
                    messageHandleSvc.handleResponse(error);
                });
        }

        function toCandidateDetail(id, index) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + id, window.location.href);
            historyPageSvc.setCurrentCandidateIdIndex(index);
            switchCandidateSvc.setCurrentList(constants.filterData.latestCvUpdate);
        }

        function toCandidateList() {
            $.jStorage.deleteKey("candidatesearch");
            switchCandidateSvc.setCurrentList(constants.filterData.latestCvUpdateViewAll);
        }
    }
})();
