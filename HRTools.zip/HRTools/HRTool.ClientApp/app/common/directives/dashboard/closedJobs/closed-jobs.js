﻿(function () {
    'use strict';
    angular.module('app').directive('ngClosedJobs', ngClosedJobs);
    ngClosedJobs.$inject = ['dashboardSvc'];
    function ngClosedJobs(dashboardSvc) {
        return {
            restrict: 'E',
            controller: 'closedJobsCtrl',
            controllerAs: 'closedJobsCtrl',
            scope: {
                "jobId": "="
            },
            templateUrl: dashboardSvc.templatePathDirectives().closedJobs
        };
    }
})();