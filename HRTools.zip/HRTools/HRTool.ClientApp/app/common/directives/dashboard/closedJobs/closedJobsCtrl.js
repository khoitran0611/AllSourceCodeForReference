﻿(function () {
    'use strict';
    angular.module('app').controller('closedJobsCtrl', closedJobsCtrl);
    closedJobsCtrl.$inject = ['dashboardSvc', 'messageHandleSvc', 'datetimeSvc', 'switchCandidateSvc', 'historyPageSvc', 'permissionSvc',
        'dbMessage', 'dbConstants', 'constants','joSearchModel',
        '$scope', '$filter', '$timeout', '$rootScope', '$state'];
    function closedJobsCtrl(dashboardSvc, messageHandleSvc, datetimeSvc, switchCandidateSvc, historyPageSvc, permissionSvc,
        dbMessage, dbConstants, constants, joSearchModel,
        $scope, $filter, $timeout, $rootScope, $state) {
        var self = this;
        self.isShowLoading = true;
        self.closedJobs = [];
        self.closedJobsNull = false;
        self.messageClosedJobEmpty = $filter(constants.translate)(dbMessage.messageClosedJobEmpty);
        self.permissionOfCurrentUser = {
            viewClosedJobsInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Dashboard_ViewClosedJobs)
        };

        self.toJobDetail = toJobDetail;
        self.toJobList = toJobList;

       
        init();

        function init() {
            dashboardSvc.getClosedJobs().query().$promise.then(
                function (data) {
                    self.closedJobs = data;
                    if (!self.closedJobs || self.closedJobs.length === 0) {
                        self.closedJobsNull = true;
                    } else {
                        data.forEach(function (job) {
                            job.Date = datetimeSvc.convertDate(job.Date);
                        });
                        self.closedJobs = data;
                    }
                    $timeout(function () {
                        self.isShowLoading = false;
                    }, 500);
                }, function (error) {
                    $rootScope.$broadcast(constants.broadCastTile.dasboardLoadFail, {});
                    messageHandleSvc.handleResponse(error);
                });
        }

        function toJobDetail(id, index) {
            historyPageSvc.setPreviousUrl(constants.baseUrl + "#/jobs/" + id + "/dashboard", window.location.href);
        }
        function toJobList() {
            var now = moment();
            $.jStorage.set("jobFilterCondition", {
                selectedCategory: "",
                selectedJobCode: {},
                selectedConditionalOperator: "0",
                postDateToDisplay: datetimeSvc.convertDateForServerSide(moment(new Date(now.year(), now.month(), now.date())), false),
                postDateDisplay: datetimeSvc.convertDateForServerSide(moment(new Date(now.year(), now.month() - 3, now.date())),false),
                selectedStatus: "4",
            });
            $.jStorage.set(constants.localStorageKey.jobSearch, {
                PostDate: datetimeSvc.convertDateForServerSide(moment(new Date(now.year(), now.month() - 3, now.date())), false),
                PostDateTo: datetimeSvc.convertDateForServerSide(moment(new Date(now.year(), now.month(), now.date())), false),
                Status: "4"

            });
        }
       
    }
})();
