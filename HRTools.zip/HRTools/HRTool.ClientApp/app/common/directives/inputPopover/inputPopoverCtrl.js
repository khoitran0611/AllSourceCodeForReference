﻿(function () {
    'use strict';
    angular.module('app').controller('inputPopoverCtrl', InputPopoverCtrl);
    InputPopoverCtrl.$inject = ['permissionSvc'];
    function InputPopoverCtrl(permissionSvc) {
        var self = this;
        self.id = String.randomString();
        self.userPermission = {
            addCandidateInfor: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CandidateInfo_AddCandidateInfo)
        };
    }
})();

