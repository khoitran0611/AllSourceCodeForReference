﻿(function () {
    'use strict';
    angular.module('app').directive('inputPopover', inputPopover);
    inputPopover.$inject = [
        '$timeout', '$resource', '$q', '$filter', '$rootScope', '$window', 'constants', 'message', 'messageHandleSvc'
    ];
    function inputPopover(
        $timeout, $resource, $q, $filter, $rootScope, $window, constants, message, messageHandleSvc) {
        return {
            restrict: 'A',
            transclude: true,
            controller: 'inputPopoverCtrl',
            controllerAs: 'ipvCtrl',
            templateUrl: "common/directives/inputPopover/inputPopover.html",
            scope: {
                value: "@value",
                candidateid: "@candidateid",
                jobapplicationid: "@jobapplicationid",
                istyle: "@istyle",
                classType: "@classType",
                placement: "@placement",
                updatevaluetoparent: "&updatevaluetoparent",
                ispreline: "@ispreline"
            },
            link: function (scope, element) {
                scope.isChrome = navigator.userAgent.toLowerCase().indexOf('chrome') > -1;

                scope.$watch('value', function (newValue) {
                    scope.displayvalue = scope.value.replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/\r?\n/g, '<br/>');

                    $timeout(function () {
                        var id = scope.ipvCtrl.id + "-show";
                        var dotId = scope.ipvCtrl.id + "-latest";
                        var textHeigth = $('#' + id).innerHeight();
                        if (textHeigth >= 185) {
                            $('#' + dotId).css('display', '');
                        }
                        else {
                            $('#' + dotId).css('display', 'none');
                        }
                    }, 250);
                }, true);


                scope.setInputValue = function () {
                    $timeout(function () {
                        var input = $("#" + scope.ipvCtrl.id + scope.candidateid);
                        input.focus();
                        var inputValue = scope.value.replaceAll('<br/>', "\n");
                        input.val(inputValue);
                        var buttonElement = element.find("button");
                        buttonElement.bind('click', function () {
                            inputValue = element.find("textarea").val();
                            updateValue(inputValue);
                        });

                        var textareaElement = element.find("textarea");

                        textareaElement.bind('input propertychange', function () {
                            growTextArea(this);
                        });
                    }, 200);

                };
                var colsDefault = 60;
                var rowsDefault = 8;
                function growTextArea(textarea) {
                    var linesCount = 0;
                    var lines = textarea.value.split('\n');

                    for (var i = lines.length - 1; i >= 0; --i) {
                        linesCount += Math.floor((lines[i].length / colsDefault) + 1);
                    }

                    if (linesCount >= rowsDefault) {
                        rowsDefault = linesCount;
                        textarea.cols = colsDefault + 1;
                        colsDefault++;
                    }
                    else
                        textarea.cols = colsDefault;
                }

                function updateValue(inputValue) {
                    $(".popover-link").popover('hide');
                    $(".popover-link").siblings('.popover').remove();
                    var currentUserLogin = JSON.parse($window.localStorage.getItem("currentuserlogin"));
                    var note = {
                        CreatedByUserId: currentUserLogin.UserId,
                        CreatedUser: currentUserLogin.LastName + ' ' + currentUserLogin.FirstName,
                        CandidateId: scope.candidateid,
                        Source: $filter(constants.translate)("Interviews.Screening"),
                        CreatedDate: new Date(),
                        Note: inputValue
                    };
                    $q.all([
                           updateJobApplicationNote(scope.candidateid, scope.jobapplicationid, inputValue),
                           addNoteDiscussion(scope.candidateid, note)
                    ]).then(function () {
                        scope.value = inputValue;
                        scope.updatevaluetoparent({ "value": scope.value });
                        toastr.success($filter(constants.translate)("General_Information.Note_Is_Updated_Successfully"));
                        $rootScope.$broadcast(constants.broadCastTile.updateCandidateNode, note);
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorInSavingData));
                    });

                }
                function updateJobApplicationNote(candidateId, jobApplicationId, inputValue) {
                    var deferred = $q.defer();
                    var jobApplicationResource = $resource(constants.apiUrl + "candidates/:candidateId/job-application/:jobApplicationId",
                        { candidateId: candidateId, jobApplicationId: jobApplicationId },
                        {
                            "update": { method: "PUT", headers: { ActionName: "UpdateJobApplicationNote" } }
                        });
                    var data = { Id: scope.jobapplicationid, CandidateId: scope.candidateid, Note: inputValue };
                    jobApplicationResource.update(data).$promise.then(
                        function (value) {
                            deferred.resolve(value);
                        }, function (reason) {
                            deferred.reject(reason);
                        });
                    return deferred.promise;
                }

                function addNoteDiscussion(candidateId, note) {
                    var deferred = $q.defer();
                    $resource(constants.apiUrl + "candidates/:id/candidate-note", { id: candidateId }).save(note).$promise.then(
                        function (value) {
                            deferred.resolve(value);
                        }, function (reason) {
                            deferred.reject(reason);
                        });
                    return deferred.promise;
                }
            }
        };
    }
})();


