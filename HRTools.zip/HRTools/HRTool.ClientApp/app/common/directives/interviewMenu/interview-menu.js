﻿(function () {
    'use strict';
    angular.module('app').directive('interviewMenu', interviewMenu);
    interviewMenu.$inject = ['$timeout', '$state', 'constants', 'enumGlyphicon', 'historyPageSvc', 'styleSvc', 'candidateSvc', 'permissionSvc'];
    function interviewMenu($timeout, $state, constants, enumGlyphicon, historyPageSvc, styleSvc, candidateSvc, permissionSvc) {
        return {
            restrict: 'A',
            transclude: true,
            controller: 'interviewMenuCtrl',
            controllerAs: 'interviewMenuCtrl',
            templateUrl: "common/directives/interviewMenu/interviewMenu.html",
            scope: {
                "candidateId": "@",
                "interviewId": "@",
                "jobApplicationId": "@",
                "overalStatus": "=",
                "iconTitle": "=",
                "isFinish": "=",
                "interviewResult": "=",
                "isCanceled": "="
            },
            link: function (scope) {
                scope.userPermission = {
                    canViewEditInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_EditInterview) && permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview),
                    canViewReschedules: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_EditSchedule) && permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_ViewScheduleInterview),
                    canViewInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_AddInterview) && permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview)
                };
                scope.goToReschedulePage = function (candidateId, jobApplicationId, interviewId) {
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + candidateId + "/job-application/" + jobApplicationId + "/schedule-interview/" + interviewId, window.location.href);
                    candidateSvc.getCandidateInforData(candidateId, function () {
                        $state.go('scheduleInterview', { id: candidateId, jobApplicationId: jobApplicationId, interviewId: interviewId });
                    });
                };
                scope.rejectStatus = constants.applicationStatus.Other.RejectAll;
                scope.goToInterviewPage = function (interviewId) {
                    if (scope.isCanceled || !scope.userPermission.canViewEditInterview) return;
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/interviews/" + interviewId + "/conduct-interview", window.location.href);
                    $state.go('conductInterview', { interviewId: interviewId });
                };
                scope.goToCancelInterviewPage = function (interviewId) {
                    if (scope.isCanceled || !scope.userPermission.canViewEditInterview) return;
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/interviews/" + interviewId + "/cancel-interview", window.location.href);
                    $state.go('cancelInterview', { interviewId: interviewId });
                };

                scope.getIcon = function (statusId) {
                    switch (statusId) {
                        case constants.applicationStatus.ScreeningCv.Passed:
                        case constants.interviewResult.passForSort:
                        case constants.interviewResult.passText:
                            return enumGlyphicon.glyphiconPass;
                        case constants.applicationStatus.ScreeningCv.Rejected:
                        case constants.interviewResult.rejectText:
                            return enumGlyphicon.glyphiconReject;
                        default:
                            return 'glyphicon glyphicon-interview-hand-up';
                    }
                };
                scope.$watch("overalStatus", function (value) {
                    if (value == constants.applicationStatus.OfferStatus.HasOffer ||
                        value == constants.applicationStatus.OfferStatus.AlreadySent ||
                        value == constants.applicationStatus.OfferStatus.AcceptOffer ||
                        value == constants.applicationStatus.OfferStatus.RejectOffer ||
                        value == constants.applicationStatus.Other.RejectAll) {
                        scope.addonIcon = "glyphicon-calendar-disable icon-disabled";
                        scope.hideCalendarAction = true;
                        //if (!scope.$$phase) scope.$apply();
                        return true;
                    }
                    scope.hideCalendarAction = false;
                    scope.addonIcon = " glyphicon-calendar";
                    //if (!scope.$$phase) scope.$apply();
                    return false;
                }, true);

                scope.nevigative = function (value) {
                    return !value;
                };
            }
        };
    }
})();

