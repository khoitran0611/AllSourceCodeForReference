﻿(function () {
    'use strict';
    angular.module('app').directive('jobStatusDropdown', jobStatusDropdown);
    function jobStatusDropdown() {
        return {
            restrict: 'E',
            transclude: true,
            controller: 'jobStatusDropdownCtrl',
            controllerAs: 'jobSDCtrl',
            templateUrl: "common/directives/jobStatusDropdown/jobStatusDropdown.html",
            scope: {
                "jobId": "=",
                "job": "=",
                "isPublishJobCompleted": "="
            }
        };
    }
})();

