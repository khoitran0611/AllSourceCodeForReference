﻿(function () {
    "use strict";
    angular.module('app').controller('jobStatusDropdownCtrl', jobStatusDropdownCtrl);
    jobStatusDropdownCtrl.$inject = [
        '$scope', '$filter', 'constants', 'message', 'jobStatusDropdownSvc',
        'styleSvc', 'datetimeSvc', 'jobSvc', 'emailSvc', 'loadingSvc', 'permissionSvc', 'dropdownSvc', 'messageHandleSvc'];
    function jobStatusDropdownCtrl(
        $scope, $filter, constants, message, jobStatusDropdownSvc,
        styleSvc, datetimeSvc, jobSvc, emailSvc, loadingSvc, permissionSvc, dropdownSvc, messageHandleSvc) {
        /* jshint -W040 */
        var self = this;
        var _selectedStatusId;
        var _candidatesAppliedToPosition = [];
        var _defaultResultOfValidateDate = {
            valid: true,
            errorMessageKey: ""
        };
        var jobStatusDropdown = '.job-status-dropdown';


        self.currentOptions = [];
        self.jobStatus = {};
        self.popupId = String.randomString();
        self.validationApplyBeforeDateResult = angular.copy(_defaultResultOfValidateDate);
        self.emailDataForSendingThankYouLetter = {};
        self.emailDataForSendingThankYouLetter.listOfJobApplication = [];
        self.permissionOfCurrentUser = {
            updateOpenPosition: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.OpenPositions_EditOpenPosition)
        };
        self.dialogConfirm = {
            dialogId: "menuaction" + String.randomString(),
            dialogTitle: "Job_Message.Confirm_Action",
            dialogMessage: "Job_Message.Confirm_Close_Job"
        };

        self.selectOption = selectOption;
        self.savePublishJobStatus = savePublishJobStatus;
        self.cancelUpdateJob = cancelUpdateJob;
        self.changeApplyBeforeDate = changeApplyBeforeDate;
        self.onOpenPopup = onOpenPopup;
        self.denySendingConfirmMail = denySendingConfirmMail;
        self.acceptSendingConfirmMail = acceptSendingConfirmMail;

        init();

        function init() {
            $scope.$watch("job.Status", function (newValue, oldValue) {
                self.jobStatusId = angular.copy($scope.job.Status);
                self.currentOptions = jobStatusDropdownSvc.getOptionsByStatus(newValue);
                self.jobStatus = styleSvc.setPositionStatus(newValue);
            }, true);
            getCandidatesForSendingRejectMail();
            self.validationApplyBeforeDateResult = angular.copy(_defaultResultOfValidateDate);
        }

        function getCandidatesForSendingRejectMail() {
            jobSvc.getAllCandidateAppliedToPosition($scope.job.Id).query(function (candidates) {
                _candidatesAppliedToPosition = candidates;
                self.emailDataForSendingThankYouLetter.listOfJobApplication = candidates;
                getEmailDataForThankyouLetter();
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
            });
        }

        function getEmailDataForThankyouLetter() {
            emailSvc.getEmailDataForThankYouLetter().get(function (emailData) {
                self.emailDataForSendingThankYouLetter = emailData;
                self.emailDataForSendingThankYouLetter.To = $filter(constants.translate)("Update_Cv_Message") + _candidatesAppliedToPosition.length + $filter(constants.translate)("candidates");
                self.emailDataForSendingThankYouLetter.JobId = self.id;
                self.originContent = JSON.stringify(self.emailDataForSendingThankYouLetter.Content);
                self.emailDataForSendingThankYouLetter.originContent = self.originContent;
                self.originSubject = JSON.stringify(self.emailDataForSendingThankYouLetter.Subject);
                self.emailDataForSendingThankYouLetter.originSubject = self.originSubject;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(message.errorLoadingData));
            });
        }

        function selectOption(status) {
            _selectedStatusId = status.id;
            dropdownSvc.close(jobStatusDropdown);

            switch (status.id) {
                case constants.jobStatusId.New:
                case constants.jobStatusId.Closed:
                    updateJobStatus(buildModelToUpdateJobStatus());
                    break;
                case constants.jobStatusId.Ended:
                    $("#" + self.dialogConfirm.dialogId).modal('show');
                    break;
                case constants.jobStatusId.Published:
                    self.publishPopupTitle = ($scope.job.Status == constants.jobStatusId.New) ? "Job.Publish_Job" : "Job.Re_Publish_Job";
                    self.postDate = datetimeSvc.convertDateNowToString();
                    changeApplyBeforeDate();
                    $('#' + self.popupId + '-change-date').modal('show');
                    $('#' + self.popupId + '-picker').datepicker({ autoclose: true, todayHighlight: true });
                    $('#' + self.popupId + '-picker').datepicker("setDate", self.startWorkingDate);
                    break;
            }
        }

        function savePublishJobStatus() {
            publishJob(preparePublishJobDataForServer());
            $('#' + self.popupId + '-change-date').modal('hide');
        }

        function buildModelToUpdateJobStatus() {
            return {
                Id: $scope.jobId,
                Status: _selectedStatusId
            };
        }

        function preparePublishJobDataForServer() {
            return {
                Id: $scope.jobId,
                Status: _selectedStatusId,
                StartWorkingDate: datetimeSvc.convertDateForServerSide(self.startWorkingDate),
                PostDate: datetimeSvc.convertDateForServerSide(self.postDate)
            };
        }

        function updateJobStatus(job, callback) {
            if (!self.permissionOfCurrentUser.updateOpenPosition) return;
            loadingSvc.show();
            jobStatusDropdownSvc.updateJobProperty(job, "updateJobStatus").update(job,
                function () {
                    $scope.job.Status = job.Status;
                    toastr.success($filter(constants.translate)("Job.Update_Job_Status_Success"));
                    setTimeout(function () {
                        loadingSvc.close();
                    }, 1000);
                    if (typeof callback === 'function') callback();
                }, function (error) {
                    loadingSvc.close();
                    toastr.error($filter(constants.translate)("Job.Update_Job_Status_Fail"));
                });
        }

        function handleSendingThankYouEmail() {
            if (_candidatesAppliedToPosition.length == 0) return;
            previewThankyouEmailData();
        }

        function publishJob(job) {
            if (!self.permissionOfCurrentUser.updateOpenPosition) return;
            loadingSvc.show();
            jobStatusDropdownSvc.updateJobProperty(job, "publishJob").update(job,
                function () {
                    $scope.job.Status = job.Status;
                    $scope.job.PostDate = self.postDate;
                    $scope.job.StartWorkingDate = self.startWorkingDate;
                    toastr.success($filter(constants.translate)("Job.Update_Job_Status_Success"));
                    $scope.isPublishJobCompleted = true;
                    setTimeout(function () {
                        loadingSvc.close();
                    }, 1000);
                }, function (error) {
                    loadingSvc.close();
                    toastr.error($filter(constants.translate)("Job.Update_Job_Status_Fail"));
                });
        }


        function previewThankyouEmailData() {
            self.emailDataForSendingThankYouLetter.listOfJobApplication = _candidatesAppliedToPosition;
            self.emailDataForSendingThankYouLetter.To = $filter(constants.translate)("Update_Cv_Message") + _candidatesAppliedToPosition.length + $filter(constants.translate)("candidates");

            if ($scope.job.Status == constants.jobStatusId.Ended && _candidatesAppliedToPosition.length === 1) {
                emailSvc.getLetter(constants.emailCode.thankYouLetter, { CanRndCanDtllId: _candidatesAppliedToPosition[0].JobApplicationId }).get(function (data) {
                    self.emailDataForSendingThankYouLetter.dataForPreview = data;
                }, function (error) {
                    messageHandleSvc.handleResponse(error, $filter(constants.translate)(message.errorLoadingData));
                });
                $('#reviewThankYouMailModal').modal('show');
                return;
            }
            if ($scope.job.Status == constants.jobStatusId.Ended) {
                $('#thankYouLetter').modal('show');
            }
        }

        function cancelUpdateJob() {
            $('#' + self.popupId + '-change-date').modal('hide');
            self.validationApplyBeforeDateResult = angular.copy(_defaultResultOfValidateDate);
        }

        function changeApplyBeforeDate() {
            self.validationApplyBeforeDateResult = jobSvc.validateApplyBeforeDate(self.startWorkingDate, self.postDate);
        }

        function onOpenPopup() {
            self.postDate = $scope.job.PostDate;
            self.startWorkingDate = $scope.job.StartWorkingDate;
            changeApplyBeforeDate();
            dropdownSvc.show(jobStatusDropdown);
        }

        function denySendingConfirmMail() {
            updateJobStatus(buildModelToUpdateJobStatus());
        }

        function acceptSendingConfirmMail() {
            updateJobStatus(buildModelToUpdateJobStatus(), handleSendingThankYouEmail);
        }
    }
})();