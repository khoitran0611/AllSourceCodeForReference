﻿(function () {
    'use strict';
    angular.module("app").factory('jobStatusDropdownSvc', jobStatusDropdownSvc);
    jobStatusDropdownSvc.$inject = ['$resource', 'constants'];
    function jobStatusDropdownSvc($resource, constants) {

        return {
            updateJobProperty: updateJobProperty,
            getOptionsByStatus: getOptionsByStatus
        };

        function updateJobProperty(data, action) {
            return $resource(constants.apiUrl + 'openpositions/:id/detail', { id: data.Id, action: action }, { update: { method: 'PUT' } });
        }

        function getOptionsByStatus(status) {
            switch (status) {
                case constants.jobStatusId.New:
                case "0":
                    return [{ id: constants.jobStatusId.Published, name: "Publish" }];
                case constants.jobStatusId.Published:
                case "3":
                    return [{ id: constants.jobStatusId.New, name: "New" },
                            { id: constants.jobStatusId.Closed, name: "Close" }];
                case constants.jobStatusId.Closed:
                case "4":
                    return [{ id: constants.jobStatusId.Published, name: "Publish" },
                            { id: constants.jobStatusId.Ended, name: "End" }];
                case constants.jobStatusId.Ended:
                case "5":
                    return [{ id: constants.jobStatusId.Closed, name: "Close" }];
                default: return [];
            }
        }
    }
})();