﻿(function () {
    'use strict';
    angular.module('app').directive('cropImage', cropImage);
    function cropImage() {
        return {
            restrict: 'A',
            controller: 'cropImageCtrl',
            controllerAs: 'cropImageCtrl',
            scope: {
                'init': '=init',
                'crop': '&'
            },
            templateUrl: "common/directives/cropImage/crop-image.html",
            link: function (scope) {
            }
        };
    }
})();
