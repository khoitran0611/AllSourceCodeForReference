﻿(function () {
    'use strict';
    angular.module('app').controller('cropImageCtrl', CropImageCtrl);
    CropImageCtrl.$inject = ["$scope", "$filter", "caConstants", "caMessage"];
    function CropImageCtrl($scope, $filter, caConstants, caMessage) {
        var self = this;

        self.uploadImagePopUp = $('#upload-image-modal');
        self.imageUploaded = $('.img-container > img');

        self.imageUploadZoomIn = imageUploadZoomIn;
        self.imageUploadZoomOut = imageUploadZoomOut;
        self.imageUploadMoveLeft = imageUploadMoveLeft;
        self.imageUploadMoveRight = imageUploadMoveRight;
        self.imageUploadMoveUp = imageUploadMoveUp;
        self.imageUploadMoveDown = imageUploadMoveDown;
        self.imageUploadRotateLeft = imageUploadRotateLeft;
        self.imageUploadRotateRight = imageUploadRotateRight;
        self.imageUploadReset = imageUploadReset;

        $scope.imageUploadChangeImage = imageUploadChangeImage;

        var $body = $('body');

        init();

        function init() {
            $scope.$on(caConstants.events.updateCropImageSource, function (event, rootScopeParams) {
                self.imageUploaded.attr("src", rootScopeParams);
                if (!$scope.$$phase) $scope.$apply();
            });

            self.uploadImagePopUp.on('shown.bs.modal', function () {
                self.imageUploaded.cropper({
                    strict: true,
                    aspectRatio: 6 / 7,
                    autoCropArea: 0.5,
                    responsive: true,
                    guides: true,
                    modal: true,
                    autoCrop: true,
                    background: true,
                    dragCrop: true,
                    movable: true,
                    scalable: true,
                    rotatable: true,
                    zoomable: true,
                    mouseWheelZoom: true
                    //preview: '.img-preview',
                });
            });

            self.uploadImagePopUp.on('hidden.bs.modal', function () {
                var control = $('#imageCandidate');
                control.replaceWith(control = control.clone(true));
                self.imageUploaded.cropper("destroy");
            });

            $body.on('keydown', function (e) {
                if (!self.imageUploaded || !self.imageUploaded.data('cropper')) {
                    return;
                }
                switch (e.which) {
                    case 37:
                        e.preventDefault();
                        $scope.imageUploaded.cropper('move', -1, 0);
                        break;

                    case 38:
                        e.preventDefault();
                        $scope.imageUploaded.cropper('move', 0, -1);
                        break;

                    case 39:
                        e.preventDefault();
                        $scope.imageUploaded.cropper('move', 1, 0);
                        break;

                    case 40:
                        e.preventDefault();
                        $scope.imageUploaded.cropper('move', 0, 1);
                        break;
                }
            });
        }

        function imageUploadZoomIn() {
            self.imageUploaded.cropper("zoom", 0.1);
        }

        function imageUploadZoomOut() {
            self.imageUploaded.cropper("zoom", -0.1);
        }

        function imageUploadMoveLeft() {
            self.imageUploaded.cropper("move", -10, 0);
        }

        function imageUploadMoveRight() {
            self.imageUploaded.cropper("move", 10, 0);
        }

        function imageUploadMoveUp() {
            self.imageUploaded.cropper("move", 0, -10);
        }

        function imageUploadMoveDown() {
            self.imageUploaded.cropper("move", 0, 10);
        }

        function imageUploadRotateLeft() {
            self.imageUploaded.cropper("rotate", -45);
        }

        function imageUploadRotateRight() {
            self.imageUploaded.cropper("rotate", 45);
        }

        function imageUploadReset() {
            self.imageUploaded.cropper("reset");
        }

        function imageUploadChangeImage() {
            var $input = document.getElementById('inputImage');
            if (!$input.files || !$input.files[0]) return;
            var fileSize = $input.files[0].size;
            if (fileSize >= caConstants.maxFileSizeUploaded) {
                toastr.warning($filter(caConstants.translate)(caMessage.uploadFileLessThan) + ' ' + $filter(caConstants.translate)(caMessage.sizeOfImage));
                var control = $('input#inputImage');
                control.replaceWith(control = control.clone(true));
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
                return;
            }
            var reader = new FileReader();
            reader.onload = function (element) {
                self.imageUploaded.cropper('replace', element.target.result);
                self.imageUploaded.cropper("reset");
                if (!$scope.$$phase && !$scope.$root.$$phase) {
                    $scope.$apply();
                }
            };
            reader.readAsDataURL($input.files[0]);
        }
    }
})();
