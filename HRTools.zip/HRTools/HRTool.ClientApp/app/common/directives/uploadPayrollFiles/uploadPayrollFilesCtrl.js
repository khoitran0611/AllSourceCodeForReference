﻿(function () {
    'use strict';
    angular.module('app').controller('uploadPayrollFilesCtrl', UploadPayrollFilesCtrl);
    UploadPayrollFilesCtrl.$inject = ["uploadPayrollFilesSvc", '$modal', '$filter', "$scope", 'constants'];
    function UploadPayrollFilesCtrl(uploadPayrollFilesSvc, $modal, $filter, $scope, constants) {
        var self = this;

        $scope.uploadFile = uploadFile;
        self.onClickRemove = onClickRemove;

        function uploadFile() {
            if ($('#payrollFileUpload').val() !== "") {
                uploadPayrollFilesSvc.uploadFile($scope);
            }
        }

        function onClickRemove(fileId, index, parentScope) {
            $modal.open({
                templateUrl: 'common/directives/uploadPayrollFiles/dialogConfirmModal.html',
                controller: ['$scope', '$modalInstance', function ($scope, $modalInstance) {
                    $scope.header = $filter(constants.translate)("CV.Confirm_Delete");
                    $scope.message = $filter(constants.translate)("Confirm_Delete_File");
                    $scope.ok = function () {
                        uploadPayrollFilesSvc.removeFile(fileId, index, $scope, parentScope);
                        $modalInstance.dismiss('cancel');
                    };
                    $scope.cancel = function () {
                        $modalInstance.dismiss('cancel');
                    };
                }]
            });
        }
    }
})();

