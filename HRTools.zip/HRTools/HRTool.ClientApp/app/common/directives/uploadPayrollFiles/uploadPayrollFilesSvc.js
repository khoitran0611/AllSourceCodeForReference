﻿(function () {
    'use strict';
    angular.module('app').factory('uploadPayrollFilesSvc', uploadPayrollFilesSvc);
    uploadPayrollFilesSvc.$inject = ['constants', '$filter', 'comparisonUtilSvc'];
    function uploadPayrollFilesSvc(constants, $filter, comparisonUtilSvc) {
        var revealed = {
            uploadFile: uploadFile,
            removeFile: removeFile
        };
        var cvFilesRemoving = [];


        return revealed;

        function uploadFile(scope) {
            $('#formPayrollFile').ajaxForm({
                data: { ActionName: constants.fileType.payroll },
                url: constants.apiUrl + 'files',
                beforeSend: function (xhr) {
                    xhr.setRequestHeader("ActionName", scope.fileType);
                },
                success: function (data) {
                    if (scope.fileType == constants.fileType.payroll) {
                        onUploadFileSuccess(data, scope);
                    }
                }
            }).submit();
        }

        function onUploadFileSuccess(data, scope) {
            if (comparisonUtilSvc.isNullOrUndefinedValue(scope.cvFiles)) scope.cvFiles = [];
            scope.cvFiles = [];
            var dataArray = data.split(',');
            if (dataArray.length > 0) {
                var cvFile = {};
                cvFile.Url = dataArray[0].substring(1, dataArray[0].length);
                var fileName = dataArray[1].substring(0, dataArray[1].length - 1);
                cvFile.FileName = (fileName.indexOf(":") > -1) ? cvFile.FileName = fileName.split(':')[1] : fileName;
                scope.cvFiles.push(cvFile);
                scope.$apply();
            }
        }

        function removeFile(fileId, index, $scope, parentScope) {
            if (fileId) {
                cvFilesRemoving.push(fileId);
            }
            if (parentScope.$parent.fileType == constants.fileType.payroll) {
                parentScope.$parent.cvFiles = [];
                angular.element(document.querySelector('#formPayrollFile')).resetForm();
                toastr.success($filter(constants.translate)("PayrollFile.Delete_Payroll_File_Success"));
            }
        }
    }
})();

