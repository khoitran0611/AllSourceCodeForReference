﻿(function () {
    'use strict';
    angular.module('app').directive('uploadPayrollFiles', uploadPayrollFiles);

    function uploadPayrollFiles() {
        return {
            restrict: 'AE',
            controller: 'uploadPayrollFilesCtrl',
            controllerAs: 'uploadCtrl',
            templateUrl: 'common/directives/uploadPayrollFiles/uploadPayrollFiles.html',
            scope: {
                cvFiles: '=cvFiles',
                fileType: '=fileType'
            },
            link: function (scope, el) {
                el.bind("change", function () {
                    scope.uploadFile();
                });
            }
        };
    }
})();

