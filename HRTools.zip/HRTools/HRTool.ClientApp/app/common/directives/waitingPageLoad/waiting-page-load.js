﻿(function () {
    "use strict";
    angular.module('app').directive('waitingPageLoad', waitingPageLoad);

    function waitingPageLoad() {
        return {
            priority: 1000,
            restrict: "A",
            templateUrl: "common/directives/waitingPageLoad/waitingPageLoad.html",
            scope: {
                "isshowloading": "="
            }
        };
    }
})();