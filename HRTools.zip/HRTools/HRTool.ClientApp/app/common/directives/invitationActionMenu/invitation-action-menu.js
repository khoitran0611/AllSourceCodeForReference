﻿(function () {
    'use strict';
    angular.module('app').directive('invitationActionMenu', invitationActionMenu);
    invitationActionMenu.$inject = ['$timeout', '$rootScope', '$state', '$filter', 'constants', 'invitationActionMenuSvc'];
    function invitationActionMenu($timeout, $rootScope, $state, $filter, constants, invitationActionMenuSvc) {
        return {
            restrict: 'A',
            transclude: true,
            controller: 'invitationActionMenuCtrl',
            controllerAs: 'iatmCtrl',
            templateUrl: "common/directives/invitationActionMenu/invitationActionMenu.html",
            scope: {
                "jobId": "=",
                "candidateId": "="
            },
            link: function (scope, element) {
                function update(invitation) {
                    var updateActionTilte = "Update_Action";
                    invitationActionMenuSvc.invitationStatus(scope.candidateId, scope.jobId).update(invitation, function () {
                        $rootScope.$broadcast(updateActionTilte, {});
                        toastr.success($filter(constants.translate)("Invitation_Message.Update_Invitation_Status_Successfully"));
                    }, function () {
                        toastr.error($filter(constants.translate)("Invitation_Message.Update_Invitation_Status_Fail"));
                    });
                }
                scope.triggerAction = function (action) {
                    var invitation = { CandidateId: scope.candidateId, JobId: scope.jobId };
                    switch (action) {
                        case "accept":
                            invitation.Status = 1;
                            update(invitation);
                            return;
                        case "reject":
                            invitation.Status = 2;
                            update(invitation);
                            return;
                        default:
                            return;
                    }
                };
            }
        };
    }
})();

