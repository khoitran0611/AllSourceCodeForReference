﻿(function () {
    "use strict";
    angular.module('app').controller('invitationActionMenuCtrl', function() {
        /* jshint -W040 */
        var self = this;
    });
})();