﻿(function () {
    'use strict';
    angular.module('app').factory('invitationActionMenuSvc', invitationActionMenuSvc);
    invitationActionMenuSvc.$inject = ["constants", "$filter", "$resource"];
    function invitationActionMenuSvc(constants, $filter, $resource) {
        function invitationStatus(candidateId, jobId) {
            return $resource(constants.apiUrl + "candidates/:id/jobs/:jobId/invitation",
                { id: candidateId, jobId: jobId }, { "update": { method: "PUT" } });
        }
        var reveal = {
            invitationStatus: invitationStatus
        };
        return reveal;
    }
})();


