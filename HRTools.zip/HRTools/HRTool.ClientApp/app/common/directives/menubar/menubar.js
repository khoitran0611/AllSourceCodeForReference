﻿(function () {
    'use strict';
    angular.module('app').directive('menubar', menubar);
    menubar.$inject = ['$timeout', '$http', '$compile', '$state', 'constants', 'historyPageSvc'];
    function menubar($timeout, $http, $compile, $state, constants, historyPageSvc) {
        var candidateTemplate = "<ul class='nav nav-tabs'><li role='presentation'><a></a></li><li role='presentation' ng-repeat='item in menus' ng-class='getMenuStatus(item)' ng-click='activatetab(item)'><a class='btn-link' role='button'>{{item.name|translate}}</a></li><li class='pull-right'></li></ul>";



        var jobTemplate = "<ul class='nav nav-tabs'><li role='presentation' class='visible-lg visible-md'><a></a></li><li role='presentation' ng-repeat='item in menus' ng-class='getMenuStatus(item)' ng-click='activatetab(item)' ng-hide='item.isHide'><a class='btn-link' role='button'> {{item.name|translate}} ({{item.number}}) </a></li><li class='pull-right'></li></ul>";
        return {
            restrict: 'A',
            transclude: true,
            controller: 'menubarCtrl',
            controllerAs: 'mbCtrl',
            scope: {
                "templateurl": "@",
                "menus": "="

            },
            link: function (scope, element) {
                scope.$state = $state;
                //Todo: remove hardcode later
                var template = (scope.templateurl.indexOf('caMenu') >= 0) ? candidateTemplate : jobTemplate;
                element.html(template).show();
                $compile(element.contents())(scope);
                scope.getMenuStatus = function (item) {
                    if (item.isActive)
                        return constants.activeClass;
                    if (!item.enable)
                        return constants.disabledClass;
                    return constants.stringEmpty;
                };
                scope.activatetab = function (item) {
                    for (var i = 0; i < scope.menus.length; i++) {
                        scope.menus[i].isActive = item.name == scope.menus[i].name;
                        if (item.name == scope.menus[i].name) historyPageSvc.setPreviousTag(window.location.href, i);
                    }
                };
            }
        };
    }
})();


