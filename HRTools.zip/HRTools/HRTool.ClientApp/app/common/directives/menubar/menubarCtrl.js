﻿(function () {
    "use strict";
    angular.module('app').controller('menubarCtrl',
        function () {
            /* jshint -W040 */
            var self = this;
           
        });
})();