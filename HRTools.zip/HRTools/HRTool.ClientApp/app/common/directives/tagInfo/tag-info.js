﻿(function () {
    'use strict';
    angular.module('app').directive('tagInfo', tagInfo);
    tagInfo.$inject = ['$filter', '$timeout', '$resource', 'permissionSvc', 'messageHandleSvc', 'message', 'constants'];
    function tagInfo($filter, $timeout, $resource, permissionSvc, messageHandleSvc, message, constants) {
        var localData = {};
        return {
            restrict: 'A',
            controller: 'tagInfoCtrl',
            controllerAs: 'tifCtrl',
            templateUrl: 'common/directives/tagInfo/tagInfo.html',
            scope: {
                'inittaginfo': '=',
                'candidateid': '@'
            },
            compile: function () {
                function createSelect2Items(scope) {
                    $('#' + scope.tifCtrl.select2Id).select2({
                        tags: scope.inittaginfo.listTag
                    }).select2('val', scope.inittaginfo.initSelection);

                    var serachField = "#{0} .select2-search-field";
                    serachField = String.format(serachField, scope.tifCtrl.elementId);
                    $(serachField).addClass("hidesearchfield");

                    $(serachField).find("input").on('input', function (element) {
                        var inputValue = element.currentTarget.value;
                        var checkValue = _.some(localData.listTag, function (item) {
                            if (item.text.toLowerCase().indexOf(inputValue.toLowerCase()) >= 0)
                                return true;
                        });
                        var numberItemInDrop = $(".locationSearchfield .select2-results li:not(.select2-selected)").length;
                        if (checkValue && numberItemInDrop)
                            $(".select2-drop").removeClass("hiddensearchfield");
                        else
                            $(".select2-drop").addClass("hiddensearchfield").appendTo(document.body);
                    });

                    $(serachField).find("input").on("keyup", function (event) {
                        var escapeKeyCode = 27;
                        if (event.keyCode == escapeKeyCode) {
                            scope.isShowButttonAddNew = true;
                            $(".select2-drop").addClass("hiddensearchfield");
                            $(':focus').blur();
                            scope.$apply();
                            return;
                        }
                        var enterKeyCode = 13;
                        if (event.keyCode != enterKeyCode)
                            return;

                        var searchChoice = "#{0} .select2-choices .select2-search-choice";
                        searchChoice = String.format(searchChoice, scope.tifCtrl.elementId);
                        var lastAddedItem = $(searchChoice).last().find("div").text();
                        var index = findWithAttr(localData.listTag, "text", lastAddedItem);
                        if (index >= 0)
                            return;
                        //todo handle enter key
                    });
                }

                function addItemToListData(item) {
                    //
                }

                function toogleContainer(elementId, isShow) {
                    var selectContainer = "#{0}  .select2-container";
                    selectContainer = String.format(selectContainer, elementId);
                    return isShow ? $(selectContainer).show() : $(selectContainer).hide();
                }

                function toogleSearchField(elementId, isShow) {
                    var serachField = "#{0}  .select2-search-field";
                    serachField = String.format(serachField, elementId);
                    return isShow ? $(serachField).show() : $(serachField).hide();
                }

                return {
                    pre: function preLink(scope) {
                        $timeout(function () {
                            if (!scope.tifCtrl.permissionOfCurrentUser.canUpdateCandidateTag)
                                $(".select2-tag").addClass("select2-tag-no-permision");
                            else $(".select2-tag").removeClass("select2-tag-no-permision");

                            if (!scope.inittaginfo)
                                return;
                            localData = scope.inittaginfo;
                            scope.inittaginfo.initSelection = scope.inittaginfo.initSelection.length > 0 ? scope.inittaginfo.initSelection : [];
                            createSelect2Items(scope);

                            scope.isHidden = scope.inittaginfo.initSelection.length <= 0 || scope.inittaginfo.listTag.length <= 0;

                            toogleSearchField(scope.tifCtrl.elementId, false);

                            toogleContainer(scope.tifCtrl.elementId, !scope.isHidden);

                        }, 500);

                    },
                    post: function postLink(scope, element) {
                        scope.isShowButttonAddNew = true;

                        element.on("select2-selecting", function (item) {
                            var id = item.object.id == item.object.text ? undefined : item.object.id;
                            if (!id) {
                                item.object.id = item.object.text = item.object.text.trim();
                                var isExisted = false;
                                for (var index = 0; index < scope.inittaginfo.listTag.length; index++) {
                                    if (scope.inittaginfo.listTag[index].text.toLowerCase() == item.object.text.toLowerCase()) {
                                        isExisted = false;
                                        for (var tagIndex = 0; tagIndex < scope.inittaginfo.initSelection.length; tagIndex++) {
                                            if (scope.inittaginfo.initSelection[tagIndex] == scope.inittaginfo.listTag[index].id) {
                                                isExisted = true;
                                                break;
                                            }
                                        }
                                        if (!isExisted) {
                                            id = scope.inittaginfo.listTag[index].id;
                                            item.object.id = scope.inittaginfo.listTag[index].id;
                                            item.object.text = scope.inittaginfo.listTag[index].text;
                                        }
                                        break;
                                    }
                                }
                                if (isExisted) {
                                    item.preventDefault();
                                    scope.isShowButttonAddNew = true;
                                    scope.$apply();
                                    $('#' + scope.tifCtrl.select2Id).select2('close');
                                    return;
                                }
                            }

                            var tag = { "TagId": id, "TagName": item.object.text, "Description": item.object.text };
                            var updateResource = $resource(constants.apiUrl + "candidates/:id/taginfo", { id: scope.candidateid },
                            {
                                "update": {
                                    method: "PUT", headers: { ActionName: "UpdateTagInfo" }
                                }

                            });
                            updateResource.update(tag).$promise.then(
                                function (value) {
                                    //todo when call api success
                                    var result = arrayResourceToInt(value);
                                    if (result > 0) {
                                        scope.inittaginfo.initSelection = scope.inittaginfo.initSelection.length > 0 ? scope.inittaginfo.initSelection : [];
                                        scope.inittaginfo.initSelection.push(result);
                                        if (!tag.TagId) {
                                            scope.inittaginfo.listTag = !scope.inittaginfo.listTag || scope.inittaginfo.listTag.length === 0 ? [] : scope.inittaginfo.listTag;
                                            scope.inittaginfo.listTag.push({ id: result, text: tag.TagName });
                                        }
                                    }
                                }, function (reason) {
                                    //todo when call api error
                                    item.preventDefault();
                                    messageHandleSvc.handleResponse(reason, $filter(constants.translate)(message.addTagError));
                                });

                        });

                        element.on("select2-removing", function (item) {
                            if (!scope.tifCtrl.permissionOfCurrentUser.canUpdateCandidateTag) {
                                item.preventDefault();
                                return;
                            }
                            for (var index = 0; index < scope.inittaginfo.listTag.length; index++) {
                                if (scope.inittaginfo.listTag[index].text == item.choice.text) {
                                    item.choice.id = scope.inittaginfo.listTag[index].id;
                                    item.val = scope.inittaginfo.listTag[index].id;
                                    break;
                                }
                            }

                            var removeResource = $resource(constants.apiUrl + "candidates/:id/taginfo", { id: scope.candidateid },
                            {
                                "update": {
                                    method: "PUT", headers: { ActionName: "RemoveTagInfo" }
                                }

                            });
                            var tag = { "TagId": item.val };

                            removeResource.update(tag).$promise.then(
                                function (value) {
                                    //todo when call api success
                                    var result = arrayResourceToInt(value);
                                    if (result > 0) {
                                        for (var tagIndex = 0; tagIndex < scope.inittaginfo.initSelection.length; tagIndex++) {
                                            if (scope.inittaginfo.initSelection[tagIndex] == result) {
                                                scope.inittaginfo.initSelection.splice(tagIndex, 1);
                                                break;
                                            }
                                        }
                                    }
                                }, function (reason) {
                                    //todo when call api error
                                    item.preventDefault();
                                    messageHandleSvc.handleResponse(reason, $filter(constants.translate)(message.deleteTagError));
                                });
                        });

                        element.on("select2-opening", function (event) {
                            if (!scope.tifCtrl.permissionOfCurrentUser.canUpdateCandidateTag) {
                                event.preventDefault();
                                return;
                            }
                            $(".select2-drop").addClass("locationSearchfield").appendTo(document.body);
                            $(".select2-drop").addClass("hiddensearchfield").appendTo(document.body);
                            var inputSearchField = "#{0} .select2-choices .select2-search-field input";
                            inputSearchField = String.format(inputSearchField, scope.tifCtrl.elementId);
                            var elementWidth = $("#" + scope.tifCtrl.elementId).width();
                            var sigma = 20;
                            $(inputSearchField).css({ "max-width": elementWidth + sigma });
                            $timeout(function () {
                                var selectedData = $('#' + scope.tifCtrl.select2Id).select2("data");
                                var numberItemInDrop = $(".locationSearchfield .select2-results li:not(.select2-selected)").length;
                                if (selectedData.length != localData.listTag.length && numberItemInDrop > 0)
                                    $(".select2-drop").removeClass("hiddensearchfield");
                            });
                        });

                        element.on("select2-focus", function (item) {
                            //todo when focus input
                        });

                        scope.addNewTag = function () {
                            scope.isShowButttonAddNew = false;
                            var selectContainer = "#{0}  .select2-container";
                            selectContainer = String.format(selectContainer, scope.tifCtrl.elementId);
                            $(selectContainer).show();

                            toogleSearchField(scope.tifCtrl.elementId, true);

                            var inputField = "#{0} .select2-search-field input";
                            inputField = String.format(inputField, scope.tifCtrl.elementId);
                            $(inputField).focus();

                            $('#' + scope.tifCtrl.select2Id).select2('open');

                        };

                        element.on("select2-blur", function () {
                            scope.isShowButttonAddNew = true;
                            scope.$apply();
                            toogleSearchField(scope.tifCtrl.elementId, false);
                            var selectedData = $('#' + scope.tifCtrl.select2Id).select2("data");
                            toogleContainer(scope.tifCtrl.elementId, selectedData.length > 0);
                        });

                        element.on("select2-close", function () {
                            var selectedData = $('#' + scope.tifCtrl.select2Id).select2("data");
                            toogleContainer(scope.tifCtrl.elementId, selectedData.length > 0);
                            $(':focus').blur();
                        });

                        element.on("select2-removed", function (item) {
                            var selectedData = $('#' + scope.tifCtrl.select2Id).select2("data");
                            toogleContainer(scope.tifCtrl.elementId, selectedData.length > 0);
                            var index = findWithAttr(localData.listTag, "id", item.val);
                            if (index >= 0)
                                return;
                            var newData = { id: _.random(-999999, 0), text: item.choice.text };
                            localData.listTag.push(newData);
                        });

                        scope.$watch("value", function (newValue) {
                            //todo when value change here
                        });

                        scope.$on("$destroy", function () {
                            //todo when object destroyed here
                        });

                        angular.element(window).on('resize', function () {
                            scope.isShowButttonAddNew = true;
                            scope.$apply();
                        });

                    }
                };
            }
        };
    }
})();
