﻿(function () {
    'use strict';
    angular.module('app').controller('tagInfoCtrl', TagInfoCtrl);
    TagInfoCtrl.$inject = ['$scope', 'permissionSvc'];
    function TagInfoCtrl($scope, permissionSvc) {
        var self = this;
        self.elementId = String.randomString();
        self.select2Id = String.randomString();
        self.permissionOfCurrentUser = {
            canUpdateCandidateTag: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_UpdateCandidateTag)
        };
    }
})();
