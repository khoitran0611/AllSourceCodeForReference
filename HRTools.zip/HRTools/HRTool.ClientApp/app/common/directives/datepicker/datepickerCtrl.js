﻿(function () {
    angular.module('app').controller('datepickerCtrl',
        function () {
            $('.date').datepicker({ changeMonth: true, changeYear: true, autoclose: true, todayHighlight: true });
        });
})();