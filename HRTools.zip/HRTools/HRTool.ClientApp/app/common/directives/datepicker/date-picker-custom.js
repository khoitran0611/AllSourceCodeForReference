﻿(function () {
    'use strict';
    angular.module('app').directive('datePickerCustom', datePickerCustom);

    function datePickerCustom() {
        return {
            restrict: 'A',
            transclude: true,
            controller: 'datepickerCtrl',
            controllerAs: 'dp',
            templateUrl: 'common/directives/datepicker/datepicker.html',
            scope: {
                'value': '='
            },
            link: function (scope) {
                scope.$watch('value', function (newVal, oldVal) {
                    if (newVal != oldVal)
                        scope.$emit('inner::changeDate', newVal);
                });
            }
        };
    }
})();
