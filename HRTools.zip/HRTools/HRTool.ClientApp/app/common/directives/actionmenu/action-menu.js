﻿(function () {
    'use strict';
    angular.module('app').directive('actionMenu', actionMenu);
    actionMenu.$inject = [
        '$timeout', '$rootScope', 'constants', 'actionMenuSvc', 'emailSvc', '$filter',
        'message', 'messageHandleSvc', 'comparisonUtilSvc'];
    function actionMenu(
        $timeout, $rootScope, constants, actionMenuSvc, emailSvc, $filter,
        message, messageHandleSvc, comparisonUtilSvc) {
        return {
            restrict: 'A',
            transclude: true,
            controller: 'actionMenuCtrl',
            controllerAs: 'atmCtrl',
            templateUrl: "common/directives/actionmenu/actionMenu.html",
            scope: {
                "listaction": "=",
                "jobapplicationid": "=",
                "candidateid": "@",
                "interviews": "=",
                "lastupdatestatus": "=",
                "didNotLoadCandidate": "@",
                "isActionProcessing": "="
            },
            link: function (scope, element) {
                scope.$watch('interviews', function (newValue, oldValue) {
                    if (newValue == oldValue) return;
                    if (scope.atmCtrl.currentListAction && scope.atmCtrl.currentListAction.length > 0)
                        scope = actionMenuSvc.setStatusDisplayMenu(scope, scope.atmCtrl.currentListAction);

                }, true);

                scope.$watch('lastupdatestatus', function (newValue, oldValue) {
                    if (comparisonUtilSvc.isNullOrUndefinedValue(newValue)) return;
                    if (scope.atmCtrl.currentListAction && scope.atmCtrl.currentListAction.length > 0)
                        scope = actionMenuSvc.setStatusDisplayMenu(scope, scope.atmCtrl.currentListAction);

                }, true);

                scope.triggerAction = function (action) {
                    var dropdownElement = element.find(".dropdown.open");
                    $('.dropdown-toggle').dropdown();
                    dropdownElement.removeClass("open");
                    actionMenuSvc.triggerAction(action, scope);
                };

                scope.onYes = function () {
                    actionMenuSvc.acceptAction(scope);
                    emailSvc.getLetter(constants.emailCode.thankYouLetter,
                        { CanRndCanDtllId: scope.jobapplicationid })
                        .get(function (data) {
                            data.jobApplicationId = scope.jobapplicationid;
                            data.isRejectMail = true;
                            $rootScope.$broadcast(constants.broadCastTile.rejectCandidate, data);
                        },
                        function (error) {
                            messageHandleSvc.handleResponse(error, $filter(constants.translate)(message.errorLoadingData));
                        });
                };

            }
        };
    }
})();