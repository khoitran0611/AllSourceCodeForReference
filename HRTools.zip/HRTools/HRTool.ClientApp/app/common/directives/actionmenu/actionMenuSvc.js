﻿(function () {
    'use strict';
    angular.module('app').factory('actionMenuSvc', actionMenuSvc);
    actionMenuSvc.$inject = ["constants", "$filter", "$resource", "$state", "$rootScope", "$window", "permissionSvc",
        "caDetailSvc", "datetimeSvc", "messageHandleSvc", "caApplicationsSvc", "historyPageSvc", "candidateSvc", "loadingSvc",
        "caMessage", "message"];
    function actionMenuSvc(constants, $filter, $resource, $state, $rootScope, $window, permissionSvc,
        caDetailSvc, datetimeSvc, messageHandleSvc, caApplicationsSvc, historyPageSvc, candidateSvc, loadingSvc,
            caMessage, message) {
        var revealed = {
            setStatusDisplayMenu: setStatusDisplayMenu,
            triggerAction: triggerAction,
            acceptAction: acceptAction
        };
        var currentUserPermission = {
            addInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_AddInterview),
            editInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_EditInterview),
            viewInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview),
            addSchedule: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_AddSchedule),
            editSchedule: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_EditSchedule),
            viewSchedule: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_ViewScheduleInterview),
            viewOfferLetterPage: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.CreateOfferLetter_ViewOfferLetterPage),
            canUpdateJobStatus: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.UpdateOfferStatus_UpdateOfferStatus),
            viewOfferLetterStatus: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.UpdateOfferStatus_ViewStatusOfferLetter),
            becomeEmployee: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.EmployeeInfo_BecomeEmployee),
            sendMailRole: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.Candidates_SendMailUpdateCV),
            canViewEditInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_EditInterview) && permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview),
            canViewReschedules: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_EditSchedule) && permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.ScheduleInterview_ViewScheduleInterview),
            canViewInterview: permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_AddInterview) && permissionSvc.isHavePermission(permissionSvc.permissionNameConstant.StartInterview_ViewInterview)
        };

        var updateActionTilte = "Update_Action";
        var getUserLoginFromCookie = JSON.parse($window.localStorage.getItem("currentuserlogin"));
        var screeningCvModel = {
            "JobApplicationId": null,
            "ModifiedDate": datetimeSvc.convertDateForServerSide(new Date(), true),
            "ModifiedByUserId": getUserLoginFromCookie.UserId,
            "ModifiedUserName": getUserLoginFromCookie.FullName,
            "Note": null,
            "Status": null
        };
        return revealed;


        function setStatusDisplayMenu(scope, currentListAction) {
            var result = scope;
            result.listaction = angular.copy(currentListAction);
            var inputAction = angular.element(document.getElementById('action-menu-clickable'));
            var navAction = angular.element(document).find(".action-menu nav.navbar");
            inputAction.removeClass("non-clickable");
            navAction.removeClass("non-clickable");

            var indexAction = {
                "Mark_Candidate_As_Interesting_Action": 0,
                "Pass_Screening_Action": 1,
                "Pass_Screening_And_Schedule_Interview_Action": 2,
                "Schedule_Interview_Action": 3,
                "Shortlist_Candidate_Action": 4,
                "Reject_Candidate_Action": 5,
                "Offer_Job_Action": 6,
                "Become_Employee_Action": 7,
                "Update_Offer_Status_Action": 8,
                "Reject_CV_Action": 9,
                "Candidate_Accepted_Offer_Action": 10,
                "Candidate_Rejected_Offer_Action": 11,
                "Create_New_Offer_Action": 12
            };

            var lastupdatestatus = safeToString(result.lastupdatestatus);

            switch (lastupdatestatus) {
                case constants.applicationStatus.OfferStatus.RejectOffer:
                    result.disableMenu = false;
                    result.addonClass = "activity-status";
                    result.listaction[indexAction.Update_Offer_Status_Action].isShow = currentUserPermission.canUpdateJobStatus;
                    result.listaction[indexAction.Candidate_Accepted_Offer_Action].isShow = currentUserPermission.canUpdateJobStatus;
                    result.listaction[indexAction.Create_New_Offer_Action].isShow = currentUserPermission.viewOfferLetterPage;
                    scope.atmCtrl.showMenu = true;

                    return result;
                case constants.applicationStatus.OfferStatus.AcceptOffer:
                    result.disableMenu = false;
                    result.addonClass = "activity-status";
                    result.listaction[indexAction.Become_Employee_Action].isShow = currentUserPermission.becomeEmployee;
                    result.listaction[indexAction.Update_Offer_Status_Action].isShow = currentUserPermission.canUpdateJobStatus;
                    result.listaction[indexAction.Create_New_Offer_Action].isShow = currentUserPermission.viewOfferLetterPage;
                    scope.atmCtrl.showMenu = true;


                    return result;
                case constants.applicationStatus.OfferStatus.AlreadySent:
                    result.disableMenu = false;
                    result.addonClass = "activity-status";
                    result.listaction[indexAction.Candidate_Accepted_Offer_Action].isShow = currentUserPermission.canUpdateJobStatus;
                    result.listaction[indexAction.Candidate_Rejected_Offer_Action].isShow = currentUserPermission.canUpdateJobStatus;
                    result.listaction[indexAction.Create_New_Offer_Action].isShow = currentUserPermission.viewOfferLetterPage;
                    scope.atmCtrl.showMenu = true;

                    return result;
                case constants.applicationStatus.Other.Shortlist:
                    result.disableMenu = false;
                    result.addonClass = "activity-status";
                    result.listaction[indexAction.Schedule_Interview_Action].isShow = result.interviews.length < constants.numberInterviews ? true : false;
                    result.listaction[indexAction.Offer_Job_Action].isShow = true;
                    result.listaction[indexAction.Reject_Candidate_Action].isShow = currentUserPermission.canUpdateJobStatus;
                    scope.atmCtrl.showMenu = true;

                    return result;

                case constants.applicationStatus.Other.RejectAll:
                case constants.applicationStatus.Other.BecomeEmployee:
                    result.disableMenu = true;
                    scope.atmCtrl.showMenu = true;
                    result.addonClass = "";

                    return result;
                case constants.applicationStatus.ScreeningCv.Passed:
                    result.disableMenu = false;
                    result.addonClass = "activity-status";
                    if (result.interviews.length < constants.numberInterviews) {
                        result.listaction[indexAction.Shortlist_Candidate_Action].isShow = true;
                        result.listaction[indexAction.Reject_Candidate_Action].isShow = true;
                        result.listaction[indexAction.Offer_Job_Action].isShow = true;
                        result.listaction[indexAction.Schedule_Interview_Action].isShow = true;
                    }
                    else if (result.interviews.length == constants.numberInterviews) {
                        result.listaction[indexAction.Shortlist_Candidate_Action].isShow = true;
                        result.listaction[indexAction.Reject_Candidate_Action].isShow = true;
                        result.listaction[indexAction.Offer_Job_Action].isShow = true;
                    }
                    scope.atmCtrl.showMenu = true;
                    return result;

                case constants.applicationStatus.ScreeningCv.Interested:
                    result.disableMenu = false;
                    result.addonClass = "activity-status";
                    //-future requirement- result.listaction[indexAction.Reject_Candidate_Action].isShow = true;
                    result.listaction[indexAction.Pass_Screening_Action].isShow = true;
                    result.listaction[indexAction.Pass_Screening_And_Schedule_Interview_Action].isShow = true;
                    //-infuture requirement- result.listaction[indexAction.Reject_CV_Action].isShow = false;
                    result.listaction[indexAction.Reject_CV_Action].isShow = true;
                    scope.atmCtrl.showMenu = true;

                    return result;

                case constants.applicationStatus.ScreeningCv.Rejected:
                case constants.applicationStatus.ScreeningCv.BlackList:
                    result.addonClass = "";
                    result.disableMenu = true;
                    scope.atmCtrl.showMenu = true;
                    return result;

                case constants.applicationStatus.ScreeningCv.New:
                case constants.applicationStatus.ScreeningCv.newUnknown:
                case constants.applicationStatus.ScreeningCv.OnHold:
                    result.disableMenu = false;
                    result.addonClass = "activity-status";
                    //- future requirement - result.listaction[indexAction.Reject_Candidate_Action].isShow = true;
                    result.listaction[indexAction.Pass_Screening_Action].isShow = true;
                    result.listaction[indexAction.Pass_Screening_And_Schedule_Interview_Action].isShow = true;
                    result.listaction[indexAction.Mark_Candidate_As_Interesting_Action].isShow = true;
                    //- future requirement - result.listaction[indexAction.Reject_CV_Action].isShow = false;
                    result.listaction[indexAction.Reject_CV_Action].isShow = true;
                    scope.atmCtrl.showMenu = true;
                    return result;

                case constants.applicationStatus.FirstInterview.Rejected:
                case constants.applicationStatus.SecondInterview.Rejected:
                case constants.applicationStatus.ThirdInterview.Rejected:
                case constants.applicationStatus.FirstInterview.New:
                case constants.applicationStatus.SecondInterview.New:
                case constants.applicationStatus.ThirdInterview.New:
                case constants.applicationStatus.FirstInterview.Passed:
                case constants.applicationStatus.SecondInterview.Passed:
                case constants.applicationStatus.ThirdInterview.Passed:
                    result.disableMenu = false;
                    result.addonClass = "activity-status";
                    result.listaction[indexAction.Schedule_Interview_Action].isShow = result.interviews.length < constants.numberInterviews ? true : false;
                    result.listaction[indexAction.Shortlist_Candidate_Action].isShow = true;
                    result.listaction[indexAction.Offer_Job_Action].isShow = true;
                    result.listaction[indexAction.Reject_Candidate_Action].isShow = true;
                    scope.atmCtrl.showMenu = true;
                    return result;
                default:
                    result.disableMenu = false;
                    result.addonClass = "activity-status";
                    break;
            }

            return result;

        }

        function triggerAction(action, scope) {
            screeningCvModel.JobApplicationId = scope.jobapplicationid;
            switch (action.key) {
                case "Mark_Candidate_As_Interesting_Action":
                    scope.isActionProcessing = true;
                    screeningCvModel.Status = constants.applicationStatus.ScreeningCv.Open;
                    getScreeningCvResource(scope.candidateid, scope.jobapplicationid).save(screeningCvModel).$promise.then(
                    function () {
                        scope.lastupdatestatus = constants.applicationStatus.ScreeningCv.Open;
                        caDetailSvc.updateScreeningStatus(constants.applicationStatus.ScreeningCv.Open, scope.jobapplicationid, true);
                        caDetailSvc.updateLastUpdateStatus(constants.applicationStatus.ScreeningCv.Open, scope.jobapplicationid);
                        caApplicationsSvc.setJobApplicationScreenCVStatus(scope.jobapplicationid, constants.applicationStatus.ScreeningCv.Open);
                        $rootScope.$broadcast(updateActionTilte, {});
                        toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                        scope.isActionProcessing = false;
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.updateCvStatusError));
                        scope.isActionProcessing = false;
                    });
                    break;
                case "Pass_Screening_Action":
                    scope.isActionProcessing = true;
                    screeningCvModel.Status = constants.applicationStatus.ScreeningCv.Passed;
                    getScreeningCvResource(scope.candidateid, scope.jobapplicationid).save(screeningCvModel).$promise.then(
                    function () {
                        scope.lastupdatestatus = constants.applicationStatus.ScreeningCv.Passed;
                        caDetailSvc.updateScreeningStatus(constants.applicationStatus.ScreeningCv.Passed, scope.jobapplicationid, true);
                        caDetailSvc.updateLastUpdateStatus(constants.applicationStatus.ScreeningCv.Passed, scope.jobapplicationid);
                        caApplicationsSvc.setJobApplicationScreenCVStatus(scope.jobapplicationid, constants.applicationStatus.ScreeningCv.Passed);
                        $rootScope.$broadcast(updateActionTilte, {});
                        toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                        scope.isActionProcessing = false;
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.updateCvStatusError));
                        scope.isActionProcessing = false;
                    });
                    break;
                case "Reject_CV_Action":
                    scope.isActionProcessing = true;
                    screeningCvModel.Status = constants.applicationStatus.ScreeningCv.Rejected;
                    getScreeningCvResource(scope.candidateid, scope.jobapplicationid).save(screeningCvModel).$promise.then(
                    function () {
                        scope.lastupdatestatus = constants.applicationStatus.ScreeningCv.Rejected;
                        caDetailSvc.updateScreeningStatus(constants.applicationStatus.ScreeningCv.Rejected, scope.jobapplicationid, true);
                        caDetailSvc.updateLastUpdateStatus(constants.applicationStatus.ScreeningCv.Rejected, scope.jobapplicationid);
                        caApplicationsSvc.setJobApplicationScreenCVStatus(scope.jobapplicationid, constants.applicationStatus.ScreeningCv.Rejected);
                        $rootScope.$broadcast(updateActionTilte, {});
                        toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                        scope.isActionProcessing = false;
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.updateCvStatusError));
                        scope.isActionProcessing = false;
                    });
                    break;
                case "Pass_Screening_And_Schedule_Interview_Action":
                    scope.isActionProcessing = true;
                    screeningCvModel.Status = constants.applicationStatus.ScreeningCv.Passed;
                    getScreeningCvResource(scope.candidateid, scope.jobapplicationid).save(screeningCvModel).$promise.then(
                    function () {
                        scope.lastupdatestatus = constants.applicationStatus.ScreeningCv.Passed;
                        caDetailSvc.updateLastUpdateStatus(constants.applicationStatus.ScreeningCv.Passed, scope.jobapplicationid);
                        caDetailSvc.updateScreeningStatus(constants.applicationStatus.ScreeningCv.Passed, scope.jobapplicationid, true);
                        caApplicationsSvc.setJobApplicationScreenCVStatus(scope.jobapplicationid, constants.applicationStatus.ScreeningCv.Passed);
                        $rootScope.$broadcast(updateActionTilte, {});
                        toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                        historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + scope.candidateid + "/job-application/" + scope.jobapplicationid + "/schedule-interview/0", window.location.href);
                        scope.isActionProcessing = false;
                        if (scope.didNotLoadCandidate) {
                            candidateSvc.getCandidateInforData(scope.candidateid, function () { loadInterview(scope); });
                            return;
                        }
                        loadInterview(scope);

                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.updateCvStatusError));
                        scope.isActionProcessing = false;
                    });
                    break;
                case "Schedule_Interview_Action":
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + scope.candidateid + "/job-application/" + scope.jobapplicationid + "/schedule-interview/0", window.location.href);
                    if (scope.didNotLoadCandidate) {
                        candidateSvc.getCandidateInforData(scope.candidateid, function () { loadInterview(scope); });
                        return;
                    }
                    loadInterview(scope);
                    break;
                case "Shortlist_Candidate_Action":
                    scope.isActionProcessing = true;
                    getJobApplicationResource(scope.candidateid, scope.jobapplicationid).update({ Id: scope.jobapplicationid, CandidateId: scope.candidateid, OverallStatus: constants.applicationStatus.Other.Shortlist }).$promise.then(
                    function () {
                        scope.lastupdatestatus = constants.applicationStatus.Other.Shortlist;
                        $rootScope.$broadcast(updateActionTilte, {});
                        toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                        scope.isActionProcessing = false;
                    }, function (xhr) {
                        messageHandleSvc.handleResponse(xhr, caMessage.generalInformation.updateCvStatusError);
                        scope.isActionProcessing = false;

                    });

                    break;
                case "Reject_Candidate_Action":
                    scope.atmCtrl.dialogConfirm.dialogMessage = "Interviews.Do_You_Want_To_Reject_Candidate";
                    $("#" + scope.atmCtrl.dialogConfirm.dialogId).modal('show');
                    break;
                case "Offer_Job_Action":
                    if (scope.hasOfferLetter) {
                        historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + scope.candidateid + "/job-application/" + scope.jobapplicationid + "/offer-letter/status", window.location.href);
                        $state.go('offerLetterStatus', { candidateId: scope.candidateid, jobApplicationId: scope.jobapplicationid });
                        return;
                    }
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + scope.candidateid + "/job-application/" + scope.jobapplicationid + "/offer-letter/create", window.location.href);
                    $state.go('offerLetterCreate', { candidateId: scope.candidateid, jobApplicationId: scope.jobapplicationid });
                    break;
                case "Become_Employee_Action":
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + scope.candidateid + "/job-application/" + scope.jobapplicationid + "/become-employee", window.location.href);
                    $state.go("become-employee", { candidateId: scope.candidateid, jobApplicationId: scope.jobapplicationid });
                    break;
                case "Update_Offer_Status_Action":
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + scope.candidateid + "/job-application/" + scope.jobapplicationid + "/offer-letter/status", window.location.href);
                    $state.go('offerLetterStatus', { candidateId: scope.candidateid, jobApplicationId: scope.jobapplicationid });
                    break;
                case "Candidate_Accepted_Offer_Action":
                    $.jStorage.set("offerLetterStatus", "Accepted");
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + scope.candidateid + "/job-application/" + scope.jobapplicationid + "/offer-letter/status", window.location.href);
                    $state.go('offerLetterStatus', { candidateId: scope.candidateid, jobApplicationId: scope.jobapplicationid });
                    break;
                case "Candidate_Rejected_Offer_Action":
                    $.jStorage.set("offerLetterStatus", "Rejected");
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + scope.candidateid + "/job-application/" + scope.jobapplicationid + "/offer-letter/status", window.location.href);
                    $state.go('offerLetterStatus', { candidateId: scope.candidateid, jobApplicationId: scope.jobapplicationid });
                    break;
                case "Create_New_Offer_Action":
                    historyPageSvc.setPreviousUrl(constants.baseUrl + "#/candidates/" + scope.candidateid + "/job-application/" + scope.jobapplicationid + "/offer-letter/create", window.location.href);
                    $state.go('offerLetterCreate', { candidateId: scope.candidateid, jobApplicationId: scope.jobapplicationid });
                    break;
                default:
                    break;
            }

        }

        function loadInterview(scope) {
            $state.go('scheduleInterview', { id: scope.candidateid, jobApplicationId: scope.jobapplicationid, interviewId: 0 });
        }

        function getScreeningCvResource(candidateId, jobApplicationId) {
            return $resource(constants.apiUrl + "candidates/:candidateId/job-application/:jobApplicationId/cscreening-cv-history", { candidateId: candidateId, jobApplicationId: jobApplicationId }, { "update": { method: "PUT" } });

        }
        function getJobApplicationResource(candidateId, jobApplicationId) {
            return $resource(constants.apiUrl + "candidates/:candidateId/job-application/:jobApplicationId", { candidateId: candidateId, jobApplicationId: jobApplicationId }, { "update": { method: "PUT", headers: { ActionName: "UpdateOverallStatus" } } });

        }
        function acceptAction(scope) {
            scope.isActionProcessing = true;
            getJobApplicationResource(scope.candidateid, scope.jobapplicationid).update({ Id: scope.jobapplicationid, CandidateId: scope.candidateid, OverallStatus: constants.applicationStatus.Other.RejectAll }).$promise.then(
            function () {
                scope.lastupdatestatus = constants.applicationStatus.Other.RejectAll;
                caDetailSvc.updateLastUpdateStatus(constants.applicationStatus.Other.RejectAll, scope.jobapplicationid);
                $rootScope.$broadcast(updateActionTilte, {});
                toastr.success($filter(constants.translate)(caMessage.generalInformation.updateCvStatusSuccess));
                scope.isActionProcessing = false;
            }, function (xhr) {
                messageHandleSvc.handleResponse(xhr, $filter(constants.translate)(caMessage.generalInformation.updateCvStatusError));
                scope.isActionProcessing = false;

            });
        }
    }
})();


