﻿(function () {
    'use strict';
    angular.module('app').controller('actionMenuCtrl', ActionMenuCtrl);
    ActionMenuCtrl.$inject = ['constants', '$filter'];
    function ActionMenuCtrl(constants, $filter) {
        var self = this;

        self.currentListAction = JSON.parse(JSON.stringify(constants.listAction));
        self.id = String.randomString();
        self.showMenu = false;
        self.disableMenu = false;
        self.dialogConfirm = {
            dialogId: "menuaction" + self.id,
            dialogTitle: "Interviews.Confirm_Action",
            dialogMessage: ""
        };

        init();

        function init() {
            for (var m = 0; m < self.currentListAction.length; m++) {
                self.currentListAction[m].displayName = $filter(constants.translate)(self.currentListAction[m].displayName);
            }

            $(document).bind('click', function (e) {
                var $clicked = $(e.target);
                if (!$clicked.parents().hasClass("dropdown-menu-action")) {
                    var dropdownElement = $("#dropdown-menu-action .dropdown");
                    dropdownElement.removeClass("open");
                }
            });
        }
    }
})();
