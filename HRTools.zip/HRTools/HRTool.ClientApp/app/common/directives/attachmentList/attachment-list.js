﻿(function () {
    "use strict";
    angular.module('app').directive('attachmentList', attachmentList);
    attachmentList.$inject = ['caCvSvc', 'constants', '$window'];
    function attachmentList(caCvSvc, constants, $window) {
        return {
            restrict: 'E',
            templateUrl: 'common/directives/attachmentList/attachmentList.html',
            scope: {
                attachments: '='
            },
            link: function ($scope, element, atts) {
                $scope.getAttachmentInfo = function (item) {
                    if (item.Path.indexOf("http") > -1) {
                        item.attachmentDownloadingUrl = true;
                        caCvSvc.getAttachmentInfoFromCandidate(item.Id).then(function (attachmentUrlResult) {
                            var modifiedAttachmentUrl = attachmentUrlResult.substring(1, attachmentUrlResult.length - 1);
                            item.Path = modifiedAttachmentUrl;
                        }).then(function () {
                            item.attachmentDownloadingUrl = false;
                            $window.open(constants.serverUrl + item.Path);
                        });
                    }
                    else {
                        $window.open(constants.serverUrl + item.Path);
                    }
                }
            }
        };
    }
})();