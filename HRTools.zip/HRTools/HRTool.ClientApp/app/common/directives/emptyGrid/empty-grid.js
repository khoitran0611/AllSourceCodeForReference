﻿(function () {
    "use strict";
    angular.module('app').directive('emptyGrid', emptyGrid);
    function emptyGrid() {
        var directive = {};
        directive.restrict = 'E';
        directive.templateUrl = 'common/directives/emptyGrid/emptyGrid.html';
        directive.scope = {
            bigText: '@',
            smallText: '@',
            isSearching: '=',
            iconClass: '@'
        };

        return directive;
    }
})();