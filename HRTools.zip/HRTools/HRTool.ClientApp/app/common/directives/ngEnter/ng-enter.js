﻿(function () {
    'use strict';
    angular.module('app').directive('ngEnter', ngEnter);
    ngEnter.$inject = ['constants'];
    function ngEnter(constants) {
        return function (scope, element, attrs) {
            element.bind("keydown keypress", function (event) {
                if (event.which == constants.enterKeyCode) {
                    scope.$apply(function () {
                        scope.$eval(attrs.ngEnter);
                    });

                    event.preventDefault();
                }
            });
        };
    }
})();
