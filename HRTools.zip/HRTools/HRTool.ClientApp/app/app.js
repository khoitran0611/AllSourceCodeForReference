//(function () {
//    angular.module('app', ['routeResolver', 'ui.router', 'ngRoute', 'ngResource', 'ngGrid', 'ngAnimate', 'ui.bootstrap', 'ngCkeditor', 'pascalprecht.translate', 'ngSanitize', 'ui.select2', 'ui.calendar', 'ngCookies', 'ui.utils']);
//    angular.module('app').controller('signInViewCtrl',
//    function () {

//    });
//    //app.register = app;

//    //return app;
//})();

