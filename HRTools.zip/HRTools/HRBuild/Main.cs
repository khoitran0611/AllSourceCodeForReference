﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Build
{
    class Class
    {
        public static void Main(string[] args) { }
    }
}
