﻿namespace Eli.Common.ExcelHelper
{
    public class ExcelColumnMap
    {
        public string SheetColumnName { get; set; }
        public string ObjectColumnName { get; set; }
    }
}
