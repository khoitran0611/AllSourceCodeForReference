﻿namespace Eli.Common
{
    public static class Settings
    {
        public static string ConnectionString = string.Empty;
        public static string DefaultLanguage = string.Empty;
    }
}
