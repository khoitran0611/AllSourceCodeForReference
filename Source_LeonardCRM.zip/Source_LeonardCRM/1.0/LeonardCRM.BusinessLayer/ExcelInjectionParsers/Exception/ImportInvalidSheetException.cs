﻿namespace LeonardCRM.BusinessLayer.ExcelInjectionParsers.Exception
{
    public class ImportInvalidSheetException : System.Exception
    {
    }
}
