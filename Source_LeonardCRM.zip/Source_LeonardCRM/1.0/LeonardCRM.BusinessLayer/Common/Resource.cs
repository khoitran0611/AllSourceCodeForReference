﻿namespace LeonardCRM.BusinessLayer.Common
{
    public class Resource
    {
        public string Name { get; set; }
        public string Default { get; set; }
        public string Value { get; set; }
    }
}
