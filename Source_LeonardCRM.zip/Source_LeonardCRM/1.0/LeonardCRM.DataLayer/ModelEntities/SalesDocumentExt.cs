﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public partial class SalesDocument
    {
        public string name 
        {
            get { return FileName; }
        }
    }
}
