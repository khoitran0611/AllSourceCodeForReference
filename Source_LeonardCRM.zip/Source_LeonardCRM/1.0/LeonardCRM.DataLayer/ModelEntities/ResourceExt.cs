﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public class ResourceExt
    {
        public string Name { get; set; }
    }
}
