﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public partial class Eli_ModuleRelationship
    {
        public string MasterFieldName { get; set; }
        public string ChildFieldName { get; set; }
        public string MasterTableName { get; set; }
        public string ChildTableName { get; set; }
    }
}
