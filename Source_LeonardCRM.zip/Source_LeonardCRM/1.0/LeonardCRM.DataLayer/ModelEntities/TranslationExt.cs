﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public class TranslationExt
    {
        public string FileName { get; set; }
        public string ResourceName { get; set; }
        public string Key { get; set; }
        public string TranslationDefault { get; set; }
        public string Translation { get; set; }
    }
}
