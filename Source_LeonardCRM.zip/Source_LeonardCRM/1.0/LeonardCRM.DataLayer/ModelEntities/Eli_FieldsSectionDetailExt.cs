﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public partial class Eli_FieldsSectionDetail
    {
        public string LabelDisplay { get; set; }
    }
}
