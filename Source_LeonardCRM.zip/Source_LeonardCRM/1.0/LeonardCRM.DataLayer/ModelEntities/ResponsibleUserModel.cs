﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public class ResponsibleUserModel
    {
        public int Id { get; set; }
        public string Description { get; set; }
        public int RoleId { get; set; }
        public string Role { get; set; }
    }
}
