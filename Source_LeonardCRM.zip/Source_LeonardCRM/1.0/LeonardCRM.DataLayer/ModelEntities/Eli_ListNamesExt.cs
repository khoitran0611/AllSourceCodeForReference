﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public partial class Eli_ListNames
    {
        public int[] ModuleIds { get; set; }
    }
}
