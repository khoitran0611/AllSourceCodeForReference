﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LeonardCRM.DataLayer.ModelEntities
{
    public class NgTableModel
    {
        public int Total { get; set; }
        public object Data { get; set; }
        public object ExtModel { get; set; }
    }
}
