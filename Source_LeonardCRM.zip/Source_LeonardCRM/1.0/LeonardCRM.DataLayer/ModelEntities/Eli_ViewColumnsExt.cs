﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public partial class Eli_ViewColumns
    {
        public string ColumnName { get; set; }
        public string LabelDisplay { get; set; }
        public bool AllowGroup { get; set; }
    }
}
