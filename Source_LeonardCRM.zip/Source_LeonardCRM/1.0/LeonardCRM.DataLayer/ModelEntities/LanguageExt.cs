﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public class LanguageExt
    {
        public string LanguageName { get; set; }
        public string LanguageCode { get; set; }
        public string CultureCode { get; set; }
    }
}
