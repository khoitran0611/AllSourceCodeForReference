﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public partial class Eli_ListValues
    {
        public bool Selected { get; set; }
    }
}
