﻿using System.Collections.Generic;

namespace LeonardCRM.DataLayer.ModelEntities
{
   public  class CustomField
    {
       public IList<vwEntityFieldData> CustomFields { get; set; } 
    }
}
