﻿namespace LeonardCRM.DataLayer.ModelEntities
{
    public partial class vwViewColumn
    {
        public bool Selected { get; set; }
        public string Width { get; set; }
    }
}
