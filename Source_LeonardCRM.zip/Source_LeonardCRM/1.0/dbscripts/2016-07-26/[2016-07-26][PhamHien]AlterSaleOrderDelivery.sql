ALTER TABLE SalesOrderDelivery ADD [SaleDate] [date] NULL
