UPDATE Eli_Roles SET Parent = '1,26' WHERE Id = 2 AND Name = 'Contract Manager'


UPDATE Eli_Views SET UserRole = '1,2,23,3' WHERE ModuleId =3 AND Id IN (2,48,49,51,271,272,273,274,275)

UPDATE Eli_Views SET UserRole = '1,2,23,3,26' WHERE ModuleId =3 AND Id = 50
