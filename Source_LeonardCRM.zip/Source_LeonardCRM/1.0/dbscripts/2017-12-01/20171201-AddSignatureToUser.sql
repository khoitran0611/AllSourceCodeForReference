-- Add signature to user
Alter Table Eli_User Add [Signature] nvarchar (max)