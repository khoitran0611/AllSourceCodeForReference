ALTER TABLE [dbo].[SalesCustomer] 
ADD
[DeliveryStreet] [nvarchar](100) NULL,
[DeliveryCity] [nvarchar](50) NULL,
[DeliveryCountry] [int] NULL,
[DeliveryState] [int] NULL,
[DeliveryZip] [nchar](6) NULL	
