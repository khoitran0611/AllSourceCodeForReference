﻿namespace BinderOne.Tests
{
    using System;
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using BinderOne.EF;
    using Newtonsoft.Json;

    [TestClass]
    public class BinderOneEfTest
    {
        [TestMethod]
        public void QueryTest()
        {
            using (var dbContext = new BinderOneEntities())
            {
                Assert.IsNotNull(dbContext);

                var query = from q in dbContext.access_ct_list select q;
                Assert.IsNotNull(query);

                var items = query.Take(10).ToList();
                Assert.IsNotNull(items);

                foreach (var item in items)
                {
                    System.Diagnostics.Trace.WriteLine(JsonConvert.SerializeObject(item));
                }
            }
        }

        [TestMethod]
        public void InsertTest() 
        {
            using (var dbContext = new BinderOneEntities())
            {
                Assert.IsNotNull(dbContext);

                var newItem = new access_ct_list { ct = "Test CT", ct_ID = 88, user_ID = 88 };
                dbContext.access_ct_list.Add(newItem);
                var count = dbContext.SaveChanges();

                Assert.AreEqual(count, 1);
            }
        }

        [TestMethod]
        public void DeleteTest()
        {
            using (var dbContext = new BinderOneEntities())
            {
                Assert.IsNotNull(dbContext);

                var query = from q in dbContext.access_ct_list
                            where q.ct == "Test CT"
                            select q;

                var removed = dbContext.access_ct_list.RemoveRange(query);
                dbContext.SaveChanges();

                Assert.AreEqual(query.Count(), removed.Count());
            }
        }
    }
}
