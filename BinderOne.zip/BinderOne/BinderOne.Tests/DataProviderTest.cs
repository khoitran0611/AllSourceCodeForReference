﻿namespace BinderOne.Tests
{
    using System.Linq;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using BinderOne.EF;
    using Services;
    using System.Security.Claims;
    using Models;

    [TestClass]
    public class DataProviderTest
    {
        [TestMethod]
        public void GetContactSummariesTest()
        {
            var dbContext = new DataProvider { DbContext = new BinderOneEntities() };

            var testIdentity = new ClaimsIdentity();
            testIdentity.AddClaim(new Claim(ClaimTypes.PrimaryGroupSid, "90001"));

            var testCriteria = new ContractSearchCriteriaViewModel();
            var actual = dbContext.GetContractSummaries(testIdentity, testCriteria);

            Assert.IsNotNull(actual);
            //Assert.IsTrue(actual.ContractSummaries.Count == 25);
            //Assert.IsNotNull(actual.ContractSummaries.FirstOrDefault());
        }

        [TestMethod]
        public void Get2ndPageContactSummariesTest()
        {
            var dbContext = new DataProvider { DbContext = new BinderOneEntities() };

            var testIdentity = new ClaimsIdentity();
            testIdentity.AddClaim(new Claim(ClaimTypes.PrimaryGroupSid, "90001"));

            var testCriteria = new ContractSearchCriteriaViewModel { PageIndex = 1 };
            var actual = dbContext.GetContractSummaries(testIdentity, testCriteria);

            Assert.IsNotNull(actual);
            //Assert.IsTrue(actual.ContractSummaries.Count > 0);
            //Assert.IsNotNull(actual.ContractSummaries.FirstOrDefault());
        }
    }
}
