﻿namespace BinderOne.Tests
{
    using BinderOne.Models;
    using BinderOne.Security;
    using Microsoft.AspNet.Identity;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using MySql.AspNet.Identity;
    using System;
    using System.Linq;
    using System.Security.Claims;
    using BoClaimTypes = BinderOne.Common.Security.ClaimTypes;
    using ClaimTypes = System.Security.Claims.ClaimTypes;

    [TestClass]
    public class BinderOneSecurityTest
    {
        [TestMethod]
        public void CreateUserTest()
        {
            var userManager = new ApplicationUserManager(new MySqlUserStore<ApplicationUser>());
            Assert.IsNotNull(userManager);

            var user = new ApplicationUser();
            user.UserName = "TestUser1";
            user.Email = "TestUser1@example.com";

            try
            {
                var currentUser = userManager.FindByName(user.UserName);

                if (currentUser != null)
                {
                    var deleted = userManager.Delete(currentUser);
                    Assert.IsTrue(deleted.Succeeded);
                }

                var identityresult = userManager.Create(user, "Pw3214");
                Assert.IsTrue(identityresult.Succeeded);

                //user id
                identityresult = userManager.AddClaim(user.Id, new Claim(ClaimTypes.Sid, value: "80001"));
                Assert.IsTrue(identityresult.Succeeded);

                //corp id
                identityresult = userManager.AddClaim(user.Id, new Claim(ClaimTypes.PrimaryGroupSid, value: "90001"));
                Assert.IsTrue(identityresult.Succeeded);

                //contract manager module access level
                //identityresult = userManager.AddClaim(user.Id, new Claim(BoClaimTypes.ContractManagerModule, value: "All"));
                //Assert.IsTrue(identityresult.Succeeded);

                var claimIdentity = userManager.CreateIdentity(user, DefaultAuthenticationTypes.ApplicationCookie);
                Assert.IsTrue(claimIdentity.Claims.First(c => c.Type == ClaimTypes.PrimaryGroupSid).Value == "90001");
                Assert.IsTrue(claimIdentity.Claims.First(c => c.Type == ClaimTypes.Sid).Value == "80001");
                //Assert.IsTrue(claimIdentity.Claims.First(c => c.Type == BoClaimTypes.ContractManagerModule).Value == "All");
            }
            catch (Exception e)
            {
                Assert.Fail(e.StackTrace);
            }
        }
    }
}