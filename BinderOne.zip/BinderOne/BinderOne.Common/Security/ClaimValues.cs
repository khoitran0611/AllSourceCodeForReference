﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Common.Security
{
    public static class ClaimValues
    {
        public const string All = "All";
        public const string Corporate = "Corporate";
        public const string Optional = "";
        public const string CareType_Both = "Both";
        public const string CareType_Nmc = "NMC";
        public const string CareType_Mc = "MC";
    }
}