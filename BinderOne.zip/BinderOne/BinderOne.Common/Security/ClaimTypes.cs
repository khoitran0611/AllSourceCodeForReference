﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Common.Security
{
    public static class ClaimTypes
    {
        #region Module Claims

        public const string ContractManagerModule = "http://www.binderone.com/ws/2015/10/identity/claims/cmm";
        public const string EmployeeManagerModule = "http://www.binderone.com/ws/2015/10/identity/claims/emm";
        public const string ManagedCaredModule = "http://www.binderone.com/ws/2015/10/identity/claims/mcm";
        public const string AdminModule = "http://www.binderone.com/ws/2015/10/identity/claims/uam";

        #endregion Module Claims

        #region Action Claims

        public const string HomeAction = "http://www.binderone.com/ws/2015/10/identity/claims/homeactn";
        public const string ReportWriterAction = "http://www.binderone.com/ws/2015/10/identity/claims/reportwriteactn";
        public const string ReportHomeAction = "http://www.binderone.com/ws/2015/10/identity/claims/reportdashboardactn";
        public const string DocumentAction = "http://www.binderone.com/ws/2015/10/identity/claims/docactn";

        #endregion Action Claims

        #region Access Claims

        public const string AccessLevel = "http://www.binderone.com/ws/2015/10/identity/claims/accesslevel";
        public const string CorpProductType = "http://www.binderone.com/ws/2015/10/identity/claims/corpproducttype";
        public const string LoginUserName = "http://www.binderone.com/ws/2015/10/identity/claims/loginusername";
        public const string UserRights = "http://www.binderone.com/ws/2015/10/identity/claims/userrights";
        public const string LoginId = "http://www.binderone.com/ws/2015/10/identity/claims/loginid";
        public const string FacilityId = "http://www.binderone.com/ws/2015/10/identity/claims/facilityid";

        #endregion Access Claims
    }
}