﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace MySql.AspNet.Identity.Repositories
{
    using Data.Types;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Security.Cryptography;
    using System.Text;
    using MySqlConnection = MySql.Data.MySqlClient.MySqlConnection;

    public class BoUserRepository<TUser> : UserRepository<TUser> where TUser : BoIdentityUser
    {
        public BoUserRepository(string connectionString) : base(connectionString)
        {
        }

        public override void Insert(TUser user)
        {
            throw new NotImplementedException();
        }

        public override void Delete(TUser user)
        {
            throw new NotImplementedException();
        }

        public override IQueryable<TUser> GetAll()
        {
            throw new NotImplementedException();
        }

        public override TUser GetById(string userId)
        {
            var user = (TUser)Activator.CreateInstance(typeof(TUser));
            using (var conn = new MySqlConnection(_connectionString))
            {
                var parameters = new Dictionary<string, object>
                {
                    {"@Id", int.Parse(userId)}
                };

                var reader = MySqlHelper.ExecuteReader(conn, CommandType.Text,
                    @"SELECT Id, email, true, password, login_after1, true, bad_logins, total_bad_logins, login,
                    logins
                    FROM logins
                    WHERE Id=@Id", parameters);
                while (reader.Read())
                {
                    user.Id = reader[0].ToString();
                    user.Email = reader[1].ToString();
                    user.EmailConfirmed = ((long)reader[2] == 1);
                    user.PasswordHash = reader[3].ToString();
                    user.SecurityStamp = GenerateSecurityStamp(user.PasswordHash).ToString();
                    user.PhoneNumber = string.Empty;
                    user.PhoneNumberConfirmed = false;
                    user.TwoFactorAuthEnabled = false;
                    user.LockoutEndDate = reader[4] == DBNull.Value ? null : (DateTime?)((MySqlDateTime)reader[4]).Value;
                    user.LockoutEnabled = ((long)reader[5] == 1);
                    user.AccessFailedCount = (int)reader[6];
                    user.TotalAccessFailedCount = (int)reader[7];
                    user.UserName = reader[8].ToString();
                    user.TotalFailedCountAfterLockOutPeriod = (int)reader[9];
                }
            }

            return user;
        }

        public override TUser GetByName(string userName)
        {
            var user = (TUser)Activator.CreateInstance(typeof(TUser));
            using (var conn = new MySqlConnection(_connectionString))
            {
                var parameters = new Dictionary<string, object>
                {
                    {"@UserName", userName}
                };

                var reader = MySqlHelper.ExecuteReader(conn, CommandType.Text,
                    @"SELECT Id, email, true, password, login_after1, true, bad_logins, total_bad_logins, login, logins
                    FROM logins
                    WHERE login=@UserName", parameters);
                while (reader.Read())
                {
                    user.Id = reader[0].ToString();
                    user.Email = reader[1].ToString();
                    user.EmailConfirmed = ((long)reader[2] == 1);
                    user.PasswordHash = reader[3].ToString();
                    user.SecurityStamp = GenerateSecurityStamp(user.PasswordHash).ToString();
                    user.PhoneNumber = string.Empty;
                    user.PhoneNumberConfirmed = false;
                    user.TwoFactorAuthEnabled = false;
                    user.LockoutEndDate = reader[4] == DBNull.Value ? null : (DateTime?)((MySqlDateTime)reader[4]).Value;
                    user.LockoutEnabled = ((long)reader[5] == 1);
                    user.AccessFailedCount = (int)reader[6];
                    user.TotalAccessFailedCount = (int)reader[7];
                    user.UserName = reader[8].ToString();
                    user.TotalFailedCountAfterLockOutPeriod = (int)reader[9];
                }
            }

            return user;
        }

        public override TUser GetByEmail(string email)
        {
            var user = (TUser)Activator.CreateInstance(typeof(TUser));
            using (var conn = new MySqlConnection(_connectionString))
            {
                var parameters = new Dictionary<string, object>
                {
                    {"@Email", email}
                };

                var reader = MySqlHelper.ExecuteReader(conn, CommandType.Text,
                    @"SELECT Id, email, true, password, login_after1, true, bad_logins, total_bad_logins, login, logins
                    FROM logins
                    WHERE Email=@Email", parameters);
                while (reader.Read())
                {
                    user.Id = reader[0].ToString();
                    user.Email = reader[1].ToString();
                    user.EmailConfirmed = ((long)reader[2] == 1);
                    user.PasswordHash = reader[3].ToString();
                    user.SecurityStamp = GenerateSecurityStamp(user.PasswordHash).ToString();
                    user.PhoneNumber = string.Empty;
                    user.PhoneNumberConfirmed = false;
                    user.TwoFactorAuthEnabled = false;
                    user.LockoutEndDate = reader[4] == DBNull.Value ? null : (DateTime?)((MySqlDateTime)reader[4]).Value;
                    user.LockoutEnabled = ((long)reader[5] == 1);
                    user.AccessFailedCount = (int)reader[6];
                    user.TotalAccessFailedCount = (int)reader[7];
                    user.UserName = reader[8].ToString();
                    user.TotalFailedCountAfterLockOutPeriod = (int)reader[9];
                }
            }

            return user;
        }

        public override void Update(TUser user)
        {
            using (var conn = new MySqlConnection(_connectionString))
            {
                var parameters = new Dictionary<string, object>
                {
                   {"@Id", user.Id},
                   {"@Email", user.Email},
                   {"@Password", user.PasswordHash},
                   {"@Login_after1", (object)user.LockoutEndDate ?? DBNull.Value},
                   {"@Bad_Logins", user.AccessFailedCount},
                   {"@Total_Bad_Logins", user.TotalAccessFailedCount},
                   {"@TotalAccessFailCountAfterLockOutPeriod", user.TotalFailedCountAfterLockOutPeriod},
                   {"@Login", user.UserName}
                };

                MySqlHelper.ExecuteNonQuery(conn, @"UPDATE logins
                SET Email=@Email,Password=@Password,Login_after1=@Login_after1,Bad_Logins=@Bad_Logins,
                Total_Bad_Logins=@Total_Bad_Logins, Logins = @TotalAccessFailCountAfterLockOutPeriod, Login=@Login
                WHERE Id=@Id", parameters);

                //MySqlHelper.ExecuteNonQuery(conn, @"UPDATE aspnetusers
                //SET AccessFailedCount = @Bad_Logins, LockoutEndDateUtc = @Login_after1
                //WHERE UserName=@Login", parameters);
            }
        }

        private Guid GenerateSecurityStamp(string password)
        {
            if (string.IsNullOrWhiteSpace(password)) return Guid.Empty;

            using (MD5 md5 = MD5.Create())
            {
                byte[] hash = md5.ComputeHash(Encoding.Default.GetBytes(password));
                Guid result = new Guid(hash);
                return result;
            }
        }
    }
}