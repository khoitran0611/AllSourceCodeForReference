﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace MySql.AspNet.Identity.Repositories
{
    using Microsoft.AspNet.Identity;
    using System;
    using System.Collections.Generic;

    public class BoUserLoginRepository : UserLoginRepository
    {
        public BoUserLoginRepository(string connectionString) : base(connectionString)
        {
        }

        public override void Insert(IdentityUser user, UserLoginInfo login)
        {
            throw new NotImplementedException();
        }

        public override void Delete(IdentityUser user, UserLoginInfo login)
        {
            throw new NotImplementedException();
        }

        public override string GetByUserLoginInfo(UserLoginInfo login)
        {
            return string.Empty;
        }

        public override List<UserLoginInfo> PopulateLogins(string userId)
        {
            return new List<UserLoginInfo>();
        }
    }
}