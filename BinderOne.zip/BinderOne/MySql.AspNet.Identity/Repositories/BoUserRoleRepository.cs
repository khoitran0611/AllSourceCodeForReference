﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace MySql.AspNet.Identity.Repositories
{
    using System;
    using System.Collections.Generic;

    public class BoUserRoleRepository<TUser> : UserRoleRepository<TUser> where TUser : IdentityUser
    {
        public BoUserRoleRepository(string connectionString) : base(connectionString)
        {
        }

        public override void Insert(TUser user, string roleName)
        {
            throw new NotImplementedException();
        }

        public override void Delete(TUser user, string roleName)
        {
            throw new NotImplementedException();
        }

        public override List<String> PopulateRoles(string userId)
        {
            return new List<string>();
        }
    }
}