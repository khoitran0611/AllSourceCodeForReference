﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace MySql.AspNet.Identity.Repositories
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Security.Claims;
    using MySqlConnection = MySql.Data.MySqlClient.MySqlConnection;
    using SysClaimTypes = System.Security.Claims.ClaimTypes;

    public class BoUserClaimRepository<TUser> : UserClaimRepository<TUser> where TUser : IdentityUser
    {
        public BoUserClaimRepository(string connectionString) : base(connectionString)
        {
        }

        public override void Insert(TUser user, Claim claim)
        {
            throw new NotImplementedException();
        }

        public override void Delete(TUser user, Claim claim)
        {
            throw new NotImplementedException();
        }

        public override List<IdentityUserClaim> PopulateClaims(string userId)
        {
            var claims = new List<IdentityUserClaim>();

            using (var conn = new MySqlConnection(_connectionString))
            {
                var parameters = new Dictionary<string, object>
                {
                    {"@Id", int.Parse(userId)}
                };

                var reader = MySqlHelper.ExecuteReader(conn, CommandType.Text,
                    @"SELECT id, corp_id FROM logins WHERE Id=@Id", parameters);
                while (reader.Read())
                {
                    claims.Add(new IdentityUserClaim() { ClaimType = SysClaimTypes.Sid, ClaimValue = userId });
                    claims.Add(new IdentityUserClaim() { ClaimType = SysClaimTypes.PrimaryGroupSid, ClaimValue = reader[1].ToString() });
                }
            }
            return claims;
        }
    }
}