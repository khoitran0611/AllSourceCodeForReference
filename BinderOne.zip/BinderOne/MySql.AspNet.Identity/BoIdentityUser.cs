﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace MySql.AspNet.Identity
{
    public class BoIdentityUser : IdentityUser
    {
        public virtual int TotalAccessFailedCount { get; set; }
        public virtual int TotalFailedCountAfterLockOutPeriod { get; set; }
    }
}