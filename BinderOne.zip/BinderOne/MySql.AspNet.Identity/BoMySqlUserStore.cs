﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace MySql.AspNet.Identity
{
    using MySql.AspNet.Identity.Repositories;

    public class BoMySqlUserStore<TUser> : MySqlUserStore<TUser> where TUser : BoIdentityUser
    {
        protected override void SetupRepositories()
        {
            this._userRepository = new BoUserRepository<TUser>(this._connectionString);
            this._userLoginRepository = new BoUserLoginRepository(this._connectionString);
            this._userClaimRepository = new BoUserClaimRepository<TUser>(_connectionString);
            this._userRoleRepository = new BoUserRoleRepository<TUser>(_connectionString);
        }
    }
}