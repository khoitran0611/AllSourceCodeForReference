-- MySQL dump 10.13  Distrib 5.6.24, for Win64 (x86_64)
--
-- Host: localhost    Database: binderone
-- ------------------------------------------------------
-- Server version	5.5.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `access_ct_list`
--

DROP TABLE IF EXISTS `access_ct_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_ct_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_ID` int(11) DEFAULT NULL,
  `ct_ID` int(11) DEFAULT NULL,
  `ct` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_f_list`
--

DROP TABLE IF EXISTS `access_f_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_f_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_ID` int(11) DEFAULT NULL,
  `fac_ID` int(11) DEFAULT NULL,
  `fac_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `access_list`
--

DROP TABLE IF EXISTS `access_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `access_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `user_ID` int(11) DEFAULT NULL,
  `Company_ID` int(11) DEFAULT NULL,
  `corp_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `UserID` varchar(50) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `Access_level` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `UserID` (`UserID`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `admin_contract_type`
--

DROP TABLE IF EXISTS `admin_contract_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_contract_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `login_ID` int(11) DEFAULT NULL,
  `contract_type` varchar(100) DEFAULT NULL,
  `ct_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aspnetroles`
--

DROP TABLE IF EXISTS `aspnetroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aspnetroles` (
  `Id` varchar(128) NOT NULL,
  `Name` varchar(256) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aspnetuserclaims`
--

DROP TABLE IF EXISTS `aspnetuserclaims`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aspnetuserclaims` (
  `Id` int(11) NOT NULL AUTO_INCREMENT,
  `UserId` varchar(128) NOT NULL,
  `ClaimType` longtext,
  `ClaimValue` longtext,
  PRIMARY KEY (`Id`),
  UNIQUE KEY `Id` (`Id`),
  KEY `UserId` (`UserId`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aspnetuserlogins`
--

DROP TABLE IF EXISTS `aspnetuserlogins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aspnetuserlogins` (
  `LoginProvider` varchar(128) NOT NULL,
  `ProviderKey` varchar(128) NOT NULL,
  `UserId` varchar(128) NOT NULL,
  PRIMARY KEY (`LoginProvider`,`ProviderKey`,`UserId`),
  KEY `ApplicationUser_Logins` (`UserId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aspnetuserroles`
--

DROP TABLE IF EXISTS `aspnetuserroles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aspnetuserroles` (
  `UserId` varchar(128) NOT NULL,
  `RoleId` varchar(128) NOT NULL,
  PRIMARY KEY (`UserId`,`RoleId`),
  KEY `IdentityRole_Users` (`RoleId`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `aspnetusers`
--

DROP TABLE IF EXISTS `aspnetusers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `aspnetusers` (
  `Id` varchar(128) NOT NULL,
  `Email` varchar(256) DEFAULT NULL,
  `EmailConfirmed` tinyint(1) NOT NULL,
  `PasswordHash` longtext,
  `SecurityStamp` longtext,
  `PhoneNumber` longtext,
  `PhoneNumberConfirmed` tinyint(1) NOT NULL,
  `TwoFactorEnabled` tinyint(1) NOT NULL,
  `LockoutEndDateUtc` datetime DEFAULT NULL,
  `LockoutEnabled` tinyint(1) NOT NULL,
  `AccessFailedCount` int(11) NOT NULL,
  `UserName` varchar(256) NOT NULL,
  PRIMARY KEY (`Id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `build_shackle`
--

DROP TABLE IF EXISTS `build_shackle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `build_shackle` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `s_code` varchar(5) DEFAULT NULL,
  `S_length` varchar(5) DEFAULT NULL,
  `Material` varchar(15) DEFAULT NULL,
  `Manufacturer` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `caserates`
--

DROP TABLE IF EXISTS `caserates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `caserates` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=195 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `client_label_list`
--

DROP TABLE IF EXISTS `client_label_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client_label_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `label1` varchar(100) DEFAULT NULL,
  `label2` varchar(2100) DEFAULT NULL,
  `show_me` char(1) DEFAULT 'Y',
  `Client_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=138 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cm_emp`
--

DROP TABLE IF EXISTS `cm_emp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_emp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Facility` varchar(50) DEFAULT NULL,
  `vendor` varchar(50) DEFAULT NULL,
  `vendor_ID` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `Job_Title` varchar(50) DEFAULT NULL,
  `job_class` varchar(50) DEFAULT NULL,
  `Emp_ID` varchar(50) DEFAULT NULL,
  `Hourly_Rate` varchar(10) DEFAULT '0',
  `HeaderNotes` text,
  `start_date` date DEFAULT NULL,
  `lic_num` varchar(50) DEFAULT NULL,
  `lic_exp_date` date DEFAULT NULL,
  `lic_ExpriationNotifyPriorDays` int(11) DEFAULT NULL,
  `lic_action` varchar(50) DEFAULT NULL,
  `bcls_num` varchar(50) DEFAULT NULL,
  `bcls_date` date DEFAULT NULL,
  `bcls_NPD` int(11) DEFAULT NULL,
  `bcls_action` varchar(50) DEFAULT NULL,
  `acls_num` varchar(50) DEFAULT NULL,
  `acls_date` date DEFAULT NULL,
  `acls_NPD` int(11) DEFAULT NULL,
  `acls_action` varchar(50) DEFAULT NULL,
  `comp_chk_num` varchar(50) DEFAULT NULL,
  `comp_chk_date` date DEFAULT NULL,
  `comp_chk_NPD` int(11) DEFAULT NULL,
  `comp_chk_action` varchar(50) DEFAULT NULL,
  `extra_lic_num` varchar(50) DEFAULT NULL,
  `extra_lic_date` date DEFAULT NULL,
  `extra_lic_NPD` int(11) DEFAULT NULL,
  `extra_lic_action` varchar(50) DEFAULT NULL,
  `extra1_lic_num` varchar(50) DEFAULT NULL,
  `extra1_lic_date` date DEFAULT NULL,
  `extra1_lic_NPD` int(11) DEFAULT NULL,
  `extra1_lic_action` varchar(50) DEFAULT NULL,
  `Background_Check` char(3) DEFAULT NULL,
  `Job_Description` text,
  `Orientation_Packet` char(3) DEFAULT NULL,
  `Unit_Orientation` char(3) DEFAULT NULL,
  `active` char(3) DEFAULT NULL,
  `Blank1` char(3) DEFAULT NULL,
  `Blank2` char(3) DEFAULT NULL,
  `Blank3` char(3) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) DEFAULT NULL,
  `lic_ver_date` date DEFAULT NULL,
  `lic_ver_by` varchar(50) DEFAULT NULL,
  `lic_ver_file` varchar(100) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `ex_email` char(1) DEFAULT NULL,
  `bcls_email` char(1) DEFAULT NULL,
  `acls_email` char(1) DEFAULT NULL,
  `bcls_ver_date` date DEFAULT NULL,
  `bcls_ver_by` varchar(50) DEFAULT NULL,
  `bcls_ver_file` varchar(50) DEFAULT NULL,
  `acls_ver_date` date DEFAULT NULL,
  `acls_ver_by` varchar(50) DEFAULT NULL,
  `acls_ver_file` varchar(50) DEFAULT NULL,
  `comp_ver_date` date DEFAULT NULL,
  `comp_ver_by` varchar(50) DEFAULT NULL,
  `comp_ver_file` varchar(50) DEFAULT NULL,
  `ex_ver_date` date DEFAULT NULL,
  `ex_ver_by` varchar(50) DEFAULT NULL,
  `ex_ver_file` text,
  `ex1_ver_date` date DEFAULT NULL,
  `ex1_ver_by` varchar(50) DEFAULT NULL,
  `ex1_ver_file` text,
  `comp_email` char(1) DEFAULT NULL,
  `extra_email` char(1) DEFAULT NULL,
  `extra1_email` char(1) DEFAULT NULL,
  `job` varchar(50) DEFAULT NULL,
  `ex_ver_type` varchar(5) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `exclude` varchar(50) DEFAULT NULL,
  `extra2_num` varchar(50) DEFAULT NULL,
  `extra2_date` date DEFAULT NULL,
  `extra2_NPD` int(11) DEFAULT NULL,
  `extra2_action` varchar(50) DEFAULT NULL,
  `extra3_num` varchar(50) DEFAULT NULL,
  `extra3_date` date DEFAULT NULL,
  `extra3_NPD` int(11) DEFAULT NULL,
  `extra3_action` varchar(50) DEFAULT NULL,
  `extra4_num` varchar(50) DEFAULT NULL,
  `extra4_date` date DEFAULT NULL,
  `extra4_NPD` int(11) DEFAULT NULL,
  `extra4_action` varchar(50) DEFAULT NULL,
  `extra2_ver_date` date DEFAULT NULL,
  `extra3_ver_date` date DEFAULT NULL,
  `extra4_ver_date` date DEFAULT NULL,
  `ex2_ver_file` text,
  `ex3_ver_file` text,
  `ex4_ver_file` text,
  `ex2_ver_by` varchar(50) DEFAULT NULL,
  `ex3_ver_by` varchar(50) DEFAULT NULL,
  `ex4_ver_by` varchar(50) DEFAULT NULL,
  `ex2_email` varchar(50) DEFAULT NULL,
  `ex3_email` varchar(50) DEFAULT NULL,
  `ex4_email` varchar(50) DEFAULT NULL,
  `oig_bad` char(1) DEFAULT 'N',
  `oig_checked` date DEFAULT NULL,
  `oig_check_on` date DEFAULT NULL,
  `Blank4` varchar(50) DEFAULT 'Blank4',
  `Blank5` varchar(50) DEFAULT 'Blank5',
  `Blank6` varchar(50) DEFAULT 'Blank6',
  `Blank7` varchar(50) DEFAULT 'Blank7',
  `Blank8` varchar(50) DEFAULT 'Blank8',
  `Blank9` varchar(50) DEFAULT 'Blank9',
  `Blank10` varchar(50) DEFAULT 'Blank10',
  `Blank11` varchar(50) DEFAULT 'Blank11',
  `Blank12` varchar(50) DEFAULT 'Blank12',
  `rp_email` varchar(50) DEFAULT NULL,
  `rp_email2` varchar(50) DEFAULT NULL,
  `rp_email3` varchar(50) DEFAULT NULL,
  `x1` text,
  `x2` text,
  `x3` text,
  `x4` text,
  `x5` text,
  `x6` text,
  `x7` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=927 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cm_emp_setup`
--

DROP TABLE IF EXISTS `cm_emp_setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_emp_setup` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Facility` varchar(50) DEFAULT NULL,
  `vendor` varchar(50) DEFAULT NULL,
  `vendor_ID` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `Job_Title` varchar(50) DEFAULT NULL,
  `job_class` varchar(50) DEFAULT NULL,
  `Emp_ID` varchar(50) DEFAULT NULL,
  `Hourly_Rate` varchar(50) DEFAULT '0',
  `HeaderNotes` varchar(50) DEFAULT NULL,
  `start_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `lic_num` varchar(50) DEFAULT NULL,
  `lic_exp_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `lic_ExpriationNotifyPriorDays` varchar(50) DEFAULT NULL,
  `lic_action` varchar(50) DEFAULT NULL,
  `bcls_num` varchar(50) DEFAULT NULL,
  `bcls_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `bcls_NPD` varchar(50) DEFAULT NULL,
  `bcls_action` varchar(50) DEFAULT NULL,
  `acls_num` varchar(50) DEFAULT NULL,
  `acls_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `acls_NPD` varchar(50) DEFAULT NULL,
  `acls_action` varchar(50) DEFAULT NULL,
  `comp_chk_num` varchar(50) DEFAULT NULL,
  `comp_chk_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `comp_chk_NPD` varchar(50) DEFAULT NULL,
  `comp_chk_action` varchar(50) DEFAULT NULL,
  `extra_lic_num` varchar(50) DEFAULT NULL,
  `extra_lic_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `extra_lic_NPD` varchar(50) DEFAULT NULL,
  `extra_lic_action` varchar(50) DEFAULT NULL,
  `extra1_lic_num` varchar(50) DEFAULT NULL,
  `extra1_lic_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `extra1_lic_NPD` varchar(50) DEFAULT NULL,
  `extra1_lic_action` varchar(50) DEFAULT NULL,
  `Background_Check` varchar(50) DEFAULT NULL,
  `Job_Description` varchar(50) DEFAULT NULL,
  `Orientation_Packet` varchar(50) DEFAULT NULL,
  `Unit_Orientation` varchar(50) DEFAULT NULL,
  `active` varchar(50) DEFAULT NULL,
  `Blank1` varchar(50) DEFAULT NULL,
  `Blank2` varchar(50) DEFAULT NULL,
  `Blank3` varchar(50) DEFAULT NULL,
  `updated` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `lic_ver_date` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `lic_ver_by` varchar(50) DEFAULT NULL,
  `lic_ver_file` varchar(100) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `S_comp_chk_num` char(1) DEFAULT 'Y',
  `S_extra_lic_num` char(1) DEFAULT 'Y',
  `S_extra1_lic_num` char(1) DEFAULT 'Y',
  `S_Job_class` char(1) DEFAULT 'Y',
  `S_Hourly_Rate` char(1) DEFAULT 'Y',
  `S_Background_Check` char(1) DEFAULT 'Y',
  `S_Unit_Orientation` char(1) DEFAULT 'Y',
  `S_Blank2` char(1) DEFAULT 'Y',
  `S_Orientation_Packet` char(1) DEFAULT 'Y',
  `S_Blank1` char(1) DEFAULT 'Y',
  `S_Blank3` char(1) DEFAULT 'Y',
  `S_Job_Description` char(1) DEFAULT 'Y',
  `extra2_numx` varchar(50) DEFAULT NULL,
  `extra2_datex` varchar(50) DEFAULT NULL,
  `extra2_NPDx` varchar(50) DEFAULT NULL,
  `extra2_actionx` varchar(50) DEFAULT NULL,
  `extra3_numx` varchar(50) DEFAULT NULL,
  `extra3_datex` varchar(50) DEFAULT NULL,
  `extra3_NPDx` varchar(50) DEFAULT NULL,
  `extra3_actionx` varchar(50) DEFAULT NULL,
  `extra4_numx` varchar(50) DEFAULT NULL,
  `extra4_datex` varchar(50) DEFAULT NULL,
  `extra4_NPDx` varchar(50) DEFAULT NULL,
  `extra4_actionx` varchar(50) DEFAULT NULL,
  `S_extra_lic_num2` varchar(50) DEFAULT 'Y',
  `extra2_num` varchar(50) DEFAULT NULL,
  `extra2_date` varchar(50) DEFAULT NULL,
  `extra2_NPD` varchar(50) DEFAULT NULL,
  `extra2_action` varchar(50) DEFAULT NULL,
  `extra3_num` varchar(50) DEFAULT NULL,
  `extra3_date` varchar(50) DEFAULT NULL,
  `extra3_NPD` varchar(50) DEFAULT NULL,
  `extra3_action` varchar(50) DEFAULT NULL,
  `extra4_num` varchar(50) DEFAULT NULL,
  `extra4_date` varchar(50) DEFAULT NULL,
  `extra4_NPD` varchar(50) DEFAULT NULL,
  `extra4_action` varchar(50) DEFAULT NULL,
  `S_extra_lic_num3` varchar(50) DEFAULT 'Y',
  `S_extra_lic_num4` varchar(50) DEFAULT 'Y',
  `S_Blank4` varchar(50) DEFAULT NULL,
  `S_Blank5` varchar(50) DEFAULT NULL,
  `S_Blank6` varchar(50) DEFAULT NULL,
  `S_Blank7` varchar(50) DEFAULT NULL,
  `S_Blank8` varchar(50) DEFAULT NULL,
  `S_Blank9` varchar(50) DEFAULT NULL,
  `S_Blank10` varchar(50) DEFAULT NULL,
  `S_Blank11` varchar(50) DEFAULT NULL,
  `S_Blank12` varchar(50) DEFAULT NULL,
  `j` varchar(50) DEFAULT NULL,
  `k` varchar(50) DEFAULT NULL,
  `l` varchar(50) DEFAULT NULL,
  `o` varchar(50) DEFAULT NULL,
  `Blank4` varchar(50) DEFAULT 'Blank4',
  `Blank5` varchar(50) DEFAULT 'Blank5',
  `Blank6` varchar(50) DEFAULT 'Blank6',
  `Blank7` varchar(50) DEFAULT 'Blank7',
  `Blank8` varchar(50) DEFAULT 'Blank8',
  `Blank9` varchar(50) DEFAULT 'Blank9',
  `Blank10` varchar(50) DEFAULT 'Blank10',
  `Blank11` varchar(50) DEFAULT 'Blank11',
  `Blank12` varchar(50) DEFAULT 'Blank12',
  `rp_email` varchar(50) DEFAULT NULL,
  `rp_email2` varchar(50) DEFAULT NULL,
  `rp_email3` varchar(50) DEFAULT NULL,
  `X1` varchar(50) DEFAULT NULL,
  `X2` varchar(50) DEFAULT NULL,
  `X3` varchar(50) DEFAULT NULL,
  `X4` varchar(50) DEFAULT NULL,
  `X5` varchar(50) DEFAULT NULL,
  `X6` varchar(50) DEFAULT NULL,
  `X7` varchar(50) DEFAULT NULL,
  `sx1` char(1) DEFAULT NULL,
  `sx2` char(1) DEFAULT NULL,
  `sx3` char(1) DEFAULT NULL,
  `sx4` char(1) DEFAULT NULL,
  `sx5` char(1) DEFAULT NULL,
  `sx6` char(1) DEFAULT NULL,
  `sx7` char(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cm_emp_temp`
--

DROP TABLE IF EXISTS `cm_emp_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_emp_temp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Facility` varchar(50) DEFAULT NULL,
  `vendor` varchar(50) DEFAULT NULL,
  `vendor_ID` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `Job_Title` varchar(50) DEFAULT NULL,
  `job_class` varchar(50) DEFAULT NULL,
  `Emp_ID` varchar(50) DEFAULT NULL,
  `Hourly_Rate` varchar(10) DEFAULT '0',
  `HeaderNotes` text,
  `start_date` date DEFAULT NULL,
  `lic_num` varchar(50) DEFAULT NULL,
  `lic_exp_date` date DEFAULT NULL,
  `lic_ExpriationNotifyPriorDays` int(11) DEFAULT NULL,
  `lic_action` varchar(50) DEFAULT NULL,
  `bcls_num` varchar(50) DEFAULT NULL,
  `bcls_date` date DEFAULT NULL,
  `bcls_NPD` int(11) DEFAULT NULL,
  `bcls_action` varchar(50) DEFAULT NULL,
  `acls_num` varchar(50) DEFAULT NULL,
  `acls_date` date DEFAULT NULL,
  `acls_NPD` int(11) DEFAULT NULL,
  `acls_action` varchar(50) DEFAULT NULL,
  `comp_chk_num` varchar(50) DEFAULT NULL,
  `comp_chk_date` date DEFAULT NULL,
  `comp_chk_NPD` int(11) DEFAULT NULL,
  `comp_chk_action` varchar(50) DEFAULT NULL,
  `extra_lic_num` varchar(50) DEFAULT NULL,
  `extra_lic_date` date DEFAULT NULL,
  `extra_lic_NPD` int(11) DEFAULT NULL,
  `extra_lic_action` varchar(50) DEFAULT NULL,
  `extra1_lic_num` varchar(50) DEFAULT NULL,
  `extra1_lic_date` date DEFAULT NULL,
  `extra1_lic_NPD` int(11) DEFAULT NULL,
  `extra1_lic_action` varchar(50) DEFAULT NULL,
  `Background_Check` char(3) DEFAULT NULL,
  `Job_Description` text,
  `Orientation_Packet` char(3) DEFAULT NULL,
  `Unit_Orientation` char(3) DEFAULT NULL,
  `active` char(3) DEFAULT NULL,
  `Blank1` char(3) DEFAULT NULL,
  `Blank2` char(3) DEFAULT NULL,
  `Blank3` char(3) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) DEFAULT NULL,
  `lic_ver_date` date DEFAULT NULL,
  `lic_ver_by` varchar(50) DEFAULT NULL,
  `lic_ver_file` varchar(100) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `ex_email` char(1) DEFAULT NULL,
  `bcls_email` char(1) DEFAULT NULL,
  `acls_email` char(1) DEFAULT NULL,
  `bcls_ver_date` date DEFAULT NULL,
  `bcls_ver_by` varchar(50) DEFAULT NULL,
  `bcls_ver_file` varchar(50) DEFAULT NULL,
  `acls_ver_date` date DEFAULT NULL,
  `acls_ver_by` varchar(50) DEFAULT NULL,
  `acls_ver_file` varchar(50) DEFAULT NULL,
  `comp_ver_date` date DEFAULT NULL,
  `comp_ver_by` varchar(50) DEFAULT NULL,
  `comp_ver_file` varchar(50) DEFAULT NULL,
  `ex_ver_date` date DEFAULT NULL,
  `ex_ver_by` varchar(50) DEFAULT NULL,
  `ex_ver_file` text,
  `ex1_ver_date` date DEFAULT NULL,
  `ex1_ver_by` varchar(50) DEFAULT NULL,
  `ex1_ver_file` text,
  `comp_email` char(1) DEFAULT NULL,
  `extra_email` char(1) DEFAULT NULL,
  `extra1_email` char(1) DEFAULT NULL,
  `job` varchar(50) DEFAULT NULL,
  `ex_ver_type` varchar(5) DEFAULT NULL,
  `fname` varchar(50) DEFAULT NULL,
  `exclude` varchar(50) DEFAULT NULL,
  `extra2_num` varchar(50) DEFAULT NULL,
  `extra2_date` date DEFAULT NULL,
  `extra2_NPD` int(11) DEFAULT NULL,
  `extra2_action` varchar(50) DEFAULT NULL,
  `extra3_num` varchar(50) DEFAULT NULL,
  `extra3_date` date DEFAULT NULL,
  `extra3_NPD` int(11) DEFAULT NULL,
  `extra3_action` varchar(50) DEFAULT NULL,
  `extra4_num` varchar(50) DEFAULT NULL,
  `extra4_date` date DEFAULT NULL,
  `extra4_NPD` int(11) DEFAULT NULL,
  `extra4_action` varchar(50) DEFAULT NULL,
  `extra2_ver_date` date DEFAULT NULL,
  `extra3_ver_date` date DEFAULT NULL,
  `extra4_ver_date` date DEFAULT NULL,
  `ex2_ver_file` text,
  `ex3_ver_file` text,
  `ex4_ver_file` text,
  `ex2_ver_by` varchar(50) DEFAULT NULL,
  `ex3_ver_by` varchar(50) DEFAULT NULL,
  `ex4_ver_by` varchar(50) DEFAULT NULL,
  `ex2_email` varchar(50) DEFAULT NULL,
  `ex3_email` varchar(50) DEFAULT NULL,
  `ex4_email` varchar(50) DEFAULT NULL,
  `oig_bad` char(1) DEFAULT 'N',
  `oig_checked` date DEFAULT NULL,
  `oig_check_on` date DEFAULT NULL,
  `Blank4` varchar(50) DEFAULT 'Blank4',
  `Blank5` varchar(50) DEFAULT 'Blank5',
  `Blank6` varchar(50) DEFAULT 'Blank6',
  `Blank7` varchar(50) DEFAULT 'Blank7',
  `Blank8` varchar(50) DEFAULT 'Blank8',
  `Blank9` varchar(50) DEFAULT 'Blank9',
  `Blank10` varchar(50) DEFAULT 'Blank10',
  `Blank11` varchar(50) DEFAULT 'Blank11',
  `Blank12` varchar(50) DEFAULT 'Blank12',
  `rp_email` varchar(50) DEFAULT NULL,
  `rp_email2` varchar(50) DEFAULT NULL,
  `rp_email3` varchar(50) DEFAULT NULL,
  `x1` text,
  `x2` text,
  `x3` text,
  `x4` text,
  `x5` text,
  `x6` text,
  `x7` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5647 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cm_lic_url`
--

DROP TABLE IF EXISTS `cm_lic_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_lic_url` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Job` varchar(50) DEFAULT NULL,
  `ver_Url` varchar(200) DEFAULT NULL,
  `view_url` varchar(200) DEFAULT NULL,
  `code1` varchar(50) DEFAULT NULL,
  `code2` varchar(50) DEFAULT NULL,
  `code_name1` varchar(50) DEFAULT NULL,
  `code_name2` varchar(50) DEFAULT NULL,
  `tested` char(1) DEFAULT 'N',
  `ver_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cm_papertrail`
--

DROP TABLE IF EXISTS `cm_papertrail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_papertrail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `contract_ID` int(11) DEFAULT NULL,
  `event` text,
  `event_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1074 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cm_papertrail_emp`
--

DROP TABLE IF EXISTS `cm_papertrail_emp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_papertrail_emp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `contract_ID` int(11) DEFAULT NULL,
  `event` text,
  `event_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5495 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `cm_url`
--

DROP TABLE IF EXISTS `cm_url`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cm_url` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `URL` varchar(100) DEFAULT NULL,
  `description` text,
  `sort_order` int(11) DEFAULT '100',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `conractcategory`
--

DROP TABLE IF EXISTS `conractcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conractcategory` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ConractCategory_ID` varchar(50) DEFAULT NULL,
  `ConractCategory` varchar(100) DEFAULT NULL,
  `EffectiveDate` date DEFAULT NULL,
  `Client_ID` int(11) DEFAULT NULL,
  `contract_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_cdm_ex`
--

DROP TABLE IF EXISTS `contract_cdm_ex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_cdm_ex` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(50) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `Valuation` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  `paid_at` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=73 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_cpt_ex`
--

DROP TABLE IF EXISTS `contract_cpt_ex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_cpt_ex` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(50) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `Valuation` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  `paid_at` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6857 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_drg`
--

DROP TABLE IF EXISTS `contract_drg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_drg` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `days_TH` varchar(50) DEFAULT NULL,
  `rate_after_TH` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7146 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_drg_m`
--

DROP TABLE IF EXISTS `contract_drg_m`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_drg_m` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `DRG_Multiplier` double(13,5) DEFAULT NULL,
  `DRG_weight` double(13,5) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` double(13,5) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `days_TH` varchar(50) DEFAULT NULL,
  `rate_after_TH` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=29268 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_icd9`
--

DROP TABLE IF EXISTS `contract_icd9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_icd9` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `days_TH` varchar(50) DEFAULT NULL,
  `rate_after_TH` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=26739 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_icd_ex`
--

DROP TABLE IF EXISTS `contract_icd_ex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_icd_ex` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `Valuation` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  `paid_at` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3243 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_ins_codes`
--

DROP TABLE IF EXISTS `contract_ins_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_ins_codes` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `INS_Code` varchar(50) DEFAULT NULL,
  `Code_Desc` varchar(254) DEFAULT NULL,
  `corp_ID` bigint(20) DEFAULT '0',
  `Facility_code` bigint(20) DEFAULT '0',
  `Contract_ID` bigint(20) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `Code_Desc` (`Code_Desc`),
  KEY `Contract_ID` (`Contract_ID`),
  KEY `corp_ID` (`corp_ID`),
  KEY `Facility_code` (`Facility_code`),
  KEY `INS_Code` (`INS_Code`)
) ENGINE=MyISAM AUTO_INCREMENT=1135 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_log`
--

DROP TABLE IF EXISTS `contract_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `facility` varchar(50) DEFAULT NULL,
  `corp` varchar(50) DEFAULT NULL,
  `corp_ID` bigint(20) DEFAULT '0',
  `log_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(10) DEFAULT NULL,
  `IP` varchar(50) DEFAULT NULL,
  `Contract_name` varchar(50) DEFAULT NULL,
  `contract_ID` bigint(20) DEFAULT '0',
  `fac_ID` bigint(20) DEFAULT '0',
  `action` varchar(50) DEFAULT NULL,
  `AC` varchar(4) DEFAULT NULL,
  `User_ID` bigint(20) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `contract_ID` (`contract_ID`),
  KEY `corp_ID` (`corp_ID`),
  KEY `fac_ID` (`fac_ID`),
  KEY `User_ID` (`User_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=81779 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_op_cpt`
--

DROP TABLE IF EXISTS `contract_op_cpt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_op_cpt` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(50) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `days_TH` varchar(50) DEFAULT NULL,
  `rate_after_TH` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1295557 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_op_icd`
--

DROP TABLE IF EXISTS `contract_op_icd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_op_icd` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `days_TH` varchar(50) DEFAULT NULL,
  `rate_after_TH` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1897 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_op_services`
--

DROP TABLE IF EXISTS `contract_op_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_op_services` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(50) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=491 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_op_surgrate`
--

DROP TABLE IF EXISTS `contract_op_surgrate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_op_surgrate` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(7) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` text,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  `APC` varchar(50) DEFAULT NULL,
  `Mod1` varchar(50) DEFAULT NULL,
  `SI` varchar(50) DEFAULT NULL,
  `CI` varchar(50) DEFAULT NULL,
  `Base_Rt` double(13,5) DEFAULT NULL,
  `RW1` double(13,5) DEFAULT NULL,
  `RW2` double(13,5) DEFAULT NULL,
  `Mult1` double(13,5) DEFAULT NULL,
  `Mult2` double(13,5) DEFAULT NULL,
  `Co_Pay` double(13,5) DEFAULT NULL,
  `Pmt_Rt` double(13,5) DEFAULT NULL,
  `Blank1` varchar(50) DEFAULT NULL,
  `Blank2` double(13,5) DEFAULT NULL,
  `SI_description` text,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=552934 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_op_ub`
--

DROP TABLE IF EXISTS `contract_op_ub`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_op_ub` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `days_TH` varchar(50) DEFAULT NULL,
  `rate_after_TH` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=53347 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_perdiem`
--

DROP TABLE IF EXISTS `contract_perdiem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_perdiem` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(50) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `per_diem` text,
  `days_TH` varchar(50) DEFAULT NULL,
  `rate_after_TH` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6774 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_perdiem_drg`
--

DROP TABLE IF EXISTS `contract_perdiem_drg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_perdiem_drg` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `per_diem` text,
  `days_TH` varchar(50) DEFAULT NULL,
  `rate_after_TH` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  `Rate_used` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1555 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_stoploss`
--

DROP TABLE IF EXISTS `contract_stoploss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_stoploss` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `contract_ID` bigint(20) DEFAULT '0',
  `Stopgain_threshold` varchar(50) DEFAULT NULL,
  `Stopgain_percent` varchar(50) DEFAULT NULL,
  `Stopgain_notes` text,
  `Stoploss1_Type` varchar(50) DEFAULT NULL,
  `Stoploss1_Threshold` varchar(50) DEFAULT NULL,
  `Stoploss1_Percent` varchar(50) DEFAULT NULL,
  `Stoploss1_NTE` varchar(20) DEFAULT NULL,
  `NTE_Caserate1` varchar(50) DEFAULT NULL,
  `NTE_Per_Day1` varchar(50) DEFAULT NULL,
  `S_Multiplier1` varchar(50) DEFAULT NULL,
  `S_Reins_Percent1` varchar(50) DEFAULT NULL,
  `Exclusions1` varchar(3) DEFAULT NULL,
  `continious1` varchar(3) DEFAULT NULL,
  `Stoploss1_Notes` text,
  `Stoploss2_Type` varchar(50) DEFAULT NULL,
  `Stoploss2_Threshold` varchar(50) DEFAULT NULL,
  `Stoploss2_Percent` varchar(50) DEFAULT NULL,
  `Stoploss2_NTE` varchar(50) DEFAULT NULL,
  `NTE_Caserate2` varchar(50) DEFAULT NULL,
  `NTE_Per_Day2` varchar(50) DEFAULT NULL,
  `S_Multiplier2` varchar(50) DEFAULT NULL,
  `S_Reins_Percent2` varchar(50) DEFAULT NULL,
  `Exclusions2` varchar(50) DEFAULT NULL,
  `continious2` varchar(50) DEFAULT NULL,
  `Stoploss2_Notes` text,
  `Stoploss3_Type` varchar(50) DEFAULT NULL,
  `Stoploss3_Threshold` varchar(50) DEFAULT NULL,
  `Stoploss3_Percent` varchar(50) DEFAULT NULL,
  `Stoploss3_NTE` varchar(50) DEFAULT NULL,
  `NTE_Caserate3` varchar(50) DEFAULT NULL,
  `NTE_Per_Day3` varchar(50) DEFAULT NULL,
  `S_Multiplier3` varchar(50) DEFAULT NULL,
  `S_Reins_Percent3` varchar(50) DEFAULT NULL,
  `Exclusions3` varchar(50) DEFAULT NULL,
  `continious3` varchar(50) DEFAULT NULL,
  `Stoploss3_Notes` text,
  `NTE_Type` varchar(50) DEFAULT NULL,
  `NTE_Type2` varchar(50) DEFAULT NULL,
  `NTE_Type3` varchar(50) DEFAULT NULL,
  `threshold_criteria` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `contract_ID` (`contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=799 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_type`
--

DROP TABLE IF EXISTS `contract_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `login_ID` int(11) DEFAULT NULL,
  `contract_type` varchar(100) DEFAULT NULL,
  `member_ID` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1309 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_ub_codes`
--

DROP TABLE IF EXISTS `contract_ub_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_ub_codes` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `L_care` varchar(100) DEFAULT NULL,
  `L_rate` double(13,5) DEFAULT NULL,
  `rev_code` text,
  `notes` text,
  `contract_ID` bigint(20) DEFAULT '0',
  `d_in_contract` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `contract_ID` (`contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=4360 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_ub_ex`
--

DROP TABLE IF EXISTS `contract_ub_ex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_ub_ex` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `Valuation` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  `paid_at` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5574 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contract_ub_rev`
--

DROP TABLE IF EXISTS `contract_ub_rev`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contract_ub_rev` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `xgroup` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `caserate_percent` varchar(50) DEFAULT NULL,
  `days_TH` varchar(50) DEFAULT NULL,
  `rate_after_TH` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `Notes` text,
  `added_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1352 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contracts`
--

DROP TABLE IF EXISTS `contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contracts` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Corp_name` varchar(100) DEFAULT NULL,
  `Corp_ID` bigint(20) DEFAULT '0',
  `Fac_Name` varchar(100) DEFAULT NULL,
  `Fac_ID` bigint(20) DEFAULT '0',
  `Product` varchar(100) DEFAULT NULL,
  `contract_plan` varchar(100) DEFAULT NULL,
  `R_type` varchar(50) DEFAULT NULL,
  `R_percent` varchar(50) DEFAULT NULL,
  `R_notes` text,
  `header_notes` text,
  `INS_code` varchar(100) DEFAULT NULL,
  `Contract_status` varchar(50) DEFAULT '"In_Progress"',
  `User` varchar(50) DEFAULT NULL,
  `updated` varchar(50) DEFAULT NULL,
  `start_date` varchar(50) DEFAULT NULL,
  `end_date` varchar(50) DEFAULT NULL,
  `DRG` bigint(20) DEFAULT '0',
  `ICD9` bigint(20) DEFAULT '0',
  `UBrev` bigint(20) DEFAULT '0',
  `DRG_M` bigint(20) DEFAULT '0',
  `per_diam` bigint(20) DEFAULT '0',
  `ICD9_ex` bigint(20) DEFAULT '0',
  `UB_ex` bigint(20) DEFAULT '0',
  `CDM_ex` bigint(20) DEFAULT '0',
  `OP_S` bigint(20) DEFAULT '0',
  `OP_surg` bigint(20) DEFAULT '0',
  `OP_UB` bigint(20) DEFAULT '0',
  `OP_ICD` bigint(20) DEFAULT '0',
  `contract` varchar(100) DEFAULT NULL,
  `renew_type` varchar(50) DEFAULT NULL,
  `expire_date` varchar(50) DEFAULT NULL,
  `perdiem_drg` bigint(20) DEFAULT '0',
  `OP_CPT` bigint(20) DEFAULT '0',
  `image` varchar(50) DEFAULT NULL,
  `perdiam2` bigint(20) DEFAULT '0',
  `CPT_ex` bigint(20) DEFAULT '0',
  `ConractCategory_ID` varchar(50) DEFAULT NULL,
  `ConractCategory` varchar(50) DEFAULT NULL,
  `EffectiveDate` varchar(50) DEFAULT NULL,
  `CredentialDate` varchar(50) DEFAULT NULL,
  `IPA` char(1) DEFAULT 'N',
  `msql_date` date DEFAULT NULL,
  `e_date` date DEFAULT NULL,
  `smonth` int(11) DEFAULT NULL,
  `R_percent2` varchar(50) DEFAULT NULL,
  `R_notes2` text,
  `case_rates` char(1) DEFAULT 'N',
  `exclusions` char(1) DEFAULT 'N',
  `inpatient` char(1) DEFAULT 'N',
  `outpatient` char(1) DEFAULT 'N',
  PRIMARY KEY (`ID`),
  KEY `Corp_ID` (`Corp_ID`),
  KEY `Fac_ID` (`Fac_ID`),
  KEY `INS_code` (`INS_code`)
) ENGINE=MyISAM AUTO_INCREMENT=880 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contractstatus_contract`
--

DROP TABLE IF EXISTS `contractstatus_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractstatus_contract` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ContractStatus` varchar(50) DEFAULT NULL,
  `client_ID` int(11) DEFAULT NULL,
  `contract_ID` int(11) DEFAULT NULL,
  `use_it` char(1) DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `contractstatus_member`
--

DROP TABLE IF EXISTS `contractstatus_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contractstatus_member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ContractStatus` varchar(50) DEFAULT NULL,
  `Client_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `credentialdate`
--

DROP TABLE IF EXISTS `credentialdate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `credentialdate` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `CredentialDate` varchar(50) DEFAULT NULL,
  `client_ID` double(13,5) DEFAULT NULL,
  `contract_ID` int(11) DEFAULT NULL,
  `use_it` char(1) DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `date_checked`
--

DROP TABLE IF EXISTS `date_checked`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `date_checked` (
  `date_checked` date DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `demo`
--

DROP TABLE IF EXISTS `demo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `demo` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `F_name` varchar(50) DEFAULT NULL,
  `L_name` varchar(50) DEFAULT NULL,
  `Title` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `the_state` varchar(50) DEFAULT NULL,
  `Demo_req` varchar(50) DEFAULT NULL,
  `comments` text,
  `status` varchar(50) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `comments2` text,
  `company` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1191 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_level`
--

DROP TABLE IF EXISTS `doc_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doc_level` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Fac_name` varchar(100) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `Fac_ID` int(11) DEFAULT NULL,
  `sort_order` varchar(50) DEFAULT NULL,
  `doc_level` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=50 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `doc_link`
--

DROP TABLE IF EXISTS `doc_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doc_link` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Level_ID` int(11) DEFAULT NULL,
  `Description` text,
  `file_name` varchar(254) DEFAULT NULL,
  `link_or` varchar(50) DEFAULT NULL,
  `URL_text` varchar(254) DEFAULT NULL,
  `URL` varchar(100) DEFAULT NULL,
  `Sort_order` int(11) DEFAULT NULL,
  `open_with` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=309 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emp_file`
--

DROP TABLE IF EXISTS `emp_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emp_file` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `emp_ID` int(11) DEFAULT NULL,
  `emp_name` varchar(70) DEFAULT NULL,
  `description` text,
  `file_type` varchar(50) DEFAULT NULL,
  `file_name` varchar(200) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `vendor_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=533 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `emp_ver_file`
--

DROP TABLE IF EXISTS `emp_ver_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `emp_ver_file` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `emp_ID` int(11) DEFAULT NULL,
  `name` varchar(254) DEFAULT NULL,
  `Licence_type` varchar(50) DEFAULT NULL,
  `ver_URL` varchar(50) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Lic_num` varchar(50) DEFAULT NULL,
  `ver_file` varchar(50) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `notes` text,
  `show_it` char(1) DEFAULT 'N',
  `html_txt` text,
  `status` varchar(50) DEFAULT NULL,
  `loc_is` varchar(50) DEFAULT NULL,
  `lic_ex` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `trans_type` varchar(50) DEFAULT 'man',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7008 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ex_contracts`
--

DROP TABLE IF EXISTS `ex_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ex_contracts` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Contract_ID` bigint(20) DEFAULT '0',
  `PDF` varchar(50) DEFAULT NULL,
  `description` text,
  `Corp_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Contract_ID` (`Contract_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1755 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exclusions`
--

DROP TABLE IF EXISTS `exclusions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exclusions` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=148 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `exclusions_cpt`
--

DROP TABLE IF EXISTS `exclusions_cpt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exclusions_cpt` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `facility`
--

DROP TABLE IF EXISTS `facility`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facility` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `corp_ID` bigint(20) DEFAULT '0',
  `Corp_name` varchar(50) DEFAULT NULL,
  `Facility` varchar(50) DEFAULT NULL,
  `Login` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `thestate` varchar(50) DEFAULT NULL,
  `zipcode` varchar(50) DEFAULT NULL,
  `F_contact` varchar(50) DEFAULT NULL,
  `f_contact_title` varchar(50) DEFAULT NULL,
  `c_contact_phone_area` varchar(50) DEFAULT NULL,
  `c_contact_phone_prefix` varchar(50) DEFAULT NULL,
  `c_contact_phone_num` varchar(50) DEFAULT NULL,
  `c_contact_phone_ext` varchar(50) DEFAULT NULL,
  `c_contact_fax_area` varchar(50) DEFAULT NULL,
  `c_contact_fax_prefix` varchar(50) DEFAULT NULL,
  `c_contact_fax_num` varchar(50) DEFAULT NULL,
  `c_contact_cell_area` varchar(50) DEFAULT NULL,
  `c_contact_cell_prefix` varchar(50) DEFAULT NULL,
  `c_contact_cell_num` varchar(50) DEFAULT NULL,
  `f_contact_email` varchar(100) DEFAULT NULL,
  `IT_contact` varchar(50) DEFAULT NULL,
  `IT_contact_title` varchar(50) DEFAULT NULL,
  `IT_contact_phone_area` varchar(50) DEFAULT NULL,
  `IT_contact_phone_prefix` varchar(50) DEFAULT NULL,
  `IT_contact_phone_num` varchar(50) DEFAULT NULL,
  `IT_contact_phone_ext` varchar(50) DEFAULT NULL,
  `IT_contact_fax_area` varchar(50) DEFAULT NULL,
  `IT_contact_fax_prefix` varchar(50) DEFAULT NULL,
  `IT_contact_fax_num` varchar(50) DEFAULT NULL,
  `IT_contact_cell_area` varchar(50) DEFAULT NULL,
  `IT_contact_cell_prefix` varchar(50) DEFAULT NULL,
  `IT_contact_cell_num` varchar(50) DEFAULT NULL,
  `IT_contact_email` varchar(50) DEFAULT NULL,
  `M_contact` varchar(50) DEFAULT NULL,
  `M_contact_title` varchar(50) DEFAULT NULL,
  `M_contact_phone_area` varchar(50) DEFAULT NULL,
  `M_contact_phone_prefix` varchar(50) DEFAULT NULL,
  `M_contact_phone_num` varchar(50) DEFAULT NULL,
  `M_contact_phone_ext` varchar(50) DEFAULT NULL,
  `M_contact_fax_area` varchar(50) DEFAULT NULL,
  `M_contact_fax_prefix` varchar(50) DEFAULT NULL,
  `M_contact_fax_num` varchar(50) DEFAULT NULL,
  `M_contact_cell_area` varchar(50) DEFAULT NULL,
  `M_contact_cell_prefix` varchar(50) DEFAULT NULL,
  `M_contact_cell_num` varchar(50) DEFAULT NULL,
  `M_contact_email` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `c_contact_cell_num` (`IT_contact_cell_num`),
  KEY `c_contact_cell_num1` (`M_contact_cell_num`),
  KEY `c_contact_fax_num` (`IT_contact_fax_num`),
  KEY `c_contact_fax_num1` (`M_contact_fax_num`),
  KEY `c_contact_phone_num` (`IT_contact_phone_num`),
  KEY `c_contact_phone_num1` (`M_contact_phone_num`),
  KEY `corp_ID` (`corp_ID`),
  KEY `zipcode` (`zipcode`)
) ENGINE=MyISAM AUTO_INCREMENT=178 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fee_crosswalk`
--

DROP TABLE IF EXISTS `fee_crosswalk`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fee_crosswalk` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Contract_ID` int(11) DEFAULT NULL,
  `Plan_ID` int(11) DEFAULT NULL,
  `FeeSchd_ID` varchar(50) DEFAULT NULL,
  `Description` varchar(100) DEFAULT NULL,
  `fee_multi` double(13,5) DEFAULT NULL,
  `Plan` varchar(100) DEFAULT NULL,
  `Product` varchar(100) DEFAULT NULL,
  `CPT` varchar(10) DEFAULT NULL,
  `use_it` char(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=209 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fee_descript`
--

DROP TABLE IF EXISTS `fee_descript`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fee_descript` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Description` varchar(254) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `feeschedules`
--

DROP TABLE IF EXISTS `feeschedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feeschedules` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CPT` varchar(5) DEFAULT NULL,
  `CPT_grouping` varchar(50) DEFAULT NULL,
  `CPT_Desc` varchar(254) DEFAULT NULL,
  `CPT_grouping2` varchar(50) DEFAULT NULL,
  `Notes` text,
  `APC` varchar(50) DEFAULT NULL,
  `Mod1` varchar(50) DEFAULT NULL,
  `SI` varchar(50) DEFAULT NULL,
  `CI` varchar(50) DEFAULT NULL,
  `Base_Rt` double(13,5) DEFAULT NULL,
  `RW1` double(13,5) DEFAULT NULL,
  `RW2` double(13,5) DEFAULT NULL,
  `Mult1` double(13,5) DEFAULT NULL,
  `Mult2` double(13,5) DEFAULT NULL,
  `Co_Pay` double(13,5) DEFAULT NULL,
  `Pmt_Rt` double(13,5) DEFAULT NULL,
  `Blank1` varchar(50) DEFAULT NULL,
  `Blank2` double(13,5) DEFAULT NULL,
  `SI_description` text,
  `Effective_Date` varchar(50) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `Locality` varchar(255) DEFAULT NULL,
  `Limiting_Charge` double(13,5) DEFAULT NULL,
  `FC_Mod_Amt` double(13,5) DEFAULT NULL,
  `FB_Mod_Amt` double(13,5) DEFAULT NULL,
  `Schedule_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=126012 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `fs_labels`
--

DROP TABLE IF EXISTS `fs_labels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `fs_labels` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Client_ID` int(11) DEFAULT NULL,
  `Schedule_ID` int(11) DEFAULT NULL,
  `FS_name` varchar(100) DEFAULT NULL,
  `CPT` varchar(50) DEFAULT NULL,
  `CPT_grouping` varchar(50) DEFAULT NULL,
  `CPT_Desc` varchar(50) DEFAULT NULL,
  `CPT_grouping2` varchar(50) DEFAULT NULL,
  `Notes` varchar(50) DEFAULT NULL,
  `APC` varchar(50) DEFAULT NULL,
  `Mod1` varchar(50) DEFAULT NULL,
  `SI` varchar(50) DEFAULT NULL,
  `CI` varchar(50) DEFAULT NULL,
  `Base_Rt` varchar(50) DEFAULT NULL,
  `Co_Pay` varchar(50) DEFAULT NULL,
  `RW1` varchar(50) DEFAULT NULL,
  `RW2` varchar(50) DEFAULT NULL,
  `Mult1` varchar(50) DEFAULT NULL,
  `Mult2` varchar(50) DEFAULT NULL,
  `Pmt_Rt` varchar(50) DEFAULT NULL,
  `SI_description` varchar(50) DEFAULT NULL,
  `Blank1` varchar(50) DEFAULT NULL,
  `Blank2` varchar(50) DEFAULT NULL,
  `Effective_Date` varchar(50) DEFAULT NULL,
  `Locality` varchar(50) DEFAULT NULL,
  `Limiting_Charge` varchar(50) DEFAULT NULL,
  `FC_Mod_Amt` varchar(50) DEFAULT NULL,
  `FB_Mod_Amt` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=185 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `hrbinderoneupload`
--

DROP TABLE IF EXISTS `hrbinderoneupload`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hrbinderoneupload` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `fName` varchar(255) DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `X2` varchar(255) DEFAULT NULL,
  `Job_Title` varchar(255) DEFAULT NULL,
  `Start_Date` varchar(255) DEFAULT NULL,
  `Active` varchar(255) DEFAULT NULL,
  `X3` varchar(255) DEFAULT NULL,
  `comp_chk_date` varchar(255) DEFAULT NULL,
  `Hourly_Rate` varchar(255) DEFAULT NULL,
  `License_num` varchar(255) DEFAULT NULL,
  `lic_exp_date` varchar(255) DEFAULT NULL,
  `Vendor` varchar(255) DEFAULT NULL,
  `X1` varchar(255) DEFAULT NULL,
  `X7` varchar(255) DEFAULT NULL,
  `ACLS_num` varchar(255) DEFAULT NULL,
  `ACLS_Date` varchar(255) DEFAULT NULL,
  `BCLS_num` varchar(255) DEFAULT NULL,
  `BCLS_Date` varchar(255) DEFAULT NULL,
  `X4` varchar(255) DEFAULT NULL,
  `X5` varchar(255) DEFAULT NULL,
  `Unit_Orientation` varchar(255) DEFAULT NULL,
  `Extra_Lic_num` varchar(255) DEFAULT NULL,
  `Extra_lic_Date` varchar(255) DEFAULT NULL,
  `Extra3_num` varchar(255) DEFAULT NULL,
  `Extra3_Date` varchar(255) DEFAULT NULL,
  `Extra2_num` varchar(255) DEFAULT NULL,
  `Extra2_Date` varchar(255) DEFAULT NULL,
  `Extra4_num` varchar(255) DEFAULT NULL,
  `Extra4_Date` varchar(255) DEFAULT NULL,
  `Blank8` varchar(255) DEFAULT NULL,
  `Blank9` varchar(255) DEFAULT NULL,
  `Background_Check` varchar(255) DEFAULT NULL,
  `Blank5` varchar(255) DEFAULT NULL,
  `Blank10` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=458 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `icd9`
--

DROP TABLE IF EXISTS `icd9`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `icd9` (
  `CaseRate_ID` int(11) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(255) DEFAULT NULL,
  `DRG_Desc` varchar(50) DEFAULT NULL,
  `Menu1` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `DRG_Weight` double(13,5) DEFAULT NULL,
  KEY `CaseRate_ID` (`CaseRate_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ins_codes`
--

DROP TABLE IF EXISTS `ins_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ins_codes` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `INS_Code` varchar(50) DEFAULT NULL,
  `Code_Desc` varchar(254) DEFAULT NULL,
  `corp_ID` bigint(20) DEFAULT '0',
  `Facility_code` bigint(20) DEFAULT '0',
  `Reimb_type` varchar(50) DEFAULT NULL,
  `Reimb_percent` varchar(50) DEFAULT NULL,
  `Reimb_notes` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `Code_Desc` (`Code_Desc`),
  KEY `corp_ID` (`corp_ID`),
  KEY `Facility_code` (`Facility_code`),
  KEY `INS_Code` (`INS_Code`)
) ENGINE=MyISAM AUTO_INCREMENT=99 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `label_list`
--

DROP TABLE IF EXISTS `label_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `label_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Client_ID` int(11) DEFAULT NULL,
  `Fac_ID` int(11) DEFAULT NULL,
  `ProviderGroupID` varchar(50) DEFAULT NULL,
  `CredentialDate` varchar(50) DEFAULT NULL,
  `TypeOfProvider` varchar(50) DEFAULT NULL,
  `ContractStatus` varchar(50) DEFAULT NULL,
  `PrimaryNetwork` varchar(50) DEFAULT NULL,
  `OtherNetwork` varchar(50) DEFAULT NULL,
  `ConractCategory` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `lic_verify`
--

DROP TABLE IF EXISTS `lic_verify`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lic_verify` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `emp_ID` int(11) DEFAULT NULL,
  `html_text` text,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(50) DEFAULT NULL,
  `lic_type` varchar(50) DEFAULT NULL,
  `lic_num` varchar(50) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `log_module`
--

DROP TABLE IF EXISTS `log_module`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log_module` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `corp` varchar(50) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `facility` varchar(50) DEFAULT NULL,
  `fac_ID` int(11) DEFAULT NULL,
  `name` varchar(50) DEFAULT NULL,
  `module` varchar(50) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `IP` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=61662 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `login_date`
--

DROP TABLE IF EXISTS `login_date`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_date` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `logIN_date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=790 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `login_dept`
--

DROP TABLE IF EXISTS `login_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_dept` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `member_ID` int(11) DEFAULT NULL,
  `Login_ID` int(11) DEFAULT NULL,
  `Department` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2009 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `login_facs`
--

DROP TABLE IF EXISTS `login_facs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_facs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `login_id` int(11) DEFAULT NULL,
  `facility` varchar(100) DEFAULT NULL,
  `fac_ID` int(11) DEFAULT NULL,
  `corp` varchar(100) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5592 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `login_log`
--

DROP TABLE IF EXISTS `login_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `facility` varchar(50) DEFAULT NULL,
  `corp` varchar(50) DEFAULT NULL,
  `corp_ID` bigint(20) DEFAULT '0',
  `log_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `status` varchar(10) DEFAULT NULL,
  `IP` varchar(50) DEFAULT NULL,
  `fac_ID` bigint(20) DEFAULT '0',
  `login_type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `corp_ID` (`corp_ID`),
  KEY `fac_ID` (`fac_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=67155 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `logins`
--

DROP TABLE IF EXISTS `logins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logins` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Name` varchar(50) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `login_class` varchar(50) DEFAULT NULL,
  `Facility` varchar(50) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `corp` varchar(50) DEFAULT NULL,
  `access_level` varchar(50) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT '0',
  `fac_ID` int(11) DEFAULT '0',
  `A_level` varchar(50) DEFAULT NULL,
  `account_type` varchar(50) DEFAULT NULL,
  `care_type` varchar(10) DEFAULT 'MC',
  `admin` char(1) DEFAULT NULL,
  `cm` char(1) DEFAULT 'N',
  `view_all` char(1) DEFAULT 'N',
  `logins` int(11) DEFAULT '0',
  `cm_logins` int(11) DEFAULT '0',
  `nmc_logins` int(11) DEFAULT '0',
  `c_logins` int(11) DEFAULT '0',
  `del_ver` char(1) DEFAULT 'N',
  `oig` char(1) DEFAULT 'N',
  `bad_logins` int(11) DEFAULT '0',
  `login_after` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `total_bad_logins` int(11) DEFAULT '0',
  `login_after1` datetime DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `corp_ID` (`corp_ID`),
  KEY `fac_ID` (`fac_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1463 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `member_dept`
--

DROP TABLE IF EXISTS `member_dept`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member_dept` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `member_ID` int(11) DEFAULT NULL,
  `department` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=133 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `corp_name` varchar(100) DEFAULT NULL,
  `Attention` varchar(50) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `thestate` varchar(50) DEFAULT NULL,
  `zipcode` varchar(50) DEFAULT NULL,
  `b_address` varchar(100) DEFAULT NULL,
  `b_city` varchar(50) DEFAULT NULL,
  `b_state` varchar(50) DEFAULT NULL,
  `b_zipcode` varchar(50) DEFAULT NULL,
  `bill_same` varchar(1) DEFAULT 'N',
  `c_contact` varchar(50) DEFAULT NULL,
  `c_contact_title` varchar(50) DEFAULT NULL,
  `c_contact_phone_area` varchar(50) DEFAULT NULL,
  `c_contact_phone_prefix` varchar(50) DEFAULT NULL,
  `c_contact_phone_num` varchar(50) DEFAULT NULL,
  `c_contact_phone_ext` varchar(50) DEFAULT NULL,
  `c_contact_fax_area` varchar(50) DEFAULT NULL,
  `c_contact_fax_prefix` varchar(50) DEFAULT NULL,
  `c_contact_fax_num` varchar(50) DEFAULT NULL,
  `c_contact_cell_area` varchar(50) DEFAULT NULL,
  `c_contact_cell_prefix` varchar(50) DEFAULT NULL,
  `c_contact_cell_num` varchar(50) DEFAULT NULL,
  `c_contact_email` varchar(50) DEFAULT NULL,
  `Contract_type` varchar(50) DEFAULT NULL,
  `start_date` varchar(50) DEFAULT NULL,
  `end_date` varchar(50) DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `fee_rate` double(13,5) DEFAULT NULL,
  `Account_status` varchar(50) DEFAULT NULL,
  `Account_notes` text,
  `IT_contact` varchar(50) DEFAULT NULL,
  `IT_contact_title` varchar(50) DEFAULT NULL,
  `IT_contact_phone_area` varchar(50) DEFAULT NULL,
  `IT_contact_phone_prefix` varchar(50) DEFAULT NULL,
  `IT_contact_phone_num` varchar(50) DEFAULT NULL,
  `IT_contact_phone_ext` varchar(50) DEFAULT NULL,
  `IT_contact_fax_area` varchar(50) DEFAULT NULL,
  `IT_contact_fax_prefix` varchar(50) DEFAULT NULL,
  `IT_contact_fax_num` varchar(50) DEFAULT NULL,
  `IT_contact_cell_area` varchar(50) DEFAULT NULL,
  `IT_contact_cell_prefix` varchar(50) DEFAULT NULL,
  `IT_contact_cell_num` varchar(50) DEFAULT NULL,
  `IT_contact_email` varchar(50) DEFAULT NULL,
  `M_contact` varchar(50) DEFAULT NULL,
  `M_contact_title` varchar(50) DEFAULT NULL,
  `M_contact_phone_area` varchar(50) DEFAULT NULL,
  `M_contact_phone_prefix` varchar(50) DEFAULT NULL,
  `M_contact_phone_num` varchar(50) DEFAULT NULL,
  `M_contact_phone_ext` varchar(50) DEFAULT NULL,
  `M_contact_fax_area` varchar(50) DEFAULT NULL,
  `M_contact_fax_prefix` varchar(50) DEFAULT NULL,
  `M_contact_fax_num` varchar(50) DEFAULT NULL,
  `M_contact_cell_area` varchar(50) DEFAULT NULL,
  `M_contact_cell_prefix` varchar(50) DEFAULT NULL,
  `M_contact_cell_num` varchar(50) DEFAULT NULL,
  `M_contact_email` varchar(50) DEFAULT NULL,
  `image` varchar(50) DEFAULT NULL,
  `Account_type` varchar(50) DEFAULT NULL,
  `care_type` varchar(50) DEFAULT NULL,
  `cm` char(1) DEFAULT 'N',
  `oig` char(1) DEFAULT 'N',
  `oig_duration` int(11) DEFAULT '365',
  `logins` int(11) DEFAULT '0',
  `cm_logins` int(11) DEFAULT '0',
  `nmc_logins` int(11) DEFAULT '0',
  `c_logins` int(11) DEFAULT '0',
  `ipa_logins` int(11) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `b_zipcode` (`b_zipcode`),
  KEY `c_contact_cell_num` (`IT_contact_cell_num`),
  KEY `c_contact_fax_num` (`IT_contact_fax_num`),
  KEY `c_contact_phone_num` (`IT_contact_phone_num`),
  KEY `IT_contact_cell_num` (`M_contact_cell_num`),
  KEY `IT_contact_fax_num` (`M_contact_fax_num`),
  KEY `IT_contact_phone_num` (`M_contact_phone_num`),
  KEY `zipcode` (`zipcode`)
) ENGINE=MyISAM AUTO_INCREMENT=58 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `members_fs`
--

DROP TABLE IF EXISTS `members_fs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `members_fs` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Fee_schedule` varchar(100) DEFAULT NULL,
  `Client_ID` int(11) DEFAULT NULL,
  `Schule_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nmc_eval`
--

DROP TABLE IF EXISTS `nmc_eval`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nmc_eval` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `contract_ID` int(11) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `start_date` varchar(50) DEFAULT NULL,
  `Satisfactory` varchar(3) DEFAULT NULL,
  `Comments` text,
  `Recommendation` varchar(50) DEFAULT NULL,
  `F1` varchar(50) DEFAULT NULL,
  `F2` varchar(50) DEFAULT NULL,
  `F3` varchar(50) DEFAULT NULL,
  `F4` varchar(50) DEFAULT NULL,
  `F5` varchar(50) DEFAULT NULL,
  `F6` varchar(50) DEFAULT NULL,
  `F7` varchar(50) DEFAULT NULL,
  `F8` varchar(50) DEFAULT NULL,
  `F9` varchar(50) DEFAULT NULL,
  `F10` varchar(50) DEFAULT NULL,
  `F11` varchar(50) DEFAULT NULL,
  `F12` varchar(50) DEFAULT NULL,
  `F13` varchar(50) DEFAULT NULL,
  `F14` varchar(50) DEFAULT NULL,
  `F15` varchar(50) DEFAULT NULL,
  `F16` varchar(50) DEFAULT NULL,
  `F17` varchar(50) DEFAULT NULL,
  `F18` varchar(50) DEFAULT NULL,
  `F19` varchar(50) DEFAULT NULL,
  `F20` varchar(50) DEFAULT NULL,
  `F21` varchar(50) DEFAULT NULL,
  `F22` varchar(50) DEFAULT NULL,
  `F23` varchar(50) DEFAULT NULL,
  `F24` varchar(50) DEFAULT NULL,
  `F25` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=114 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nmc_eval_setup`
--

DROP TABLE IF EXISTS `nmc_eval_setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nmc_eval_setup` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `corp_ID` int(11) DEFAULT NULL,
  `updated_by` varchar(50) DEFAULT NULL,
  `updated` varchar(50) DEFAULT NULL,
  `start_date` varchar(50) DEFAULT NULL,
  `Satisfactory` varchar(50) DEFAULT NULL,
  `Comments` varchar(50) DEFAULT NULL,
  `Recommendation` varchar(50) DEFAULT NULL,
  `F1` varchar(254) DEFAULT NULL,
  `F2` varchar(254) DEFAULT NULL,
  `F3` varchar(254) DEFAULT NULL,
  `F4` varchar(254) DEFAULT NULL,
  `F5` varchar(254) DEFAULT NULL,
  `F6` varchar(254) DEFAULT NULL,
  `F7` varchar(254) DEFAULT NULL,
  `F8` varchar(254) DEFAULT NULL,
  `F9` varchar(254) DEFAULT NULL,
  `F10` varchar(254) DEFAULT NULL,
  `F11` varchar(254) DEFAULT NULL,
  `F12` varchar(254) DEFAULT NULL,
  `F13` varchar(254) DEFAULT NULL,
  `F14` varchar(254) DEFAULT NULL,
  `F15` varchar(254) DEFAULT NULL,
  `F16` varchar(254) DEFAULT NULL,
  `F17` varchar(254) DEFAULT NULL,
  `F18` varchar(254) DEFAULT NULL,
  `F19` varchar(254) DEFAULT NULL,
  `F20` varchar(254) DEFAULT NULL,
  `F21` varchar(254) DEFAULT NULL,
  `F22` varchar(254) DEFAULT NULL,
  `F23` varchar(254) DEFAULT NULL,
  `F24` varchar(254) DEFAULT NULL,
  `F25` varchar(254) DEFAULT NULL,
  `X_F1` char(1) DEFAULT 'Y',
  `X_F2` char(1) DEFAULT 'Y',
  `X_F3` char(1) DEFAULT 'Y',
  `X_F4` char(1) DEFAULT 'Y',
  `X_F5` char(1) DEFAULT 'Y',
  `X_F6` char(1) DEFAULT 'Y',
  `X_F7` char(1) DEFAULT 'Y',
  `X_F8` char(1) DEFAULT 'Y',
  `X_F9` char(1) DEFAULT 'Y',
  `X_F10` char(1) DEFAULT 'Y',
  `X_F11` char(1) DEFAULT 'Y',
  `X_F12` char(1) DEFAULT 'Y',
  `X_F13` char(1) DEFAULT 'Y',
  `X_F14` char(1) DEFAULT 'Y',
  `X_F15` char(1) DEFAULT 'Y',
  `X_F16` char(1) DEFAULT 'Y',
  `X_F17` char(1) DEFAULT 'Y',
  `X_F18` char(1) DEFAULT 'Y',
  `X_F19` char(1) DEFAULT 'Y',
  `X_F20` char(1) DEFAULT 'Y',
  `X_F21` char(1) DEFAULT 'Y',
  `X_F22` char(1) DEFAULT 'Y',
  `X_F23` char(1) DEFAULT 'Y',
  `X_F24` char(1) DEFAULT 'Y',
  `X_F25` char(1) DEFAULT 'Y',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `nmc_ex_contracts`
--

DROP TABLE IF EXISTS `nmc_ex_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nmc_ex_contracts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Contract_ID` int(11) DEFAULT NULL,
  `PDF` varchar(254) DEFAULT NULL,
  `Description` text,
  `corp_ID` int(11) DEFAULT NULL,
  `optimized` char(1) DEFAULT NULL,
  `uploaded` date DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `action_date` date DEFAULT NULL,
  `uploaded_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=5200 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oig_names`
--

DROP TABLE IF EXISTS `oig_names`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oig_names` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `contract_ID` int(11) DEFAULT NULL,
  `biz_name` varchar(100) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `mid_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=385 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oig_names_cm`
--

DROP TABLE IF EXISTS `oig_names_cm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oig_names_cm` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_ID` int(11) DEFAULT NULL,
  `biz_name` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `Last_name` varchar(50) DEFAULT NULL,
  `mid_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oig_names_cm_emp`
--

DROP TABLE IF EXISTS `oig_names_cm_emp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oig_names_cm_emp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `emp_ID` int(11) DEFAULT NULL,
  `biz_name` varchar(50) DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `Last_name` varchar(50) DEFAULT NULL,
  `mid_name` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=70 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oig_results`
--

DROP TABLE IF EXISTS `oig_results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oig_results` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `contract_ID` int(11) DEFAULT NULL,
  `date_checked` date DEFAULT NULL,
  `checked_by` varchar(50) DEFAULT NULL,
  `my_html` text,
  `pass_fail` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7019 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oig_results_cm`
--

DROP TABLE IF EXISTS `oig_results_cm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oig_results_cm` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Vendor_ID` int(11) DEFAULT NULL,
  `date_checked` date DEFAULT NULL,
  `checked_by` varchar(50) DEFAULT NULL,
  `my_html` text,
  `pass_fail` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1095 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `oig_results_cm_emp`
--

DROP TABLE IF EXISTS `oig_results_cm_emp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oig_results_cm_emp` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `emp_ID` int(11) DEFAULT NULL,
  `date_checked` date DEFAULT NULL,
  `checked_by` varchar(50) DEFAULT NULL,
  `my_html` text,
  `pass_fail` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=10386 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `op`
--

DROP TABLE IF EXISTS `op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `op` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `xgroup` varchar(50) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=834 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `op1`
--

DROP TABLE IF EXISTS `op1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `op1` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `xgroup` varchar(50) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `op_services`
--

DROP TABLE IF EXISTS `op_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `op_services` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `op_service` varchar(50) DEFAULT NULL,
  `svc_type` varchar(50) DEFAULT NULL,
  `svc_desc` varchar(50) DEFAULT NULL,
  `d_in_contract` varchar(3) DEFAULT NULL,
  `rate_used` varchar(50) DEFAULT NULL,
  `case_rate` varchar(50) DEFAULT NULL,
  `op_percent` varchar(50) DEFAULT NULL,
  `NTE` varchar(50) DEFAULT NULL,
  `notes` text,
  `caserate_ID` bigint(20) DEFAULT '0',
  `menu1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `service_ID` (`caserate_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `othernetwork_contract`
--

DROP TABLE IF EXISTS `othernetwork_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `othernetwork_contract` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `OtherNetwork` varchar(50) DEFAULT NULL,
  `Client_ID` int(11) DEFAULT NULL,
  `Contract_ID` int(11) DEFAULT NULL,
  `use_it` char(1) DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=64 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `othernetwork_member`
--

DROP TABLE IF EXISTS `othernetwork_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `othernetwork_member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `OtherNetwork` varchar(50) DEFAULT NULL,
  `Client_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pd`
--

DROP TABLE IF EXISTS `pd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pd` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CaseRate_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`CaseRate_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=342 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `pd1`
--

DROP TABLE IF EXISTS `pd1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pd1` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `per_diam`
--

DROP TABLE IF EXISTS `per_diam`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `per_diam` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(50) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=62 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `plan_category`
--

DROP TABLE IF EXISTS `plan_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `plan_category` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `plan` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=154 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `press`
--

DROP TABLE IF EXISTS `press`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `press` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `a_text` text,
  `a_date` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `primarynetwork_contract`
--

DROP TABLE IF EXISTS `primarynetwork_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `primarynetwork_contract` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PrimaryNetwork` varchar(50) DEFAULT NULL,
  `Client_ID` int(11) DEFAULT NULL,
  `Contract_ID` int(11) DEFAULT NULL,
  `use_it` char(1) DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `primarynetwork_member`
--

DROP TABLE IF EXISTS `primarynetwork_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `primarynetwork_member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PrimaryNetwork` varchar(50) DEFAULT NULL,
  `Client_ID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Product` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=100 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `providergroupid`
--

DROP TABLE IF EXISTS `providergroupid`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providergroupid` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `ProviderGroupID` varchar(50) DEFAULT NULL,
  `ProviderGroupID_Desc` varchar(100) DEFAULT NULL,
  `Client_ID` int(11) DEFAULT NULL,
  `Contract_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Provider` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `quicksearch_log`
--

DROP TABLE IF EXISTS `quicksearch_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quicksearch_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `facility` varchar(50) DEFAULT NULL,
  `corp` varchar(50) DEFAULT NULL,
  `corp_ID` bigint(20) DEFAULT '0',
  `log_date` datetime DEFAULT NULL,
  `fd_status` varchar(10) DEFAULT NULL,
  `IP` varchar(50) DEFAULT NULL,
  `Contract_name` varchar(50) DEFAULT NULL,
  `Contract_ID` bigint(20) DEFAULT '0',
  `fac_ID` bigint(20) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `Contract_ID` (`Contract_ID`),
  KEY `corp_ID` (`corp_ID`),
  KEY `fac_ID` (`fac_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `reg`
--

DROP TABLE IF EXISTS `reg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reg` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `f_name` varchar(50) DEFAULT NULL,
  `l_name` varchar(50) DEFAULT NULL,
  `job_title` varchar(50) DEFAULT NULL,
  `Company` varchar(100) DEFAULT NULL,
  `email` varchar(50) DEFAULT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `address1` varchar(50) DEFAULT NULL,
  `address2` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `thestate` varchar(50) DEFAULT NULL,
  `zipcode` varchar(50) DEFAULT NULL,
  `h_about` varchar(50) DEFAULT NULL,
  `Comments` text,
  `requested` varchar(100) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `notes` text,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `rp_list`
--

DROP TABLE IF EXISTS `rp_list`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rp_list` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `corp` varchar(75) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `facility` varchar(75) DEFAULT NULL,
  `Facility_ID` int(11) DEFAULT NULL,
  `RP_name` varchar(50) DEFAULT NULL,
  `RP_title` varchar(50) DEFAULT NULL,
  `RP_email` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=983 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stoploss_calc`
--

DROP TABLE IF EXISTS `stoploss_calc`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stoploss_calc` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `Stoploss_type` varchar(200) DEFAULT NULL,
  `stoploss_num` varchar(1) DEFAULT NULL,
  `create_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `Stoploss1_Notes` text,
  `Stoploss1_Type` varchar(50) DEFAULT NULL,
  `Stoploss1_Threshold` double(13,5) DEFAULT NULL,
  `Stoploss1_Percent` varchar(50) DEFAULT NULL,
  `NTE_Caserate1` varchar(50) DEFAULT NULL,
  `NTE_Per_Day1` double(13,5) DEFAULT NULL,
  `NTE_type` varchar(50) DEFAULT NULL,
  `S_Multiplier1` varchar(50) DEFAULT NULL,
  `S_Reins_Percent1` varchar(50) DEFAULT NULL,
  `Exclusions1` varchar(50) DEFAULT NULL,
  `continious1` varchar(50) DEFAULT NULL,
  `patient_name` varchar(50) DEFAULT NULL,
  `patient_ID` varchar(50) DEFAULT NULL,
  `admit_month` varchar(2) DEFAULT NULL,
  `admit_day` varchar(2) DEFAULT NULL,
  `admit_year` varchar(2) DEFAULT NULL,
  `admit_date` varchar(50) DEFAULT NULL,
  `discharge_month` varchar(2) DEFAULT NULL,
  `discharge_day` varchar(2) DEFAULT NULL,
  `discharge_year` varchar(2) DEFAULT NULL,
  `discharge_date` varchar(50) DEFAULT NULL,
  `length_of_stay` int(11) DEFAULT '0',
  `T_billed_charges` double(13,5) DEFAULT NULL,
  `denied_charges` double(13,5) DEFAULT NULL,
  `exclusions` double(13,5) DEFAULT NULL,
  `Total_Excluded_Charges` double(13,5) DEFAULT NULL,
  `Total_Covered_Charges` double(13,5) DEFAULT NULL,
  `Total_Insurance` double(13,5) DEFAULT NULL,
  `Total_patient` double(13,5) DEFAULT NULL,
  `session_ID1` varchar(50) DEFAULT NULL,
  `contract_ID` int(11) DEFAULT '0',
  `drg` int(11) DEFAULT '0',
  `ICD1` double(13,5) DEFAULT NULL,
  `ICD2` double(13,5) DEFAULT NULL,
  `ICD3` double(13,5) DEFAULT NULL,
  `ICD4` double(13,5) DEFAULT NULL,
  `ICD5` double(13,5) DEFAULT NULL,
  `ICD6` double(13,5) DEFAULT NULL,
  `ICD7` double(13,5) DEFAULT NULL,
  `ICD8` double(13,5) DEFAULT NULL,
  `Exclusion_amount` double(13,5) DEFAULT '0.00000',
  `non_covered_charges` double(13,5) DEFAULT '0.00000',
  `User` varchar(50) DEFAULT NULL,
  `rate_selected` varchar(5) DEFAULT NULL,
  `other_excuded` double(13,5) DEFAULT '0.00000',
  `carve_out` double(13,5) DEFAULT '0.00000',
  PRIMARY KEY (`ID`),
  KEY `contract_ID` (`contract_ID`),
  KEY `patient_ID` (`patient_ID`),
  KEY `session_ID` (`session_ID1`),
  KEY `stoploss_num` (`stoploss_num`)
) ENGINE=MyISAM AUTO_INCREMENT=374 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stoploss_charges`
--

DROP TABLE IF EXISTS `stoploss_charges`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stoploss_charges` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `rev_code` varchar(50) DEFAULT NULL,
  `service_month` varchar(2) DEFAULT NULL,
  `service_day` varchar(2) DEFAULT NULL,
  `service_year` varchar(2) DEFAULT NULL,
  `service_date` datetime DEFAULT NULL,
  `charges` double(13,5) DEFAULT NULL,
  `exclude_it` varchar(3) DEFAULT NULL,
  `contract_ID` int(11) DEFAULT '0',
  `stoploss_ID` int(11) DEFAULT '0',
  `patient_ID` varchar(50) DEFAULT NULL,
  `enter_date` datetime DEFAULT NULL,
  `valid_YN` varchar(1) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `contract_ID` (`contract_ID`),
  KEY `patient_ID` (`patient_ID`),
  KEY `rev_code` (`rev_code`),
  KEY `stoploss_ID` (`stoploss_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=350 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stoploss_log`
--

DROP TABLE IF EXISTS `stoploss_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stoploss_log` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) DEFAULT NULL,
  `login` varchar(50) DEFAULT NULL,
  `fd_password` varchar(50) DEFAULT NULL,
  `facility` varchar(50) DEFAULT NULL,
  `corp` varchar(50) DEFAULT NULL,
  `corp_ID` bigint(20) DEFAULT '0',
  `log_date` datetime DEFAULT NULL,
  `fd_status` varchar(10) DEFAULT NULL,
  `IP` varchar(50) DEFAULT NULL,
  `Contract_name` varchar(50) DEFAULT NULL,
  `Contract_ID` bigint(20) DEFAULT '0',
  `fac_ID` bigint(20) DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `Contract_ID` (`Contract_ID`),
  KEY `corp_ID` (`corp_ID`),
  KEY `fac_ID` (`fac_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stoploss_rates`
--

DROP TABLE IF EXISTS `stoploss_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stoploss_rates` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `rev_date` datetime DEFAULT NULL,
  `rev_code` double(13,5) DEFAULT NULL,
  `rev_rate` varchar(50) DEFAULT NULL,
  `rev_care` varchar(50) DEFAULT NULL,
  `stoploss_ID` int(11) DEFAULT '0',
  `contract_ID` int(11) DEFAULT '0',
  `M_rate` bigint(20) DEFAULT '0',
  `M_desc` varchar(200) DEFAULT NULL,
  `rate_selected` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `contract_ID` (`contract_ID`),
  KEY `ID` (`ID`),
  KEY `rev_code` (`rev_code`),
  KEY `stoploss_ID` (`stoploss_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=239 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `stoploss_rev_code`
--

DROP TABLE IF EXISTS `stoploss_rev_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stoploss_rev_code` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `rev_date` datetime DEFAULT NULL,
  `rev_code` varchar(50) DEFAULT NULL,
  `charges` double(13,5) DEFAULT NULL,
  `perdiem_rate` double(13,5) DEFAULT NULL,
  `Lev_care` varchar(100) DEFAULT NULL,
  `contract_ID` bigint(20) DEFAULT '0',
  `enter_date` datetime DEFAULT NULL,
  `m_rate` double(13,5) DEFAULT NULL,
  `m_desc` varchar(50) DEFAULT NULL,
  `rate_selected` varchar(5) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `contract_ID` (`contract_ID`),
  KEY `rev_code` (`rev_code`)
) ENGINE=MyISAM AUTO_INCREMENT=1701 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_caserate`
--

DROP TABLE IF EXISTS `sub_caserate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_caserate` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CaseRate_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(254) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `DRG_Weight` double(13,5) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`CaseRate_ID`),
  KEY `ID` (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=7206 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_caserate_ex`
--

DROP TABLE IF EXISTS `sub_caserate_ex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_caserate_ex` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CaseRate_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`CaseRate_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=617 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_caserate_ex_cpt`
--

DROP TABLE IF EXISTS `sub_caserate_ex_cpt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_caserate_ex_cpt` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CaseRate_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(50) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`CaseRate_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2428 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_caserate_pd`
--

DROP TABLE IF EXISTS `sub_caserate_pd`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_caserate_pd` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CaseRate_ID` bigint(20) DEFAULT '0',
  `DRG` double(13,5) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`CaseRate_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=888 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_castrate_pd_drg`
--

DROP TABLE IF EXISTS `sub_castrate_pd_drg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_castrate_pd_drg` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CaseRate_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(50) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`CaseRate_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_op`
--

DROP TABLE IF EXISTS `sub_op`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_op` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CaseRate_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(50) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(255) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  `APC` varchar(50) DEFAULT NULL,
  `Mod1` varchar(50) DEFAULT NULL,
  `SI` varchar(50) DEFAULT NULL,
  `CI` varchar(50) DEFAULT NULL,
  `Base_Rt` double(13,5) DEFAULT NULL,
  `RW1` double(13,5) DEFAULT NULL,
  `RW2` double(13,5) DEFAULT NULL,
  `Mult1` double(13,5) DEFAULT NULL,
  `Mult2` double(13,5) DEFAULT NULL,
  `co_pay` double(13,5) DEFAULT NULL,
  `Pmt_Rt` double(13,5) DEFAULT NULL,
  `blank1` varchar(50) DEFAULT NULL,
  `blank2` double(13,5) DEFAULT NULL,
  `SI_description` text,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`CaseRate_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=214837 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `sub_op1`
--

DROP TABLE IF EXISTS `sub_op1`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sub_op1` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `CaseRate_ID` bigint(20) DEFAULT '0',
  `DRG` varchar(50) DEFAULT NULL,
  `DRG_grouping` varchar(50) DEFAULT NULL,
  `DRG_Desc` varchar(254) DEFAULT NULL,
  `menu1` varchar(50) DEFAULT NULL,
  `caserate` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`),
  KEY `CaseRate_ID` (`CaseRate_ID`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `typeofprovider_contract`
--

DROP TABLE IF EXISTS `typeofprovider_contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typeofprovider_contract` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `typeofprovider` varchar(50) DEFAULT NULL,
  `Client_ID` int(11) DEFAULT NULL,
  `contract_ID` int(11) DEFAULT NULL,
  `use_it` char(1) DEFAULT 'N',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `typeofprovider_member`
--

DROP TABLE IF EXISTS `typeofprovider_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `typeofprovider_member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `TypeOfProvider` varchar(50) DEFAULT NULL,
  `Client_ID` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `ub_rev_codes`
--

DROP TABLE IF EXISTS `ub_rev_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ub_rev_codes` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `L_care` varchar(100) DEFAULT NULL,
  `L_rate` text,
  `rev_code` varchar(254) DEFAULT NULL,
  `notes` text,
  PRIMARY KEY (`ID`),
  KEY `rev_code` (`rev_code`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_actions`
--

DROP TABLE IF EXISTS `umc_actions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_actions` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Action` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_contract_type`
--

DROP TABLE IF EXISTS `umc_contract_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_contract_type` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Contract_Type` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=95 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_contract_type_member`
--

DROP TABLE IF EXISTS `umc_contract_type_member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_contract_type_member` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Contract_Type` varchar(50) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_contracts`
--

DROP TABLE IF EXISTS `umc_contracts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_contracts` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `corp` varchar(50) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `facility` varchar(50) DEFAULT NULL,
  `facility_ID` int(11) DEFAULT NULL,
  `Vendor` varchar(50) DEFAULT NULL,
  `Services_Provided` text,
  `Contract_Type` varchar(50) DEFAULT NULL,
  `Department` varchar(50) DEFAULT NULL,
  `Effective_Date` date DEFAULT NULL,
  `Expiration_Date` date DEFAULT NULL,
  `ExpriationNotifyPriorDays` int(11) DEFAULT NULL,
  `ExpirationNotifyAction` varchar(50) DEFAULT NULL,
  `Renewal_Type` varchar(50) DEFAULT NULL,
  `Header_Notes1` text,
  `Termination_Provisions` text,
  `Renewal_Term` varchar(50) DEFAULT NULL,
  `num_Renewals` text,
  `RP_name` varchar(50) DEFAULT NULL,
  `RP_title` varchar(50) DEFAULT NULL,
  `RP_email` varchar(50) DEFAULT NULL,
  `RP_name2` varchar(50) DEFAULT NULL,
  `RP_title2` varchar(50) DEFAULT NULL,
  `RP_email2` varchar(50) DEFAULT NULL,
  `RP_email3` varchar(50) DEFAULT NULL,
  `RP_name3` varchar(50) DEFAULT NULL,
  `RP_title3` varchar(50) DEFAULT NULL,
  `cost_month` text,
  `contact_name` varchar(50) DEFAULT NULL,
  `contact_address` varchar(150) DEFAULT NULL,
  `contact_email` varchar(50) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_fax` varchar(50) DEFAULT NULL,
  `contact_phone2` varchar(50) DEFAULT NULL,
  `Fully_Executed` varchar(50) DEFAULT NULL,
  `signedby` varchar(50) DEFAULT NULL,
  `signedby_title` varchar(50) DEFAULT NULL,
  `tax_ID` varchar(50) DEFAULT NULL,
  `BR_Date` date DEFAULT NULL,
  `BR_NotifyPriorDays` int(11) DEFAULT NULL,
  `BR_action` varchar(50) DEFAULT NULL,
  `QI` varchar(50) DEFAULT NULL,
  `Liability_Amt` varchar(50) DEFAULT NULL,
  `CIS` varchar(50) DEFAULT NULL,
  `CIS_date` date DEFAULT NULL,
  `CIS_NotifyPriorDays` int(11) DEFAULT NULL,
  `CIS_action` varchar(50) DEFAULT NULL,
  `WC` varchar(50) DEFAULT NULL,
  `WC_date` date DEFAULT NULL,
  `WC_NotifyPriorDays` int(11) DEFAULT NULL,
  `Hold_Harmless` varchar(50) DEFAULT NULL,
  `BS` varchar(50) DEFAULT NULL,
  `BS_lang` varchar(50) DEFAULT NULL,
  `TP` varchar(50) DEFAULT NULL,
  `TP_lang` varchar(50) DEFAULT NULL,
  `COS1` varchar(50) DEFAULT NULL,
  `COS_lang` varchar(50) DEFAULT NULL,
  `federally_funded` varchar(50) DEFAULT NULL,
  `federally_funded_lang` varchar(50) DEFAULT NULL,
  `Accreditation` varchar(50) DEFAULT NULL,
  `Accreditation_lang` varchar(50) DEFAULT NULL,
  `insurance_requirements` varchar(50) DEFAULT NULL,
  `insurance_requirements_lang` varchar(50) DEFAULT NULL,
  `WC_action` varchar(50) DEFAULT NULL,
  `Contract_status` varchar(50) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) DEFAULT NULL,
  `contract` varchar(255) DEFAULT NULL,
  `X_Company` char(1) DEFAULT NULL,
  `X_Facility` char(1) DEFAULT NULL,
  `X_Vendor` char(1) DEFAULT NULL,
  `X_Contract_Type` char(1) DEFAULT NULL,
  `X_Effective_Date` char(1) DEFAULT NULL,
  `X_Department` char(1) DEFAULT NULL,
  `X_Renewal_Type` char(1) DEFAULT NULL,
  `X_Renewal_Term` char(1) DEFAULT NULL,
  `X_num_Renewals` char(1) DEFAULT NULL,
  `X_cost_month` char(1) DEFAULT NULL,
  `X_Expiration_Date` char(1) DEFAULT NULL,
  `X_ExpriationNotifyPriorDays` char(1) DEFAULT NULL,
  `X_ExpirationNotifyAction` char(1) DEFAULT NULL,
  `X_BR_Date` char(1) DEFAULT NULL,
  `X_BR_NotifyPriorDays` char(1) DEFAULT NULL,
  `X_BR_action` char(1) DEFAULT NULL,
  `X_CIS` char(1) DEFAULT NULL,
  `X_CIS_date` char(1) DEFAULT NULL,
  `X_CIS_NotifyPriorDays` char(1) DEFAULT NULL,
  `X_CIS_action` char(1) DEFAULT NULL,
  `X_WC` char(1) DEFAULT NULL,
  `X_WC_date` char(1) DEFAULT NULL,
  `X_WC_NotifyPriorDays` char(1) DEFAULT NULL,
  `X_WC_action` char(1) DEFAULT NULL,
  `X_RP_name` char(1) DEFAULT NULL,
  `X_RP_title` char(1) DEFAULT NULL,
  `X_RP_email` char(1) DEFAULT NULL,
  `X_RP_name2` char(1) DEFAULT NULL,
  `X_RP_title2` char(1) DEFAULT NULL,
  `X_RP_email2` char(1) DEFAULT NULL,
  `X_RP_name3` char(1) DEFAULT NULL,
  `X_RP_title3` char(1) DEFAULT NULL,
  `X_RP_email3` char(1) DEFAULT NULL,
  `X_Services_Provided` char(1) DEFAULT NULL,
  `X_Termination_Provisions` char(1) DEFAULT NULL,
  `X_HeaderNotes` char(1) DEFAULT NULL,
  `X_contact_name` char(1) DEFAULT NULL,
  `X_contact_email` char(1) DEFAULT NULL,
  `X_contact_fax` char(1) DEFAULT NULL,
  `X_contact_address` char(1) DEFAULT NULL,
  `X_contact_phone` char(1) DEFAULT NULL,
  `X_contact_phone2` char(1) DEFAULT NULL,
  `X_Fully_Executed` char(1) DEFAULT NULL,
  `X_tax_ID` char(1) DEFAULT NULL,
  `X_signedby` char(1) DEFAULT NULL,
  `X_signedby_title` char(1) DEFAULT NULL,
  `X_Liability_Amt` char(1) DEFAULT NULL,
  `X_QI` char(1) DEFAULT NULL,
  `X_Hold_Harmless` char(1) DEFAULT NULL,
  `X_BS` char(1) DEFAULT NULL,
  `X_BS_lang` char(1) DEFAULT NULL,
  `X_TP` char(1) DEFAULT NULL,
  `X_TP_lang` char(1) DEFAULT NULL,
  `X_COS1` char(1) DEFAULT NULL,
  `X_COS_lang` char(1) DEFAULT NULL,
  `X_federally_funded` char(1) DEFAULT NULL,
  `X_federally_funded_lang` char(1) DEFAULT NULL,
  `X_Accreditation` char(1) DEFAULT NULL,
  `X_Accreditation_lang` char(1) DEFAULT NULL,
  `X_insurance_requirements` char(1) DEFAULT NULL,
  `X_insurance_requirements_lang` char(1) DEFAULT NULL,
  `ex_email` char(1) DEFAULT 'Y',
  `br_email` char(1) DEFAULT 'Y',
  `CIS_email` char(1) DEFAULT 'Y',
  `WC_email` char(1) DEFAULT 'Y',
  `extra_date` date DEFAULT NULL,
  `extraNotifyPriorDays` int(11) DEFAULT NULL,
  `Extra_action` varchar(50) DEFAULT NULL,
  `X_extra_date` char(1) DEFAULT NULL,
  `extra_email` char(1) DEFAULT NULL,
  `contact_URL` varchar(100) DEFAULT NULL,
  `RP_ID` int(11) DEFAULT '0',
  `RP_ID2` int(11) DEFAULT '0',
  `RP_ID3` int(11) DEFAULT '0',
  `oig_checked` date DEFAULT NULL,
  `oig_check_on` date DEFAULT NULL,
  `oig_bad` char(1) DEFAULT 'N',
  `oig_duration` int(11) DEFAULT '365',
  `new1` text,
  `new2` text,
  `new3` text,
  `new4` text,
  `new5` text,
  `new6` text,
  `new7` text,
  `new8` text,
  `new9` text,
  `new10` text,
  `description` text,
  `X_new1` char(1) DEFAULT NULL,
  `X_new2` char(1) DEFAULT NULL,
  `X_new3` char(1) DEFAULT NULL,
  `X_new4` char(1) DEFAULT NULL,
  `X_new5` char(1) DEFAULT NULL,
  `X_new6` char(1) DEFAULT NULL,
  `X_new7` char(1) DEFAULT NULL,
  `X_new8` char(1) DEFAULT NULL,
  `X_new9` char(1) DEFAULT NULL,
  `X_new10` char(1) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2223 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_contracts_new`
--

DROP TABLE IF EXISTS `umc_contracts_new`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_contracts_new` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `corp` varchar(50) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `facility` varchar(50) DEFAULT NULL,
  `facility_ID` int(11) DEFAULT '0',
  `Vendor` varchar(50) DEFAULT NULL,
  `Services_Provided` varchar(254) DEFAULT NULL,
  `Contract_Type` varchar(50) DEFAULT NULL,
  `Department` varchar(50) DEFAULT NULL,
  `Effective_Date` date DEFAULT NULL,
  `Expiration_Date` date DEFAULT NULL,
  `ExpriationNotifyPriorDays` int(11) DEFAULT '30',
  `ExpirationNotifyAction` varchar(50) DEFAULT NULL,
  `Renewal_Type` varchar(50) DEFAULT NULL,
  `Header_Notes1` text,
  `Termination_Provisions` text,
  `Renewal_Term` varchar(50) DEFAULT NULL,
  `num_Renewals` int(11) DEFAULT '1',
  `RP_name` varchar(50) DEFAULT NULL,
  `RP_title` varchar(50) DEFAULT NULL,
  `RP_email` varchar(50) DEFAULT NULL,
  `RP_name2` varchar(50) DEFAULT NULL,
  `RP_title2` varchar(50) DEFAULT NULL,
  `RP_email2` varchar(50) DEFAULT NULL,
  `RP_email3` varchar(50) DEFAULT NULL,
  `RP_name3` varchar(50) DEFAULT NULL,
  `RP_title3` varchar(50) DEFAULT NULL,
  `cost_month` varchar(50) DEFAULT NULL,
  `contact_name` varchar(50) DEFAULT NULL,
  `contact_address` varchar(150) DEFAULT NULL,
  `contact_email` varchar(50) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_fax` varchar(50) DEFAULT NULL,
  `contact_phone2` varchar(50) DEFAULT NULL,
  `Fully_Executed` varchar(50) DEFAULT NULL,
  `signedby` varchar(50) DEFAULT NULL,
  `signedby_title` varchar(50) DEFAULT NULL,
  `tax_ID` varchar(50) DEFAULT NULL,
  `BR_Date` date DEFAULT NULL,
  `BR_NotifyPriorDays` int(11) DEFAULT '30',
  `BR_action` varchar(50) DEFAULT NULL,
  `QI` varchar(50) DEFAULT NULL,
  `Liability_Amt` varchar(50) DEFAULT NULL,
  `CIS` varchar(50) DEFAULT NULL,
  `CIS_date` date DEFAULT NULL,
  `CIS_NotifyPriorDays` int(11) DEFAULT '30',
  `CIS_action` varchar(50) DEFAULT NULL,
  `WC` varchar(50) DEFAULT NULL,
  `WC_date` date DEFAULT NULL,
  `WC_NotifyPriorDays` int(11) DEFAULT '30',
  `Hold_Harmless` varchar(50) DEFAULT NULL,
  `BS` varchar(50) DEFAULT NULL,
  `BS_lang` varchar(50) DEFAULT NULL,
  `TP` varchar(50) DEFAULT NULL,
  `TP_lang` varchar(50) DEFAULT NULL,
  `COS1` varchar(50) DEFAULT NULL,
  `COS_lang` varchar(50) DEFAULT NULL,
  `federally_funded` varchar(50) DEFAULT NULL,
  `federally_funded_lang` varchar(50) DEFAULT NULL,
  `Accreditation` varchar(50) DEFAULT NULL,
  `Accreditation_lang` varchar(50) DEFAULT NULL,
  `insurance_requirements` varchar(50) DEFAULT NULL,
  `insurance_requirements_lang` varchar(50) DEFAULT NULL,
  `WC_action` varchar(50) DEFAULT NULL,
  `Contract_status` varchar(50) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) DEFAULT NULL,
  `contract` varchar(254) DEFAULT NULL,
  `X_Company` char(1) DEFAULT NULL,
  `X_Facility` char(1) DEFAULT NULL,
  `X_Vendor` char(1) DEFAULT NULL,
  `X_Contract_Type` char(1) DEFAULT NULL,
  `X_Effective_Date` char(1) DEFAULT NULL,
  `X_Department` char(1) DEFAULT NULL,
  `X_Renewal_Type` char(1) DEFAULT NULL,
  `X_Renewal_Term` char(1) DEFAULT NULL,
  `X_num_Renewals` char(1) DEFAULT NULL,
  `X_cost_month` char(1) DEFAULT NULL,
  `X_Expiration_Date` char(1) DEFAULT NULL,
  `X_ExpriationNotifyPriorDays` char(1) DEFAULT NULL,
  `X_ExpirationNotifyAction` char(1) DEFAULT NULL,
  `X_BR_Date` char(1) DEFAULT NULL,
  `X_BR_NotifyPriorDays` char(1) DEFAULT NULL,
  `X_BR_action` char(1) DEFAULT NULL,
  `X_CIS` char(1) DEFAULT NULL,
  `X_CIS_date` char(1) DEFAULT NULL,
  `X_CIS_NotifyPriorDays` char(1) DEFAULT NULL,
  `X_CIS_action` char(1) DEFAULT NULL,
  `X_WC` char(1) DEFAULT NULL,
  `X_WC_date` char(1) DEFAULT NULL,
  `X_WC_NotifyPriorDays` char(1) DEFAULT NULL,
  `X_WC_action` char(1) DEFAULT NULL,
  `X_RP_name` char(1) DEFAULT NULL,
  `X_RP_title` char(1) DEFAULT NULL,
  `X_RP_email` char(1) DEFAULT NULL,
  `X_RP_name2` char(1) DEFAULT NULL,
  `X_RP_title2` char(1) DEFAULT NULL,
  `X_RP_email2` char(1) DEFAULT NULL,
  `X_RP_name3` char(1) DEFAULT NULL,
  `X_RP_title3` char(1) DEFAULT NULL,
  `X_RP_email3` char(1) DEFAULT NULL,
  `X_Services_Provided` char(1) DEFAULT NULL,
  `X_Termination_Provisions` char(1) DEFAULT NULL,
  `X_HeaderNotes` char(1) DEFAULT NULL,
  `X_contact_name` char(1) DEFAULT NULL,
  `X_contact_email` char(1) DEFAULT NULL,
  `X_contact_fax` char(1) DEFAULT NULL,
  `X_contact_address` char(1) DEFAULT NULL,
  `X_contact_phone` char(1) DEFAULT NULL,
  `X_contact_phone2` char(1) DEFAULT NULL,
  `X_Fully_Executed` char(1) DEFAULT NULL,
  `X_tax_ID` char(1) DEFAULT NULL,
  `X_signedby` char(1) DEFAULT NULL,
  `X_signedby_title` char(1) DEFAULT NULL,
  `X_Liability_Amt` char(1) DEFAULT NULL,
  `X_QI` char(1) DEFAULT NULL,
  `X_Hold_Harmless` char(1) DEFAULT NULL,
  `X_BS` char(1) DEFAULT NULL,
  `X_BS_lang` char(1) DEFAULT NULL,
  `X_TP` char(1) DEFAULT NULL,
  `X_TP_lang` char(1) DEFAULT NULL,
  `X_COS1` char(1) DEFAULT NULL,
  `X_COS_lang` char(1) DEFAULT NULL,
  `X_federally_funded` char(1) DEFAULT NULL,
  `X_federally_funded_lang` char(1) DEFAULT NULL,
  `X_Accreditation` char(1) DEFAULT NULL,
  `X_Accreditation_lang` char(1) DEFAULT NULL,
  `X_insurance_requirements` char(1) DEFAULT NULL,
  `X_insurance_requirements_lang` char(1) DEFAULT NULL,
  `ex_email` char(1) DEFAULT 'Y',
  `br_email` char(1) DEFAULT 'Y',
  `CIS_email` char(1) DEFAULT 'Y',
  `WC_email` char(1) DEFAULT 'Y',
  `extra_date` date DEFAULT NULL,
  `extraNotifyPriorDays` int(11) DEFAULT NULL,
  `Extra_action` varchar(50) DEFAULT NULL,
  `X_extra_date` char(1) DEFAULT NULL,
  `extra_email` char(1) DEFAULT NULL,
  `contact_URL` varchar(100) DEFAULT NULL,
  `RP_ID` int(11) DEFAULT '0',
  `RP_ID2` int(11) DEFAULT '0',
  `RP_ID3` int(11) DEFAULT '0',
  `status` varchar(50) DEFAULT NULL,
  `C_status` varchar(50) DEFAULT NULL,
  `contract_ID` int(11) DEFAULT NULL,
  `Description` text,
  `new1` varchar(50) DEFAULT NULL,
  `new2` varchar(50) DEFAULT NULL,
  `new3` varchar(50) DEFAULT NULL,
  `new4` varchar(50) DEFAULT NULL,
  `new5` varchar(50) DEFAULT NULL,
  `new6` varchar(50) DEFAULT NULL,
  `new7` varchar(50) DEFAULT NULL,
  `new8` varchar(50) DEFAULT NULL,
  `new9` varchar(50) DEFAULT NULL,
  `new10` varchar(50) DEFAULT NULL,
  `uploaded_by` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1504 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_contracts_setup`
--

DROP TABLE IF EXISTS `umc_contracts_setup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_contracts_setup` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `corp` varchar(100) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `facility` varchar(100) DEFAULT NULL,
  `facility_ID` int(11) DEFAULT NULL,
  `Vendor` varchar(100) DEFAULT NULL,
  `Services_Provided` varchar(100) DEFAULT NULL,
  `Contract_Type` varchar(100) DEFAULT NULL,
  `Department` varchar(100) DEFAULT NULL,
  `Effective_Date` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `Expiration_Date` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `ExpriationNotifyPriorDays` varchar(100) DEFAULT NULL,
  `ExpirationNotifyAction` varchar(100) DEFAULT NULL,
  `Renewal_Type` varchar(100) DEFAULT NULL,
  `Header_Notes1` varchar(100) DEFAULT NULL,
  `Termination_Provisions` varchar(100) DEFAULT NULL,
  `Renewal_Term` varchar(100) DEFAULT NULL,
  `num_Renewals` varchar(100) DEFAULT NULL,
  `RP_name` varchar(100) DEFAULT NULL,
  `RP_title` varchar(100) DEFAULT NULL,
  `RP_email` varchar(100) DEFAULT NULL,
  `RP_name2` varchar(100) DEFAULT NULL,
  `RP_title2` varchar(100) DEFAULT NULL,
  `RP_email2` varchar(100) DEFAULT NULL,
  `RP_email3` varchar(100) DEFAULT NULL,
  `RP_name3` varchar(100) DEFAULT NULL,
  `RP_title3` varchar(100) DEFAULT NULL,
  `cost_month` varchar(100) DEFAULT NULL,
  `contact_name` varchar(100) DEFAULT NULL,
  `contact_address` varchar(100) DEFAULT NULL,
  `contact_email` varchar(100) DEFAULT NULL,
  `contact_phone` varchar(100) DEFAULT NULL,
  `contact_fax` varchar(100) DEFAULT NULL,
  `contact_phone2` varchar(100) DEFAULT NULL,
  `Fully_Executed` varchar(100) DEFAULT NULL,
  `signedby` varchar(100) DEFAULT NULL,
  `signedby_title` varchar(100) DEFAULT NULL,
  `tax_ID` varchar(100) DEFAULT NULL,
  `BR_Date` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `BR_NotifyPriorDays` varchar(100) DEFAULT NULL,
  `BR_action` varchar(100) DEFAULT NULL,
  `QI` varchar(100) DEFAULT NULL,
  `Liability_Amt` varchar(100) DEFAULT NULL,
  `CIS` varchar(100) DEFAULT NULL,
  `CIS_date` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `CIS_NotifyPriorDays` varchar(100) DEFAULT NULL,
  `CIS_action` varchar(100) DEFAULT NULL,
  `WC` varchar(100) DEFAULT NULL,
  `WC_date` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `WC_NotifyPriorDays` varchar(100) DEFAULT NULL,
  `Hold_Harmless` text,
  `BS` text,
  `BS_lang` text,
  `TP` text,
  `TP_lang` text,
  `COS1` text,
  `COS_lang` text,
  `federally_funded` text,
  `federally_funded_lang` text,
  `Accreditation` text,
  `Accreditation_lang` text,
  `insurance_requirements` text,
  `insurance_requirements_lang` text,
  `WC_action` varchar(100) DEFAULT NULL,
  `X_Company` char(1) DEFAULT NULL,
  `X_Facility` char(1) DEFAULT NULL,
  `X_Vendor` char(1) DEFAULT NULL,
  `X_Contract_Type` char(1) DEFAULT NULL,
  `X_Effective_Date` char(1) DEFAULT NULL,
  `X_Department` char(1) DEFAULT NULL,
  `X_Renewal_Type` char(1) DEFAULT NULL,
  `X_Renewal_Term` char(1) DEFAULT NULL,
  `X_num_Renewals` char(1) DEFAULT NULL,
  `X_cost_month` char(1) DEFAULT NULL,
  `X_Expiration_Date` char(1) DEFAULT NULL,
  `X_ExpriationNotifyPriorDays` char(1) DEFAULT NULL,
  `X_ExpirationNotifyAction` char(1) DEFAULT NULL,
  `X_BR_Date` char(1) DEFAULT NULL,
  `X_BR_NotifyPriorDays` char(1) DEFAULT NULL,
  `X_BR_action` char(1) DEFAULT NULL,
  `X_CIS` char(1) DEFAULT NULL,
  `X_CIS_date` char(1) DEFAULT NULL,
  `X_CIS_NotifyPriorDays` char(1) DEFAULT NULL,
  `X_CIS_action` char(1) DEFAULT NULL,
  `X_WC` char(1) DEFAULT NULL,
  `X_WC_date` char(1) DEFAULT NULL,
  `X_WC_NotifyPriorDays` char(1) DEFAULT NULL,
  `X_WC_action` char(1) DEFAULT NULL,
  `X_RP_name` char(1) DEFAULT NULL,
  `X_RP_name2` char(1) DEFAULT NULL,
  `X_RP_name3` char(1) DEFAULT NULL,
  `X_RP_title` char(1) DEFAULT NULL,
  `X_RP_title2` char(1) DEFAULT NULL,
  `X_RP_title3` char(1) DEFAULT NULL,
  `X_RP_email` char(1) DEFAULT NULL,
  `X_RP_email2` char(1) DEFAULT NULL,
  `X_RP_email3` char(1) DEFAULT NULL,
  `X_Services_Provided` char(1) DEFAULT NULL,
  `X_Termination_Provisions` char(1) DEFAULT NULL,
  `X_HeaderNotes` char(1) DEFAULT NULL,
  `X_contact_name` char(1) DEFAULT NULL,
  `X_contact_email` char(1) DEFAULT NULL,
  `X_contact_fax` char(1) DEFAULT NULL,
  `X_contact_address` char(1) DEFAULT NULL,
  `X_contact_phone` char(1) DEFAULT NULL,
  `X_contact_phone2` char(1) DEFAULT NULL,
  `X_Fully_Executed` char(1) DEFAULT NULL,
  `X_tax_ID` char(1) DEFAULT NULL,
  `X_signedby` char(1) DEFAULT NULL,
  `X_signedby_title` char(1) DEFAULT NULL,
  `X_Liability_Amt` char(1) DEFAULT NULL,
  `X_QI` char(1) DEFAULT NULL,
  `X_Hold_Harmless` char(1) DEFAULT NULL,
  `X_BS` char(1) DEFAULT NULL,
  `X_BS_lang` char(1) DEFAULT NULL,
  `X_TP` char(1) DEFAULT NULL,
  `X_TP_lang` char(1) DEFAULT NULL,
  `X_COS1` char(1) DEFAULT NULL,
  `X_COS_lang` char(1) DEFAULT NULL,
  `X_federally_funded` char(1) DEFAULT NULL,
  `X_federally_funded_lang` char(1) DEFAULT NULL,
  `X_Accreditation` char(1) DEFAULT NULL,
  `X_Accreditation_lang` char(1) DEFAULT NULL,
  `X_insurance_requirements` char(1) DEFAULT NULL,
  `X_insurance_requirements_lang` char(1) DEFAULT NULL,
  `extra_Date2` char(1) CHARACTER SET latin1 COLLATE latin1_bin DEFAULT NULL,
  `extraNotifyPriorDays2` char(1) DEFAULT NULL,
  `extraNotifyAction2` char(1) DEFAULT NULL,
  `X_extra_Date` char(1) DEFAULT NULL,
  `x1` char(1) DEFAULT NULL,
  `x2` char(1) DEFAULT NULL,
  `x3` char(1) DEFAULT NULL,
  `x4` char(1) DEFAULT NULL,
  `extra_Date` varchar(50) DEFAULT NULL,
  `extraNotifyPriorDays` varchar(50) DEFAULT NULL,
  `extraNotifyAction` varchar(50) DEFAULT NULL,
  `x5` char(1) DEFAULT NULL,
  `x6` char(1) DEFAULT NULL,
  `new1` varchar(50) DEFAULT NULL,
  `new2` varchar(50) DEFAULT NULL,
  `new3` varchar(50) DEFAULT NULL,
  `new4` varchar(50) DEFAULT NULL,
  `new5` varchar(50) DEFAULT NULL,
  `new6` varchar(50) DEFAULT NULL,
  `new7` varchar(50) DEFAULT NULL,
  `new8` varchar(50) DEFAULT NULL,
  `new9` varchar(50) DEFAULT NULL,
  `new10` varchar(50) DEFAULT NULL,
  `X_new1` char(1) DEFAULT NULL,
  `X_new2` char(1) DEFAULT NULL,
  `X_new3` char(1) DEFAULT NULL,
  `X_new4` char(1) DEFAULT NULL,
  `X_new5` char(1) DEFAULT NULL,
  `X_new6` char(1) DEFAULT NULL,
  `X_new7` char(1) DEFAULT NULL,
  `X_new8` char(1) DEFAULT NULL,
  `X_new9` varchar(50) DEFAULT NULL,
  `X_new10` char(1) DEFAULT NULL,
  `Contract_Compliance` varchar(250) DEFAULT NULL,
  `Contact_Person` varchar(250) DEFAULT NULL,
  `contract_ID` varchar(50) DEFAULT 'Contract ID',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_department`
--

DROP TABLE IF EXISTS `umc_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_department` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Department` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=93 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_papertrail`
--

DROP TABLE IF EXISTS `umc_papertrail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_papertrail` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `contract_ID` int(11) DEFAULT NULL,
  `event` text,
  `event_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=8399 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_service_provided`
--

DROP TABLE IF EXISTS `umc_service_provided`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_service_provided` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `service` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=157 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `umc_vendors`
--

DROP TABLE IF EXISTS `umc_vendors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `umc_vendors` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `vendor` varchar(50) DEFAULT NULL,
  `co_name` varchar(50) DEFAULT NULL,
  `address` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `thestate` varchar(50) DEFAULT NULL,
  `zip` varchar(50) DEFAULT NULL,
  `notes` text,
  `cm_vendor` char(1) DEFAULT 'N',
  `contact_name` varchar(50) DEFAULT NULL,
  `contact_email` varchar(50) DEFAULT NULL,
  `contact_phone` varchar(50) DEFAULT NULL,
  `contact_phone2` varchar(50) DEFAULT NULL,
  `contact_title` varchar(50) DEFAULT NULL,
  `active` varchar(50) DEFAULT NULL,
  `updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` varchar(50) DEFAULT NULL,
  `contact_fax` varchar(50) DEFAULT NULL,
  `corp_ID` int(11) DEFAULT NULL,
  `Facility` varchar(50) DEFAULT NULL,
  `Facility_ID` int(11) DEFAULT NULL,
  `contract_ID` int(11) DEFAULT NULL,
  `rp_name` varchar(50) DEFAULT NULL,
  `rp_name2` varchar(50) DEFAULT NULL,
  `rp_title2` varchar(50) DEFAULT NULL,
  `rp_email3` varchar(50) DEFAULT NULL,
  `rp_email2` varchar(50) DEFAULT NULL,
  `rp_name3` varchar(50) DEFAULT NULL,
  `rp_title` varchar(50) DEFAULT NULL,
  `rp_email` varchar(50) DEFAULT NULL,
  `URL` varchar(100) DEFAULT NULL,
  `RP_ID` int(11) DEFAULT '0',
  `RP_ID2` int(11) DEFAULT '0',
  `RP_ID3` int(11) DEFAULT '0',
  `rp_title3` varchar(50) DEFAULT NULL,
  `oig_bad` char(1) DEFAULT 'N',
  `oig_checked` date DEFAULT NULL,
  `oig_check_on` date DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=1484 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `url_links`
--

DROP TABLE IF EXISTS `url_links`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `url_links` (
  `ID` bigint(20) NOT NULL AUTO_INCREMENT,
  `URL_link` varchar(200) DEFAULT NULL,
  `Title` text,
  `Sort_order` bigint(20) DEFAULT '1000',
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-11-26 11:28:43
