﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Security
{
    using BinderOne.Common.Security;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Claims;
    using BoClaimTypes = BinderOne.Common.Security.ClaimTypes;

    public static class SecurityPermissionHelper
    {
        public static bool CanShowContractManager(ClaimsIdentity identity)
        {
            //Product Type of the current user
            var corpProductType = identity.Claims.Where(c => c.Type == BoClaimTypes.CorpProductType).FirstOrDefault();

            if (corpProductType != null && (corpProductType.Value == ClaimValues.All || corpProductType.Value == ClaimValues.CareType_Both || corpProductType.Value == ClaimValues.CareType_Nmc))
            {
                return true;
            }

            return false;
        }

        public static string GetUserCareType(ClaimsIdentity identity)
        {
            //care_type of the current user
            var corpProductType = identity.Claims.Where(c => c.Type == BoClaimTypes.CorpProductType).FirstOrDefault();

            if (corpProductType == null) return string.Empty;

            var careType = corpProductType.Value;

            return (careType == ClaimValues.All || careType == ClaimValues.CareType_Both)
                ? ClaimValues.All
                : careType;
        }

        public static string GetUserLogin(ClaimsIdentity identity)
        {
            //care_type of the current user
            var logInUserClaim = identity.Claims.Where(c => c.Type == BoClaimTypes.LoginUserName).FirstOrDefault();

            if (logInUserClaim != null)
            {
                return logInUserClaim.Value;
            }

            return string.Empty;
        }

        public static int ClaimValuesMatch(string policyClaimValue, string userClaimValues)
        {
            var userClaimValuesArray = SplitString(userClaimValues);
            var policyValuesArray = SplitString(policyClaimValue);

            //If the user's claim value is (or contains) All
            //It means that the user has the rights to access this feature
            if (userClaimValuesArray.Contains("all"))
            {
                var numOfPolicyClaims = policyValuesArray.Count();
                if (numOfPolicyClaims > 0)
                {
                    return numOfPolicyClaims;
                }

                return 1;
            }
            else // Not all, means we need to check that match between the user's claim
                 //and the policy claim
            {
                if (policyValuesArray.Contains("all"))
                {
                    var numOfUserClaims = userClaimValuesArray.Count();
                    if (numOfUserClaims > 0)
                    {
                        return numOfUserClaims;
                    }

                    return 1;
                }
                else
                {
                    return userClaimValuesArray.Intersect(policyValuesArray).ToList().Count;
                }
            }
        }

        public static string[] SplitString(string original)
        {
            if (string.IsNullOrEmpty(original))
            {
                return new string[0];
            }

            char[] splitParameter = new char[] { ',' };

            IEnumerable<string> strs =
                from piece in original.Split(splitParameter)
                let trimmed = piece.Trim().ToLower()
                where !string.IsNullOrEmpty(trimmed)
                select trimmed;

            return strs.ToArray<string>();
        }

        public static string GetUserLoginId(ClaimsIdentity identity)
        {
            //care_type of the current user
            var logInUserClaim = identity.Claims.Where(c => c.Type == BoClaimTypes.LoginId).FirstOrDefault();

            if (logInUserClaim != null)
            {
                return logInUserClaim.Value;
            }

            return string.Empty;
        }
    }
}