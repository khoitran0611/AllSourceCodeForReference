﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Security
{
    using Microsoft.AspNet.Identity;
    using Microsoft.AspNet.Identity.Owin;
    using Microsoft.Owin;
    using Microsoft.Owin.Security;
    using Models;
    using MySql.AspNet.Identity;
    using System;
    using System.Security.Claims;
    using System.Threading.Tasks;

    /// <summary>
    /// Configure the application sign-in manager which is used in this application.
    /// </summary>
    public class ApplicationSignInManager : SignInManager<ApplicationUser, string>
    {
        public ApplicationSignInManager(ApplicationUserManager userManager, IAuthenticationManager authenticationManager)
            : base(userManager, authenticationManager)
        {
        }

        public override Task<ClaimsIdentity> CreateUserIdentityAsync(ApplicationUser user)
        {
            if (user == null) return null;

            return user.GenerateUserIdentityAsync((ApplicationUserManager)UserManager);
        }

        public static ApplicationSignInManager Create(IdentityFactoryOptions<ApplicationSignInManager> options, IOwinContext context)
        {
            if (context == null) return null;

            return new ApplicationSignInManager(context.GetUserManager<ApplicationUserManager>(), context.Authentication);
        }

        public override async Task<SignInStatus> PasswordSignInAsync(string userName, string password, bool isPersistent, bool shouldLockout)
        {
            var status = SignInStatus.Failure;
            var userByName = await UserManager.FindByNameAsync(userName);
            var loggedInSucceeded = false;

            if (userByName != null)
            {
                var isLockedOut = DateTime.Now <= userByName.LockoutEndDate;
                var lockedOutEnabled = UserManager.GetLockoutEnabled(userByName.Id);

                //TODO: Find out reason why need to create new manager object or the Update method
                //is not called. Still not call Update when call to db 1 time to get user
                var manager = new ApplicationUserManager(new BoMySqlUserStore<ApplicationUser>());
                manager.UserLockoutEnabledByDefault = UserManager.UserLockoutEnabledByDefault;
                manager.DefaultAccountLockoutTimeSpan = UserManager.DefaultAccountLockoutTimeSpan;
                manager.MaxFailedAccessAttemptsBeforeLockout = UserManager.MaxFailedAccessAttemptsBeforeLockout;
                manager.PasswordHasher = UserManager.PasswordHasher;

                var inputHashPassword = manager.PasswordHasher.HashPassword(password);
                loggedInSucceeded = manager.PasswordHasher.
                                    VerifyHashedPassword(inputHashPassword, userByName.PasswordHash)
                                    == PasswordVerificationResult.Success;

                if (isLockedOut)
                {
                    //Still increase the total fail count if login fail
                    if (!loggedInSucceeded)
                    {
                        userByName.TotalAccessFailedCount++;
                        manager.Update(userByName);
                    }

                    return SignInStatus.LockedOut;
                }
                else
                {
                    if (shouldLockout)
                    {
                        //LockedOut is enable and the user login fails
                        if (lockedOutEnabled && !loggedInSucceeded)
                        {
                            if(userByName.LockoutEndDate != null && userByName.LockoutEndDate < DateTime.Now
                                && userByName.TotalFailedCountAfterLockOutPeriod == 0)
                            {
                                userByName.AccessFailedCount = 0;
                            }

                            //Increase the AccessFailedCount and TotalAccessFailedCount each time the login access failed
                            userByName.AccessFailedCount++;
                            userByName.TotalFailedCountAfterLockOutPeriod++;
                            userByName.TotalAccessFailedCount++;

                            var accessFailedCountAfterLockOutPeriod = userByName.TotalFailedCountAfterLockOutPeriod;
                            var attemptsLeft = manager.MaxFailedAccessAttemptsBeforeLockout - accessFailedCountAfterLockOutPeriod;
                            manager.Update(userByName);

                            //If the number of login fails count has reached, return the LockedOut status
                            if (attemptsLeft <= 0)
                            {
                                var lockedOutEndDate = DateTime.Now.Add(manager.DefaultAccountLockoutTimeSpan);
                                userByName.LockoutEndDate = lockedOutEndDate;
                                userByName.TotalFailedCountAfterLockOutPeriod = 0;

                                manager.Update(userByName);

                                return SignInStatus.LockedOut;
                            }
                        }
                    }
                }

                if (loggedInSucceeded)
                {
                    var userIdentity = await CreateUserIdentityAsync(userByName);

                    AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
                    AuthenticationManager.SignIn(new AuthenticationProperties { IsPersistent = isPersistent }, userIdentity);

                    //After user loged in sucessfully,
                    //reset the AccessFailedCount and LockedOutEndDate
                    userByName.AccessFailedCount = 0;
                    userByName.TotalFailedCountAfterLockOutPeriod = 0;
                    userByName.LockoutEndDate = null;

                    manager.Update(userByName);

                    status = SignInStatus.Success;
                }
            }

            return status;
        }
    }
}