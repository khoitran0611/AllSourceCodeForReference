﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Security
{
    using Newtonsoft.Json;
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Claims;
    using System.Web;
    using System.Web.Mvc;
    using System.Web.Routing;

    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1813:AvoidUnsealedAttributes")]
    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, Inherited = true, AllowMultiple = true)]
    public class ClaimsAuthorizeAttribute : AuthorizeAttribute
    {
        protected const string DefaultRedirectUrl = "~/Error/Unauthorized";

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Performance", "CA1819:PropertiesShouldNotReturnArrays")]
        public string[] Claims { get; set; }

        public string RedirectUrl { get; set; }

        public string Controller { get; set; }

        public string Action { get; set; }

        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            if (httpContext == null)
            {
                throw new ArgumentNullException("httpContext");
            }

            // check the basic authorization
            if (base.AuthorizeCore(httpContext) == false) return false;

            var identity = (ClaimsIdentity)httpContext.User.Identity;
            var countsMatch = 0;

            if (this.Claims != null && this.Claims.Length > 0)
            {
                //no claims to validate
                if (identity == null || identity.Claims.Count() == 0) return false;

                var userClaimSet = identity.Claims.Select(c => c.Type);

                for (int i = 0; i < Claims.Length - 1; i += 2)
                {
                    var policyClaimType = Claims[i];
                    var policyClaimValue = Claims[i + 1].ToLower();

                    var userClaim = identity.Claims.Where(c => c.Type == policyClaimType).FirstOrDefault();
                    var userClaimValues = userClaim != null ? userClaim.Value.ToLower() : string.Empty;

                    countsMatch = SecurityPermissionHelper.ClaimValuesMatch(policyClaimValue, userClaimValues);
                    if (countsMatch == 0) return false;
                }
            }

            return true;
        }

        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            if (filterContext == null)
            {
                throw new ArgumentNullException("filterContext");
            }

            if (!filterContext.HttpContext.Request.IsAuthenticated)
            {
                base.HandleUnauthorizedRequest(filterContext);
                return;
            }

            if (!string.IsNullOrWhiteSpace(this.Controller) && !string.IsNullOrWhiteSpace(this.Action))
            {
                var values = new RouteValueDictionary(new
                {
                    controller = this.Controller,
                    action = this.Action,
                    data = JsonConvert.SerializeObject(filterContext.ActionDescriptor)
                });

                filterContext.Result = new RedirectToRouteResult(values);
            }
            else
            {
                filterContext.Result = new RedirectResult(
                    string.IsNullOrWhiteSpace(this.RedirectUrl) ? DefaultRedirectUrl : this.RedirectUrl);
            }
        }

        protected static string[] SplitString(string original)
        {
            if (string.IsNullOrEmpty(original))
            {
                return new string[0];
            }

            char[] splitParameter = new char[] { ',' };

            IEnumerable<string> strs =
                from piece in original.Split(splitParameter)
                let trimmed = piece.Trim()
                where !string.IsNullOrEmpty(trimmed)
                select trimmed;

            return strs.ToArray<string>();
        }
    }
}