﻿
CREATE TABLE IF NOT EXISTS `aspnetroles` (
    `Id` VARCHAR(128) NOT NULL,
    `Name` VARCHAR(256) NOT NULL,
    PRIMARY KEY (`Id`)
)  DEFAULT CHARSET=LATIN1;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `aspnetuserclaims` (
    `Id` INT(11) NOT NULL AUTO_INCREMENT,
    `UserId` VARCHAR(128) NOT NULL,
    `ClaimType` LONGTEXT,
    `ClaimValue` LONGTEXT,
    PRIMARY KEY (`Id`),
    UNIQUE KEY `Id` (`Id`),
    KEY `UserId` (`UserId`)
)  DEFAULT CHARSET=LATIN1 AUTO_INCREMENT=1;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `aspnetuserlogins` (
    `LoginProvider` VARCHAR(128) NOT NULL,
    `ProviderKey` VARCHAR(128) NOT NULL,
    `UserId` VARCHAR(128) NOT NULL,
    PRIMARY KEY (`LoginProvider` , `ProviderKey` , `UserId`),
    KEY `ApplicationUser_Logins` (`UserId`)
)  DEFAULT CHARSET=LATIN1;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `aspnetuserroles` (
    `UserId` VARCHAR(128) NOT NULL,
    `RoleId` VARCHAR(128) NOT NULL,
    PRIMARY KEY (`UserId` , `RoleId`),
    KEY `IdentityRole_Users` (`RoleId`)
)  DEFAULT CHARSET=LATIN1;

-- --------------------------------------------------------

CREATE TABLE IF NOT EXISTS `aspnetusers` (
    `Id` VARCHAR(128) NOT NULL,
    `Email` VARCHAR(256) DEFAULT NULL,
    `EmailConfirmed` TINYINT(1) NOT NULL,
    `PasswordHash` LONGTEXT,
    `SecurityStamp` LONGTEXT,
    `PhoneNumber` LONGTEXT,
    `PhoneNumberConfirmed` TINYINT(1) NOT NULL,
    `TwoFactorEnabled` TINYINT(1) NOT NULL,
    `LockoutEndDateUtc` DATETIME DEFAULT NULL,
    `LockoutEnabled` TINYINT(1) NOT NULL,
    `AccessFailedCount` INT(11) NOT NULL,
    `UserName` VARCHAR(256) NOT NULL,
    PRIMARY KEY (`Id`)
)  DEFAULT CHARSET=LATIN1;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `aspnetuserclaims`
--
ALTER TABLE `aspnetuserclaims`
  ADD CONSTRAINT `ApplicationUser_Claims` FOREIGN KEY (`UserId`) REFERENCES `aspnetusers` (`Id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `aspnetuserlogins`
--
ALTER TABLE `aspnetuserlogins`
  ADD CONSTRAINT `ApplicationUser_Logins` FOREIGN KEY (`UserId`) REFERENCES `aspnetusers` (`Id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `aspnetuserroles`
--
ALTER TABLE `aspnetuserroles`
  ADD CONSTRAINT `ApplicationUser_Roles` FOREIGN KEY (`UserId`) REFERENCES `aspnetusers` (`Id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `IdentityRole_Users` FOREIGN KEY (`RoleId`) REFERENCES `aspnetroles` (`Id`) ON DELETE CASCADE ON UPDATE NO ACTION;
