﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne
{
    using Microsoft.AspNet.Identity;
    using System;
    using System.Configuration;
    using System.Linq;
    using System.Net.Mail;
    using System.Threading.Tasks;

    /// <summary>
    ///
    /// </summary>
    public class EmailService : IIdentityMessageService
    {
        public Task SendAsync(IdentityMessage message)
        {
            // Plug in your email service here to send an email.
            return Task.FromResult(0);
        }

        public static void SendMail(string subject, string body, string to, string ccs)
        {
            SendMail(subject, body, to, ccs, string.Empty);
        }

        public static void SendMail(string subject, string body, string to, string ccs, string bccs)
        {
            string username = ConfigurationManager.AppSettings["smtp.username"];
            SmtpClient smtpClient = new SmtpClient(ConfigurationManager.AppSettings["smtp.host"],
                int.Parse(ConfigurationManager.AppSettings["smtp.port"]));

            smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["smtp.ssl"]);

            if (!string.IsNullOrEmpty(username))
            {
                smtpClient.UseDefaultCredentials = false;
                smtpClient.Credentials = new System.Net.NetworkCredential(username,
                    ConfigurationManager.AppSettings["smtp.password"]);
            }

            var message = new MailMessage();
            message.From = new MailAddress(ConfigurationManager.AppSettings["smtp.from"]);
            message.Subject = subject;
            message.Body = body;

            if (!string.IsNullOrEmpty(to))
            {
                to = to.Replace(';', ',');
                string[] toAddress = to.Split(',');

                foreach (string t in toAddress.Where(t => !string.IsNullOrEmpty(t.Trim())))
                {
                    message.To.Add(new MailAddress(t.Trim()));
                }
            }

            if (!string.IsNullOrEmpty(ccs))
            {
                ccs = ccs.Replace(';', ',');
                string[] ccAddress = ccs.Split(',');
                foreach (string t in ccAddress.Where(t => !string.IsNullOrEmpty(t.Trim())))
                {
                    message.CC.Add(new MailAddress(t.Trim()));
                }
            }

            if (!string.IsNullOrEmpty(bccs))
            {
                bccs = bccs.Replace(';', ',');
                string[] bccAddress = bccs.Split(',');
                foreach (string t in bccAddress.Where(t => !string.IsNullOrEmpty(t.Trim())))
                    message.Bcc.Add(new MailAddress(t.Trim()));
            }

            smtpClient.Send(message);
        }

        public static void SendMail(string toEmail, string subject, string mailContent)
        {
            var smtpClient = new SmtpClient
                    (
                        ConfigurationManager.AppSettings["smtp.host"],
                        int.Parse(ConfigurationManager.AppSettings["smtp.port"])
                    );

            smtpClient.EnableSsl = Convert.ToBoolean(ConfigurationManager.AppSettings["smtp.ssl"]);
            smtpClient.UseDefaultCredentials = false;
            smtpClient.Credentials = new System.Net.NetworkCredential(ConfigurationManager.AppSettings["smtp.username"], ConfigurationManager.AppSettings["smtp.password"]);

            var message = new MailMessage();

            message.From = new MailAddress(ConfigurationManager.AppSettings["smtp.from"]);
            message.Subject = subject;
            message.Body = mailContent;
            message.IsBodyHtml = true;
            message.To.Add(new MailAddress(toEmail.Trim()));

            smtpClient.Send(message);
        }
    }
}