﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Services
{
    using BinderOne.Common.Security;
    using EF;
    using Models;
    using Models.AddionalContract;
    using Models.Document;
    using Models.EvaluateContract;
    using Security;
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;
    using System.Data.Entity.Validation;
    using System.Linq;
    using System.Security.Claims;
    using Action = Models.Action;
    using BoClaimTypes = BinderOne.Common.Security.ClaimTypes;
    using SysClaimTypes = System.Security.Claims.ClaimTypes;

    public class DataProvider
    {
        public BinderOneEntities DbContext { get; set; }

        public ICollection<string> GetMemberFacilities(ClaimsIdentity identity)
        {
            var result = new List<string>();
            if (identity == null) return result;

            var userId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.Sid), SysClaimTypes.Sid);
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            if (userId == 0) return result;

            var levelClaim = identity.Claims.FirstOrDefault(c => c.Type == BoClaimTypes.AccessLevel);
            if (levelClaim != null && (ClaimValues.All == levelClaim.Value || ClaimValues.Corporate == levelClaim.Value))
            {
                var corpFacilities = DbContext.facilities.Where(f => f.corp_ID == corpId);
                return corpFacilities.Select(f => f.Facility1 ?? " ").Distinct().ToList();
            }

            var facilities = DbContext.login_facs.Where(f => f.login_id == userId);
            if (facilities.Where(f => "All".Equals(f.facility, StringComparison.CurrentCultureIgnoreCase)).Count() > 0 && corpId > 0)
            {
                var corpFacilities = DbContext.facilities.Where(f => f.corp_ID == corpId);
                return corpFacilities.Select(f => f.Facility1 ?? " ").Distinct().ToList();
            }
            else
            {
                return facilities.Select(f => f.facility ?? " ").Distinct().ToList();
            }
        }

        public ICollection<string> GetMemberDepartments(ClaimsIdentity identity)
        {
            var result = new List<string>();

            if (identity == null) return result;

            var userId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.Sid), SysClaimTypes.Sid);
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            if (userId == 0) return result;

            var departments = DbContext.login_dept.Where(d => d.Login_ID == userId);

            if (departments.Where(d => "All".Equals(d.Department, StringComparison.CurrentCultureIgnoreCase)).Count() > 0 && corpId > 0)
            {
                var corpDepartments = DbContext.login_dept.Where(d => d.member_ID == corpId && !"All".Equals(d.Department, StringComparison.CurrentCultureIgnoreCase));
                return corpDepartments.Select(d => d.Department ?? " ").Distinct().ToList();
            }
            else
            {
                return departments.Select(d => d.Department ?? " ").Distinct().ToList();
            }
        }

        public ICollection<string> GetMemberContractTypes(ClaimsIdentity identity)
        {
            var result = new List<string>();

            if (identity == null) return result;

            var userId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.Sid), SysClaimTypes.Sid);
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            var contractTypes = DbContext.contract_type.Where(c => c.login_ID == userId).Select(c => c.contract_type1);
            var contracts = DbContext.umc_contracts.Where(c => c.corp_ID == corpId);

            if (!contractTypes.Contains("All")) //Not SuperAdmin, return only the data user can see
            {
                contracts = GetContractsOnUserAndCorp(userId, corpId);
            }

            result = contracts.Select(c => c.Contract_Type ?? " ").Distinct().ToList();

            return result.Where(e => !string.IsNullOrEmpty(e) && e != " ").ToList();
        }

        public ICollection<string> GetContractVendors(ClaimsIdentity identity)
        {
            var result = new List<string>();

            if (identity == null) return result;

            var userId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.Sid), SysClaimTypes.Sid);
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            if (corpId == 0) return result;

            //Get only data that user can see
            var vendors = GetContractsOnUserAndCorp(userId, corpId).Where(c => c.Contract_status == "Completed");

            return vendors.Select(c => c.Vendor ?? " ").Distinct().ToList();
        }

        public ContractSearchResultViewModel GetContractSummaries(ClaimsIdentity identity, ContractSearchCriteriaViewModel criteria)
        {
            var result = new ContractSearchResultViewModel { ContractSummaries = new List<ContractSummary>() };

            if (identity == null) return result;

            var userId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.Sid), SysClaimTypes.Sid);
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            if (corpId == 0) return result;

            criteria = criteria ?? new ContractSearchCriteriaViewModel();

            //main query
            var contractEntities = GetContractsOnUserAndCorp(userId, corpId);

            //filter by mode
            result.SearchMode = criteria.SearchMode;
            contractEntities = FilterBySearchMode(contractEntities, identity, criteria.SearchMode);

            //filters
            contractEntities = FilterByCriteria(contractEntities, criteria);

            //sorting
            result.SortedBy = criteria.SortedBy;
            result.SortedDescending = criteria.SortedDescending;
            contractEntities = SortByField(contractEntities, (criteria.SortedBy ?? "ID").ToLowerInvariant(), criteria.SortedDescending);

            //paging
            result.TotalCount = contractEntities.Count();
            result.PageSize = criteria.PageSize;
            result.PageIndex = criteria.PageIndex;

            var skipCount = criteria.PageIndex * criteria.PageSize;
            var takeCount = criteria.PageSize;

            if (skipCount > 0) contractEntities = contractEntities.Skip(skipCount);
            if (takeCount > 0) contractEntities = contractEntities.Take(takeCount);

            //result
            result.ContractSummaries = contractEntities.Select(c => new ContractSummary
            {
                Id = c.ID,
                ContractType = c.Contract_Type,
                Department = c.Department,
                EffectiveDate = c.Effective_Date,
                ExpirationDate = c.Expiration_Date,
                Facility = c.facility,
                HeaderNotes = c.Header_Notes1,
                OigExclusion = string.Compare(c.oig_bad, "Y", true) == 0 ? true : false,
                RenewalType = c.Renewal_Type,
                Vendor = c.Vendor
            }).ToList();

            return result;
        }

        public ICollection<Claim> ConvertLegacyRightsToClaims(long logOnId, long corpId)
        {
            var claims = new List<Claim>();
            var login = DbContext.logins.Where(l => l.ID == logOnId).FirstOrDefault();
            var member = DbContext.members.Where(m => m.ID == corpId).FirstOrDefault();
            if (login != null)
            {
                var userRights = ProcessUserRights(login.A_level);

                claims.Add(new Claim(BoClaimTypes.AccessLevel, login.access_level));
                claims.Add(new Claim(SysClaimTypes.Email, login.email));
                claims.Add(new Claim(BoClaimTypes.LoginUserName, login.Name));
                claims.Add(new Claim(BoClaimTypes.UserRights, userRights));
                claims.Add(new Claim(BoClaimTypes.LoginId, login.ID.ToString()));
                claims.Add(new Claim(BoClaimTypes.FacilityId, login.fac_ID.ToString()));
            }

            if (member != null && member.care_type != null)
            {
                var careType = member.care_type;
                if (careType == ClaimValues.CareType_Both || careType == ClaimValues.All)
                {
                    careType = ClaimValues.All;
                }

                claims.Add(new Claim(BoClaimTypes.CorpProductType, careType));
            }

            return claims;
        }

        public string GetCompanyName(long userId)
        {
            return DbContext.logins.FirstOrDefault(l => l.ID == userId).corp;
        }

        public umc_contracts_setup GetContractSetup(ClaimsIdentity identity)
        {
            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            return DbContext.umc_contracts_setup.FirstOrDefault(r => r.corp_ID == corpId);
        }

        public umc_contracts GetContract(ClaimsIdentity identity, int contractId)
        {
            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            return DbContext.umc_contracts.FirstOrDefault(r => r.ID == contractId && r.corp_ID == corpId);
        }

        public umc_contracts SaveContract(ClaimsIdentity identity, umc_contracts contract)
        {
            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);
            var login = identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.Name).Value;

            if (string.IsNullOrWhiteSpace(login))
            {
                //TODO: must not be. log the event
                return null;
            }

            var contractToBeUpdated = DbContext.umc_contracts.FirstOrDefault(c => c.ID == contract.ID && c.corp_ID == corpId);

            if (contractToBeUpdated == null) return null;

            try
            {
                //save editable fields
                MergeModifiedFields(contractToBeUpdated, contract);
                contractToBeUpdated.updated_by = login;

                var count = DbContext.SaveChanges();
                if (count == 0)
                {
                    //TODO: the update does not work. log the event
                    return null;
                }

                return contractToBeUpdated;
            }
            catch (Exception)
            {
                //TODO: log the exception
                return null;
            }
        }

        public umc_contracts_new CreateNewContract(ClaimsIdentity identity, umc_contracts_new newContract)
        {
            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);
            var login = identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.Name).Value;

            newContract.updated_by = login;
            newContract.uploaded_by = login;
            newContract.corp_ID = corpId;
            newContract.corp = new UserContext().CompanyName;

            //Data from newContract setup
            var contractSetup = DbContext.umc_contracts_setup.Where(s => s.corp_ID == corpId).FirstOrDefault();

            newContract.X_Company = contractSetup.X_Company;
            newContract.X_Facility = contractSetup.X_Facility;
            newContract.X_Vendor = contractSetup.X_Vendor;
            newContract.X_Contract_Type = contractSetup.X_Contract_Type;
            newContract.X_Services_Provided = contractSetup.X_Services_Provided;
            newContract.X_Contract_Type = contractSetup.X_Contract_Type;
            newContract.X_Department = contractSetup.X_Department;
            newContract.X_Effective_Date = contractSetup.X_Effective_Date;
            newContract.X_Expiration_Date = contractSetup.X_Expiration_Date;
            newContract.X_ExpriationNotifyPriorDays = contractSetup.X_ExpriationNotifyPriorDays;
            newContract.X_ExpirationNotifyAction = contractSetup.X_ExpirationNotifyAction;
            newContract.X_Renewal_Type = contractSetup.X_Renewal_Type;
            newContract.X_HeaderNotes = contractSetup.X_HeaderNotes;
            newContract.X_Termination_Provisions = contractSetup.X_Termination_Provisions;
            newContract.X_Renewal_Term = contractSetup.X_Renewal_Term;
            newContract.X_num_Renewals = contractSetup.X_num_Renewals;
            newContract.X_RP_name = contractSetup.X_RP_name;
            newContract.X_RP_title = contractSetup.X_RP_title;
            newContract.X_RP_email = contractSetup.X_RP_email;
            newContract.X_RP_name2 = contractSetup.X_RP_name2;
            newContract.X_RP_title2 = contractSetup.X_RP_title2;
            newContract.X_RP_email2 = contractSetup.X_RP_email2;
            newContract.X_RP_email3 = contractSetup.X_RP_email3;
            newContract.X_RP_name3 = contractSetup.X_RP_name3;
            newContract.X_RP_title3 = contractSetup.X_RP_title3;
            newContract.X_cost_month = contractSetup.X_cost_month;
            newContract.X_contact_name = contractSetup.X_contact_name;
            newContract.X_contact_address = contractSetup.X_contact_address;
            newContract.X_contact_email = contractSetup.X_contact_email;
            newContract.X_contact_phone = contractSetup.X_contact_phone;
            newContract.X_contact_fax = contractSetup.X_contact_fax;
            newContract.X_contact_phone2 = contractSetup.X_contact_phone2;
            newContract.X_Fully_Executed = contractSetup.X_Fully_Executed;
            newContract.X_signedby = contractSetup.X_signedby;
            newContract.X_signedby_title = contractSetup.X_signedby_title;
            newContract.X_tax_ID = contractSetup.X_tax_ID;
            newContract.X_BR_Date = contractSetup.X_BR_Date;
            newContract.X_BR_NotifyPriorDays = contractSetup.X_BR_NotifyPriorDays;
            newContract.X_BR_action = contractSetup.X_BR_action;
            newContract.X_QI = contractSetup.X_QI;
            newContract.X_Liability_Amt = contractSetup.X_Liability_Amt;
            newContract.X_CIS_date = contractSetup.X_CIS_date;
            newContract.X_CIS = contractSetup.X_CIS;
            newContract.X_CIS_NotifyPriorDays = contractSetup.X_CIS_NotifyPriorDays;
            newContract.X_CIS_action = contractSetup.X_CIS_action;
            newContract.X_WC = contractSetup.X_WC;
            newContract.X_WC_date = contractSetup.X_WC_date;
            newContract.X_WC_NotifyPriorDays = contractSetup.X_WC_NotifyPriorDays;
            newContract.X_Hold_Harmless = contractSetup.X_Hold_Harmless;
            newContract.X_BS = contractSetup.X_BS;
            newContract.X_BS_lang = contractSetup.X_BS_lang;
            newContract.X_TP = contractSetup.X_TP;
            newContract.X_TP_lang = contractSetup.X_TP_lang;
            newContract.X_COS1 = contractSetup.X_COS1;
            newContract.X_COS_lang = contractSetup.X_COS_lang;
            newContract.X_federally_funded = contractSetup.X_federally_funded;
            newContract.X_federally_funded_lang = contractSetup.X_federally_funded_lang;
            newContract.X_Accreditation = contractSetup.X_Accreditation;
            newContract.X_Accreditation_lang = contractSetup.X_Accreditation_lang;
            newContract.X_insurance_requirements = contractSetup.X_insurance_requirements;
            newContract.X_insurance_requirements_lang = contractSetup.X_insurance_requirements_lang;
            newContract.X_WC_action = contractSetup.X_WC_action;
            newContract.status = "New File";
            newContract.C_status = "new_doc";

            try
            {
                var newContractCreated = DbContext.umc_contracts_new.Add(newContract);

                var count = DbContext.SaveChanges();
                if (count == 0)
                {
                    //TODO: the update does not work. log the event
                    return null;
                }

                return newContract;
            }
            catch (Exception)
            {
                //TODO: log the exception
                return null;
            }
        }

        #region Helper Methods

        public static int GetClaimId(Claim claim, string type)
        {
            if (claim == null || claim.Type != type) return 0;

            var id = 0;

            if (string.IsNullOrWhiteSpace(claim.Value) || int.TryParse(claim.Value, out id) == false)
            {
                //TODO: log a warning for application troubleshooting
                return 0;
            }
            else
            {
                return id;
            }
        }

        private static IQueryable<umc_contracts> FilterBySearchMode(IQueryable<umc_contracts> contractEntities, ClaimsIdentity identity, SearchMode mode)
        {
            if (identity == null) return contractEntities;

            var userEmail = identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.Email).Value;
            switch (mode)
            {
                case SearchMode.Expiring:
                    contractEntities = contractEntities.Where(c =>
                        c.Contract_status == Status.Completed &&
                        (c.ExpirationNotifyAction == Action.SendEmail || c.BR_action == Action.SendEmail || c.CIS_action == Action.SendEmail || c.WC_action == Action.SendEmail) &&
                        (c.RP_email == userEmail || c.RP_email2 == userEmail || c.RP_email3 == userEmail));
                    break;

                case SearchMode.Inactive:
                    contractEntities = contractEntities.Where(c => c.Contract_status == Status.Inactive);
                    break;

                default:
                    break;
            }

            return contractEntities;
        }

        private static IQueryable<umc_contracts> FilterByCriteria(IQueryable<umc_contracts> contractEntities, ContractSearchCriteriaViewModel criteria)
        {
            if (criteria == null) return contractEntities;

            if (string.IsNullOrWhiteSpace(criteria.ContractId))
            {
                if (string.Compare(criteria.Facility, "All", true) != 0)
                {
                    if (string.IsNullOrWhiteSpace(criteria.Facility)) criteria.Facility = null;
                    contractEntities = contractEntities.Where(c => c.facility == criteria.Facility);
                }

                if (string.Compare(criteria.Department, "All", true) != 0)
                {
                    if (string.IsNullOrWhiteSpace(criteria.Department)) criteria.Department = null;
                    contractEntities = contractEntities.Where(c => c.Department == criteria.Department);
                }

                if (string.IsNullOrWhiteSpace(criteria.VendorMatch))
                {
                    if (string.Compare(criteria.Vendor, "All", true) != 0)
                    {
                        if (string.IsNullOrWhiteSpace(criteria.Vendor)) criteria.Vendor = null;
                        contractEntities = contractEntities.Where(c => c.Vendor == criteria.Vendor);
                    }
                }
                else
                {
                    contractEntities = contractEntities.Where(c => c.Vendor.Contains(criteria.VendorMatch));
                }

                if (string.Compare(criteria.ContractType, "All", true) != 0)
                {
                    if (string.IsNullOrWhiteSpace(criteria.ContractType)) criteria.ContractType = null;
                    contractEntities = contractEntities.Where(c => c.Contract_Type == criteria.ContractType);
                }
            }
            else
            {
                var contractId = 0;
                if (!int.TryParse(criteria.ContractId, out contractId)) return contractEntities;

                contractEntities = contractEntities.Where(c => c.ID == contractId);
            }

            return contractEntities;
        }

        private static IQueryable<umc_contracts> SortByField(IQueryable<umc_contracts> contractEntities, string field, bool descending)
        {
            if (string.IsNullOrWhiteSpace(field)) return contractEntities;

            switch (field)
            {
                case "facility":
                    contractEntities = descending ? contractEntities.OrderByDescending(c => c.facility) : contractEntities.OrderBy(c => c.facility);
                    break;

                case "date_range":
                    contractEntities = descending ? contractEntities.OrderByDescending(c => c.Effective_Date) : contractEntities.OrderBy(c => c.Effective_Date);
                    break;

                case "vendor":
                    contractEntities = descending ? contractEntities.OrderByDescending(c => c.Vendor) : contractEntities.OrderBy(c => c.Vendor);
                    break;

                case "department":
                    contractEntities = descending ? contractEntities.OrderByDescending(c => c.Department) : contractEntities.OrderBy(c => c.Department);
                    break;

                case "contract_type":
                    contractEntities = descending ? contractEntities.OrderByDescending(c => c.Contract_Type) : contractEntities.OrderBy(c => c.Contract_Type);
                    break;

                case "id":
                default:
                    contractEntities = descending ? contractEntities.OrderByDescending(c => c.ID) : contractEntities.OrderBy(c => c.ID);
                    break;
            }

            return contractEntities;
        }

        private static void MergeModifiedFields(umc_contracts contractToBeUpdated, umc_contracts contract)
        {
            contractToBeUpdated.WC = contract.WC;
            contractToBeUpdated.CIS = contract.CIS;
            contractToBeUpdated.Vendor = contract.Vendor;
            contractToBeUpdated.Contract_Type = contract.Contract_Type;
            contractToBeUpdated.Department = contract.Department;
            contractToBeUpdated.Renewal_Type = contract.Renewal_Type;
            contractToBeUpdated.Renewal_Term = contract.Renewal_Term;
            contractToBeUpdated.num_Renewals = contract.num_Renewals;
            contractToBeUpdated.Effective_Date = contract.Effective_Date;
            contractToBeUpdated.Expiration_Date = contract.Expiration_Date;
            contractToBeUpdated.ExpriationNotifyPriorDays = contract.ExpriationNotifyPriorDays;
            contractToBeUpdated.ExpirationNotifyAction = contract.ExpirationNotifyAction;
            contractToBeUpdated.BR_Date = contract.BR_Date;
            contractToBeUpdated.BR_NotifyPriorDays = contract.BR_NotifyPriorDays;
            contractToBeUpdated.BR_action = contract.BR_action;
            contractToBeUpdated.CIS_date = contract.CIS_date;
            contractToBeUpdated.CIS_NotifyPriorDays = contract.CIS_NotifyPriorDays;
            contractToBeUpdated.CIS_action = contract.CIS_action;
            contractToBeUpdated.WC_date = contract.WC_date;
            contractToBeUpdated.WC_NotifyPriorDays = contract.WC_NotifyPriorDays;
            contractToBeUpdated.WC_action = contract.WC_action;
            contractToBeUpdated.extra_date = contract.extra_date;
            contractToBeUpdated.extraNotifyPriorDays = contract.extraNotifyPriorDays;
            contractToBeUpdated.Extra_action = contract.Extra_action;
            contractToBeUpdated.Services_Provided = contract.Services_Provided;
            contractToBeUpdated.Header_Notes1 = contract.Header_Notes1;
            contractToBeUpdated.Termination_Provisions = contract.Termination_Provisions;
            contractToBeUpdated.cost_month = contract.cost_month;
            contractToBeUpdated.Fully_Executed = contract.Fully_Executed;
            contractToBeUpdated.tax_ID = contract.tax_ID;
            contractToBeUpdated.signedby = contract.signedby;
            contractToBeUpdated.signedby_title = contract.signedby_title;
            contractToBeUpdated.Liability_Amt = contract.Liability_Amt;
            contractToBeUpdated.QI = contract.QI;

            contractToBeUpdated.new1 = contract.new1;
            contractToBeUpdated.new2 = contract.new2;
            contractToBeUpdated.new3 = contract.new3;
            contractToBeUpdated.new4 = contract.new4;
            contractToBeUpdated.new5 = contract.new5;
            contractToBeUpdated.new6 = contract.new6;
            contractToBeUpdated.new7 = contract.new7;
            contractToBeUpdated.new8 = contract.new8;
            contractToBeUpdated.new9 = contract.new9;
            contractToBeUpdated.new10 = contract.new10;

            contractToBeUpdated.RP_name = contract.RP_name;
            contractToBeUpdated.RP_title = contract.RP_title;
            contractToBeUpdated.RP_email = contract.RP_email;
            contractToBeUpdated.RP_name2 = contract.RP_name2;
            contractToBeUpdated.RP_title2 = contract.RP_title2;
            contractToBeUpdated.RP_email2 = contract.RP_email2;
            contractToBeUpdated.RP_name3 = contract.RP_name3;
            contractToBeUpdated.RP_title3 = contract.RP_title3;
            contractToBeUpdated.RP_email3 = contract.RP_email3;

            contractToBeUpdated.contact_name = contract.contact_name;
            contractToBeUpdated.contact_address = contract.contact_address;
            contractToBeUpdated.contact_email = contract.contact_email;
            contractToBeUpdated.contact_phone = contract.contact_phone;
            contractToBeUpdated.contact_fax = contract.contact_fax;
            contractToBeUpdated.contact_phone2 = contract.contact_phone2;
            contractToBeUpdated.contact_URL = contract.contact_URL;

            contractToBeUpdated.Hold_Harmless = contract.Hold_Harmless;
            contractToBeUpdated.BS = contract.BS;
            contractToBeUpdated.BS_lang = contract.BS_lang;
            contractToBeUpdated.TP = contract.TP;
            contractToBeUpdated.TP_lang = contract.TP_lang;
            contractToBeUpdated.COS1 = contract.COS1;
            contractToBeUpdated.COS_lang = contract.COS_lang;
            contractToBeUpdated.federally_funded = contract.federally_funded;
            contractToBeUpdated.federally_funded_lang = contract.federally_funded_lang;
            contractToBeUpdated.Accreditation = contract.Accreditation;
            contractToBeUpdated.Accreditation_lang = contract.Accreditation_lang;
            contractToBeUpdated.insurance_requirements = contract.insurance_requirements;
        }

        #endregion Helper Methods

        #region Evaluate Contract section

        public EvaluateContractViewModel GetEvaluateContract(ClaimsIdentity identity, int contractId, int evalId = 0)
        {
            if (identity == null) return null;

            var result = new EvaluateContractViewModel();

            var contract = DbContext.umc_contracts.Where(c => c.ID == contractId).FirstOrDefault();
            if (contract != null)
            {
                result.Contract = contract;
                var evalSetup = DbContext.nmc_eval_setup.Where(e => e.corp_ID == contract.corp_ID).FirstOrDefault();
                var contractSetup = DbContext.umc_contracts_setup.Where(e => e.corp_ID == contract.corp_ID).FirstOrDefault();
                var member = DbContext.members.Where(e => e.ID == contract.corp_ID).FirstOrDefault();
                var exContracts = DbContext.nmc_ex_contracts.Where(e => e.Contract_ID == contract.ID).ToList();

                if (evalId != 0) // for edit and view Evaluation
                {
                    var evaluation = DbContext.nmc_eval.Where(e => e.ID == evalId).FirstOrDefault();
                    result.Comments = evaluation.Comments;
                    result.Satisfactory = evaluation.Satisfactory;
                    result.Recommendation = evaluation.Recommendation;
                    result.F1 = evaluation.F1;
                    result.F2 = evaluation.F2;
                    result.F3 = evaluation.F3;
                    result.F4 = evaluation.F4;
                    result.F5 = evaluation.F5;

                    result.F6 = evaluation.F6;
                    result.F7 = evaluation.F7;
                    result.F8 = evaluation.F8;
                    result.F9 = evaluation.F9;
                    result.F10 = evaluation.F10;

                    result.F11 = evaluation.F11;
                    result.F12 = evaluation.F12;
                    result.F13 = evaluation.F13;
                    result.F14 = evaluation.F14;
                    result.F15 = evaluation.F15;

                    result.F16 = evaluation.F16;
                    result.F17 = evaluation.F17;
                    result.F18 = evaluation.F18;
                    result.F19 = evaluation.F19;
                    result.F20 = evaluation.F20;

                    result.F21 = evaluation.F21;
                    result.F22 = evaluation.F22;
                    result.F23 = evaluation.F23;
                    result.F24 = evaluation.F24;
                    result.F25 = evaluation.F25;
                }

                result.EvalSetUp = evalSetup;
                result.ContractSetup = contractSetup;
                result.EXContractsCount = exContracts != null ? exContracts.Count : 0;
            }

            return result;
        }

        public bool PopulateEvaluateContract(ClaimsIdentity identity, EvaluateContractViewModel evaluateContract)
        {
            nmc_eval nmcEval = null;

            if (evaluateContract.EvalId != 0) // we are in edit or View mode
            {
                nmcEval = DbContext.nmc_eval.Where(e => e.ID == evaluateContract.EvalId).FirstOrDefault();
            }
            else // Add new evaluate contract
            {
                nmcEval = new nmc_eval();
            }
            //Insert or update to database
            try
            {
                if (nmcEval != null)
                {
                    //Fill all needed data for nmc_eval
                    nmcEval.updated_by = identity != null ? identity.Name : "";
                    nmcEval.Comments = evaluateContract.Comments ?? string.Empty;
                    nmcEval.contract_ID = evaluateContract.Contract.ID;
                    nmcEval.start_date = evaluateContract.Contract.Effective_Date.HasValue ?
                    evaluateContract.Contract.Effective_Date.Value.ToString("d") : string.Empty;
                    nmcEval.Satisfactory = evaluateContract.Satisfactory;
                    nmcEval.Recommendation = evaluateContract.Recommendation;
                    nmcEval.F1 = evaluateContract.F1;
                    nmcEval.F2 = evaluateContract.F2;
                    nmcEval.F3 = evaluateContract.F3;
                    nmcEval.F4 = evaluateContract.F4;
                    nmcEval.F5 = evaluateContract.F5;
                    nmcEval.F6 = evaluateContract.F6;
                    nmcEval.F7 = evaluateContract.F7;
                    nmcEval.F8 = evaluateContract.F8;
                    nmcEval.F9 = evaluateContract.F9;
                    nmcEval.F10 = evaluateContract.F10;
                    nmcEval.F11 = evaluateContract.F11;
                    nmcEval.F12 = evaluateContract.F12;
                    nmcEval.F13 = evaluateContract.F13;
                    nmcEval.F14 = evaluateContract.F14;
                    nmcEval.F15 = evaluateContract.F15;
                    nmcEval.F16 = evaluateContract.F16;
                    nmcEval.F17 = evaluateContract.F17;
                    nmcEval.F18 = evaluateContract.F18;
                    nmcEval.F19 = evaluateContract.F19;
                    nmcEval.F20 = evaluateContract.F20;
                    nmcEval.F21 = evaluateContract.F21;
                    nmcEval.F22 = evaluateContract.F22;
                    nmcEval.F23 = evaluateContract.F23;
                    nmcEval.F24 = evaluateContract.F24;
                    nmcEval.F25 = evaluateContract.F25;

                    if (evaluateContract.EvalId == 0) //Create new evaluation
                    {
                        DbContext.nmc_eval.Add(nmcEval);
                    }

                    //If view or edit, just need to save the update.
                    DbContext.SaveChanges();
                    return true;
                }
            }
            catch (DbEntityValidationException)
            {
                return false;
            }

            return false;
        }

        #endregion Evaluate Contract section

        #region Additional Contract region

        public AdditionalContractViewModel GetAddionalContract(ClaimsIdentity identity, ContractPagingInfo pagingInfo)
        {
            if (identity == null) return null;

            var result = new AdditionalContractViewModel();

            var contract = DbContext.umc_contracts.Where(c => c.ID == pagingInfo.ContractId).FirstOrDefault();
            if (contract != null)
            {
                result.Contract = contract;
                var contractSetup = DbContext.umc_contracts_setup.Where(e => e.corp_ID == contract.corp_ID).FirstOrDefault();
                var exContracts = DbContext.nmc_ex_contracts.Where(e => e.Contract_ID == pagingInfo.ContractId).ToList();

                result.ContractSetup = contractSetup;
                result.ExContracts = exContracts;

                pagingInfo.TotalCount = result.ExContracts != null ? result.ExContracts.Count : 0;
            }

            if (result.ContractSetup == null) return null;

            //paging
            var skipCount = pagingInfo.PageIndex * pagingInfo.PageSize;
            var takeCount = pagingInfo.PageSize;

            if (skipCount > 0) result.ExContracts = result.ExContracts.Skip(skipCount).ToList();
            if (takeCount > 0) result.ExContracts = result.ExContracts.Take(takeCount).ToList();

            return result;
        }

        #endregion Additional Contract region

        #region Edit Document

        public nmc_ex_contracts GetExContract(ClaimsIdentity identity, int exContractId)
        {
            if (identity == null) return null;

            return DbContext.nmc_ex_contracts.Where(e => e.ID == exContractId).FirstOrDefault();
        }

        public bool UpdateExContractDescription(nmc_ex_contracts exContract, string description)
        {
            var exContractToUpdate = DbContext.nmc_ex_contracts.Where(e => e.ID == exContract.ID).FirstOrDefault();
            if (exContractToUpdate != null)
            {
                try
                {
                    exContractToUpdate.Description = description;
                    DbContext.SaveChanges();
                    return true;
                }
                catch (DbEntityValidationException)
                {
                    //Log exception here
                    return false;
                }
            }

            return false;
        }

        #endregion Edit Document

        #region View Document section

        public string GenerateToken(ClaimsIdentity identity, int exContractId, int contractId)
        {
            var fileExtension = string.Empty;
            var fileName = string.Empty;
            var ownerId = 0;
            var rsaTokenizer = new RsaTokenizer();

            var exContract = GetExContract(identity, exContractId);
            var contract = GetContract(identity, contractId);
            if (identity == null || (exContract == null && contract == null)) return string.Empty;

            if (exContract != null)
            {
                fileName = exContract.PDF;
                ownerId = exContract.corp_ID.HasValue ? exContract.corp_ID.Value : 0;
            }
            else if (contract != null)
            {
                fileName = contract.contract;
                ownerId = contract.corp_ID.HasValue ? contract.corp_ID.Value : 0;
            }
            if (fileName.Length > 0 && fileName.LastIndexOf('.') > 0)
            {
                fileExtension = fileName.Substring(fileName.LastIndexOf('.') + 1);
            }

            var documentInfo = new DocumentInfo()
            {
                ContentType = GetDocumentContentType(fileExtension),
                OwnerId = ownerId,
                FileName = fileName,
                IsExternal = false, /* Leave it false for now */
                Id = exContract != null ? exContract.ID : 0,
                ContractId = contractId,
                Uri = string.Empty /* leave it empty for now */
            };

            return rsaTokenizer.Encrypt(documentInfo);
        }

        public string GetDocumentContentType(string fileExtention)
        {
            var contentType = string.Empty;

            if (!string.IsNullOrEmpty(fileExtention))
            {
                switch (fileExtention.ToLower())
                {
                    case "jpg":
                        contentType = "image/jpeg";
                        break;

                    case "bmp":
                        contentType = "image/bmp";
                        break;

                    case "png":
                        contentType = "image/png";
                        break;

                    case "pdf":
                        contentType = "application/pdf";
                        break;

                    case "doc":
                        contentType = "application/msword";
                        break;

                    case "docx":
                        contentType = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
                        break;

                    case "ppt":
                        contentType = "application/vnd.ms-powerpoint";
                        break;

                    case "pptx":
                        contentType = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
                        break;

                    case "xls":
                        contentType = "application/vnd.ms-excel";
                        break;

                    case "xlsx":
                        contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                        break;

                    default:
                        contentType = string.Empty;
                        break;
                }
            }

            return contentType;
        }

        #endregion View Document section

        #region Log section

        public List<nmc_eval> GetEval(ClaimsIdentity identity, int contractId, ContractPagingInfo pagingInfo)
        {
            if (identity == null) return null;

            var result = DbContext.nmc_eval.Where(e => e.contract_ID == contractId).OrderByDescending(e => e.updated).ToList();

            //paging
            pagingInfo.TotalCount = result.Count;
            var skipCount = pagingInfo.PageIndex * pagingInfo.PageSize;
            var takeCount = pagingInfo.PageSize;

            if (skipCount > 0) result = result.Skip(skipCount).ToList();
            if (takeCount > 0) result = result.Take(takeCount).ToList();

            return result;
        }

        public List<umc_papertrail> GetPaperTrail(ClaimsIdentity identity, int contractId, ContractPagingInfo pagingInfo)
        {
            if (identity == null) return null;

            var result = DbContext.umc_papertrail.Where(e => e.contract_ID == contractId).OrderByDescending(e => e.event_date).ToList();

            //paging
            pagingInfo.TotalCount = result.Count;
            var skipCount = pagingInfo.PageIndex * pagingInfo.PageSize;
            var takeCount = pagingInfo.PageSize;

            if (skipCount > 0) result = result.Skip(skipCount).ToList();
            if (takeCount > 0) result = result.Take(takeCount).ToList();

            return result;
        }

        #endregion Log section

        public ICollection<string> GetRPNames(ClaimsIdentity identity, int facilityId)
        {
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            var result = new List<string>();

            if (identity == null) return result;
            var rpNames = new List<rp_list>();

            rpNames = DbContext.rp_list.Where(r => r.corp_ID == corpId).ToList();

            if (facilityId != 0)
            {
                rpNames = DbContext.rp_list.Where(r => r.Facility_ID == facilityId).ToList();
            }

            return rpNames.Select(r => r.RP_name ?? " ").Distinct().ToList();
        }

        public ICollection<string> GetRenewalTypes(ClaimsIdentity identity)
        {
            var result = new List<string>();

            if (identity == null) return result;

            //The legacy code populate data for select controls with hard coded values
            return new List<string>()
            {
                "Annual",
                "Monthly",
                "Evergreen"
            };
        }

        public ICollection<facility> GetFacilities(ClaimsIdentity identity)
        {
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);
            return DbContext.facilities.Where(f => f.corp_ID == corpId).ToList();
        }

        public facility GetFacilityById(int id)
        {
            return DbContext.facilities.Where(f => f.ID == id).FirstOrDefault();
        }

        public List<umc_contracts> GetVendorsAndContractTypes(ClaimsIdentity identity, int facilityId)
        {
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            return DbContext.umc_contracts.
                   Where(c => c.corp_ID.Value == corpId && c.facility_ID == facilityId)
                  .Distinct().OrderBy(c => c.Vendor).ToList();
        }

        public AttachDocumentSearchResultViewModel GetContractsToAttachDocument(ClaimsIdentity identity, AttachDocumentFilterViewModel criteria)
        {
            var result = new AttachDocumentSearchResultViewModel { ContractSearchResult = new List<umc_contracts>() };

            if (identity == null) return result;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            if (corpId == 0) return result;

            criteria = criteria ?? new AttachDocumentFilterViewModel();

            var facilityId = int.Parse(criteria.FacilityId);
            var vendor = criteria.Vendor ?? "";
            //main query
            var contractEntities = DbContext.umc_contracts.Where(c => c.corp_ID == corpId
                                    && c.facility_ID.Value == facilityId
                                    && c.Vendor == vendor).OrderBy(c => c.Vendor).ToList();

            //paging
            result.TotalCount = contractEntities.Count();
            result.PageSize = criteria.PageSize;
            result.PageIndex = criteria.PageIndex;

            var skipCount = criteria.PageIndex * criteria.PageSize;
            var takeCount = criteria.PageSize;

            if (skipCount > 0) contractEntities = contractEntities.Skip(skipCount).ToList();
            if (takeCount > 0) contractEntities = contractEntities.Take(takeCount).ToList();

            result.ContractSearchResult = contractEntities.ToList();

            return result;
        }

        public nmc_ex_contracts AddNewExContract(ClaimsIdentity identity, AttachDocumentDialogViewModel attachDocumentModel)
        {
            nmc_ex_contracts exContractDb = null;

            if (identity == null) return null;
            try
            {
                var exContract = new nmc_ex_contracts()
                {
                    Contract_ID = attachDocumentModel.Contract_ID,
                    PDF = attachDocumentModel.PDF,
                    Description = attachDocumentModel.Description,
                    corp_ID = attachDocumentModel.Corp_ID,
                    optimized = attachDocumentModel.Optimized,
                    uploaded = attachDocumentModel.Uploaded,
                    uploaded_by = attachDocumentModel.Uploaded_by
                };

                //Insert to DB
                exContractDb = DbContext.nmc_ex_contracts.Add(exContract);
                DbContext.SaveChanges();
            }
            catch (DbEntityValidationException)
            {
                return null;
            }

            return exContractDb;
        }

        public IQueryable<umc_contracts> GetContractsOnUserAndCorp(int userId, int corpId)
        {
            var contractTypes = DbContext.contract_type.Where(c => c.login_ID == userId).Select(c => c.contract_type1);
            var departments = DbContext.login_dept.Where(d => d.Login_ID == userId).Select(d => d.Department).ToList();
            var loginFacts = DbContext.login_facs.Where(d => d.login_id == userId).Select(d => d.facility).ToList();
            var contracts = DbContext.umc_contracts.Where(c => c.corp_ID == corpId);

            //All, mean superAdmin, return all the data
            if (!loginFacts.Contains("All"))
            {
                contracts = contracts.Where(c => (loginFacts.Contains(c.facility) || c.facility == "X"));
            }

            if (!departments.Contains("All"))
            {
                contracts = contracts.Where(ct => (departments.Contains(ct.Department) || ct.Department == "X"));
            }

            if (!contractTypes.Contains("All"))
            {
                contracts = contracts.Where(ct => (contractTypes.Contains(ct.Contract_Type) || ct.Contract_Type == "X"));
            }

            return contracts;
        }

        public string ProcessUserRights(string userRights)
        {
            if (string.IsNullOrEmpty(userRights))
            {
                return string.Empty;
            }
            else
            {
                return string.Join<char>(",", userRights);
            }
        }

        public umc_contracts DeleteContract(ClaimsIdentity identity, int contractId)
        {
            umc_contracts deletedContract = null;

            if (identity == null) return null;
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);
            try
            {
                //Delete contract from DB and for only the contract that the user can delete
                deletedContract = DbContext.umc_contracts.Where(c => c.ID == contractId && c.corp_ID == corpId).FirstOrDefault();
                if (deletedContract != null)
                {
                    deletedContract = DbContext.umc_contracts.Remove(deletedContract);
                    DbContext.SaveChanges();
                }
            }
            catch (DbEntityValidationException)
            {
                return null;
            }

            return deletedContract;
        }

        public UserSearchResultViewModel GetUserList(ClaimsIdentity identity, UserSearchResultViewModel model)
        {
            if (identity == null) return null;

            var result = new UserSearchResultViewModel
            {
                UserSearchResult = new List<login>(),
                PageSize = model.PageSize,
                PageIndex = model.PageIndex
            };

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);
            var userLoginId = long.Parse(SecurityPermissionHelper.GetUserLoginId(identity));

            var loginUser = DbContext.logins.Where(l => l.ID == userLoginId).FirstOrDefault();
            var facility = loginUser != null ? loginUser.Facility : string.Empty;

            result.UserSearchResult = DbContext.logins.Where(l => l.corp_ID == corpId).OrderBy(l => l.Name).ToList();

            var loginUsers = result.UserSearchResult;

            if (!string.IsNullOrEmpty(facility) && facility.ToLower() != "corporate")
            {
                loginUsers = loginUsers.Where(u => u.Facility.ToLower().Equals(facility.ToLower())).ToList();
            }

            //paging
            result.TotalCount = loginUsers.Count();

            var skipCount = result.PageIndex * result.PageSize;
            var takeCount = result.PageSize;

            if (skipCount > 0) loginUsers = loginUsers.Skip(skipCount).ToList();
            if (takeCount > 0) loginUsers = loginUsers.Take(takeCount).ToList();

            result.UserSearchResult = loginUsers.ToList();

            return result;
        }

        public ICollection<string> GetUserTypes(ClaimsIdentity identity)
        {
            var result = new List<string>();

            if (identity == null) return result;

            //The legacy code populate data for select controls with hard coded values
            return new List<string>()
            {
                "Super User",
                "User"
            };
        }

        public login PopulateLoginUser(ClaimsIdentity identity, UserViewModel userModel, ApplicationUserManager userManager)
        {
            login logIn = null;
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);
            var facility = GetFacilityById(userModel.Facility);
            var member = DbContext.members.Where(m => m.ID == corpId).FirstOrDefault();
            var memberId = member != null ? member.ID : 0;
            var facId = facility != null ? facility.ID : 0;

            if (userModel.ID == 0)
            {
                logIn = new login();
            }
            else
            {
                logIn = DbContext.logins.Where(l => l.ID == userModel.ID).FirstOrDefault();
            }

            logIn.ID = userModel.ID;
            logIn.Name = userModel.Name;
            logIn.login1 = userModel.Login;
            logIn.email = userModel.Email;
            logIn.password = userModel.Password;
            logIn.login_class = userModel.Login_Class;
            logIn.Facility = facility != null ? facility.Facility1 : string.Empty;
            logIn.corp = new UserContext().CompanyName;
            logIn.access_level = userModel.Access_Level;
            logIn.corp_ID = corpId;
            logIn.A_level = userModel.A_Level;
            logIn.care_type = userModel.Care_Type;

            //Add some default data
            logIn.fac_ID = facility != null ? (int)facility.ID : 0;
            logIn.cm = userModel.IsEmpCompManager == null ? "N" : userModel.IsEmpCompManager;
            logIn.account_type = "Clinic";
            logIn.view_all = "N";
            logIn.logins = 0;
            logIn.cm_logins = 0;
            logIn.nmc_logins = 0;
            logIn.c_logins = 0;
            logIn.del_ver = "N";
            logIn.oig = (userModel.CanDeleteOIG == null ? "N" : userModel.CanDeleteOIG);
            logIn.bad_logins = userModel.ID == 0 ? 0 : userModel.Bad_Logins;
            logIn.total_bad_logins = userModel.ID == 0 ? 0 : userModel.Total_Bad_Logins;
            logIn.admin = userModel.Administrator == null ? "N" : userModel.Administrator;

            try
            {
                if (userModel != null)
                {
                    //Fill all needed data for login
                    if (userModel.ID == 0) //Create new User
                    {
                        logIn = DbContext.logins.Add(logIn);
                    }
                    else
                    {
                        logIn.A_level = userModel.A_Level;
                        logIn.care_type = userModel.Care_Type;
                        logIn.corp = userModel.Corp;
                        logIn.bad_logins = userModel.Bad_Logins;

                        //Reset the LockOutEndDate if needed
                        if (userModel.Bad_Logins < userManager.MaxFailedAccessAttemptsBeforeLockout)
                        {
                            logIn.logins = userModel.Bad_Logins;
                            logIn.login_after1 = null;
                        }

                        List<login_dept> loginDepts = null;
                        if (logIn != null)
                        {
                            loginDepts = DbContext.login_dept.Where(d => d.Login_ID == (int)logIn.ID).ToList();
                        }

                        List<login_facs> loginFacs = null;
                        if (logIn != null)
                        {
                            loginFacs = DbContext.login_facs.Where(d => d.login_id == (int)logIn.ID).ToList();
                        }

                        List<contract_type> contractTypes = null;
                        if (logIn != null)
                        {
                            contractTypes = DbContext.contract_type.Where(ct => ct.login_ID == (int)logIn.ID).ToList();
                        }

                        //Delete all the data of Facility, Location and Department for the selected user first
                        foreach (var dept in loginDepts)
                        {
                            DbContext.Entry(dept).State = EntityState.Deleted;
                        }

                        foreach (var fac in loginFacs)
                        {
                            DbContext.Entry(fac).State = EntityState.Deleted;
                        }

                        foreach (var ct in contractTypes)
                        {
                            DbContext.Entry(ct).State = EntityState.Deleted;
                        }

                        DbContext.SaveChanges();
                    }

                    DbContext.SaveChanges();

                    char[] splitParameter = new char[] { ',' };

                    //Insert selected locations
                    var faclityIds = userModel.Facilities != null ? userModel.Facilities.Split(splitParameter) : null;
                    if (faclityIds != null)
                    {
                        foreach (var fac in faclityIds)
                        {
                            var insertedLoginFact = new login_facs()
                            {
                                corp_ID = userModel.ID == 0 ? (int)corpId : logIn.corp_ID,
                                facility = fac,
                                fac_ID = userModel.ID == 0 ? (int)facId : logIn.fac_ID,
                                login_id = (int)logIn.ID
                            };

                            DbContext.Entry(insertedLoginFact).State = EntityState.Added;
                        }
                    }

                    //Insert selected departments
                    var departmentIds = userModel.Departments != null ? userModel.Departments.Split(splitParameter) : null;

                    if (departmentIds != null)
                    {
                        foreach (var dept in departmentIds)
                        {
                            var insertedLoginDept = new login_dept()
                            {
                                Login_ID = (int)logIn.ID,
                                member_ID = (int)memberId,
                                Department = dept
                            };

                            DbContext.Entry(insertedLoginDept).State = EntityState.Added;
                        }
                    }

                    //Insert selected contractTypes
                    var strContractTypes = userModel.ContractTypes != null ? userModel.ContractTypes.Split(splitParameter) : null;
                    if (strContractTypes != null)
                    {
                        foreach (var ct in strContractTypes)
                        {
                            var insertedContractTypes = new contract_type()
                            {
                                login_ID = (int)logIn.ID,
                                member_ID = (int)memberId,
                                contract_type1 = ct
                            };

                            DbContext.Entry(insertedContractTypes).State = EntityState.Added;
                        }
                    }

                    DbContext.SaveChanges();

                    return logIn;
                }
            }
            catch (DbEntityValidationException)
            {
                return null;
            }

            return null;
        }

        public UserViewModel GetLoginUserById(ClaimsIdentity identity, int id)
        {
            UserViewModel user = null;
            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);
            var logIn = DbContext.logins.Where(l => l.ID == id && l.corp_ID == corpId).FirstOrDefault();

            if (logIn.login_after1 != null && logIn.login_after1 < DateTime.Now
                                && logIn.logins == 0)
            {
                logIn.bad_logins = 0;
            }

            DbContext.SaveChanges();

            if (logIn != null)
            {
                user = new UserViewModel()
                {
                    ID = (int)logIn.ID,
                    Name = logIn.Name,
                    Login = logIn.login1,
                    Email = logIn.email,
                    Password = logIn.password,
                    Login_Class = logIn.login_class,
                    Facility = logIn.fac_ID.HasValue ? logIn.fac_ID.Value : 0,
                    Corp = logIn.corp,
                    Access_Level = logIn.access_level,
                    Corp_ID = logIn.corp_ID.HasValue ? logIn.corp_ID.Value : 0,
                    Care_Type = logIn.care_type,
                    Bad_Logins = logIn.bad_logins != null ? logIn.bad_logins.Value : 0,
                    Total_Bad_Logins = logIn.total_bad_logins != null ? logIn.total_bad_logins.Value : 0,
                    A_Level = logIn.A_level.ToUpper(),
                    Administrator = logIn.admin.ToUpper(),
                    IsEmpCompManager = logIn.cm.ToUpper(),
                    CanDeleteOIG = logIn.oig.ToUpper()
                };
            }

            return user;
        }

        public login DeleteUser(ClaimsIdentity identity, int userId)
        {
            login deleteUser = null;

            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            try
            {
                //Delete user from DB for only those in the same corporation
                deleteUser = DbContext.logins.Where(c => c.ID == userId && c.corp_ID == corpId).FirstOrDefault();
                if (deleteUser != null)
                {
                    deleteUser = DbContext.logins.Remove(deleteUser);
                    DbContext.SaveChanges();
                }
            }
            catch (DbEntityValidationException)
            {
                return null;
            }

            return deleteUser;
        }

        public List<login> GetSelectedUsers(ClaimsIdentity identity, List<int> selectedIds)
        {
            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            return DbContext.logins.Where(l => selectedIds.Contains((int)l.ID) && l.corp_ID == corpId).ToList();
        }

        #region ManagedCare section

        public List<string> GetPlans(ClaimsIdentity identity)
        {
            var result = new List<string>();

            if (identity == null) return result;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            var plans = DbContext.contracts.
                Where(p => p.Corp_ID == corpId && p.Contract_status == "Completed")
                .Select(p => p.contract_plan).Distinct().ToList();

            return plans;
        }

        public List<string> GetProducts(ClaimsIdentity identity)
        {
            var result = new List<string>();

            if (identity == null) return result;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            if (corpId == 0) return result;

            var products = DbContext.contracts.Where(c => c.Corp_ID == corpId).OrderBy(c => c.Product);

            result = products.Select(p => p.Product).Distinct().ToList();

            return result;
        }

        public ManagedCareSearchResultViewModel GetContracts(ClaimsIdentity identity, ManagedCareSearchCriteriaViewModel criteria, bool searchByCriteria = false)
        {
            IQueryable<contract> contracts = null;

            var result = new ManagedCareSearchResultViewModel { ManagedCareContracts = new List<ManagedCareContractResult>() };

            if (identity == null) return result;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);
            var facilityIdClaim = identity.Claims.Where(c => c.Type == BoClaimTypes.FacilityId).FirstOrDefault();
            var userFacility = GetFacilityById(int.Parse(facilityIdClaim.Value));
            var facility = userFacility != null ? userFacility.Facility1 : "All";

            if (corpId == 0) return result;

            criteria = criteria ?? new ManagedCareSearchCriteriaViewModel();

            if (!searchByCriteria) criteria.Facility = facility;

            if (!string.IsNullOrEmpty(criteria.CompanyCode))
            {
                var ins_codes = DbContext.contract_ins_codes.
                    Where(i => i.INS_Code == criteria.CompanyCode && i.corp_ID == corpId).ToList();

                List<long?> contractInsCode = ins_codes.Select(i => i.Contract_ID).ToList();
                if (criteria.Facility.ToLowerInvariant() != "all")
                {
                    contractInsCode = new List<long?>();
                    foreach (var code in ins_codes)
                    {
                        if (GetFacilityById((int)code.Facility_code.Value).Facility1 == criteria.Facility)
                        {
                            contractInsCode.Add(code.Contract_ID.Value);
                        }
                    }
                }

                //main query
                contracts = DbContext.contracts.
                    Where(c => c.Corp_ID == corpId && contractInsCode.Contains(c.ID))
                    .OrderBy(c => c.Fac_Name).AsQueryable();
            }
            else
            {
                //main query
                contracts = DbContext.contracts.
                    Where(c => c.Corp_ID == corpId).OrderBy(c => c.Fac_Name).AsQueryable();
            }
            //filter by mode
            result.SearchMode = criteria.SearchMode;
            contracts = FilterMangedCareContractBySearchMode(contracts, identity, criteria.SearchMode);

            //filter by criteria
            if (!searchByCriteria) criteria.Facility = facility;

            contracts = FilterManagedCareContractsByCriteria(contracts, criteria);

            //sorting
            result.SortedBy = criteria.SortedBy;
            result.SortedDescending = criteria.SortedDescending;
            contracts = SortMangedCareByField(contracts, (criteria.SortedBy ?? "Facility").ToLowerInvariant(), criteria.SortedDescending);

            //paging
            result.TotalCount = contracts.Count();
            result.PageSize = criteria.PageSize;
            result.PageIndex = criteria.PageIndex;

            var skipCount = criteria.PageIndex * criteria.PageSize;
            var takeCount = criteria.PageSize;

            if (skipCount > 0) contracts = contracts.Skip(skipCount);
            if (takeCount > 0) contracts = contracts.Take(takeCount);

            var contractInsCodeList = DbContext.contract_ins_codes
                                     .Where(c => c.corp_ID == corpId).ToList();

            var contractResultList = new List<ManagedCareContractResult>();

            //Update the value for company code here
            foreach (var c in contracts)
            {
                var companyCode = string.Empty;

                foreach (var ins in contractInsCodeList)
                {
                    if (c.ID == ins.Contract_ID)
                    {
                        //Update value for the company code
                        companyCode += ins.INS_Code;
                        companyCode += ", ";
                    }
                }

                var contractResult = new ManagedCareContractResult
                {
                    Id = (int)c.ID,
                    Facility = c.Fac_Name,
                    Plan = c.contract_plan,
                    Product = c.Product,
                    CompanyCode = companyCode != "" ? companyCode.Substring(0, companyCode.Length - 2) : "",
                    Header = c.header_notes,
                    RenewalType = c.renew_type,
                    ReimbType = c.R_type,
                    StartDate = c.start_date,
                    EndDate = c.end_date,
                    ExpirationDate = c.expire_date
                };

                contractResultList.Add(contractResult);
            }

            result.ManagedCareContracts = contractResultList;

            return result;
        }

        public IQueryable<contract> GetManagedCareContracts(int corpId, string facilityName)
        {
            var contracts = DbContext.contracts.
                Where(c => c.Corp_ID == corpId && c.Fac_Name.ToLower().Equals(facilityName.ToLower()));

            return contracts;
        }

        private IQueryable<contract> FilterMangedCareContractBySearchMode(IQueryable<contract> contracts, ClaimsIdentity identity, SearchMode mode)
        {
            if (identity == null) return contracts;

            switch (mode)
            {
                case SearchMode.All:
                    contracts = contracts.Where(c => c.Contract_status == Status.Completed
                    || c.Contract_status == Status.Inactive);
                    break;

                case SearchMode.Inactive:
                    contracts = contracts.Where(c => c.Contract_status == Status.Inactive);
                    break;

                default:
                    break;
            }

            return contracts;
        }

        private IQueryable<contract> FilterManagedCareContractsByCriteria(IQueryable<contract> contracts, ManagedCareSearchCriteriaViewModel criteria)
        {
            if (criteria == null) return contracts;

            if (string.Compare(criteria.Facility, "All", true) != 0)
            {
                if (string.IsNullOrWhiteSpace(criteria.Facility)) criteria.Facility = null;
                contracts = contracts.Where(c => c.Fac_Name == criteria.Facility);
            }

            if (string.Compare(criteria.Plan, "All", true) != 0)
            {
                if (string.IsNullOrWhiteSpace(criteria.Plan)) criteria.Plan = null;
                contracts = contracts.Where(c => c.contract_plan == criteria.Plan);
            }

            if (string.Compare(criteria.Product, "All", true) != 0)
            {
                if (string.IsNullOrWhiteSpace(criteria.Product)) criteria.Product = null;
                contracts = contracts.Where(c => c.Product == criteria.Product);
            }

            return contracts;
        }

        private static IQueryable<contract> SortMangedCareByField(IQueryable<contract> contracts, string field, bool descending)
        {
            if (string.IsNullOrWhiteSpace(field)) return contracts;

            switch (field)
            {
                case "facility":
                    contracts = descending ? contracts.OrderByDescending(c => c.Fac_Name) : contracts.OrderBy(c => c.Fac_Name);
                    break;

                case "date_range":
                    IQueryable<contract> contractList = contracts;
                    foreach (var c in contractList)
                    {
                        DateTime? startDate = !string.IsNullOrEmpty(c.start_date) ? Convert.ToDateTime(c.start_date) : DateTime.MinValue;
                        c.msql_date = startDate;
                    }

                    contracts = descending ? contractList.OrderByDescending(c => c.msql_date) : contractList.OrderBy(c => c.msql_date);
                    break;

                case "plan":
                    contracts = descending ? contracts.OrderByDescending(c => c.contract_plan) : contracts.OrderBy(c => c.contract_plan);
                    break;

                case "product":
                    contracts = descending ? contracts.OrderByDescending(c => c.Product) : contracts.OrderBy(c => c.Product);
                    break;

                case "r_type":
                    contracts = descending ? contracts.OrderByDescending(c => c.R_type) : contracts.OrderBy(c => c.R_type);
                    break;

                case "renew_type":
                    contracts = descending ? contracts.OrderByDescending(c => c.renew_type) : contracts.OrderBy(c => c.renew_type);
                    break;

                case "header_notes":
                    contracts = descending ? contracts.OrderByDescending(c => c.header_notes) : contracts.OrderBy(c => c.header_notes);
                    break;

                case "companycode":
                default:
                    break;
            }

            return contracts;
        }

        #endregion ManagedCare section

        #region Contracts section

        public ContractViewModel GetContractById(ClaimsIdentity identity, int id, QuickSearchViewModel quickSearchModel)
        {
            var result = new ContractViewModel();
            var ubRevCodes = quickSearchModel != null && !string.IsNullOrEmpty(quickSearchModel.UbRevenueCode)
                             ? quickSearchModel.UbRevenueCode.Split(new char[] { ',' }).ToList() : null;
            var drgInputs = quickSearchModel != null && !string.IsNullOrEmpty(quickSearchModel.DRG)
                             ? quickSearchModel.DRG.Split(new char[] { ',' }).ToList() : null;
            var cpts = quickSearchModel != null && !string.IsNullOrEmpty(quickSearchModel.Cpt)
                             ? quickSearchModel.Cpt.Split(new char[] { ',' }).ToList() : null;

            var icd9s = quickSearchModel != null && !string.IsNullOrEmpty(quickSearchModel.IcdProcCode)
                             ? quickSearchModel.IcdProcCode.Split(new char[] { ',' }).ToList() : null;

            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            var contract = DbContext.contracts.Where(c => c.Corp_ID == corpId && c.ID == id).FirstOrDefault();

            var contractInsCodeList = DbContext.contract_ins_codes
                                     .Where(c => c.corp_ID == corpId && c.Contract_ID == id).ToList();

            var contractUbList = DbContext.contract_ub_codes
                                     .Where(c => c.contract_ID == id).OrderBy(c => c.L_care).ToList();

            //Get data for contract perdiem icd
            var xGroup = DbContext.contract_perdiem.Where(cp => cp.Contract_ID == id)
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var perDiemICDList = new List<contract_perdiem>();

            foreach (var x in xGroup)
            {
                var groupCode = string.Empty;

                var perDiemICDs = DbContext.contract_perdiem.Where(cp => cp.Contract_ID == id
                                    && cp.xgroup.ToLower() == x.ToLower()).Distinct();

                var perDiemICD = DbContext.contract_perdiem.Where(cp => cp.Contract_ID == id
                                    && cp.xgroup.ToLower() == x.ToLower()).Distinct().FirstOrDefault();

                foreach (var p in perDiemICDs)
                {
                    groupCode += p.DRG;
                    groupCode += ", ";
                }

                perDiemICD.DRG = groupCode.Substring(0, groupCode.Length - 2);

                perDiemICDList.Add(perDiemICD);
            }

            //Get data for contract perdiem icd
            var xGroupDRG = DbContext.contract_perdiem_drg.Where(cp => cp.Contract_ID == id)
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var perDiemDRGList = new List<contract_perdiem_drg>();

            foreach (var x in xGroupDRG)
            {
                var groupCode = string.Empty;

                var perDiemDRGs = DbContext.contract_perdiem_drg.Where(cp => cp.Contract_ID == id
                                    && cp.xgroup.ToLower() == x.ToLower()).Distinct();

                var perDiemDRG = DbContext.contract_perdiem_drg.Where(cp => cp.Contract_ID == id
                                    && cp.xgroup.ToLower() == x.ToLower()).Distinct().FirstOrDefault();

                foreach (var p in perDiemDRGs)
                {
                    groupCode += p.DRG.ToString();
                    groupCode += ", ";
                }

                perDiemDRG.DRG_Desc = groupCode.Substring(0, groupCode.Length - 2);

                perDiemDRGList.Add(perDiemDRG);
            }

            //Set data for return result
            result.Contract = contract;
            result.ContractInsList = contractInsCodeList;
            result.PerDiemDRGList = perDiemDRGList.ToList();
            result.PerDiemIDCList = perDiemICDList.ToList();
            result.ContractUBList = contractUbList;
            result.QuickSearch = quickSearchModel == null ? new QuickSearchViewModel() : quickSearchModel;

            //Set data for quick search

            //Data for UB Rev section
            result.UbRevs = GetUbCaseRate(id, ubRevCodes);
            result.UBREVCodes = GetUBREVCodes(id, ubRevCodes);
            result.UBOpInfo = GetUBOpInfo(id, ubRevCodes);
            result.UBExInfo = GetUBExInfo(id, ubRevCodes);

            //Data for ICD section
            result.PerdiemICD9Info = GetIcdPerdiemInfo(id, icd9s);
            result.ICD9Info = GetIcdCaseRateInfo(id, icd9s);
            result.ICD9OpInfo = GetIcdOpInfo(id, icd9s);
            result.ICD9ExInfo = GetIcdExInfo(id, icd9s);

            //Data for DRG section
            result.PerDiemDRGsForQuickSearch = GetPerDiemDRGs(id, drgInputs);

            //Data for CPT section
            result.CPTInfo = GetCPTOptInfo(id, cpts);
            result.CPTExInfo = GetCPTExclusionInfo(id, cpts);

            //Total Charge section
            result.Stoplosses = GetStoplossCharges(id);

            //OutPatient Surgrate section
            result.OpSurgrates = GetCPTOpFeeScheduleInfo(id, cpts);

            return result;
        }

        public List<contract_ins_codes> GetContractInsCode(ClaimsIdentity identity, int contractId)
        {
            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            return DbContext.contract_ins_codes.Where(c => c.corp_ID == corpId && c.Contract_ID == contractId).ToList();
        }

        #endregion Contracts section

        public List<contract_type> GetContractTypeByLoginId(ClaimsIdentity identity, int loginId)
        {
            var result = new List<contract_type>();

            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            result = DbContext.contract_type.Where(ct => ct.login_ID == loginId && ct.member_ID == corpId).ToList();
            result = result.Where(e => !string.IsNullOrEmpty(e.contract_type1) && e.contract_type1 != "").ToList();

            return result;
        }

        public List<login_facs> GetLoginFacByLoginId(ClaimsIdentity identity, int loginId)
        {
            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            return DbContext.login_facs.Where(lf => lf.login_id == loginId && lf.corp_ID == corpId).ToList();
        }

        public List<login_dept> GetLoginDeptByLoginId(ClaimsIdentity identity, int loginId)
        {
            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            return DbContext.login_dept.Where(ld => ld.Login_ID == loginId && ld.member_ID == corpId).ToList();
        }

        public ContractViewModel GetContractByQuickSearch(ClaimsIdentity identity, QuickSearchViewModel quickSearchModel, int id)
        {
            var result = new ContractViewModel()
            {
                QuickSearch = quickSearchModel
            };

            var ubRevCodes = !string.IsNullOrEmpty(quickSearchModel.UbRevenueCode)
                             ? quickSearchModel.UbRevenueCode.Split(new char[] { ',' }).ToList() : null;
            var drgInputs = !string.IsNullOrEmpty(quickSearchModel.DRG)
                             ? quickSearchModel.DRG.Split(new char[] { ',' }).ToList() : null;

            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            var contract = DbContext.contracts.Where(c => c.Corp_ID == corpId && c.ID == id).FirstOrDefault();

            var contractUbList = GetUBREVCodes(id, ubRevCodes);
            var perDiemDRGList = GetPerDiemDRGs(id, drgInputs);

            //Get data for contract perdiem icd
            var xGroup = DbContext.contract_perdiem.Where(cp => cp.Contract_ID == id)
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var perDiemICDList = new List<contract_perdiem>();
            var contractInsCodeList = new List<contract_ins_codes>();

            //Set data for return result
            result.Contract = contract;
            result.ContractInsList = contractInsCodeList;
            result.PerDiemDRGList = perDiemDRGList.ToList();
            result.PerDiemIDCList = perDiemICDList.ToList();
            result.ContractUBList = contractUbList;

            return result;
        }

        #region Quick Search By Code

        #region UB REVENUE CODE section

        public List<contract_ub_codes> GetUBREVCodes(int contractId, List<string> lCares)
        {
            var result = new List<contract_ub_codes>();
            var lastResult = new List<contract_ub_codes>();
            var lCareList = new List<string>();

            if (lCares == null || lCares.Count == 0) return result;

            var lCareIgCase = new List<string>();
            foreach (var l in lCares)
            {
                lCareIgCase.Add(l.ToLower());
            }

            //Get data for contract ub
            var revUbCodes = DbContext.contract_ub_codes.
                Where(ub => ub.contract_ID == contractId).Distinct().ToList();

            foreach (var l in lCareIgCase)
            {
                foreach (var u in revUbCodes)
                {
                    if (u.rev_code.ToLower().IndexOf(l) >= 0)
                    {
                        lCareList.Add(u.L_care.ToLower());
                    }
                }
            }

            foreach (var lcare in lCareList)
            {
                var ubCodes = DbContext.contract_ub_codes.
                    Where(u => u.contract_ID == contractId
                    && u.L_care.ToLower() == lcare).Distinct().ToList();

                foreach (var l in lCareIgCase)
                {
                    for (int i = 0; i < ubCodes.Count; i++)
                    {
                        result.Add(ubCodes[i]);
                    }
                }
            }

            var result1 = result.Distinct().ToList();

            if (result1.Count > 0)
            {
                foreach (var r in result1)
                {
                    var codes = string.Empty;

                    foreach (var l in lCares)
                    {
                        if (r.rev_code.Contains(l))
                        {
                            codes += l;
                            codes += ", ";
                        }
                    }

                    if (codes != string.Empty)
                    {
                        r.rev_code = codes.Substring(0, codes.Length - 2);
                    }

                    lastResult.Add(r);
                }
            }

            return lastResult;
        }

        public List<contract_ub_ex> GetUBExInfo(int contractId, List<string> lCares)
        {
            var result = new List<contract_ub_ex>();

            if (lCares == null || lCares.Count == 0) return result;

            //Get data for contract perdiem icd
            //var xGroup = DbContext.contract_ub_ex.
            //    Where(cp => cp.Contract_ID == contractId && lCares.Contains(cp.DRG.ToString()))
            //    .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var icd9 = DbContext.contract_ub_ex.Where(u => u.Contract_ID == contractId).ToList();

            foreach (var icd in icd9)
            {
                foreach (var i in lCares)
                {
                    double icdVal = 0d;
                    bool isValid = Double.TryParse(i, out icdVal);
                    if (icd.DRG == icdVal)
                    {
                        result.Add(icd);
                    }
                }
            }

            result = result.OrderBy(i => i.xgroup).Distinct().ToList();

            //Build the code returned for CPT
            foreach (var opt in result)
            {
                var codes = string.Empty;
                codes += opt.DRG.ToString();
                codes += ", ";

                opt.DRG_Desc = !string.IsNullOrEmpty(codes) ? codes.Substring(0, codes.Length - 2) : "";
            }

            return result.OrderBy(i => i.xgroup).Distinct().ToList();
        }

        public List<contract_op_ub> GetUBOpInfo(int contractId, List<string> lCares)
        {
            var result = new List<contract_op_ub>();

            if (lCares == null || lCares.Count == 0) return result;

            var icd9 = DbContext.contract_op_ub.Where(u => u.Contract_ID == contractId).ToList();

            foreach (var icd in icd9)
            {
                foreach (var i in lCares)
                {
                    double icdVal = 0d;
                    bool isValid = Double.TryParse(i, out icdVal);
                    if (icd.DRG == icdVal)
                    {
                        result.Add(icd);
                    }
                }
            }

            result = result.OrderBy(i => i.xgroup).Distinct().ToList();

            //Build the code returned for CPT
            foreach (var opt in result)
            {
                var codes = string.Empty;
                codes += opt.DRG.ToString();
                codes += ", ";

                opt.DRG_Desc = !string.IsNullOrEmpty(codes) ? codes.Substring(0, codes.Length - 2) : "";
            }

            return result.OrderBy(i => i.xgroup).Distinct().ToList();
        }

        public List<contract_ub_rev> GetUbCaseRate(int contractId, List<string> lCares)
        {
            var result = new List<contract_ub_rev>();

            if (lCares == null || lCares.Count == 0) return result;

            //Get data
            var xGroup = DbContext.contract_ub_rev.Where(cp => cp.Contract_ID == contractId)
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var caseRates = DbContext.contract_ub_rev.Where(u => u.Contract_ID == contractId).ToList();

            foreach (var icd in caseRates)
            {
                foreach (var i in lCares)
                {
                    double icdVal = 0d;
                    bool isValid = Double.TryParse(i, out icdVal);
                    if (icd.DRG == icdVal)
                    {
                        result.Add(icd);
                    }
                }
            }

            result = result.OrderBy(i => i.xgroup).Distinct().ToList();

            //Build the code returned for ICD9 opt
            foreach (var icd in result)
            {
                var codes = string.Empty;
                foreach (var x in xGroup)
                {
                    var xIgnoreCase = x.ToLower();

                    if (icd.xgroup.ToLower() == xIgnoreCase)
                    {
                        codes += icd.DRG.ToString();
                        codes += ", ";
                    }
                }

                icd.DRG_Desc = !string.IsNullOrEmpty(codes) ? codes.Substring(0, codes.Length - 2) : "";
            }

            return result.OrderBy(i => i.xgroup).Distinct().ToList();
        }

        #endregion UB REVENUE CODE section

        #region DRG section

        public List<contract_perdiem_drg> GetPerDiemDRGs(int contractId, List<string> drgList)
        {
            var result = new List<contract_perdiem_drg>();

            if (drgList == null || drgList.Count == 0) return result;

            var xGroup = DbContext.contract_perdiem_drg
                .Where(cp => cp.Contract_ID == contractId)
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            foreach (var x in xGroup)
            {
                var xIgnoreCase = x.ToLower();
                var drgs = DbContext.contract_perdiem_drg.Where(u => u.Contract_ID == contractId
                           && u.xgroup.ToLower() == xIgnoreCase).ToList();

                foreach (var drg in drgs)
                {
                    var codes = string.Empty;

                    foreach (var d in drgList)
                    {
                        double drgVal = 0d;
                        bool isValid = Double.TryParse(d, out drgVal);
                        if (drgVal == drg.DRG)
                        {
                            codes += drg.DRG.ToString();
                            codes += ", ";

                            drg.DRG_Desc = !string.IsNullOrEmpty(codes) ? codes.Substring(0, codes.Length - 2) : "";
                            result.Add(drg);
                        }
                    }
                }
            }

            return result.Distinct().ToList();
        }

        #endregion DRG section

        #region ICD Search section

        public List<contract_icd9> GetIcdCaseRateInfo(int contractId, List<string> icdList)
        {
            var result = new List<contract_icd9>();

            if (icdList == null || icdList.Count == 0) return result;

            //Get data for contract perdiem icd
            var xGroup = DbContext.contract_icd9.Where(cp => cp.Contract_ID == contractId)
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var icd9 = DbContext.contract_icd9.Where(u => u.Contract_ID == contractId).ToList();

            foreach (var icd in icd9)
            {
                foreach (var i in icdList)
                {
                    double icdVal = 0d;
                    bool isValid = Double.TryParse(i, out icdVal);
                    if (icd.DRG == icdVal)
                    {
                        result.Add(icd);
                    }
                }
            }

            result = result.OrderBy(i => i.xgroup).Distinct().ToList();

            //Build the code returned for ICD9
            foreach (var icd in result)
            {
                var codes = string.Empty;
                foreach (var x in xGroup)
                {
                    var xIgnoreCase = x.ToLower();

                    if (icd.xgroup.ToLower() == xIgnoreCase)
                    {
                        codes += icd.DRG.ToString();
                        codes += ", ";
                    }
                }

                icd.DRG_Desc = codes.Substring(0, codes.Length - 2);
            }

            return result.OrderBy(i => i.xgroup).Distinct().ToList();
        }

        private List<contract_icd_ex> GetIcdExInfo(int contractId, List<string> icdList)
        {
            var result = new List<contract_icd_ex>();

            if (icdList == null || icdList.Count == 0) return result;

            //Get data
            var xGroup = DbContext.contract_icd_ex.Where(cp => cp.Contract_ID == contractId)
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var icd9 = DbContext.contract_icd_ex.Where(u => u.Contract_ID == contractId).ToList();

            foreach (var icd in icd9)
            {
                foreach (var i in icdList)
                {
                    double icdVal = 0d;
                    bool isValid = Double.TryParse(i, out icdVal);
                    if (icd.DRG == icdVal)
                    {
                        result.Add(icd);
                    }
                }
            }

            result = result.OrderBy(i => i.xgroup).Distinct().ToList();

            //Build the code returned for ICD9 ex
            foreach (var icd in result)
            {
                var codes = string.Empty;
                foreach (var x in xGroup)
                {
                    var xIgnoreCase = x.ToLower();

                    if (icd.xgroup.ToLower() == xIgnoreCase)
                    {
                        codes += icd.DRG.ToString();
                        codes += ", ";
                    }
                }

                icd.DRG_Desc = !string.IsNullOrEmpty(codes) ? codes.Substring(0, codes.Length - 2) : "";
            }

            return result.OrderBy(i => i.xgroup).Distinct().ToList();
        }

        private List<contract_op_icd> GetIcdOpInfo(int contractId, List<string> icdList)
        {
            var result = new List<contract_op_icd>();

            if (icdList == null || icdList.Count == 0) return result;

            //Get data
            var xGroup = DbContext.contract_op_icd.Where(cp => cp.Contract_ID == contractId)
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var icd9 = DbContext.contract_op_icd.Where(u => u.Contract_ID == contractId).ToList();

            foreach (var icd in icd9)
            {
                foreach (var i in icdList)
                {
                    double icdVal = 0d;
                    bool isValid = Double.TryParse(i, out icdVal);
                    if (icd.DRG == icdVal)
                    {
                        result.Add(icd);
                    }
                }
            }

            result = result.OrderBy(i => i.xgroup).Distinct().ToList();

            //Build the code returned for ICD9 opt
            foreach (var icd in result)
            {
                var codes = string.Empty;
                foreach (var x in xGroup)
                {
                    var xIgnoreCase = x.ToLower();

                    if (icd.xgroup.ToLower() == xIgnoreCase)
                    {
                        codes += icd.DRG.ToString();
                        codes += ", ";
                    }
                }

                icd.DRG_Desc = !string.IsNullOrEmpty(codes) ? codes.Substring(0, codes.Length - 2) : "";
            }

            return result.OrderBy(i => i.xgroup).Distinct().ToList();
        }

        public List<contract_perdiem> GetIcdPerdiemInfo(int contractId, List<string> drgList)
        {
            var result = new List<contract_perdiem>();
            var lastResult = new List<contract_perdiem>();

            var drgIgnoreCaseList = new List<string>();

            if (drgList == null || drgList.Count == 0) return result;

            foreach (var drg in drgList)
            {
                drgIgnoreCaseList.Add(drg.ToLower());
            }

            //Get data for contract perdiem
            var xGroup = DbContext.contract_perdiem.Where(cp => cp.Contract_ID == contractId
                        && drgIgnoreCaseList.Contains(cp.DRG)).Select(c => c.xgroup)
                        .OrderBy(x => x).Distinct().ToList();

            foreach (var x in xGroup)
            {
                var xIgnoreCase = x.ToLower();

                var perdiems = DbContext.contract_perdiem.
                    Where(u => u.Contract_ID == contractId && u.xgroup.ToLower() == xIgnoreCase
                    && drgIgnoreCaseList.Contains(u.DRG.ToLower())).ToList();

                foreach (var r in perdiems)
                {
                    var codes = string.Empty;
                    if (r.xgroup.ToLower() == xIgnoreCase)
                    {
                        codes += r.DRG.ToString();
                        codes += ", ";

                        r.DRG_Desc = codes;

                        result.Add(r);
                    }
                    //r.DRG_Desc = !string.IsNullOrEmpty(codes) ? codes.Substring(0, codes.Length - 2) : "";
                }
            }

            var result1 = result.ToList();

            if (result1.Count > 0)
            {
                foreach (var r in result1)
                {
                    var codes = string.Empty;

                    foreach (var l in drgList)
                    {
                        if (r.DRG.Contains(l))
                        {
                            codes += l;
                            codes += ", ";
                        }
                    }

                    if (codes != string.Empty)
                    {
                        r.DRG_Desc = codes.Substring(0, codes.Length - 2);
                    }

                    lastResult.Add(r);
                }
            }

            return lastResult;
        }

        #endregion ICD Search section

        #region CPT search section

        public List<contract_op_cpt> GetCPTOptInfo(int contractId, List<string> optList)
        {
            var result = new List<contract_op_cpt>();

            if (optList == null || optList.Count == 0) return result;

            //Get data for contract perdiem icd
            var xGroup = DbContext.contract_op_cpt.
                Where(cp => cp.Contract_ID == contractId && optList.Contains(cp.DRG))
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var cpts = DbContext.contract_op_cpt.Where(u => u.Contract_ID == contractId).ToList();

            foreach (var cpt in cpts)
            {
                foreach (var i in optList)
                {
                    var oIgnoreCase = i.ToLower();

                    if (cpt.DRG.ToLower() == oIgnoreCase)
                    {
                        result.Add(cpt);
                    }
                }
            }
            result = result.OrderBy(i => i.xgroup).Distinct().ToList();

            //Build the code returned for CPT
            foreach (var opt in result)
            {
                var codes = string.Empty;
                foreach (var x in xGroup)
                {
                    var xIgnoreCase = x.ToLower();

                    if (opt.xgroup.ToLower() == xIgnoreCase)
                    {
                        codes += opt.DRG.ToString();
                        codes += ", ";
                    }
                }

                opt.DRG_Desc = codes.Substring(0, codes.Length - 2);
            }

            return result.OrderBy(i => i.xgroup).Distinct().ToList();
        }

        public List<contract_cpt_ex> GetCPTExclusionInfo(int contractId, List<string> cptList)
        {
            var result = new List<contract_cpt_ex>();

            if (cptList == null || cptList.Count == 0) return result;

            //Get data for ex cpt
            var xGroup = DbContext.contract_cpt_ex.
                Where(cp => cp.Contract_ID == contractId && cptList.Contains(cp.DRG))
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var cpts = DbContext.contract_cpt_ex.Where(u => u.Contract_ID == contractId).ToList();

            foreach (var cpt in cpts)
            {
                foreach (var i in cptList)
                {
                    var cIgnoreCase = i.ToLower();

                    if (cpt.DRG.ToLower() == cIgnoreCase)
                    {
                        result.Add(cpt);
                    }
                }
            }
            result = result.OrderBy(i => i.xgroup).Distinct().ToList();

            //Build the code returned for ex CPT
            foreach (var opt in result)
            {
                var codes = string.Empty;
                foreach (var x in xGroup)
                {
                    var xIgnoreCase = x.ToLower();

                    if (opt.xgroup.ToLower() == xIgnoreCase)
                    {
                        codes += opt.DRG.ToString();
                        codes += ", ";
                    }
                }

                opt.DRG_Desc = codes.Substring(0, codes.Length - 2);
            }

            return result.OrderBy(i => i.xgroup).Distinct().ToList();
        }

        #endregion CPT search section

        #region Stoploss Charges section

        public List<contract_stoploss> GetStoplossCharges(int contractId)
        {
            return DbContext.contract_stoploss.Where(s => s.contract_ID == contractId).ToList();
        }

        #endregion Stoploss Charges section

        #region Outpatient Fee Schedules section

        public List<contract_op_surgrate> GetCPTOpFeeScheduleInfo(int contractId, List<string> cptList)
        {
            var result = new List<contract_op_surgrate>();

            if (cptList == null || cptList.Count == 0) return result;

            //Get data for cpt fee schedule
            var xGroup = DbContext.contract_op_surgrate.
                Where(cp => cp.Contract_ID == contractId && cptList.Contains(cp.DRG))
                .Select(c => c.xgroup).OrderBy(x => x).Distinct().ToList();

            var cpts = DbContext.contract_op_surgrate.Where(u => u.Contract_ID == contractId).ToList();

            foreach (var cpt in cpts)
            {
                foreach (var i in cptList)
                {
                    var cIgnoreCase = i.ToLower();

                    if (cpt.DRG.ToLower() == cIgnoreCase)
                    {
                        result.Add(cpt);
                    }
                }
            }
            result = result.OrderBy(i => i.xgroup).Distinct().ToList();

            //Build the code returned for CPT fee schedule
            foreach (var opt in result)
            {
                var codes = string.Empty;
                foreach (var x in xGroup)
                {
                    var xIgnoreCase = x.ToLower();

                    if (opt.xgroup.ToLower() == xIgnoreCase)
                    {
                        codes += opt.DRG.ToString();
                        codes += ", ";
                    }
                }

                opt.Blank1 = codes.Substring(0, codes.Length - 2);
            }

            return result.OrderBy(i => i.xgroup).Distinct().ToList();
        }

        #endregion Outpatient Fee Schedules section

        #region Fee crossward

        public List<feeschedule> GetFeeSchedules(ClaimsIdentity identity, int contractId, List<string> cptList)
        {
            var result = new List<feeschedule>();
            var fsLabels = new List<fs_labels>();
            var feeScheduleId = 0;

            if (identity == null) return null;

            var corpId = GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

            var feeCrosswalks = DbContext.fee_crosswalk.Where(f => f.Contract_ID == contractId
                  && f.use_it.ToLower() == "y").ToList();

            foreach (var crosswalk in feeCrosswalks)
            {
                var feeDescription = crosswalk.Description;
                if (!string.IsNullOrEmpty(crosswalk.FeeSchd_ID))
                {
                    Int32.TryParse(crosswalk.FeeSchd_ID, out feeScheduleId);
                }

                if (feeDescription != string.Empty)
                {
                    result = DbContext.feeschedules.
                    Where(cp => cp.CPT_grouping == feeDescription
                          && cp.Schedule_ID == feeScheduleId && cptList.Contains(cp.CPT))
                          .OrderBy(c => c.CPT).ToList();

                    fsLabels = DbContext.fs_labels.Where(l => l.Client_ID == corpId
                    && l.Schedule_ID == feeScheduleId && cptList.Contains(l.CPT)).ToList();
                }
            }

            return result;
        }

        #endregion Fee crossward

        #endregion Quick Search By Code

        public nmc_ex_contracts GetLastExContract(ClaimsIdentity identity)
        {
            if (identity == null) return null;

            return DbContext.nmc_ex_contracts.OrderByDescending(e => e.ID).FirstOrDefault();
        }
    }
}