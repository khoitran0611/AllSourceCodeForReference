///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///
var SearchCriteria = (function () {
    function SearchCriteria() {
    }
    return SearchCriteria;
})();
var ContractPagingInfo = (function () {
    function ContractPagingInfo() {
    }
    return ContractPagingInfo;
})();
var AttachDocumentSearchCriteria = (function () {
    function AttachDocumentSearchCriteria() {
    }
    return AttachDocumentSearchCriteria;
})();
var UserSearchResultViewModel = (function () {
    function UserSearchResultViewModel() {
    }
    return UserSearchResultViewModel;
})();
var ContractManager = (function () {
    function ContractManager(container) {
        this._container = container;
    }
    ContractManager.prototype.GetSearchCriteria = function () {
        var criteria = new SearchCriteria();
        var container = $(this._container);
        if (container != null) {
            criteria.Facility = container.find("#Facility").val();
            criteria.Vendor = container.find("#Vendor").val();
            criteria.VendorMatch = container.find("#VendorMatch").val();
            criteria.Department = container.find("#Department").val();
            criteria.ContractType = container.find("#ContractType").val();
            criteria.ContractId = container.find("#ContractId").val();
            criteria.PageSize = container.find("#PageSize").val();
            criteria.PageIndex = container.find("#PageIndex").val();
            criteria.SortedBy = container.find("#SortedBy").val();
            criteria.SortedDescending = container.find("#SortedDescending").val();
            criteria.SearchMode = container.find("#SearchMode").val();
            criteria.__RequestVerificationToken = container.find("input[name='__RequestVerificationToken']").val();
        }
        return criteria;
    };
    ContractManager.prototype.SubmitSearch = function (criteria) {
        var html = "";
        var container = $(this._container);
        var formAction = container.find("form").attr("action");
        var ajaxSettings = {
            url: formAction,
            data: criteria,
            dataType: "html",
            method: "POST"
        };
        $.ajax(ajaxSettings)
            .done(function (data, textStatus, jqXHR) {
            container.find("#tableView").html(data);
        })
            .fail(function (data, textStatus, jqXHR) {
            alert("Failed to refresh content. Please try again at a later time. If it persists, please contract the support.");
        });
        return true;
    };
    ContractManager.prototype.GetContractPagingInfo = function (sectionName) {
        var pagingInfo = new ContractPagingInfo();
        var container = $(this._container);
        if (container != null) {
            switch (sectionName) {
                case "addionaldocuments":
                case "evaluationlog":
                    pagingInfo.ContractId = container.find("#Contract_ID").val();
                    pagingInfo.PageIndex = container.find("#PageIndex").val();
                    pagingInfo.TotalCount = container.find("#TotalCount").val();
                    pagingInfo.PageSize = container.find("#PageSize").val();
                    pagingInfo.PagingSection = container.find("#PagingSection").val();
                    break;
                case "contractlog":
                    pagingInfo.ContractId = container.find("#Contract_Contract_ID").val();
                    pagingInfo.PageIndex = container.find("#ContractPageIndex").val();
                    pagingInfo.TotalCount = container.find("#ContractTotalCount").val();
                    pagingInfo.PageSize = container.find("#ContractPageSize").val();
                    pagingInfo.PagingSection = container.find("#PagingSection").val();
                    break;
            }
            ;
        }
        return pagingInfo;
    };
    ContractManager.prototype.DoContractPaging = function (pagingInfo) {
        var html = "";
        var formAction = "";
        var container = $(this._container);
        var pagingSection = pagingInfo.PagingSection;
        switch (pagingSection) {
            case "additionaldocuments":
                formAction = "/Contract/AdditionalDocuments/";
                break;
            case "evaluationlog":
                formAction = "/Contract/EvaluationLog/";
                break;
            case "contractlog":
                formAction = "/Contract/ContractLog/";
                break;
        }
        ;
        var ajaxSettings = {
            url: formAction,
            data: pagingInfo,
            dataType: "html",
            method: "POST"
        };
        $.ajax(ajaxSettings)
            .done(function (data, textStatus, jqXHR) {
            container.html(data);
        })
            .fail(function (data, textStatus, jqXHR) {
            alert("Failed to refresh content. Please try again at a later time. If it persists, please contract the support.");
        });
        return true;
    };
    ContractManager.prototype.GetAttachDocumentSearchCriteria = function () {
        var criteria = new AttachDocumentSearchCriteria();
        var container = $(this._container);
        if (container != null) {
            criteria.FacilityId = container.find("#Facility option:selected").val();
            criteria.Vendor = container.find("#Vendor").val();
            criteria.PageIndex = container.find("#PageIndex").val();
            criteria.PageSize = container.find("#PageSize").val();
        }
        return criteria;
    };
    ContractManager.prototype.GetUserListPagingInfo = function () {
        var criteria = new UserSearchResultViewModel();
        var container = $(this._container);
        if (container != null) {
            criteria.PageIndex = container.find("#PageIndex").val();
            criteria.PageSize = container.find("#PageSize").val();
        }
        return criteria;
    };
    ContractManager.prototype.DoAttachDocumentPaging = function (criteria) {
        var html = "";
        var container = $(this._container);
        var formAction = container.find("form").attr("action");
        var ajaxSettings = {
            url: formAction,
            data: criteria,
            dataType: "html",
            method: "POST"
        };
        $.ajax(ajaxSettings)
            .done(function (data, textStatus, jqXHR) {
            container.find("#tableView").html(data);
            $('#searchResultCaption').text($("#VendorText").val());
        })
            .fail(function (data, textStatus, jqXHR) {
            alert("Failed to refresh content. Please try again at a later time. If it persists, please contract the support.");
        });
        return true;
    };
    ContractManager.prototype.DoUserListPaging = function (criteria) {
        var html = "";
        var container = $(this._container);
        //var formAction = container.find("form").attr("action");
        var formAction = "/Admin/SearchUserList/";
        var ajaxSettings = {
            url: formAction,
            data: criteria,
            dataType: "html",
            method: "POST"
        };
        $.ajax(ajaxSettings)
            .done(function (data, textStatus, jqXHR) {
            container.find("#tableView").html(data);
        })
            .fail(function (data, textStatus, jqXHR) {
            alert("Failed to refresh content. Please try again at a later time. If it persists, please contract the support.");
        });
        return true;
    };
    return ContractManager;
})();
//# sourceMappingURL=ContractManager.js.map