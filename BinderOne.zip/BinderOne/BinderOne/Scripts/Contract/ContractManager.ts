﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

class SearchCriteria {
    __RequestVerificationToken: string;

    Facility: string;
    Vendor: string;
    VendorMatch: string;
    Department: string;
    ContractType: string;
    ContractId: string;

    PageSize: number;
    PageIndex: number;
    SortedBy: string;
    SortedDescending: boolean;

    SearchMode: string;
}

class ContractPagingInfo {
    ContractId: number;
    PageIndex: number;
    TotalCount: number;
    PageSize: number;
    PagingSection: string;
}

class AttachDocumentSearchCriteria {
    FacilityId: number;
    Vendor: string;
    PageIndex: number;
    TotalCount: number;
    PageSize: number;
}

class UserSearchResultViewModel {    
    PageIndex: number;
    TotalCount: number;
    PageSize: number;
}

interface IContractManager {
    GetSearchCriteria(): SearchCriteria;
    GetAttachDocumentSearchCriteria(): AttachDocumentSearchCriteria;
    SubmitSearch(criteria: SearchCriteria);
    GetContractPagingInfo(sectionName: string): ContractPagingInfo;
    GetUserListPagingInfo(): UserSearchResultViewModel;
    DoContractPaging(pagingInfo: ContractPagingInfo);
    DoAttachDocumentPaging(criteria: AttachDocumentSearchCriteria);
    DoUserListPaging(criteria: UserSearchResultViewModel);
}

class ContractManager implements IContractManager {
    private _container: any;

    constructor(container: any) {
        this._container = container;
    }

    GetSearchCriteria(): SearchCriteria {
        var criteria = new SearchCriteria();
        var container = $(this._container);

        if (container != null) {
            criteria.Facility = container.find("#Facility").val();
            criteria.Vendor = container.find("#Vendor").val();
            criteria.VendorMatch = container.find("#VendorMatch").val();
            criteria.Department = container.find("#Department").val();
            criteria.ContractType = container.find("#ContractType").val();
            criteria.ContractId = container.find("#ContractId").val();

            criteria.PageSize = container.find("#PageSize").val();
            criteria.PageIndex = container.find("#PageIndex").val();
            criteria.SortedBy = container.find("#SortedBy").val();
            criteria.SortedDescending = container.find("#SortedDescending").val();

            criteria.SearchMode = container.find("#SearchMode").val();

            criteria.__RequestVerificationToken = container.find("input[name='__RequestVerificationToken']").val();
        }

        return criteria;
    }

    SubmitSearch(criteria: SearchCriteria) {
        var html = "";
        var container = $(this._container);
        var formAction = container.find("form").attr("action");

        var ajaxSettings: JQueryAjaxSettings = {
            url: formAction,
            data: criteria,
            dataType: "html",
            method: "POST"
        };

        $.ajax(ajaxSettings)
            .done(function (data, textStatus, jqXHR) {
                container.find("#tableView").html(data);
            })
            .fail(function (data, textStatus, jqXHR) {
                alert("Failed to refresh content. Please try again at a later time. If it persists, please contract the support.");
            });

        return true;
    }

    GetContractPagingInfo(sectionName: string): ContractPagingInfo {
        var pagingInfo = new ContractPagingInfo();
        var container = $(this._container);

        if (container != null) {
            switch (sectionName) {
                case "addionaldocuments":
                case "evaluationlog":
                    pagingInfo.ContractId = container.find("#Contract_ID").val();
                    pagingInfo.PageIndex = container.find("#PageIndex").val();
                    pagingInfo.TotalCount = container.find("#TotalCount").val();
                    pagingInfo.PageSize = container.find("#PageSize").val();
                    pagingInfo.PagingSection = container.find("#PagingSection").val();
                    break;
                case "contractlog":
                    pagingInfo.ContractId = container.find("#Contract_Contract_ID").val();
                    pagingInfo.PageIndex = container.find("#ContractPageIndex").val();
                    pagingInfo.TotalCount = container.find("#ContractTotalCount").val();
                    pagingInfo.PageSize = container.find("#ContractPageSize").val();
                    pagingInfo.PagingSection = container.find("#PagingSection").val();
                    break;
            };
        }

        return pagingInfo;
    }

    DoContractPaging(pagingInfo: ContractPagingInfo) {
        var html = "";
        var formAction = "";
        var container = $(this._container);
        var pagingSection = pagingInfo.PagingSection;

        switch (pagingSection) {
            case "additionaldocuments":
                formAction = "/Contract/AdditionalDocuments/";
                break;
            case "evaluationlog":
                formAction = "/Contract/EvaluationLog/";
                break;
            case "contractlog":
                formAction = "/Contract/ContractLog/";
                break;
        };

        var ajaxSettings: JQueryAjaxSettings = {
            url: formAction,
            data: pagingInfo,
            dataType: "html",
            method: "POST"
        };

        $.ajax(ajaxSettings)
            .done(function (data, textStatus, jqXHR) {
                container.html(data);
            })
            .fail(function (data, textStatus, jqXHR) {
                alert("Failed to refresh content. Please try again at a later time. If it persists, please contract the support.");
            });

        return true;
    }

    GetAttachDocumentSearchCriteria(): AttachDocumentSearchCriteria {
        var criteria = new AttachDocumentSearchCriteria();
        var container = $(this._container);

        if (container != null) {
            criteria.FacilityId = container.find("#Facility option:selected").val();
            criteria.Vendor = container.find("#Vendor").val();
            criteria.PageIndex = container.find("#PageIndex").val();
            criteria.PageSize = container.find("#PageSize").val();
        }

        return criteria;
    }

    GetUserListPagingInfo(): UserSearchResultViewModel {
        var criteria = new UserSearchResultViewModel();
        var container = $(this._container);

        if (container != null) {            
            criteria.PageIndex = container.find("#PageIndex").val();
            criteria.PageSize = container.find("#PageSize").val();
        }

        return criteria;
    }
    

    DoAttachDocumentPaging(criteria: AttachDocumentSearchCriteria) {
        var html = "";
        var container = $(this._container);
        var formAction = container.find("form").attr("action");

        var ajaxSettings: JQueryAjaxSettings = {
            url: formAction,
            data: criteria,
            dataType: "html",
            method: "POST"
        };

        $.ajax(ajaxSettings)
            .done(function (data, textStatus, jqXHR) {
                container.find("#tableView").html(data);
                $('#searchResultCaption').text($("#VendorText").val());
            })
            .fail(function (data, textStatus, jqXHR) {
                alert("Failed to refresh content. Please try again at a later time. If it persists, please contract the support.");
            });

        return true;
    }

    DoUserListPaging(criteria: UserSearchResultViewModel) {
        var html = "";
        var container = $(this._container);
        //var formAction = container.find("form").attr("action");
        var formAction = "/Admin/SearchUserList/";

        var ajaxSettings: JQueryAjaxSettings = {
            url: formAction,
            data: criteria,
            dataType: "html",
            method: "POST"
        };

        $.ajax(ajaxSettings)
            .done(function (data, textStatus, jqXHR) {
                container.find("#tableView").html(data);                
            })
            .fail(function (data, textStatus, jqXHR) {
                alert("Failed to refresh content. Please try again at a later time. If it persists, please contract the support.");
            });

        return true;
    }
}