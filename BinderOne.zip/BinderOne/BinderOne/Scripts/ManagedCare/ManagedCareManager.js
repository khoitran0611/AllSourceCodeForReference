///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///
var ManagedCareSearchCriteria = (function () {
    function ManagedCareSearchCriteria() {
    }
    return ManagedCareSearchCriteria;
})();
var ManagedCareManager = (function () {
    function ManagedCareManager(container) {
        this._container = container;
    }
    ManagedCareManager.prototype.GetSearchCriteria = function () {
        var criteria = new ManagedCareSearchCriteria();
        var container = $(this._container);
        if (container != null) {
            criteria.Facility = container.find("#Facility").val();
            criteria.Product = container.find("#Product").val();
            criteria.Plan = container.find("#Plan").val();
            criteria.CompanyCode = container.find("#CompanyCode").val();
            criteria.PageSize = container.find("#PageSize").val();
            criteria.PageIndex = container.find("#PageIndex").val();
            criteria.SortedBy = container.find("#SortedBy").val();
            criteria.SortedDescending = container.find("#SortedDescending").val();
            criteria.SearchMode = container.find("#SearchMode").val();
            criteria.__RequestVerificationToken = container.find("input[name='__RequestVerificationToken']").val();
        }
        return criteria;
    };
    ManagedCareManager.prototype.SubmitSearch = function (criteria) {
        var html = "";
        var container = $(this._container);
        var formAction = container.find("form").attr("action");
        var ajaxSettings = {
            url: formAction,
            data: criteria,
            dataType: "html",
            method: "POST"
        };
        $.ajax(ajaxSettings)
            .done(function (data, textStatus, jqXHR) {
            container.find("#tableView").html(data);
        })
            .fail(function (data, textStatus, jqXHR) {
            alert("Failed to refresh content. Please try again at a later time. If it persists, please contract the support.");
        });
        return true;
    };
    return ManagedCareManager;
})();
//# sourceMappingURL=ManagedCareManager.js.map