﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    /// <summary>
    /// Model class to hold data about the document to stream back to user to view
    /// </summary>
    public class Permission
    {       
        public string Type { get; set; }
        public string Value { get; set; }       
    }
}