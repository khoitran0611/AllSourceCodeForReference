﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using BinderOne.EF;
    using System.Collections.Generic;

    public class AttachDocumentSearchResultViewModel
    {
        public int TotalCount { get; set; }

        public int PageSize { get; set; }

        public int PageIndex { get; set; }

        public ICollection<umc_contracts> ContractSearchResult { get; set; }
    }
}