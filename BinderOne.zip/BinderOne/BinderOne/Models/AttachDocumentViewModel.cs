﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    public class AttachDocumentViewModel
    {
        public AttachDocumentFilterViewModel AttachDocFilter { get; set; }

        public AttachDocumentSearchResultViewModel SearchResult { get; set; }
    }
}