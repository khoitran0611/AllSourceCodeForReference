﻿using System.ComponentModel.DataAnnotations;

namespace BinderOne.Models
{
    public class QuickSearchViewModel
    {
        public int ContractId { get; set; }
        public string SearchType { get; set; }
        public string DRG { get; set; }
        public string UbRevenueCode { get; set; }
        public string IcdProcCode { get; set; }
        public string PeriodRequired { get; set; }
        public string Cpt { get; set; }

        [RegularExpression(@"^\d+$", ErrorMessage = "Total Charge must be a numeric")]
        public string TotalCharges { get; set; }

        public string PrinterFriendly { get; set; }
    }
}