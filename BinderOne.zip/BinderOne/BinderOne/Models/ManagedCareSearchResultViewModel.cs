﻿///
///<Copyright year="2016"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using System.Collections.Generic;

    public class ManagedCareSearchResultViewModel
    {
        public string SortedBy { get; set; }

        public bool SortedDescending { get; set; }

        public int TotalCount { get; set; }

        public int PageSize { get; set; }

        public int PageIndex { get; set; }

        public SearchMode SearchMode { get; set; }
        
        public ICollection<ManagedCareContractResult> ManagedCareContracts { get; set; }
    }
}