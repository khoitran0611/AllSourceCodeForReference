﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    public enum SearchMode
    {
        All,
        Expiring,
        Inactive
    }
}