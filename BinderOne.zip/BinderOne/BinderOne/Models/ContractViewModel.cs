﻿using BinderOne.EF;
using System.Collections.Generic;

namespace BinderOne.Models
{
    public class ContractViewModel
    {
        public int contractId { get; set; }
        public QuickSearchViewModel QuickSearch { get; set; }
        public contract Contract { get; set; }

        //public string HidContractId { get; set; }
        public List<contract_perdiem> PerDiemIDCList { get; set; }

        public List<contract_perdiem_drg> PerDiemDRGList { get; set; }
        public List<contract_ins_codes> ContractInsList { get; set; }
        public List<contract_ub_codes> ContractUBList { get; set; }

        #region Data for Quick Search section

        #region Ub Rev section

        public List<contract_ub_rev> UbRevs { get; set; }
        public List<contract_ub_codes> UBREVCodes { get; set; }
        public List<contract_ub_ex> UBExInfo { get; set; }
        public List<contract_op_ub> UBOpInfo { get; set; }

        #endregion Ub Rev section

        #region Drg section

        public List<contract_perdiem_drg> PerDiemDRGsForQuickSearch { get; set; }

        #endregion Drg section

        #region Icd section

        public List<contract_perdiem> PerdiemICD9Info { get; set; }
        public List<contract_icd9> ICD9Info { get; set; }
        public List<contract_op_icd> ICD9OpInfo { get; set; }
        public List<contract_icd_ex> ICD9ExInfo { get; set; }

        #endregion Icd section

        #region Cpt section

        public List<contract_op_cpt> CPTInfo { get; set; }
        public List<contract_cpt_ex> CPTExInfo { get; set; }

        #endregion Cpt section

        #region Total Charges section

        public List<contract_stoploss> Stoplosses { get; set; }

        #endregion Total Charges section

        #region OutPatient Fee Schedule section

        public List<contract_op_surgrate> OpSurgrates { get; set; }

        #endregion OutPatient Fee Schedule section

        #endregion Data for Quick Search section
    }
}