﻿using System.ComponentModel.DataAnnotations;

namespace BinderOne.Models
{
    public class ContactUsModel
    {
        [Display(Name = "Full Name")]
        public string FullName { get; set; }

        public string Company { get; set; }

        [Display(Name = "E-mail")]
        public string Email { get; set; }

        public string Phone { get; set; }
        public string Fax { get; set; }
        public string Message { get; set; }
        public string IsRequestCallBack { get; set; }
    }
}