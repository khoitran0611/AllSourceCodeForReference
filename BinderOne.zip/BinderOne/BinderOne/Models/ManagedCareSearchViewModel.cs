﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    public class ManagedCareSearchViewModel
    {
        public ManagedCareSearchCriteriaViewModel SearchCriteria { get; set; }

        public ManagedCareSearchResultViewModel SearchResult { get; set; }
    }
}