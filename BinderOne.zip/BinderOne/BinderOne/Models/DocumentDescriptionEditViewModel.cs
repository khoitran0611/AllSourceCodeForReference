﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    public class DocumentDescriptionEditViewModel
    {
        public int ExContractId { get; set; }
        public int? ContractId { get; set; }
        public bool IsDeleteDocument { get; set; }
        public string Description { get; set; }
        public int CurrentPageIndex { get; set; }
    }
}