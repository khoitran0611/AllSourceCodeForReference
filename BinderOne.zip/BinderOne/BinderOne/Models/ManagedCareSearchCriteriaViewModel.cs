﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using System.ComponentModel.DataAnnotations;

    public class ManagedCareSearchCriteriaViewModel
    {
        [Required]
        [Display(Name = "Location")]
        public string Facility { get; set; }

        [Required]        
        public string Plan { get; set; }

        [Display(Name = "Company Code")]
        public string CompanyCode { get; set; }

        [Required]        
        public string Product { get; set; }        

        [Display(Name = "Pagesize")]
        public int PageSize { get; set; }

        [Display(Name = "Page")]
        public int PageIndex { get; set; }

        [Display(Name = "Sorted By")]
        public string SortedBy { get; set; }

        [Display(Name = "Sorted Descending")]
        public bool SortedDescending { get; set; }

        [Display(Name = "Search Mode")]
        public SearchMode SearchMode { get; set; }

        public ManagedCareSearchCriteriaViewModel()
        {
            Facility = "All";
            Plan = "All";
            CompanyCode = "";
            Product = "All";
            PageSize = 25;
            SortedBy = "Facility";
            SearchMode = SearchMode.All;
        }
    }
}