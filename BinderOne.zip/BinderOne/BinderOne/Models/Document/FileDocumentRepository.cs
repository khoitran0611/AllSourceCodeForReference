﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models.Document
{
    using BinderOne.Models.Document.Interfaces;
    using EF;
    using Services;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Security.Claims;
    using SysClaimTypes = System.Security.Claims.ClaimTypes;

    public class FileDocumentRepository : IDocumentRepository
    {
        //The physical path where all the document files are located
        //Can be configurable
        //For testing, please make sure that the file in additional document screen exist in this physical path
        private string documentFilePath = ConfigurationManager.AppSettings["FilePath"];

        public DataProvider DataContext { get; set; }

        public FileDocumentRepository()
        {
            DataContext = new DataProvider { DbContext = new BinderOneEntities() };
        }

        public FileStream GetDocument(DocumentInfo documentInfo, ClaimsIdentity identity)
        {
            if (documentInfo == null || documentInfo.IsExternal || !IsDocumentValid(documentInfo, identity)) return null;

            if (IsDocumentValid(documentInfo, identity))
            {
                var fullName = Path.Combine(documentFilePath, Path.GetFileName(documentInfo.FileName));
                if (!File.Exists(fullName)) return null;

                return new FileStream(fullName, FileMode.Open, FileAccess.ReadWrite);
            }

            return null;
        }

        public bool IsDocumentValid(DocumentInfo documentInfo, ClaimsIdentity identity)
        {
            var isValid = false;
            var ownerId = 0;
            if (identity != null && documentInfo != null)
            {
                var corpId = DataProvider.GetClaimId(identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.PrimaryGroupSid), SysClaimTypes.PrimaryGroupSid);

                //First check if the document id is null to know which entity, ex_contract or contract
                //to work on
                if (documentInfo.Id.HasValue && documentInfo.Id != 0) //Get data from ex_contract table
                {
                    var exContract = DataContext.GetExContract(identity, documentInfo.Id.Value);
                    ownerId = exContract != null ? exContract.corp_ID.Value : 0;
                }
                else
                {
                    //if documentInfo.Id is null then we check the data on contract table
                    var contract = DataContext.GetContract(identity, documentInfo.ContractId);
                    ownerId = contract != null ? contract.corp_ID.Value : 0;
                }

                if (ownerId != 0 && ownerId == corpId) isValid = true;
            }

            return isValid;
        }
    }
}