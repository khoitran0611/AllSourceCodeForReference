﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models.Document
{
    using BinderOne.Models.Document.Interfaces;
    using Newtonsoft.Json;
    using System;
    using System.Security.Cryptography;
    using System.Text;

    public class RsaTokenizer : ITokenizer
    {
        private const string _AesIV = @"!QAZ2WSX#EDC4RFV";

        private const string _AesKey = @"P1MC0YHN7UJM(IK<";

        public DocumentInfo Decrypt(string token)
        {
            var decryptedDocumentInfo = string.Empty;

            // AesCryptoServiceProvider
            AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
            aes.BlockSize = 128;
            aes.KeySize = 128;
            aes.IV = Encoding.UTF8.GetBytes(_AesIV);
            aes.Key = Encoding.UTF8.GetBytes(_AesKey);
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            // Convert Base64 strings to byte array
            byte[] src = System.Convert.FromBase64String(token);

            // decryption
            using (ICryptoTransform decrypt = aes.CreateDecryptor())
            {
                byte[] dest = decrypt.TransformFinalBlock(src, 0, src.Length);
                decryptedDocumentInfo = Encoding.Unicode.GetString(dest);
            }

            return JsonConvert.DeserializeObject<DocumentInfo>(decryptedDocumentInfo);
        }

        public string Encrypt(DocumentInfo documentInfo)
        {
            var documentInfoSerialized = JsonConvert.SerializeObject(documentInfo);

            // AesCryptoServiceProvider
            AesCryptoServiceProvider aes = new AesCryptoServiceProvider();
            aes.BlockSize = 128;
            aes.KeySize = 128;
            aes.IV = Encoding.UTF8.GetBytes(_AesIV);
            aes.Key = Encoding.UTF8.GetBytes(_AesKey);
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            // Convert string to byte array
            byte[] src = Encoding.Unicode.GetBytes(documentInfoSerialized);

            // encryption
            using (ICryptoTransform encrypt = aes.CreateEncryptor())
            {
                byte[] dest = encrypt.TransformFinalBlock(src, 0, src.Length);

                // Convert byte array to Base64 strings
                return Convert.ToBase64String(dest);
            }
        }
    }
}