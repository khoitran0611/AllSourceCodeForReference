﻿namespace BinderOne.Models.Document
{
    using System;

    public class AttachDocumentDialogViewModel
    {
        public int Contract_ID { get; set; }

        public string PDF { get; set; }

        public string Description { get; set; }

        public int Corp_ID { get; set; }

        public string Optimized { get; set; }

        public DateTime Uploaded { get; set; }

        public string Uploaded_by { get; set; }
    }
}