﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models.Document.Interfaces
{
    public interface ITokenizer
    {
        string Encrypt(DocumentInfo documentInfo);

        DocumentInfo Decrypt(string token);
    }
}