﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models.Document.Interfaces
{
    using System.IO;
    using System.Security.Claims;

    public interface IDocumentRepository
    {
        FileStream GetDocument(DocumentInfo documentInfo, ClaimsIdentity identity);

        bool IsDocumentValid(DocumentInfo documentInfo, ClaimsIdentity identity);
    }
}