﻿///
///<Copyright year="2016"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using BinderOne.EF;
    using System.Collections.Generic;

    public class UserSearchResultViewModel
    {
        public UserSearchResultViewModel()
        {
            PageSize = 25;
            PageIndex = 0;
        }

        public string LoginEmail { get; set; }

        public int TotalCount { get; set; }

        public int PageSize { get; set; }

        public int PageIndex { get; set; }

        public List<login> UserSearchResult { get; set; }
    }
}