﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using EF;
    using Services;
    using System.Security.Claims;
    using System.Threading;

    public class UserContext
    {
        private DataProvider dataContext = new DataProvider { DbContext = new BinderOneEntities() };

        public string CompanyName
        {
            get
            {
                var claimIdentity = (ClaimsIdentity)Thread.CurrentPrincipal.Identity;
                var userId = claimIdentity.FindFirst(ClaimTypes.Sid)?.Value;

                return string.IsNullOrWhiteSpace(userId) ? string.Empty : dataContext.GetCompanyName(long.Parse(userId));
            }
        }
    }
}