﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models.AddionalContract
{
    using BinderOne.EF;
    using System.Collections.Generic;

    public class AdditionalContractViewModel
    {
        public umc_contracts_setup ContractSetup { get; set; }
        public umc_contracts Contract { get; set; }
        public List<nmc_ex_contracts> ExContracts { get; set; }
    }
}