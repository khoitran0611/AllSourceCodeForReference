﻿///
///<Copyright year="2016"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class UserViewModel
    {
        public int ID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required(ErrorMessage = "The Login (E-Mail Preferred) field is required")]
        public string Login { get; set; }

        [Required]
        [EmailAddress
          (ErrorMessage = "Invalid Email Address")
        ]
        [Display(Name = "E-Mail Address")]
        public string Email { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        [RegularExpression("([0-9]+)", ErrorMessage = "Bad Login must be a Number.")]
        public int Bad_Logins { get; set; }

        public string Login_Class { get; set; }

        public int Facility { get; set; }

        public string Corp { get; set; }

        public string Access_Level { get; set; }

        public int Corp_ID { get; set; }

        public string A_Level { get; set; }

        public string Care_Type { get; set; }

        public int Total_Bad_Logins { get; set; }

        public string CanQuickSearch { get; set; }

        public string IsAdmin { get; set; }

        public string CanStoplessCalculator { get; set; }

        public string CanViewPDF { get; set; }

        public string CanEditContractInfo { get; set; }

        public string IsEmpCompManager { get; set; }

        public string CanDeleteCompManager { get; set; }

        public string CanUploadContractDoc { get; set; }

        public string CanDeleteContract { get; set; }

        public string CanDeleteOIG { get; set; }

        public string Administrator { get; set; }

        public string Facilities { get; set; }

        public string ContractTypes { get; set; }

        public string Departments { get; set; }
    }
}