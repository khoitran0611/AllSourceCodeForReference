﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models.EvaluateContract
{
    using BinderOne.EF;

    public class EvaluateContractViewModel
    {
        public string Comments { get; set; }
        public string Satisfactory { get; set; }
        public string Recommendation { get; set; }
        public string F1 { get; set; }
        public string F2 { get; set; }
        public string F3 { get; set; }
        public string F4 { get; set; }
        public string F5 { get; set; }
        public string F6 { get; set; }
        public string F7 { get; set; }
        public string F8 { get; set; }
        public string F9 { get; set; }
        public string F10 { get; set; }
        public string F11 { get; set; }
        public string F12 { get; set; }
        public string F13 { get; set; }
        public string F14 { get; set; }
        public string F15 { get; set; }
        public string F16 { get; set; }
        public string F17 { get; set; }
        public string F18 { get; set; }
        public string F19 { get; set; }
        public string F20 { get; set; }
        public string F21 { get; set; }
        public string F22 { get; set; }
        public string F23 { get; set; }
        public string F24 { get; set; }
        public string F25 { get; set; }
        public int EXContractsCount { get; set; }
        public nmc_eval_setup EvalSetUp { get; set; }
        public umc_contracts_setup ContractSetup { get; set; }
        public umc_contracts Contract { get; set; }
        public bool isInEditMode { get; set; }
        public int EvalId { get; set; }
    }
}