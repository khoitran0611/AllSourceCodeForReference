﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using System.ComponentModel.DataAnnotations;

    public class AttachDocumentFilterViewModel
    {
        [Required]
        [Display(Name = "Location")]
        public string FacilityId { get; set; }

        [Required]
        [Display(Name = "Vendor")]
        public string Vendor { get; set; }

        [Display(Name = "Pagesize")]
        public int PageSize { get; set; }

        [Display(Name = "Page")]
        public int PageIndex { get; set; }

        public AttachDocumentFilterViewModel()
        {
            FacilityId = "23";
            Vendor = string.Empty;
            PageSize = 25;
            PageIndex = 0;
        }
    }
}