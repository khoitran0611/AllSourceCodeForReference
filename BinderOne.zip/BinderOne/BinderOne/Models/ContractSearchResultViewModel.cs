﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using System.Collections.Generic;

    public class ContractSearchResultViewModel
    {
        public string SortedBy { get; set; }

        public bool SortedDescending { get; set; }

        public int TotalCount { get; set; }

        public int PageSize { get; set; }

        public int PageIndex { get; set; }

        public SearchMode SearchMode { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public ICollection<ContractSummary> ContractSummaries { get; set; }
    }
}