﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using System.ComponentModel.DataAnnotations;

    //TODO: get display strings from umc_contracts_setup based on corp_id
    public class ContractSearchCriteriaViewModel
    {
        [Required]
        [Display(Name = "Location")]
        public string Facility { get; set; }

        [Required]
        [Display(Name = "Vendor")]
        public string Vendor { get; set; }

        [Display(Name = "Vendor matches")]
        public string VendorMatch { get; set; }

        [Required]
        [Display(Name = "Department")]
        public string Department { get; set; }

        [Required]
        [Display(Name = "Contract Type")]
        public string ContractType { get; set; }

        [Display(Name = "Contract ID")]
        public string ContractId { get; set; }

        [Display(Name = "Pagesize")]
        public int PageSize { get; set; }

        [Display(Name = "Page")]
        public int PageIndex { get; set; }

        [Display(Name = "Sorted By")]
        public string SortedBy { get; set; }

        [Display(Name = "Sorted Descending")]
        public bool SortedDescending { get; set; }

        [Display(Name = "Search Mode")]
        public SearchMode SearchMode { get; set; }

        public ContractSearchCriteriaViewModel()
        {
            Facility = "All";
            Vendor = "All";
            Department = "All";
            ContractType = "All";
            PageSize = 25;
            SortedBy = "ID";
            SearchMode = SearchMode.Expiring;
        }
    }
}