﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    public sealed class Action
    {
        private Action()
        {
        }

        public const string SendEmail = "Send E-mail";
    }
}