﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using System;

    public class ManagedCareContractResult
    {
        public int Id { get; set; }
        public string Facility { get; set; }
        public string StartDate { get; set; }
        public string Plan { get; set; }
        public string Product { get; set; }
        public string RenewalType { get; set; }
        public string EndDate { get; set; }
        public string ExpirationDate { get; set; }
        public string ReimbType { get; set; }
        public string Header { get; set; }
        public string CompanyCode { get; set; }
    }
}