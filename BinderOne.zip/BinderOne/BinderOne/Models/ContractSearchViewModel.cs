﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    public class ContractSearchViewModel
    {
        public ContractSearchCriteriaViewModel SearchCriteria { get; set; }

        public ContractSearchResultViewModel SearchResult { get; set; }
    }
}