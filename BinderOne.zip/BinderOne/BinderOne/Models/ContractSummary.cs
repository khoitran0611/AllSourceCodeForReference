﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Models
{
    using System;

    public class ContractSummary
    {
        public int Id { get; set; }
        public string Facility { get; set; }
        public DateTime? EffectiveDate { get; set; }
        public string Vendor { get; set; }
        public string ContractType { get; set; }
        public string RenewalType { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public string Department { get; set; }
        public string HeaderNotes { get; set; }
        public bool OigExclusion { get; set; }
    }
}