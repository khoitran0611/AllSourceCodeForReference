﻿
using BinderOne.EF;
using BinderOne.Models.Document;
///
///<Copyright year="2016"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///
namespace BinderOne.Models
{
    public class AttachDocumentDialogModel
    {
        public AttachDocumentDialogViewModel AttachDialogViewModel { get; set; }
        public umc_contracts_setup ContractSetup { get; set; }
        public umc_contracts Contract { get; set; }
    }
}