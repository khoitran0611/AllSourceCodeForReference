﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne
{
    using System.Web.Optimization;

    public sealed class BundleConfig
    {
        private BundleConfig()
        {
        }

        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            if (bundles == null) return;

            #region Javascript Framework bundles

            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                "~/Scripts/jquery.validate*"));

            bundles.Add(new ScriptBundle("~/bundles/modernizr")
                .Include("~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                "~/Content/flat-ui/js/bootstrap.min.js",
                "~/Scripts/multiselect/bootstrap-multiselect.js",
                "~/Scripts/datatables/jquery.dataTables.min.js",
                "~/Content/flat-ui/js/respond.min.js"));

            bundles.Add(new ScriptBundle("~/bundles/flatui").Include(
                //"~/Content/flat-ui/js/jquery-1.8.3.min.js",
                "~/Content/flat-ui/js/jquery-ui-1.10.3.custom.min.js",
                "~/Content/flat-ui/js/jquery.ui.touch-punch.min.js",
                //"~/Content/flat-ui/js/bootstrap.min.js",
                "~/Content/flat-ui/js/bootstrap-select.js",
                "~/Content/flat-ui/js/bootstrap-switch.js",
                "~/Content/flat-ui/js/flatui-checkbox.js",
                "~/Content/flat-ui/js/flatui-radio.js",
                //"~/Content/flat-ui/js/flat-ui.min.js",
                "~/Content/flat-ui/js/jquery.tagsinput.js",
                "~/Scripts/jquery.form.min.js",
                "~/Scripts/jquery-ui-1.11.4.min.js",
                "~/Content/flat-ui/js/jquery.placeholder.js"));

            #endregion Javascript Framework bundles

            #region Style Framework bundles

            bundles.Add(new StyleBundle("~/bundles/appl-css")
               .Include("~/Content/flat-ui/bootstrap/css/bootstrap.css", new CssRewriteUrlTransform())
               .Include("~/Content/ui-kit/ui-kit-footer/css/style.css", new CssRewriteUrlTransform())
               .Include("~/Content/flat-ui/css/flat-ui.css", new CssRewriteUrlTransform())
               .Include("~/Content/common-files/css/animations.css", new CssRewriteUrlTransform())
               .Include("~/Content/themes/base/all.css", new CssRewriteUrlTransform())
               .Include("~/Content/multiselect/bootstrap-multiselect.css", new CssRewriteUrlTransform())
               .Include("~/Content/datatables/jquery.dataTables.min.css", new CssRewriteUrlTransform())
               .Include("~/Content/Site.css", new CssRewriteUrlTransform()));

            #endregion Style Framework bundles

            #region Company page scripts and styles

            //bundles used in non-application pages (i.e. company pages)
            bundles.Add(new ScriptBundle("~/bundles/static").Include(
                "~/Content/common-files/js/jquery-1.10.2.min.js",
                "~/Content/common-files/js/jquery.bxslider.min.js",
                "~/Content/common-files/js/jquery.scrollTo-1.4.3.1-min.js",
                "~/Content/common-files/js/jquery.sharrre.min.js",
                "~/Content/flat-ui/js/bootstrap.min.js",
                "~/Content/common-files/js/masonry.pkgd.min.js",
                "~/Content/common-files/js/modernizr.custom.js",
                "~/Content/common-files/js/page-transitions.js",
                "~/Content/common-files/js/easing.min.js",
                "~/Content/common-files/js/jquery.svg.js",
                "~/Content/common-files/js/jquery.svganim.js",
                "~/Content/common-files/js/jquery.backgroundvideo.js",
                "~/Content/common-files/js/froogaloop.js",
                "~/Content/common-files/js/startup-kit.js"));

            bundles.Add(new StyleBundle("~/bundles/site-css")
                .Include("~/Content/flat-ui/bootstrap/css/bootstrap.css", new CssRewriteUrlTransform())
                .Include("~/Content/flat-ui/css/flat-ui.css", new CssRewriteUrlTransform())
                .Include("~/Content/static/css/style.css", new CssRewriteUrlTransform())
                .Include("~/Content/ui-kit/ui-kit-blog/css/style.css", new CssRewriteUrlTransform())
                .Include("~/Content/ui-kit/ui-kit-header/css/style.css", new CssRewriteUrlTransform())
                .Include("~/Content/ui-kit/ui-kit-content/css/style.css", new CssRewriteUrlTransform())
                .Include("~/Content/ui-kit/ui-kit-projects/css/style.css", new CssRewriteUrlTransform())
                .Include("~/Content/common-files/css/animations.css", new CssRewriteUrlTransform()));

            #endregion Company page scripts and styles

            #region Application Module Typescript bundles

            bundles.Add(new ScriptBundle("~/bundles/app/cmm").Include(
                "~/Scripts/Contract/ContractManager.js",
                "~/Scripts/ManagedCare/ManagedCareManager.js"));

            #endregion Application Module Typescript bundles
        }
    }
}