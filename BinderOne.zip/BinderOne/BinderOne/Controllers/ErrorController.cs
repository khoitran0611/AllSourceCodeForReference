﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Controllers
{
    using System.Web.Mvc;

    public class ErrorController : SecuredController
    {
        [HttpGet]
        [AllowAnonymous]
        public ActionResult Index()
        {
            return View("Error");
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult Unauthorized(string jsonData)
        {
            return View(jsonData);
        }

        [HttpGet]
        [AllowAnonymous]
        public ActionResult Http404()
        {
            return View();
        }
    }
}