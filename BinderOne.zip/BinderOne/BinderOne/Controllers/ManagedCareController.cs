﻿///
///<Copyright year="2016"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Controllers
{
    using EF;
    using Models;
    using Security;
    using Services;
    using System.Collections.Generic;
    using System.Linq;
    using System.Security.Claims;
    using System.Web.Mvc;
    using BoClaimTypes = BinderOne.Common.Security.ClaimTypes;
    using SysClaimTypes = System.Security.Claims.ClaimTypes;

    [ClaimsAuthorize(
        Claims = new[]
        {
            SysClaimTypes.Sid, "All",
            SysClaimTypes.PrimaryGroupSid, "All",
            BoClaimTypes.CorpProductType, "Both,MC"
        }
    )]
    public class ManagedCareController : SecuredController
    {
        public DataProvider DataContext { get; set; }

        public ManagedCareController()
        {
            DataContext = new DataProvider { DbContext = new BinderOneEntities() };
        }

        [HttpGet]
        public ActionResult Index()
        {
            var model = new ManagedCareSearchViewModel()
            {
                SearchCriteria = new ManagedCareSearchCriteriaViewModel(),
                SearchResult = new ManagedCareSearchResultViewModel()
            };

            model.SearchResult.ManagedCareContracts = new List<ManagedCareContractResult>();

            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                var facilityIdClaim = identity.Claims.Where(c => c.Type == BoClaimTypes.FacilityId).FirstOrDefault();
                var userFacility = DataContext.GetFacilityById(int.Parse(facilityIdClaim.Value));
                var facility = userFacility != null ? userFacility.Facility1 : "All";

                ViewBag.Facilities = DataContext.GetMemberFacilities(identity);
                ViewBag.Plans = DataContext.GetPlans(identity);
                ViewBag.Products = DataContext.GetProducts(identity);
                model.SearchCriteria.Facility = facility;
                model.SearchResult = DataContext.GetContracts(identity, model.SearchCriteria, false);
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Search(ManagedCareSearchCriteriaViewModel criteria)
        {
            var identity = (ClaimsIdentity)User.Identity;

            var model = new ManagedCareSearchResultViewModel { ManagedCareContracts = new List<ManagedCareContractResult>() };

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                model = DataContext.GetContracts(identity, criteria, true);
            }

            return PartialView("_Search", model);
        }

        [HttpGet]
        public ActionResult Show(int id)
        {
            var model = new ContractViewModel()
            {
                Contract = new contract(),
                ContractInsList = new List<contract_ins_codes>(),
                PerDiemDRGList = new List<contract_perdiem_drg>(),
                PerDiemIDCList = new List<contract_perdiem>()
            };

            QuickSearchViewModel quickSearchModel = null;
            model.contractId = id;
            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                ViewBag.ContractSetup = this.DataContext.GetContractSetup(identity);
                model = DataContext.GetContractById(identity, id, quickSearchModel);
                ViewBag.IsQuickSearch = false;
            }

            if (model.Contract == null)
            {
                return RedirectToAction("Index", "Error");
            }

            return View(model);
        }

        [HttpGet]
        public JsonResult GetContractInfo(int id, string ubRevCodes, string IcdProcCode, string Cpt, string DRG)
        {
            var model = new ContractViewModel()
            {
                Contract = new contract(),
                ContractInsList = new List<contract_ins_codes>(),
                PerDiemDRGList = new List<contract_perdiem_drg>(),
                PerDiemIDCList = new List<contract_perdiem>()
            };

            var quickSearchModel = new QuickSearchViewModel()
            {
                UbRevenueCode = ubRevCodes,
                DRG = DRG,
                Cpt = Cpt,
                IcdProcCode = IcdProcCode
            };
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //throw exception or get to error page
            }

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                model = this.DataContext.GetContractById(identity, id, quickSearchModel);
            }

            return Json(model, JsonRequestBehavior.AllowGet);
        }

        #region Quick Search By Code

        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult QuickSearchByCode(int id)
        {
            var model = new QuickSearchViewModel()
            {
                ContractId = id
            };

            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            return PartialView("_QuickSearchByCode", model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult QuickSearchByCode(QuickSearchViewModel model)
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            var contractId = !string.IsNullOrEmpty(Request.Form["ContractId"]) ? int.Parse(Request.Form["ContractId"].ToString()) : 0;

            var result = DataContext.GetContractById(identity, contractId, model);

            ViewBag.ContractSetup = DataContext.GetContractSetup(identity);
            ViewBag.IsQuickSearch = true;
            result.QuickSearch = model;

            if (model.PrinterFriendly == "No")
            {
                return View("Show", result);
            }
            else
            {
                return View("ShowPrinterFriendly", result);
            }
        }

        #endregion Quick Search By Code
    }
}