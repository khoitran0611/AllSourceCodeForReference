﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Controllers
{
    using BinderOne.Models.Document;
    using EF;
    using Models;
    using Models.AddionalContract;
    using Models.EvaluateContract;
    using Security;
    using Services;
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Linq;
    using System.Security.Claims;
    using System.Web;
    using System.Web.Mvc;
    using BoClaimTypes = BinderOne.Common.Security.ClaimTypes;
    using SysClaimTypes = System.Security.Claims.ClaimTypes;

    [ClaimsAuthorize(
        Claims = new[]
        {
            SysClaimTypes.Sid, "All",
            SysClaimTypes.PrimaryGroupSid, "All",
            BoClaimTypes.CorpProductType, "Both,NMC"
        }
    )]
    public class ContractController : SecuredController
    {
        public DataProvider DataContext { get; set; }

        public ContractController()
        {
            DataContext = new DataProvider { DbContext = new BinderOneEntities() };
        }

        // GET: ContractSummary
        [HttpGet]
        public ActionResult Index()
        {
            var model = new ContractSearchViewModel();
            model.SearchCriteria = new ContractSearchCriteriaViewModel();
            model.SearchResult = new ContractSearchResultViewModel();

            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                var facilityIdClaim = identity.Claims.Where(c => c.Type == BoClaimTypes.FacilityId).FirstOrDefault();
                var userFacility = DataContext.GetFacilityById(int.Parse(facilityIdClaim.Value));
                var facility = userFacility != null ? userFacility.Facility1 : "All";

                ViewBag.Facilities = DataContext.GetMemberFacilities(identity);
                ViewBag.Departments = DataContext.GetMemberDepartments(identity);
                ViewBag.Vendors = DataContext.GetContractVendors(identity);
                ViewBag.ContractTypes = DataContext.GetMemberContractTypes(identity);
                ViewBag.ContractSetup = this.DataContext.GetContractSetup(identity);
                model.SearchCriteria.Facility = facility;
                model.SearchResult = DataContext.GetContractSummaries(identity, model.SearchCriteria);
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Search(ContractSearchCriteriaViewModel criteria)
        {
            var model = new ContractSearchResultViewModel { ContractSummaries = new List<ContractSummary>() };
            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                model = DataContext.GetContractSummaries(identity, criteria);
                ViewBag.ContractSetup = this.DataContext.GetContractSetup(identity);
            }

            return PartialView("_Search", model);
        }

        [HttpGet]
        public ActionResult Show(int id)
        {
            var model = new umc_contracts();
            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                var evalPagingInfo = new ContractPagingInfo()
                {
                    ContractId = id,
                    PageSize = 25
                };

                var contractPagingInfo = new ContractPagingInfo()
                {
                    ContractId = id,
                    PageSize = 25
                };

                ViewBag.ContractSetup = this.DataContext.GetContractSetup(identity);
                ViewBag.Eval = DataContext.GetEval(identity, id, evalPagingInfo);
                ViewBag.PaperTrailList = DataContext.GetPaperTrail(identity, id, contractPagingInfo);
                ViewBag.PagingInfo = evalPagingInfo;
                ViewBag.ContractPagingInfo = contractPagingInfo;

                model = this.DataContext.GetContract(identity, id);
            }

            return View(model);
        }

        [HttpGet]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "E"
            }
        )]
        public ActionResult Edit(int id)
        {
            var model = new umc_contracts();
            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                ViewBag.ContractSetup = this.DataContext.GetContractSetup(identity);
                ViewBag.Departments = DataContext.GetMemberDepartments(identity);
                ViewBag.Vendors = DataContext.GetContractVendors(identity);
                ViewBag.ContractTypes = DataContext.GetMemberContractTypes(identity);

                model = this.DataContext.GetContract(identity, id);

                var facilityId = model.facility_ID.HasValue ? model.facility_ID.Value : 0;
                ViewBag.RPNameList = DataContext.GetRPNames(identity, facilityId);

                ViewBag.RenewalTypeList = DataContext.GetRenewalTypes(identity);
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Save(umc_contracts contract)
        {
            var identity = (ClaimsIdentity)User.Identity;

            umc_contracts updatedContract = null;
            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                updatedContract = this.DataContext.SaveContract(identity, contract);
            }

            if (updatedContract == null)
            {
                //TODO: show an error message to user
            }

            return RedirectToAction("Show", new { id = updatedContract.ID });
        }

        #region Evaluate Contract section

        [HttpGet]
        public ActionResult EvaluateContract(int id)
        {
            EvaluateContractViewModel evaluateContractViewModel = null;
            var identity = (ClaimsIdentity)User.Identity;
            var evalId = 0;
            var isInEditMode = true;

            //Get eval_id from querystring first
            //if it is null or empty, it is create new
            //else if isEdit equals true --> edit mode, else create new mode
            if (identity != null)
            {
                //Check if the evalId is passed
                if (!string.IsNullOrEmpty(Request.QueryString["evalId"]))
                {
                    evalId = int.Parse(Request.QueryString["evalId"]);
                }

                //Which mode are users in
                if (!string.IsNullOrEmpty(Request.QueryString["isEdit"]))
                {
                    isInEditMode = bool.Parse(Request.QueryString["isEdit"].ToLower());
                }

                //Edit or view evaluate contract
                if (evalId != 0)
                {
                    evaluateContractViewModel = DataContext.GetEvaluateContract(identity, id, evalId);
                }
                else //Create new Evaluate contract
                {
                    evaluateContractViewModel = DataContext.GetEvaluateContract(identity, id, 0);
                }
            }

            if (evaluateContractViewModel == null)
            {
                //TODO: Show error message
            }

            if (isInEditMode)
            {
                evaluateContractViewModel.isInEditMode = true;
            }

            evaluateContractViewModel.EvalId = evalId;

            return View(evaluateContractViewModel);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult EvaluateContract(EvaluateContractViewModel model)
        {
            var contractId = 0;

            var identity = (ClaimsIdentity)User.Identity;
            EvaluateContractViewModel evaluateContractViewModel = null;
            var evalId = 0;
            var isInEditMode = true;

            if (identity != null)
            {
                if (int.TryParse(Request.Form["ID"], out contractId))
                {
                    evaluateContractViewModel = DataContext.GetEvaluateContract(identity, contractId);
                }

                //Update the EvalId and IsInEditMode status
                if (int.TryParse(Request.Form["EvalIdHidden"], out evalId))
                {
                    model.EvalId = evalId;
                }

                if (bool.TryParse(Request.Form["isInEditModeHidden"].ToLower(), out isInEditMode))
                {
                    model.isInEditMode = isInEditMode;
                }
            }

            if (evaluateContractViewModel == null)
            {
                //TODO: Show error message
            }

            model.Contract = evaluateContractViewModel.Contract;
            model.EXContractsCount = evaluateContractViewModel.EXContractsCount;

            var isSuceeded = DataContext.PopulateEvaluateContract(identity, model);
            if (isSuceeded)
            {
                var evalPagingInfo = new ContractPagingInfo()
                {
                    ContractId = model.Contract.ID,
                    PageSize = 25
                };

                var contractPagingInfo = new ContractPagingInfo()
                {
                    ContractId = model.Contract.ID,
                    PageSize = 25
                };

                ViewBag.ContractSetup = this.DataContext.GetContractSetup(identity);
                ViewBag.Eval = DataContext.GetEval(identity, model.Contract.ID, evalPagingInfo);
                ViewBag.PaperTrailList = DataContext.GetPaperTrail(identity, model.Contract.ID, contractPagingInfo);
                ViewBag.PagingInfo = evalPagingInfo;
                ViewBag.ContractPagingInfo = contractPagingInfo;

                return RedirectToAction("Show", new { id = contractId });
            }

            return View(model);
        }

        [HttpGet]
        public ActionResult ViewEvaluateContract(int id)
        {
            EvaluateContractViewModel evaluateContractViewModel = null;
            var identity = (ClaimsIdentity)User.Identity;
            var evalId = 0;
            var isInEditMode = true;

            //Get eval_id from querystring first
            //if it is null or empty, it is create new
            //else if isEdit equals true --> edit mode, else create new mode
            if (identity != null)
            {
                //Check if the evalId is passed
                if (!string.IsNullOrEmpty(Request.QueryString["evalId"]))
                {
                    evalId = int.Parse(Request.QueryString["evalId"]);
                }

                //Which mode are users in
                if (!string.IsNullOrEmpty(Request.QueryString["isEdit"]))
                {
                    isInEditMode = bool.Parse(Request.QueryString["isEdit"].ToLower());
                }

                //Edit or view evaluate contract
                if (evalId != 0)
                {
                    evaluateContractViewModel = DataContext.GetEvaluateContract(identity, id, evalId);
                }
                else //Create new Evaluate contract
                {
                    evaluateContractViewModel = DataContext.GetEvaluateContract(identity, id, 0);
                }
            }

            if (evaluateContractViewModel == null)
            {
                //TODO: Show error message
            }

            if (isInEditMode)
            {
                evaluateContractViewModel.isInEditMode = true;
            }

            evaluateContractViewModel.EvalId = evalId;

            return View(evaluateContractViewModel);
        }

        #endregion Evaluate Contract section

        #region Addional Contract section

        [HttpGet]
        public ActionResult AdditionalDocuments(int id, int pageIndex = 0)
        {
            var contractPagingInfo = new ContractPagingInfo()
            {
                ContractId = id,
                PageSize = 25, /*TODO: Set dynamically later*/
                PageIndex = string.IsNullOrEmpty(Request.QueryString["pageIndex"]) ? 0 : int.Parse(Request.QueryString["pageIndex"])
            };

            ViewBag.ContractPagingInfo = contractPagingInfo;

            var identity = (ClaimsIdentity)User.Identity;
            ViewBag.DataContext = DataContext;
            ViewBag.Identity = identity;

            AdditionalContractViewModel additionalContractViewModel = null;

            /*TODO: get value for showEdit from logins in claims later */
            if (identity != null)
            {
                additionalContractViewModel = DataContext.GetAddionalContract(identity, contractPagingInfo);
            }

            if (identity == null || additionalContractViewModel == null)
            {
                //TODO: Show error message
            }

            //if contractSetup is null --> corpid of the identity is not the same with the contract corpid
            //if (additionalContractViewModel.ContractSetup == null)
            //{
            //    return RedirectToAction("Index", "Error");
            //}

            return View(additionalContractViewModel);
        }

        [HttpPost]
        public ActionResult AdditionalDocuments(ContractPagingInfo pagingInfo)
        {
            var identity = (ClaimsIdentity)User.Identity;
            AdditionalContractViewModel additionalContractViewModel = null;

            /*TODO: get value for showEdit from logins in claims later */
            if (identity != null)
            {
                additionalContractViewModel = DataContext.GetAddionalContract(identity, pagingInfo);
            }

            if (additionalContractViewModel == null)
            {
                //TODO: Show error message
            }

            ViewBag.ContractPagingInfo = pagingInfo;
            ViewBag.DataContext = DataContext;
            ViewBag.Identity = identity;

            if (additionalContractViewModel.ContractSetup == null)
            {
                return RedirectToAction("Index", "Error");
            }

            return PartialView("_AdditionalDocumentsPaging", additionalContractViewModel);
        }

        #endregion Addional Contract section

        #region Edit Document section

        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "E"
            }
        )]
        public ActionResult EditDocumentDescription(string id)
        {
            var exContractId = 0;
            var currentPageIndex = 0;
            var exContract = new nmc_ex_contracts();
            var documentDescriptionEdit = new DocumentDescriptionEditViewModel();
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            //Split to get the nmc_ex_contract id
            //and the current page to get back after edit the description
            string[] documentInfo = id.Split(',');
            if (int.TryParse(documentInfo[0], out exContractId))
            {
                exContract = DataContext.GetExContract(identity, exContractId);
            }
            if (int.TryParse(documentInfo[1], out currentPageIndex))
            {
                documentDescriptionEdit.CurrentPageIndex = currentPageIndex;
            }

            documentDescriptionEdit.Description = exContract == null ? string.Empty : exContract.Description;
            documentDescriptionEdit.ExContractId = exContract == null ? 0 : exContract.ID;
            documentDescriptionEdit.ContractId = exContract.Contract_ID;

            return PartialView("_DocumentDescriptionEdit", documentDescriptionEdit);
        }

        [HttpPost]
        public ActionResult EditDocumentDescription(DocumentDescriptionEditViewModel model)
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            var exContract = DataContext.GetExContract(identity, model.ExContractId);
            DataContext.UpdateExContractDescription(exContract, model.Description);

            /*TODO: Call the code to check and delete the document here*/

            //After update data, close the popup, but still keep the current page to see the data updated
            return RedirectToAction("AdditionalDocuments",
                new { id = model.ContractId, pageIndex = model.CurrentPageIndex });
        }

        #endregion Edit Document section

        #region Log section

        [HttpPost]
        public ActionResult EvaluationLog(ContractPagingInfo pagingInfo)
        {
            var identity = (ClaimsIdentity)User.Identity;
            List<nmc_eval> evalList = null;

            if (identity != null)
            {
                evalList = DataContext.GetEval(identity, pagingInfo.ContractId, pagingInfo);
                ViewBag.PagingInfo = pagingInfo;
                ViewBag.Eval = evalList;
                ViewBag.IsShowEvaluation = true;

                return PartialView("_ContractEvaluationLog", null);
            }

            //If the flow goes here, there is error
            return RedirectToAction("Http404", "Error");
        }

        [HttpPost]
        public ActionResult ContractLog(ContractPagingInfo pagingInfo)
        {
            var identity = (ClaimsIdentity)User.Identity;
            List<umc_papertrail> paperTrailList = null;

            if (identity != null)
            {
                paperTrailList = DataContext.GetPaperTrail(identity, pagingInfo.ContractId, pagingInfo);
                ViewBag.ContractPagingInfo = pagingInfo;
                ViewBag.PaperTrailList = paperTrailList;
                ViewBag.IsShowContract = true;

                return PartialView("_ContractLog");
            }

            //If the flow goes here, there is error
            return RedirectToAction("Http404", "Error");
        }

        #endregion Log section

        #region Upload contract and document

        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult UploadContractAndDocument()
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            return PartialView("_UploadContractAndDocument");
        }

        [HttpGet]
        public ActionResult UploadNewContract()
        {
            var model = new umc_contracts_new();
            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                ViewBag.ContractSetup = this.DataContext.GetContractSetup(identity);
                ViewBag.Departments = DataContext.GetMemberDepartments(identity);
                ViewBag.Vendors = DataContext.GetContractVendors(identity);
                ViewBag.ContractTypes = DataContext.GetMemberContractTypes(identity);

                var facilityId = 0;

                //For create new contract, the facilityId is always 0
                ViewBag.RPNameList = DataContext.GetRPNames(identity, facilityId);

                ViewBag.RenewalTypeList = DataContext.GetRenewalTypes(identity);

                ViewBag.Facilities = DataContext.GetFacilities(identity);
            }

            return View(model);
        }

        [HttpGet]
        public ActionResult AttachDocToExistingContract()
        {
            var identity = (ClaimsIdentity)User.Identity;

            var model = new AttachDocumentViewModel();
            model.AttachDocFilter = new AttachDocumentFilterViewModel();
            model.SearchResult = new AttachDocumentSearchResultViewModel();
            model.SearchResult.ContractSearchResult = new List<umc_contracts>();

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                ViewBag.ContractSetup = this.DataContext.GetContractSetup(identity);
                ViewBag.Facilities = DataContext.GetFacilities(identity);
            }

            //Put data to session to show in the dialog

            return View(model);
        }

        #endregion Upload contract and document

        #region Proceed To Upload

        [HttpPost]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult ProceedToUpload(umc_contracts_new model)
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }
            model.facility = DataContext.GetFacilityById(model.facility_ID.Value).Facility1;

            TempData["ContractSummary"] = model;

            return PartialView("_ProceedToUpload");
        }

        [HttpPost]
        public JsonResult UploadContract()
        {
            var isSuceeded = false;
            HttpPostedFileBase contractFile = Request.Files["fileupload"];
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null || contractFile == null)
            {
                //TODO: throw exception or show error page
            }

            var inputStream = contractFile.InputStream;
            string documentFilePath = ConfigurationManager.AppSettings["FilePath"];
            var originalFileName = Path.GetFileName(contractFile.FileName);
            originalFileName = originalFileName.Substring(0, originalFileName.LastIndexOf("."));
            var fileExtension = Path.GetExtension(contractFile.FileName);
            var fullpath = Path.Combine(documentFilePath, Path.GetFileName(contractFile.FileName));
            var fileName = originalFileName;
            try
            {
                if (System.IO.File.Exists(fullpath))
                {
                    //Get all file from selected folder with the name starts with
                    //the file passed in
                    DirectoryInfo d = new DirectoryInfo(documentFilePath);
                    List<FileInfo> Files = d.GetFiles(originalFileName + ".*").ToList();
                    var filesWithUnderScore = d.GetFiles("*.*").Where(f => f.Name.StartsWith(originalFileName + "_")).ToList();
                    var fileNameEndWithUnderScore = 0;

                    foreach (var aFile in filesWithUnderScore)
                    {
                        var underScorePos = aFile.Name.LastIndexOf("_");
                        var newName = aFile.Name.Substring(underScorePos);
                        var numberPart = newName.Substring(1, newName.LastIndexOf(".") - 1);
                        if (int.TryParse(numberPart, out fileNameEndWithUnderScore))
                        {
                            Files.Add(aFile);
                        }
                    }

                    if (Files.Count > 1)
                    {
                        var fileNumList = new List<int>();
                        foreach (FileInfo file in Files)
                        {
                            var lastUnderScorePos = file.Name.LastIndexOf("_");
                            var fileNum = 0;
                            if (lastUnderScorePos > 0)
                            {
                                var newName = file.Name.Substring(lastUnderScorePos);
                                var numberPart = newName.Substring(1, newName.LastIndexOf(".") - 1);
                                int.TryParse(numberPart, out fileNum);

                                if (fileNum > 0) //There are other files with the same name with postfixs already
                                {
                                    fileNumList.Add(fileNum);
                                }
                            }
                        }

                        if (fileNumList.Count > 0)
                        {
                            fileName = originalFileName + "_" + (fileNumList.Max() + 1).ToString();
                        }
                        else
                        {
                            fileName = originalFileName + "_1";
                        }
                    }
                    else // only one file with the same name exist
                    {
                        fileName = originalFileName + "_1";
                    }

                    fullpath = Path.Combine(documentFilePath, fileName + fileExtension);
                }

                //Create a new file and write its content
                using (var fs = new FileStream(fullpath, FileMode.Append, FileAccess.Write))
                {
                    var buffer = new byte[1024];

                    var l = inputStream.Read(buffer, 0, 1024);
                    while (l > 0)
                    {
                        fs.Write(buffer, 0, l);
                        l = inputStream.Read(buffer, 0, 1024);
                    }
                    fs.Flush();
                    fs.Close();
                }

                var model = (umc_contracts_new)TempData["ContractSummary"];
                model.contract = fileName + fileExtension;

                var contract = DataContext.CreateNewContract(identity, model);
                var adminEmail = ConfigurationManager.AppSettings["adminEmail"];

                if (contract != null) //Only when the contract is created sucessfully, send email to admin
                {
                    isSuceeded = true;

                    //TODO: Define template later for the email content
                    EmailService.SendMail(adminEmail, "Test Email", "A new contract has been saved. Please take a look. Thank you");
                }
                else
                {
                    if (System.IO.File.Exists(fullpath))
                    {
                        System.IO.File.Delete(fullpath);
                    }
                }
            }
            catch (Exception)
            {
                //TODO: Log exception to log file.

                //If for some reason there are errors, delete the newly created file
                //if (System.IO.File.Exists(fullpath))
                //{
                //    System.IO.File.Delete(fullpath);
                //}

                isSuceeded = false;
            }

            return Json(new { FileName = contractFile.FileName, Suceeded = isSuceeded.ToString() });
        }

        #endregion Proceed To Upload

        [HttpGet]
        public JsonResult PopulateVendorAndContractType(int facilityId)
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            var vendors = DataContext.GetVendorsAndContractTypes(identity, facilityId);

            var vendorsJson = vendors.Select(v => new
            {
                ID = v.Vendor == null ? "" : v.Vendor,
                Value = (v.Vendor == null ? " - " : v.Vendor + " - ")
                       + (v.Contract_Type == null ? " - " : v.Contract_Type
                       + " - ") + v.ID
            });
            return Json(vendorsJson.ToList(), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult SearchContractForAttachDocument(AttachDocumentFilterViewModel criteria)
        {
            var model = new AttachDocumentSearchResultViewModel { ContractSearchResult = new List<umc_contracts>() };
            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null && identity.Claims.Where(c => string.Compare(c.Type, SysClaimTypes.PrimaryGroupSid, true) == 0).Count() > 0)
            {
                model = DataContext.GetContractsToAttachDocument(identity, criteria);
            }

            ViewBag.DataContext = DataContext;
            ViewBag.Identity = identity;

            return PartialView("_AttachDocumentSearchResult", model);
        }

        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult AttachDocumentDialog(int id)
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }
            var attachDocumentModel = new AttachDocumentDialogModel();
            var login = identity.Claims.FirstOrDefault(c => c.Type == SysClaimTypes.Name)?.Value;
            var contract = DataContext.GetContract(identity, id);
            var contractSetup = DataContext.GetContractSetup(identity);

            ViewBag.ContractSetup = contractSetup;
            ViewBag.Contract = contract;

            attachDocumentModel.ContractSetup = contractSetup;
            attachDocumentModel.Contract = contract;

            var attachDocumentViewModel = new AttachDocumentDialogViewModel()
            {
                Contract_ID = contract.ID,
                PDF = "",
                Description = "",
                Corp_ID = contract.corp_ID ?? 0,
                Optimized = "N",
                Uploaded = DateTime.Now,
                Uploaded_by = login
            };

            attachDocumentModel.AttachDialogViewModel = attachDocumentViewModel;

            return PartialView("_AttachDocumentDialog", attachDocumentModel);
        }

        [HttpPost]
        public JsonResult AttachDocToContract(AttachDocumentDialogModel model)
        {
            var identity = (ClaimsIdentity)User.Identity;
            HttpPostedFileBase contractFile = Request.Files["fileupload"];

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            var inputStream = contractFile.InputStream;
            string documentFilePath = ConfigurationManager.AppSettings["FilePath"];
            var originalFileName = Path.GetFileName(contractFile.FileName);
            originalFileName = originalFileName.Substring(0, originalFileName.LastIndexOf("."));
            var fileExtension = Path.GetExtension(contractFile.FileName);
            var fullpath = Path.Combine(documentFilePath, Path.GetFileName(contractFile.FileName));
            var fileName = originalFileName;
            try
            {
                if (System.IO.File.Exists(fullpath))
                {
                    //Get all file from selected folder with the name starts with
                    //the file passed in
                    DirectoryInfo d = new DirectoryInfo(documentFilePath);
                    List<FileInfo> Files = d.GetFiles(originalFileName + ".*").ToList();
                    var filesWithUnderScore = d.GetFiles("*.*").Where(f => f.Name.StartsWith(originalFileName + "_")).ToList();
                    var fileNameEndWithUnderScore = 0;

                    foreach (var aFile in filesWithUnderScore)
                    {
                        var underScorePos = aFile.Name.LastIndexOf("_");
                        var newName = aFile.Name.Substring(underScorePos);
                        var numberPart = newName.Substring(1, newName.LastIndexOf(".") - 1);
                        if (int.TryParse(numberPart, out fileNameEndWithUnderScore))
                        {
                            Files.Add(aFile);
                        }
                    }

                    if (Files.Count > 1)
                    {
                        var fileNumList = new List<int>();
                        foreach (FileInfo file in Files)
                        {
                            var lastUnderScorePos = file.Name.LastIndexOf("_");
                            var fileNum = 0;
                            if (lastUnderScorePos > 0)
                            {
                                var newName = file.Name.Substring(lastUnderScorePos);
                                var numberPart = newName.Substring(1, newName.LastIndexOf(".") - 1);
                                int.TryParse(numberPart, out fileNum);

                                if (fileNum > 0) //There are other files with the same name with postfixs already
                                {
                                    fileNumList.Add(fileNum);
                                }
                            }
                        }

                        if (fileNumList.Count > 0)
                        {
                            fileName = originalFileName + "_" + (fileNumList.Max() + 1).ToString();
                        }
                        else
                        {
                            fileName = originalFileName + "_1";
                        }
                    }
                    else // only one file with the same name exist
                    {
                        fileName = originalFileName + "_1";
                    }

                    fullpath = Path.Combine(documentFilePath, fileName + fileExtension);
                }

                //Create a new file and write its content
                using (var fs = new FileStream(fullpath, FileMode.Append, FileAccess.Write))
                {
                    var buffer = new byte[1024];

                    var l = inputStream.Read(buffer, 0, 1024);
                    while (l > 0)
                    {
                        fs.Write(buffer, 0, l);
                        l = inputStream.Read(buffer, 0, 1024);
                    }
                    fs.Flush();
                    fs.Close();
                }

                //TODO: Find other solution to remove data from session later
                var attachDocumentModel = model.AttachDialogViewModel;
                attachDocumentModel.Description = model.AttachDialogViewModel.Description;

                //Insert data to exContract table
                attachDocumentModel.PDF = fileName + fileExtension;
                var exContract = DataContext.AddNewExContract(identity, attachDocumentModel);

                var adminEmail = ConfigurationManager.AppSettings["adminEmail"];

                if (exContract != null) //Only when the contract is created sucessfully, send email to admin
                {
                    EmailService.SendMail(adminEmail, "Test Email", "A new contract has been saved. Please take a look. Thank you");
                }
                else
                {
                    if (System.IO.File.Exists(fullpath))
                    {
                        System.IO.File.Delete(fullpath);
                    }
                }
            }
            catch (Exception)
            {
                //TODO: Log to log file here
            }

            return Json(new { Message = "Will be developed soon!" });
        }

        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult ViewSuccessDialog()
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            ViewBag.DataContext = DataContext;
            ViewBag.Identity = identity;

            return PartialView("_SuccessDialog");
        }

        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "X"
            }
        )]
        public ActionResult ShowDeleteContractDialog(int id)
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            return PartialView("_DeleteContractPopup", id);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "X"
            }
        )]
        public ActionResult DeleteContract(int id)
        {
            var identity = (ClaimsIdentity)User.Identity;
            var isDeletedSuccess = false;
            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            //Delete the contract
            var deletedContract = DataContext.DeleteContract(identity, id);
            isDeletedSuccess = deletedContract != null;

            if (isDeletedSuccess)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index", "Error");
            }
        }
    }
}