﻿///
///<Copyright year="2016"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Controllers
{
    using EF;
    using Microsoft.AspNet.Identity.Owin;
    using Models;
    using Security;
    using Services;
    using System.Collections.Generic;
    using System.Security.Claims;
    using System.Web;
    using System.Web.Mvc;
    using BoClaimTypes = BinderOne.Common.Security.ClaimTypes;
    using SysClaimTypes = System.Security.Claims.ClaimTypes;

    [ClaimsAuthorize(
        Claims = new[]
        {
            SysClaimTypes.Sid, "All",
            SysClaimTypes.PrimaryGroupSid, "All",
            BoClaimTypes.UserRights, "U"
        }
    )]
    public class AdminController : SecuredController
    {
        public DataProvider DataContext { get; set; }
        private ApplicationUserManager _userManager;

        public AdminController()
        {
            DataContext = new DataProvider { DbContext = new BinderOneEntities() };
        }

        public AdminController(ApplicationUserManager userManager)
        {
            UserManager = userManager;
        }

        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        // GET: UserList
        [HttpGet]
        public ActionResult Index()
        {
            var model = new UserSearchResultViewModel();
            model.UserSearchResult = new List<login>();

            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //Throw exception or show error page
            }
            if (identity != null)
            {
                ViewBag.ContractSetup = this.DataContext.GetContractSetup(identity);
            }

            model = DataContext.GetUserList(identity, model);
            model.UserSearchResult = model.UserSearchResult;

            ViewBag.UserList = model.UserSearchResult;

            return View(model);
        }

        [HttpPost]
        public ActionResult SearchUserList(UserSearchResultViewModel model)
        {
            model.UserSearchResult = new List<login>();

            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null)
            {
                model = DataContext.GetUserList(identity, model);
            }

            return PartialView("_UserListSearchResult", model);
        }

        [HttpGet]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "U"
            }
        )]
        public ActionResult Add()
        {
            var model = new UserViewModel()
            {
                IsAdmin = "N",
                A_Level = "",
                Administrator = "N",
                CanDeleteCompManager = "",
                CanDeleteContract = "",
                CanQuickSearch = "",
                CanUploadContractDoc = "",
                CanViewPDF = "",
                CanDeleteOIG = "",
                CanEditContractInfo = "",
                CanStoplessCalculator = "",
                IsEmpCompManager = "",
                ContractTypes = "",
                Departments = "",
                Facilities = ""
            };

            var identity = (ClaimsIdentity)User.Identity;

            if (identity != null)
            {
                ViewBag.UserTypes = DataContext.GetUserTypes(identity);
                ViewBag.Facilities = DataContext.GetFacilities(identity);
                ViewBag.ContractSetup = DataContext.GetContractSetup(identity);
                ViewBag.Departments = DataContext.GetMemberDepartments(identity);
                ViewBag.ContractTypes = DataContext.GetMemberContractTypes(identity);
            }

            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "U"
            }
        )]
        public ActionResult Add(UserViewModel model)
        {
            model.A_Level = model.A_Level != null ? model.A_Level : string.Empty;
            model.Corp = model.Corp != null ? model.Corp : string.Empty;
            model.Administrator = model.Administrator ?? "N";
            model.CanDeleteOIG = model.CanDeleteOIG ?? "N";
            model.IsEmpCompManager = model.IsEmpCompManager ?? "N";
            model.CanEditContractInfo = model.CanEditContractInfo ?? "";
            model.CanUploadContractDoc = model.CanUploadContractDoc ?? "";
            model.CanDeleteContract = model.CanDeleteContract ?? "";
            model.CanDeleteCompManager = model.CanDeleteCompManager ?? "";
            model.CanViewPDF = model.CanViewPDF ?? "";
            model.CanStoplessCalculator = model.CanStoplessCalculator ?? "";
            model.CanQuickSearch = model.CanQuickSearch ?? "";
            model.IsAdmin = model.IsAdmin ?? "";
            
            var identity = (ClaimsIdentity)User.Identity;

            //Add data to populate dropdown list
            ViewBag.UserTypes = DataContext.GetUserTypes(identity);
            ViewBag.Facilities = DataContext.GetFacilities(identity);
            ViewBag.ContractSetup = DataContext.GetContractSetup(identity);
            ViewBag.Departments = DataContext.GetMemberDepartments(identity);
            ViewBag.ContractTypes = DataContext.GetMemberContractTypes(identity);

            if (identity == null)
            {
                //Show error message
            }
            if (identity != null)
            {
                if (ModelState.IsValid)
                {
                    //Add or save data
                    var login = DataContext.PopulateLoginUser(identity, model, UserManager);
                    if (login != null)
                    {
                        return RedirectToAction("Edit", new { id = login.ID });
                    }
                    else
                    {
                        return RedirectToAction("Index", "Error");
                    }
                }
            }

            return View(model);
        }

        [HttpGet]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "U"
            }
        )]
        public ActionResult Edit(int id)
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //Show error message
            }
            var model = DataContext.GetLoginUserById(identity, id);
            ViewBag.UserTypes = DataContext.GetUserTypes(identity);
            ViewBag.Facilities = DataContext.GetFacilities(identity);
            ViewBag.ContractSetup = DataContext.GetContractSetup(identity);            
            ViewBag.Departments = DataContext.GetMemberDepartments(identity);            
            ViewBag.ContractTypes = DataContext.GetMemberContractTypes(identity);
            ViewBag.LoginDepts = DataContext.GetLoginDeptByLoginId(identity,id);
            ViewBag.LoginFacs = DataContext.GetLoginFacByLoginId(identity,id);
            ViewBag.LoginContractTypes = DataContext.GetContractTypeByLoginId(identity,id);

            if (identity != null)
            {
                if (model != null)
                {
                    return View(model);
                }
            }

            return RedirectToAction("Index", "Error");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "U"
            }
        )]
        public ActionResult Edit(UserViewModel model)
        {
            model.A_Level = model.A_Level != null ? model.A_Level : string.Empty;
            model.Corp = model.Corp != null ? model.Corp : string.Empty;
            model.Administrator = model.Administrator ?? "N";
            model.CanDeleteOIG = model.CanDeleteOIG ?? "N";
            model.IsEmpCompManager = model.IsEmpCompManager ?? "N";
            model.CanEditContractInfo = model.CanEditContractInfo ?? "";
            model.CanUploadContractDoc = model.CanUploadContractDoc ?? "";
            model.CanDeleteContract = model.CanDeleteContract ?? "";
            model.CanDeleteCompManager = model.CanDeleteCompManager ?? "";
            model.CanViewPDF = model.CanViewPDF ?? "";
            model.CanStoplessCalculator = model.CanStoplessCalculator ?? "";
            model.CanQuickSearch = model.CanQuickSearch ?? "";
            model.IsAdmin = model.IsAdmin ?? "";

            var identity = (ClaimsIdentity)User.Identity;

            //Add data to populate dropdown list
            ViewBag.UserTypes = DataContext.GetUserTypes(identity);
            ViewBag.Facilities = DataContext.GetFacilities(identity);
            ViewBag.ContractSetup = DataContext.GetContractSetup(identity);
            ViewBag.Departments = DataContext.GetMemberDepartments(identity);
            ViewBag.ContractTypes = DataContext.GetMemberContractTypes(identity);
            ViewBag.LoginDepts = DataContext.GetLoginDeptByLoginId(identity,model.ID);
            ViewBag.LoginFacs = DataContext.GetLoginFacByLoginId(identity,model.ID);
            ViewBag.LoginContractTypes = DataContext.GetContractTypeByLoginId(identity,model.ID);

            if (identity == null)
            {
                //Show error message
            }
            if (identity != null)
            {
                if (ModelState.IsValid)
                {
                    //Add or save data
                    var login = DataContext.PopulateLoginUser(identity, model, UserManager);
                    if (login != null)
                    {
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        return RedirectToAction("Index", "Error");
                    }
                }
            }

            return View(model);
        }

        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "X"
            }
        )]
        public ActionResult ShowDeleteUserDialog(int id)
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            return PartialView("_DeleteUserPopup", id);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "X"
            }
        )]
        public ActionResult DeleteUser(int id)
        {
            var identity = (ClaimsIdentity)User.Identity;
            var isDeletedSuccess = false;
            if (identity == null)
            {
                //TODO: throw exception or show error page
            }

            //Delete the user
            var deletedUser = DataContext.DeleteUser(identity, id);
            isDeletedSuccess = deletedUser != null;

            if (isDeletedSuccess)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return RedirectToAction("Index", "Error");
            }
        }

        #region Send mail for login info, will be used later

        //[HttpGet]
        ////[ValidateAntiForgeryToken]
        //[OverrideAuthorization()]
        //[ClaimsAuthorize(
        //    Claims = new[]
        //    {
        //        BoClaimTypes.UserRights, "U"
        //    }
        //)]
        //public JsonResult SendMail(List<int> userList)
        //{
        //    var identity = (ClaimsIdentity)User.Identity;

        //    if(identity == null)
        //    {
        //        //throw exception or get to error page
        //    }

        //    var contactEmail = ConfigurationManager.AppSettings["adminEmail"];
        //    var mailSubject = "Login Info for binderone.com";
        //    var lineBreak = "<br/>";
        //    var mailContent = new StringBuilder();
        //    var users = DataContext.GetSelectedUsers(identity, userList);

        //    if (users != null && users.Count > 0)
        //    {
        //        foreach (var user in users)
        //        {
        //            mailContent.Append(lineBreak);
        //            mailContent.AppendFormat("Exclusively for : {0}", user.Name);

        //            mailContent.Append(lineBreak);
        //            mailContent.Append(lineBreak);
        //            mailContent.Append("Login Info for http://www.binderone.com");

        //            mailContent.Append(lineBreak);
        //            mailContent.Append(lineBreak);
        //            mailContent.AppendFormat("Login: {0}", user.login1);

        //            mailContent.Append(lineBreak);
        //            mailContent.AppendFormat("Password: {0}", user.password);

        //            mailContent.Append(lineBreak);
        //            mailContent.Append(lineBreak);
        //            mailContent.AppendFormat("Regards,");

        //            mailContent.Append(lineBreak);
        //            mailContent.AppendFormat("BinderOne");

        //            mailContent.Append(lineBreak);
        //            mailContent.Append(lineBreak);
        //            mailContent.AppendFormat("Note: This E-mail was automatically generated. Please do not respond.");

        //            //Send mail
        //            EmailService.SendMail(contactEmail, mailSubject, mailContent.ToString());
        //            mailContent.Clear();
        //        }
        //    }

        //    return Json(mailContent.ToString(), JsonRequestBehavior.AllowGet);
        //}

        //[HttpGet]
        //[OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        //[OverrideAuthorization()]
        //[ClaimsAuthorize(
        //    Claims = new[]
        //    {
        //        BoClaimTypes.UserRights, "U"
        //    }
        //)]
        //public ActionResult ViewSuccessDialog()
        //{
        //    return PartialView("_LoginMailSentSuccessDialog");
        //}

        #endregion Send mail for login info, will be used later
    }
}