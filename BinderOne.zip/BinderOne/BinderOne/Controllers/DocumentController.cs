﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Controllers
{
    using Models.Document;
    using Models.Document.Interfaces;
    using Security;
    using System.Security.Claims;
    using System.Web.Mvc;
    using BoClaimTypes = BinderOne.Common.Security.ClaimTypes;
    using SysClaimTypes = System.Security.Claims.ClaimTypes;

    [ClaimsAuthorize(
        Claims = new[]
        {
            SysClaimTypes.Sid, "All",
            SysClaimTypes.PrimaryGroupSid, "All",
            BoClaimTypes.CorpProductType, "All"
        }
    )]
    public class DocumentController : SecuredController
    {
        private IDocumentRepository _documentRepo;
        private ITokenizer _tokenizer;

        public DocumentController()
            : this(new FileDocumentRepository(), new RsaTokenizer())
        {
            /* TODO: inject in IoC container later instead of new instance directly here */
        }

        public DocumentController(IDocumentRepository documentRepo, ITokenizer tokenizer)
        {
            _documentRepo = documentRepo;
            _tokenizer = tokenizer;
        }

        [HttpGet]
        [OverrideAuthorization()]
        [ClaimsAuthorize(
            Claims = new[]
            {
                BoClaimTypes.UserRights, "V"
            }
        )]
        public ActionResult ViewDocument()
        {
            var identity = (ClaimsIdentity)User.Identity;

            if (identity == null)
            {
                /* TODO: throw exception or show error page here */
            }

            var token = string.IsNullOrEmpty(Request.QueryString["token"]) ? string.Empty : Request.QueryString["token"];
            var documentInfo = _tokenizer.Decrypt(token);

            if (documentInfo == null)
            {
                return RedirectToAction("Http404", "Error");
            }

            var docInfoStream = _documentRepo.GetDocument(documentInfo, identity);

            if (docInfoStream == null)
            {
                return RedirectToAction("Http404", "Error");
            }

            return File(docInfoStream, documentInfo.ContentType, documentInfo.FileName);
        }
    }
}