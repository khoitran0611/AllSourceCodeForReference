﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Controllers
{
    using BinderOne.Models;
    using Security;
    using System.Configuration;
    using System.Security.Claims;
    using System.Text;
    using System.Web.Mvc;
    using BoClaimTypes = BinderOne.Common.Security.ClaimTypes;
    using BoClaimValues = BinderOne.Common.Security.ClaimValues;
    using SysClaimTypes = System.Security.Claims.ClaimTypes;

    [AllowAnonymous]
    public class HomeController : SecuredController
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult WhitePaper()
        {
            return View();
        }

        public ActionResult Solution()
        {
            return View();
        }

        public ActionResult ContractManager()
        {
            return View();
        }

        public ActionResult ManagedCareContractMatrix()
        {
            return View();
        }

        public ActionResult EmployeeManager()
        {
            return View();
        }

        public ActionResult AprDrgPricer()
        {
            return View();
        }

        public ActionResult ManagedCareConsulting()
        {
            return View();
        }

        public ActionResult ContactUs()
        {
            return View();
        }

        public ActionResult Demo()
        {
            return View();
        }

        [ClaimsAuthorize(
            Claims = new[]
            {
                SysClaimTypes.Sid, "All",
                SysClaimTypes.PrimaryGroupSid, "All",
                BoClaimTypes.CorpProductType, "All"
            }
        )]
        public ActionResult LandingPage()
        {
            ClaimsIdentity identity = (ClaimsIdentity)User.Identity;
            string careType = SecurityPermissionHelper.GetUserCareType(identity);

            switch (careType)
            {
                case BoClaimValues.All:
                case BoClaimValues.CareType_Mc:
                    return RedirectToAction("Index", "ManagedCare");

                case BoClaimValues.CareType_Nmc:
                    return RedirectToAction("Index", "Contract");

                default:
                    return RedirectToAction("Index", "Home");
            }
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SendMail(ContactUsModel model)
        {
            var contactEmail = ConfigurationManager.AppSettings["ContactEmail"];
            var mailSubject = "Binderone Contact Us";
            var lineBreak = "<br/>";
            var mailContent = new StringBuilder();

            mailContent.Append(lineBreak);
            mailContent.AppendFormat("Name: {0}", model.FullName);

            mailContent.Append(lineBreak);
            mailContent.AppendFormat("Company: {0}", model.Company);

            mailContent.Append(lineBreak);
            mailContent.AppendFormat("E-Mail: {0}", model.Email);

            mailContent.Append(lineBreak);
            mailContent.AppendFormat("Phone: {0}", model.Phone);

            mailContent.Append(lineBreak);
            mailContent.AppendFormat("Fax: {0}", model.Fax);

            mailContent.Append(lineBreak);
            mailContent.AppendFormat("Call back: {0}", string.Compare(model.IsRequestCallBack, "true", true) == 0 ? "Yes" : "No");

            mailContent.Append(lineBreak);
            mailContent.AppendFormat("Message: {0}", model.Message);

            mailContent.Append(lineBreak);
            mailContent.Append(lineBreak);
            mailContent.AppendFormat("Regards,");

            mailContent.Append(lineBreak);
            mailContent.AppendFormat("BinderOne");

            //Send mail
            EmailService.SendMail(contactEmail, mailSubject, mailContent.ToString());

            return Content(mailContent.ToString());
        }

        [HttpGet]
        [OutputCache(NoStore = true, Duration = 0, VaryByParam = "*")]
        public ActionResult ViewSuccessDialog()
        {
            return PartialView("_MailSentSuccessDialog");
        }
    }
}