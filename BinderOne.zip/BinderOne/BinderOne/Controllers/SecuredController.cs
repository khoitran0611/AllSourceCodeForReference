﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne.Controllers
{
    using BinderOne.Security;
    using System.Web.Mvc;

    [ClaimsAuthorize]
    public abstract class SecuredController : Controller
    {
    }
}