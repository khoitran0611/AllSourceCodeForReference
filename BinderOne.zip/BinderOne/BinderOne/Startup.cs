﻿///
///<Copyright year="2015"><Company>BICON, INC.</Company><Website>https://bicon.mobi</Website></Copyright>
///

namespace BinderOne
{
    using Owin;

    public sealed partial class Startup
    {
        public static void Configuration(IAppBuilder app)
        {
            ConfigureAuthentication(app);
        }
    }
}